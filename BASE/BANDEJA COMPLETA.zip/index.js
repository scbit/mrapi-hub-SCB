require("dotenv").config();

const functions = require("@google-cloud/functions-framework");
const express = require("express");
const cors = require("cors");
const admin = require("firebase-admin");
const twilio = require("twilio");
const Busboy = require("busboy");
const axios = require("axios");
const { Storage } = require("@google-cloud/storage");
const { SessionsClient } = require("@google-cloud/dialogflow-cx");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const os = require("os");
const path = require("path");
const fs = require("fs/promises");
const { spawn } = require("child_process");
const ffmpegPath = require("ffmpeg-static");

const storage = new Storage();

const BASIC_USER = process.env.BASIC_USER || "fpozzan@sentirecustomsbroker.com";
const BASIC_PASS = process.env.BASIC_PASS || "Facu1010!";

const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID || "";
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN || "";
const TWILIO_WHATSAPP_FROM = process.env.TWILIO_WHATSAPP_FROM || "";
const FILES_BUCKET = process.env.FILES_BUCKET || "scb-whatsapp-media";
const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL || "";

const DF_PROJECT_ID = process.env.DF_PROJECT_ID || "ia-sentire-customs-broker";
const DF_LOCATION = process.env.DF_LOCATION || "global";
const DF_AGENT_ID = process.env.DF_AGENT_ID || "5b007401-59cf-4652-a10d-70abf175c585";
const DF_LANGUAGE_CODE = process.env.DF_LANGUAGE_CODE || "es";

const META_ACCESS_TOKEN = process.env.META_ACCESS_TOKEN || "";
const META_GRAPH_VERSION = process.env.META_GRAPH_VERSION || "v20.0";

const twilioClient =
  TWILIO_ACCOUNT_SID && TWILIO_AUTH_TOKEN
    ? twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    : null;

const dialogflowClient = new SessionsClient(
  DF_LOCATION && DF_LOCATION !== "global"
    ? { apiEndpoint: `${DF_LOCATION}-dialogflow.googleapis.com` }
    : {}
);

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.applicationDefault(),
  });
}

const db = getFirestore(undefined, "bsscb");

// Límites de lectura configurables para evitar picos de Firestore.
const CONVERSATIONS_PAGE_SIZE = Math.max(25, Math.min(Number(process.env.CONVERSATIONS_PAGE_SIZE || 100), 300));
const MESSAGES_PER_CONVERSATION_LIMIT = Math.max(100, Math.min(Number(process.env.MESSAGES_PER_CONVERSATION_LIMIT || 500), 1500));
const MAX_RELATED_CONVERSATION_IDS = 20;
const CONVERSATION_LOOKUP_COLLECTION = "conversation_lookup";

const app = express();

app.use(cors());

app.use(express.json({ limit: "15mb" }));
app.use(express.urlencoded({ extended: true }));



function unauthorized(res) {
  res.set("WWW-Authenticate", 'Basic realm="SCB Inbox"');
  return res.status(401).send("Unauthorized");
}

function basicAuth(req, res, next) {
  const header = req.headers.authorization || "";
  if (!header.startsWith("Basic ")) return unauthorized(res);

  const decoded = Buffer.from(header.slice(6), "base64").toString("utf8");
  const idx = decoded.indexOf(":");
  const user = idx >= 0 ? decoded.slice(0, idx) : "";
  const pass = idx >= 0 ? decoded.slice(idx + 1) : "";

  if (user === BASIC_USER && pass === BASIC_PASS) return next();
  return unauthorized(res);
}

function cleanWhatsappNumber(value) {
  return String(value || "").replace(/^whatsapp:/i, "").trim();
}

function ensureWhatsappPrefix(value) {
  const v = String(value || "").trim();
  if (!v) return "";
  return v.startsWith("whatsapp:") ? v : `whatsapp:${v}`;
}

function normalizeOutboundLineForTwilio(value) {
  const clean = cleanWhatsappNumber(value);
  if (!clean) return "";
  return clean.startsWith("+") ? clean : `+${clean}`;
}

function messagePreview(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 160);
}

function buildLastPreview(text, numMedia) {
  const clean = messagePreview(text);
  if (clean) return clean;
  if (Number(numMedia || 0) > 0) return `Adjunto (${numMedia})`;
  return "";
}

function normalizeMode(mode) {
  return String(mode || "BOT").toUpperCase() === "HUMAN" ? "HUMAN" : "BOT";
}

function buildConversationId(from, to) {
  const a = cleanWhatsappNumber(from);
  const b = cleanWhatsappNumber(to);
  if (!a && !b) return "";
  if (!b) return a;
  return `${a}__${b}`;
}

function normalizeConversationNumber(value) {
  return String(cleanWhatsappNumber(value) || "")
    .replace(/[^\d+]/g, "")
    .replace(/^\+/, "")
    .trim();
}

function buildCanonicalConversationId(from, to) {
  const a = normalizeConversationNumber(from);
  const b = normalizeConversationNumber(to);
  if (!a && !b) return "";
  if (!b) return a;
  return `${a}__${b}`;
}

function uniqueStrings(values = []) {
  const out = [];
  const seen = new Set();
  for (const value of Array.isArray(values) ? values : []) {
    const clean = String(value || "").trim();
    if (!clean || seen.has(clean)) continue;
    seen.add(clean);
    out.push(clean);
  }
  return out;
}

function buildConversationIdCandidates(from, to) {
  const aRaw = cleanWhatsappNumber(from);
  const bRaw = cleanWhatsappNumber(to);
  const aNorm = normalizeConversationNumber(from);
  const bNorm = normalizeConversationNumber(to);

  return uniqueStrings([
    buildConversationId(from, to),
    buildCanonicalConversationId(from, to),
    aNorm && bRaw ? `${aNorm}__${bRaw}` : "",
    aRaw && bNorm ? `${aRaw}__${bNorm}` : "",
    aRaw && bRaw && !aRaw.startsWith("+") && !bRaw.startsWith("+") ? `+${aRaw}__+${bRaw}` : "",
    aNorm,
    aRaw
  ]);
}

function lineDisplayLabel(value) {
  const clean = cleanWhatsappNumber(value);
  return clean || String(value || "").trim();
}

function conversationLookupRefByKey(key) {
  const cleanKey = String(key || "").trim();
  return cleanKey ? db.collection(CONVERSATION_LOOKUP_COLLECTION).doc(cleanKey) : null;
}

async function readConversationLookup(key) {
  const ref = conversationLookupRefByKey(key);
  if (!ref) return { key: "", primaryConversationId: "", conversationIds: [] };
  const snap = await ref.get();
  if (!snap.exists) return { key, primaryConversationId: "", conversationIds: [] };
  const data = snap.data() || {};
  return {
    key,
    primaryConversationId: String(data.primaryConversationId || "").trim(),
    conversationIds: uniqueStrings(data.conversationIds || []).slice(0, MAX_RELATED_CONVERSATION_IDS),
  };
}

async function saveConversationLookup(key, conversationIds = [], primaryConversationId = "") {
  const ref = conversationLookupRefByKey(key);
  const ids = uniqueStrings([primaryConversationId, ...conversationIds]).slice(0, MAX_RELATED_CONVERSATION_IDS);
  if (!ref || !ids.length) return;
  const patch = {
    canonicalConversationKey: key,
    conversationIds: FieldValue.arrayUnion(...ids),
    updatedAt: FieldValue.serverTimestamp(),
  };
  if (primaryConversationId) patch.primaryConversationId = primaryConversationId;
  await ref.set(patch, { merge: true });
}

function buildWaFromQueryVariants(value) {
  const normalized = normalizeConversationNumber(value);
  const clean = cleanWhatsappNumber(value);
  return uniqueStrings([
    String(value || "").trim(),
    ensureWhatsappPrefix(value),
    clean,
    clean ? ensureWhatsappPrefix(clean) : "",
    normalized,
    normalized ? `+${normalized}` : "",
    normalized ? `whatsapp:+${normalized}` : "",
  ]).slice(0, 10);
}

async function findConversationByStoredFields(from, to) {
  const variants = buildWaFromQueryVariants(from);
  const currentLine = normalizeConversationNumber(to || "");
  if (!variants.length) return null;

  const snap = await db.collection("conversations").where("waFrom", "in", variants).limit(20).get();
  for (const doc of snap.docs) {
    const data = doc.data() || {};
    const existingLine = normalizeConversationNumber(data.inboundTo || data.lineId || "");
    if (!existingLine || !currentLine || existingLine === currentLine) {
      return { id: doc.id, ref: doc.ref, snap: doc, data };
    }
  }
  return null;
}

async function resolveConversationRef(from, to) {
  const candidateIds = buildConversationIdCandidates(from, to);
  const currentLine = normalizeConversationNumber(to || "");
  const canonicalKey = getConversationCanonicalKey({ waFrom: from, inboundTo: to }, "") || buildCanonicalConversationId(from, to);

  const lookup = await readConversationLookup(canonicalKey);
  const lookupIds = uniqueStrings([lookup.primaryConversationId, ...lookup.conversationIds]);

  for (const candidateId of uniqueStrings([...lookupIds, ...candidateIds])) {
    const ref = db.collection("conversations").doc(candidateId);
    const snap = await ref.get();
    if (!snap.exists) continue;

    const data = snap.data() || {};
    const existingLine = normalizeConversationNumber(data.inboundTo || data.lineId || "");
    if (!existingLine || !currentLine || existingLine === currentLine) {
      await saveConversationLookup(canonicalKey, [...lookupIds, candidateId], candidateId);
      return {
        ref,
        id: candidateId,
        snap,
        isLegacy: !String(candidateId || "").includes("__"),
        reusedExisting: true,
        candidateIds: uniqueStrings([...lookupIds, ...candidateIds]),
      };
    }
  }

  // Compatibilidad con conversaciones viejas: consulta solo documentos cuyo
  // waFrom coincide. Nunca recorre toda la colección.
  const storedMatch = await findConversationByStoredFields(from, to);
  if (storedMatch) {
    await saveConversationLookup(canonicalKey, [storedMatch.id], storedMatch.id);
    return {
      ref: storedMatch.ref,
      id: storedMatch.id,
      snap: storedMatch.snap,
      isLegacy: !String(storedMatch.id || "").includes("__"),
      reusedExisting: true,
      candidateIds: uniqueStrings([...candidateIds, storedMatch.id]),
    };
  }

  const canonicalId = buildCanonicalConversationId(from, to) || buildConversationId(from, to);
  const ref = db.collection("conversations").doc(canonicalId);
  const snap = await ref.get();
  await saveConversationLookup(canonicalKey, [canonicalId], canonicalId);

  return {
    ref,
    id: canonicalId,
    snap,
    isLegacy: !String(canonicalId || "").includes("__"),
    reusedExisting: false,
    candidateIds: uniqueStrings([...candidateIds, canonicalId]),
  };
}

function getConversationPairFromId(id) {
  const raw = String(id || "").trim();
  if (!raw) return { customer: "", line: "" };
  const parts = raw.split("__");
  if (parts.length >= 2) {
    return {
      customer: normalizeConversationNumber(parts[0]),
      line: normalizeConversationNumber(parts.slice(1).join("__")),
    };
  }
  return { customer: normalizeConversationNumber(raw), line: "" };
}

function getConversationCanonicalKey(convo = {}, id = "") {
  const fromData = normalizeConversationNumber(convo.waFrom || "");
  const lineData = normalizeConversationNumber(convo.inboundTo || convo.lineId || "");
  const fromId = getConversationPairFromId(id);
  const customer = fromData || fromId.customer;
  const line = lineData || fromId.line;
  return line ? `${customer}__${line}` : customer;
}

function docTimestampMillis(value) {
  try {
    if (!value) return 0;
    if (typeof value === "number") return value;
    if (typeof value === "string") {
      const t = new Date(value).getTime();
      return Number.isFinite(t) ? t : 0;
    }
    if (typeof value.toMillis === "function") return value.toMillis();
    if (value._seconds) return Number(value._seconds) * 1000;
    if (value.seconds) return Number(value.seconds) * 1000;
  } catch {}
  return 0;
}

function getConversationCompletenessScore(convo = {}) {
  let score = 0;
  if (String(convo.contactName || "").trim()) score += 10;
  if (String(convo.stage || "").trim() && String(convo.stage || "").trim().toLowerCase() !== "nuevo") score += 20;
  if (String(convo.sourceChannel || "").trim() && String(convo.sourceChannel || "").trim() !== "outbound-template") score += 20;
  if (convo.leadAd && typeof convo.leadAd === "object") score += 15;
  if (String(convo.referralAdId || "").trim()) score += 10;
  if (String(convo.dealId || "").trim()) score += 25;
  if (String(convo.contactId || "").trim()) score += 20;
  if (convo.hasUnread) score += 5;
  score += Math.min(10, Number(convo.unreadCount || 0));
  return score;
}

function mergeConversationForList(existing, incoming) {
  if (!existing) return incoming;
  const existingScore = getConversationCompletenessScore(existing);
  const incomingScore = getConversationCompletenessScore(incoming);
  const display = incomingScore > existingScore ? incoming : existing;
  const latest = docTimestampMillis(incoming.lastMessageAt || incoming.updatedAt || incoming.lastCustomerMessageAt) >=
    docTimestampMillis(existing.lastMessageAt || existing.updatedAt || existing.lastCustomerMessageAt)
    ? incoming
    : existing;

  return {
    ...display,
    id: latest.id || display.id || existing.id || incoming.id,
    waFrom: display.waFrom || latest.waFrom || existing.waFrom || incoming.waFrom || "",
    inboundTo: display.inboundTo || latest.inboundTo || existing.inboundTo || incoming.inboundTo || "",
    lineId: display.lineId || latest.lineId || existing.lineId || incoming.lineId || "",
    contactName: display.contactName || latest.contactName || existing.contactName || incoming.contactName || "",
    stage: display.stage || latest.stage || existing.stage || incoming.stage || "nuevo",
    sourceChannel: display.sourceChannel || latest.sourceChannel || existing.sourceChannel || incoming.sourceChannel || "",
    leadAd: display.leadAd || latest.leadAd || existing.leadAd || incoming.leadAd || null,
    leadPlatform: display.leadPlatform || latest.leadPlatform || existing.leadPlatform || incoming.leadPlatform || "",
    referralCtwaClid: display.referralCtwaClid || latest.referralCtwaClid || existing.referralCtwaClid || incoming.referralCtwaClid || "",
    referralAdId: display.referralAdId || latest.referralAdId || existing.referralAdId || incoming.referralAdId || "",
    referralHeadline: display.referralHeadline || latest.referralHeadline || existing.referralHeadline || incoming.referralHeadline || "",
    referralBody: display.referralBody || latest.referralBody || existing.referralBody || incoming.referralBody || "",
    referralImageUrl: display.referralImageUrl || latest.referralImageUrl || existing.referralImageUrl || incoming.referralImageUrl || "",
    dealId: display.dealId || latest.dealId || existing.dealId || incoming.dealId || "",
    contactId: display.contactId || latest.contactId || existing.contactId || incoming.contactId || "",
    mode: latest.mode || display.mode || existing.mode || incoming.mode || "BOT",
    lastMessageAt: latest.lastMessageAt || display.lastMessageAt || existing.lastMessageAt || incoming.lastMessageAt || null,
    lastMessagePreview: latest.lastMessagePreview || display.lastMessagePreview || existing.lastMessagePreview || incoming.lastMessagePreview || "",
    updatedAt: latest.updatedAt || display.updatedAt || existing.updatedAt || incoming.updatedAt || null,
    lastDeliveryStatus: latest.lastDeliveryStatus || display.lastDeliveryStatus || existing.lastDeliveryStatus || incoming.lastDeliveryStatus || "",
    lastMessageDirection: latest.lastMessageDirection || display.lastMessageDirection || existing.lastMessageDirection || incoming.lastMessageDirection || "",
    lastHumanMessageAt: latest.lastHumanMessageAt || display.lastHumanMessageAt || existing.lastHumanMessageAt || incoming.lastHumanMessageAt || null,
    hasUnread: !!(existing.hasUnread || incoming.hasUnread),
    unreadCount: Math.max(Number(existing.unreadCount || 0), Number(incoming.unreadCount || 0)),
    duplicateConversationIds: uniqueStrings([...(existing.duplicateConversationIds || []), ...(incoming.duplicateConversationIds || []), existing.id, incoming.id]),
    canonicalConversationKey: existing.canonicalConversationKey || incoming.canonicalConversationKey || getConversationCanonicalKey(display, display.id),
  };
}

async function getDuplicateConversationDocsByPair(from, to) {
  const targetKey = getConversationCanonicalKey({ waFrom: from, inboundTo: to }, "");
  const candidateIds = buildConversationIdCandidates(from, to);
  const lookup = await readConversationLookup(targetKey);
  const ids = uniqueStrings([lookup.primaryConversationId, ...lookup.conversationIds, ...candidateIds])
    .slice(0, MAX_RELATED_CONVERSATION_IDS);
  const out = [];

  for (const id of ids) {
    const ref = db.collection("conversations").doc(id);
    const snap = await ref.get();
    if (!snap.exists) continue;
    out.push({ id, ref, snap, data: snap.data() || {} });
  }

  if (!out.length) {
    const storedMatch = await findConversationByStoredFields(from, to);
    if (storedMatch) out.push(storedMatch);
  }

  if (targetKey && out.length) {
    await saveConversationLookup(targetKey, out.map((item) => item.id), out[0].id);
  }
  return out;
}

function getSessionId(conversationId) {
  return (
    cleanWhatsappNumber(conversationId)
      .replace(/[^a-zA-Z0-9_-]/g, "_")
      .slice(0, 120) || `scb_${Date.now()}`
  );
}

function extractBotText(response) {
  const messages = response?.queryResult?.responseMessages || [];
  const parts = [];

  for (const msg of messages) {
    if (msg.text && Array.isArray(msg.text.text)) {
      for (const t of msg.text.text) {
        const clean = String(t || "").trim();
        if (clean) parts.push(clean);
      }
    }
  }

  return parts.join("\n\n").trim();
}

function normalizeMediaArray(raw) {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((item) => {
      if (!item) return null;
      return {
        url: String(item.url || "").trim(),
        contentType: String(item.contentType || "").trim(),
        filename: String(item.filename || "").trim(),
        source: String(item.source || "").trim(),
      };
    })
    .filter((x) => x && x.url);
}

function extFromMime(mime, originalName = "") {
  const lower = String(mime || "").toLowerCase();
  const file = String(originalName || "").toLowerCase();
  if (file.includes(".")) return file.split(".").pop();
  if (lower.includes("jpeg")) return "jpg";
  if (lower.includes("png")) return "png";
  if (lower.includes("gif")) return "gif";
  if (lower.includes("webp")) return "webp";
  if (lower.includes("pdf")) return "pdf";
  if (lower.includes("mp4")) return "mp4";
  if (lower.includes("mpeg")) return "mp3";
  if (lower.includes("ogg")) return "ogg";
  if (lower.includes("wav")) return "wav";
  return "bin";
}

function safeFileName(name) {
  return String(name || "archivo")
    .replace(/[^a-zA-Z0-9._-]/g, "_")
    .slice(-120);
}

function isAudioMime(mime) {
  return String(mime || "").toLowerCase().startsWith("audio/");
}

function fileBaseName(name) {
  const safe = safeFileName(name || "audio");
  const parts = safe.split(".");
  if (parts.length <= 1) return safe;
  parts.pop();
  return parts.join(".") || "audio";
}

async function runFfmpeg(args) {
  return await new Promise((resolve, reject) => {
    if (!ffmpegPath) return reject(new Error("ffmpeg no está disponible en el servidor"));
    const child = spawn(ffmpegPath, args, { stdio: ["ignore", "ignore", "pipe"] });
    let stderr = "";
    child.stderr.on("data", (chunk) => { stderr += String(chunk || ""); });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) return resolve();
      reject(new Error(`ffmpeg falló (${code}): ${stderr.slice(-800)}`));
    });
  });
}

async function convertAudioToWhatsappMp3({ buffer, mimeType, originalName }) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error("Audio inválido para convertir");
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "scb-audio-"));
  const inputExt = extFromMime(mimeType, originalName) || "bin";
  const inputPath = path.join(tempDir, `input.${inputExt}`);
  const outputPath = path.join(tempDir, "output.mp3");

  try {
    await fs.writeFile(inputPath, buffer);
    await runFfmpeg([
      "-y",
      "-i", inputPath,
      "-vn",
      "-codec:a", "libmp3lame",
      "-q:a", "4",
      "-ar", "44100",
      outputPath,
    ]);
    const convertedBuffer = await fs.readFile(outputPath);
    return {
      buffer: convertedBuffer,
      mimetype: "audio/mpeg",
      originalname: `${fileBaseName(originalName || "audio")}.mp3`,
      size: convertedBuffer.length,
    };
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true }).catch(() => {});
  }
}


function getWhatsappApprovalStatus(item) {
  const status = String(
    item?.approval_requests?.status || item?.approvals?.whatsapp?.status || ""
  ).toLowerCase();

  if (status.includes("approved")) return "approved";
  if (status.includes("pending")) return "pending";
  if (status.includes("rejected")) return "rejected";
  if (status.includes("unsubmitted")) return "unsubmitted";

  const flat = JSON.stringify(item || {}).toLowerCase();
  if (flat.includes("approved")) return "approved";
  if (flat.includes("pending")) return "pending";
  if (flat.includes("rejected")) return "rejected";
  if (flat.includes("unsubmitted")) return "unsubmitted";

  return "unknown";
}

function getTemplateCategory(item) {
  const category = String(item?.approval_requests?.category || item?.category || "").toLowerCase();
  if (category.includes("utility")) return "utility";
  if (category.includes("marketing")) return "marketing";
  if (category.includes("authentication")) return "authentication";
  const flat = JSON.stringify(item || {}).toLowerCase();
  if (flat.includes("utility")) return "utility";
  if (flat.includes("marketing")) return "marketing";
  if (flat.includes("authentication")) return "authentication";
  return "text";
}

async function listApprovedTemplates() {
  const response = await axios.get("https://content.twilio.com/v1/ContentAndApprovals", {
    auth: {
      username: TWILIO_ACCOUNT_SID,
      password: TWILIO_AUTH_TOKEN,
    },
    timeout: 20000,
  });

  const contents = response.data?.contents || [];

  return contents
    .map((item) => ({
      sid: item.sid,
      name: item.friendly_name || item.friendlyName || item.sid,
      language: item.language || item.locale || "",
      category: getTemplateCategory(item),
      whatsappStatus: getWhatsappApprovalStatus(item),
    }))
    .filter((t) => t.whatsappStatus === "approved")
    .sort((a, b) => a.name.localeCompare(b.name, "es", { sensitivity: "base" }));
}

async function getTwilioTemplateBySid(contentSid) {
  const cleanSid = String(contentSid || "").trim();
  if (!cleanSid) throw new Error("Falta contentSid");

  const response = await axios.get(`https://content.twilio.com/v1/Content/${encodeURIComponent(cleanSid)}`, {
    auth: {
      username: TWILIO_ACCOUNT_SID,
      password: TWILIO_AUTH_TOKEN,
    },
    timeout: 20000,
  });

  return response.data || {};
}

function getFirstNonEmptyString(values = []) {
  for (const value of Array.isArray(values) ? values : []) {
    const text = String(value || "").trim();
    if (text) return text;
  }
  return "";
}

function getTwilioTemplateTypes(item) {
  const rawTypes = item?.types;
  if (!rawTypes || typeof rawTypes !== "object") return [];
  return Object.entries(rawTypes)
    .filter(([, value]) => value && typeof value === "object")
    .map(([key, value]) => ({ key, value }));
}

function extractButtonsFromTwilioType(typeValue) {
  const buttons = [];
  if (!typeValue || typeof typeValue !== "object") return buttons;

  const rawButtons = [];
  if (Array.isArray(typeValue.actions)) rawButtons.push(...typeValue.actions);
  if (Array.isArray(typeValue.buttons)) rawButtons.push(...typeValue.buttons);
  if (Array.isArray(typeValue.suggestions)) rawButtons.push(...typeValue.suggestions);

  for (const btn of rawButtons) {
    if (!btn || typeof btn !== "object") continue;
    const title = getFirstNonEmptyString([
      btn.title,
      btn.text,
      btn.label,
      btn.body,
      btn.url,
      btn.phone_number,
      btn.phoneNumber,
      btn.value,
    ]);
    if (!title) continue;
    buttons.push({
      type: getFirstNonEmptyString([btn.type, btn.action, btn.kind, "button"]),
      text: title,
    });
  }

  return buttons;
}

function buildTwilioTemplatePreview(item) {
  const types = getTwilioTemplateTypes(item);
  const header = getFirstNonEmptyString(types.map(({ value }) => value?.header));
  const body = getFirstNonEmptyString(types.flatMap(({ value }) => [
    value?.body,
    value?.text,
    value?.content,
    value?.message,
  ]));
  const footer = getFirstNonEmptyString(types.map(({ value }) => value?.footer));

  const buttons = [];
  for (const { value } of types) {
    buttons.push(...extractButtonsFromTwilioType(value));
  }

  const previewLines = [];
  if (header) previewLines.push(header);
  if (body) previewLines.push(body);
  if (footer) previewLines.push(footer);
  if (buttons.length) {
    previewLines.push("Botones: " + buttons.map((btn) => btn.text).join(" | "));
  }

  return {
    sid: item?.sid || "",
    name: item?.friendly_name || item?.friendlyName || item?.sid || "",
    language: item?.language || item?.locale || "",
    category: getTemplateCategory(item),
    whatsappStatus: getWhatsappApprovalStatus(item),
    header,
    body,
    footer,
    buttons,
    previewText: previewLines.join("\n\n").trim(),
    types: types.map(({ key }) => key),
  };
}

function getBodyValueByAliases(body, aliases = []) {
  if (!body || typeof body !== "object") return "";

  const normalizedMap = new Map();
  for (const [key, value] of Object.entries(body)) {
    const normalizedKey = String(key || "")
      .replace(/[^a-zA-Z0-9]/g, "")
      .toLowerCase();
    if (!normalizedMap.has(normalizedKey)) {
      normalizedMap.set(normalizedKey, value);
    }
  }

  for (const alias of aliases) {
    if (Object.prototype.hasOwnProperty.call(body, alias)) {
      const direct = String(body[alias] || "").trim();
      if (direct) return direct;
    }

    const normalizedAlias = String(alias || "")
      .replace(/[^a-zA-Z0-9]/g, "")
      .toLowerCase();

    if (normalizedMap.has(normalizedAlias)) {
      const value = String(normalizedMap.get(normalizedAlias) || "").trim();
      if (value) return value;
    }
  }

  return "";
}

function pickReferralAdId(body) {
  return getBodyValueByAliases(body, [
    "ReferralAdId",
    "ReferralSourceId",
    "referralAdId",
    "referralSourceId",
    "referral_ad_id",
    "ad_id",
  ]);
}

function detectLeadPlatformFromSourceType(value) {
  const source = String(value || "").toLowerCase();
  if (source.includes("instagram") || source.includes("ig")) return "instagram";
  if (source.includes("facebook") || source.includes("fb")) return "facebook";
  if (source.includes("meta")) return "meta";
  return "";
}

function extractReferralPayload(body) {
  const referralCtwaClid = getBodyValueByAliases(body, [
    "ReferralCtwaClid",
    "ReferralCtwaCLID",
    "referralCtwaClid",
    "referral_ctwa_clid",
    "ctwaClid",
  ]);

  const referralAdId = pickReferralAdId(body);
  const referralSourceType = getBodyValueByAliases(body, [
    "ReferralSourceType",
    "referralSourceType",
    "referral_source_type",
    "SourceType",
  ]);
  const referralHeadline = getBodyValueByAliases(body, [
    "ReferralHeadline",
    "referralHeadline",
    "referral_headline",
    "Headline",
    "AdHeadline",
    "adHeadline",
    "title",
  ]);
  const referralBody = getBodyValueByAliases(body, [
    "ReferralBody",
    "referralBody",
    "referral_body",
    "Body",
    "AdBody",
    "adBody",
    "description",
  ]);
  const referralImageUrl = getBodyValueByAliases(body, [
    "ReferralImageUrl",
    "ReferralImageURL",
    "referralImageUrl",
    "referral_image_url",
    "AdImageUrl",
    "AdImageURL",
    "adImageUrl",
    "imageUrl",
    "image_url",
  ]);

  return {
    referralCtwaClid,
    referralAdId,
    referralSourceType,
    referralHeadline,
    referralBody,
    referralImageUrl,
  };
}

function buildLeadAdFallback({ oldLeadAd = null, referralPayload = {}, messageMedia = [] }) {
  const old = oldLeadAd && typeof oldLeadAd === "object" ? oldLeadAd : {};
  const platform =
    detectLeadPlatformFromSourceType(referralPayload.referralSourceType) ||
    String(old.platform || "").trim() ||
    (referralPayload.referralCtwaClid || referralPayload.referralAdId ? "meta" : "");

  const firstImageMedia = Array.isArray(messageMedia)
    ? messageMedia.find((item) => String(item?.contentType || "").toLowerCase().startsWith("image/"))
    : null;

  const imageUrl =
    String(referralPayload.referralImageUrl || "").trim() ||
    String(old.imageUrl || "").trim() ||
    "";

  const title =
    String(referralPayload.referralHeadline || "").trim() ||
    String(old.title || "").trim() ||
    String(old.adName || "").trim() ||
    "";

  const body =
    String(referralPayload.referralBody || "").trim() ||
    String(old.body || "").trim() ||
    "";

  const adId =
    String(referralPayload.referralAdId || "").trim() ||
    String(old.adId || "").trim() ||
    "";

  const fallback = {
    ...old,
    adId,
    imageUrl,
    title,
    body,
    platform,
    adName: String(old.adName || title || "").trim(),
    source: imageUrl ? "meta_referral_or_graph" : (firstImageMedia ? "message_media" : String(old.source || "").trim()),
    lastMergedAt: new Date().toISOString(),
  };

  if (!fallback.imageUrl && old.imageUrl) fallback.imageUrl = String(old.imageUrl || "").trim();

  return fallback;
}

function hasLeadAdContent(leadAd) {
  if (!leadAd || typeof leadAd !== "object") return false;
  return !!(
    String(leadAd.imageUrl || "").trim() ||
    String(leadAd.title || "").trim() ||
    String(leadAd.body || "").trim() ||
    String(leadAd.adName || "").trim() ||
    String(leadAd.campaignName || "").trim() ||
    String(leadAd.adsetName || "").trim() ||
    String(leadAd.adId || "").trim()
  );
}

function getPublicBaseUrl(req) {
  if (PUBLIC_BASE_URL) return PUBLIC_BASE_URL.replace(/\/$/, "");
  const proto = req.headers["x-forwarded-proto"] || req.protocol || "https";
  const host = req.headers["x-forwarded-host"] || req.get("host") || "";
  return `${proto}://${host}`.replace(/\/$/, "");
}

function buildStatusCallbackUrl(req) {
  return `${getPublicBaseUrl(req)}/webhooks/twilio/status`;
}

async function fetchMetaGraph(path, params = {}) {
  if (!META_ACCESS_TOKEN) throw new Error("META_ACCESS_TOKEN no configurado");
  const url = `https://graph.facebook.com/${META_GRAPH_VERSION}/${path}`;
  const response = await axios.get(url, {
    params: {
      access_token: META_ACCESS_TOKEN,
      ...params,
    },
    timeout: 20000,
  });
  return response.data;
}

function detectLeadPlatformFromCreative(ad = {}) {
  const creative = ad.creative || {};
  const oss = creative.object_story_spec || {};
  if (oss.instagram_actor_id || creative.instagram_actor_id) return "instagram";
  if (oss.page_id || creative.page_id) return "facebook";
  return "meta";
}

async function fetchMetaAdDetails(adId) {
  if (!adId || !META_ACCESS_TOKEN) return null;

  const ad = await fetchMetaGraph(adId, {
    fields: "id,name,creative{id,name,image_url,thumbnail_url,object_story_spec,effective_object_story_id,title,body,instagram_actor_id,page_id},campaign{id,name},adset{id,name}",
  });

  const creative = ad.creative || {};
  const objectStorySpec = creative.object_story_spec || {};
  const linkData = objectStorySpec.link_data || {};
  const videoData = objectStorySpec.video_data || {};

  const imageUrl =
    creative.image_url ||
    creative.thumbnail_url ||
    linkData.image_url ||
    videoData.image_url ||
    "";

  const title =
    creative.title ||
    linkData.name ||
    videoData.title ||
    ad.name ||
    "";

  const body =
    creative.body ||
    linkData.message ||
    videoData.message ||
    "";

  const platform = detectLeadPlatformFromCreative(ad);

  return {
    adId: String(ad.id || adId),
    adName: String(ad.name || ""),
    campaignId: String(ad.campaign?.id || ""),
    campaignName: String(ad.campaign?.name || ""),
    adsetId: String(ad.adset?.id || ""),
    adsetName: String(ad.adset?.name || ""),
    creativeId: String(creative.id || ""),
    creativeName: String(creative.name || ""),
    imageUrl: String(imageUrl || ""),
    title: String(title || ""),
    body: String(body || ""),
    pageId: String(objectStorySpec.page_id || creative.page_id || ""),
    instagramActorId: String(objectStorySpec.instagram_actor_id || creative.instagram_actor_id || ""),
    platform,
    fetchedAt: new Date().toISOString(),
  };
}

async function uploadBufferToGCS({ buffer, mimeType, originalName, folder = "uploads" }) {
  const bucket = storage.bucket(FILES_BUCKET);
  const ext = extFromMime(mimeType, originalName);
  const base = safeFileName(originalName || `file.${ext}`);
  const objectName = `${folder}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}_${base}`;
  const file = bucket.file(objectName);

  await file.save(buffer, {
    resumable: false,
    metadata: {
      contentType: mimeType || "application/octet-stream",
      cacheControl: "public, max-age=3600",
    },
  });

  return {
    url: `https://storage.googleapis.com/${FILES_BUCKET}/${objectName}`,
    contentType: mimeType || "application/octet-stream",
    filename: originalName || base,
    source: "gcs",
  };
}

async function detectIntentText({ conversationId, text, languageCode }) {
  const sessionId = getSessionId(conversationId);
  const sessionPath = dialogflowClient.projectLocationAgentSessionPath(
    DF_PROJECT_ID,
    DF_LOCATION,
    DF_AGENT_ID,
    sessionId
  );

  const request = {
    session: sessionPath,
    queryInput: {
      text: { text },
      languageCode: languageCode || DF_LANGUAGE_CODE,
    },
  };

  const [response] = await dialogflowClient.detectIntent(request);
  return {
    text: extractBotText(response),
    raw: response,
  };
}

async function saveMessage(convoRef, docId, payload) {
  await convoRef.collection("messages").doc(docId).set(payload, { merge: true });
}

async function updateMessageDeliveryBySid(messageSid, patch) {
  if (!messageSid) return false;

  const snap = await db
    .collectionGroup("messages")
    .where("messageSid", "==", messageSid)
    .limit(1)
    .get();

  if (snap.empty) {
    console.log("updateMessageDeliveryBySid: no se encontró mensaje", { messageSid });
    return false;
  }

  const doc = snap.docs[0];

  await doc.ref.set(patch, { merge: true });

  const convoRef = doc.ref.parent.parent;
  if (convoRef) {
    await convoRef.set(
      {
        updatedAt: FieldValue.serverTimestamp(),
        lastDeliveryStatus: patch.deliveryStatus || "",
        lastReadAt: patch.readAt || null,
      },
      { merge: true }
    );
  }

  return true;
}






async function sendWhatsappMessage({ from, to, body, mediaUrls = [], statusCallback }) {
  if (!twilioClient) throw new Error("Twilio no configurado");

  const payload = {
    from: ensureWhatsappPrefix(from),
    to: ensureWhatsappPrefix(to),
  };

  const cleanBody = String(body || "").trim();
  const cleanMediaUrls = Array.isArray(mediaUrls)
    ? mediaUrls.map((x) => String(x || "").trim()).filter(Boolean)
    : [];

  if (cleanBody) payload.body = cleanBody;
  if (cleanMediaUrls.length) payload.mediaUrl = cleanMediaUrls;
  if (statusCallback) payload.statusCallback = statusCallback;

  return twilioClient.messages.create(payload);
}

function normalizeTemplateVariables(raw) {
  if (!raw) return {};
  if (typeof raw === "string") {
    const trimmed = raw.trim();
    if (!trimmed) return {};
    return JSON.parse(trimmed);
  }
  if (typeof raw === "object" && !Array.isArray(raw)) return raw;
  throw new Error("contentVariables inválido");
}

async function sendWhatsappTemplate({ from, to, contentSid, contentVariables = {}, statusCallback }) {
  if (!twilioClient) throw new Error("Twilio no configurado");

  const cleanContentSid = String(contentSid || "").trim();
  if (!cleanContentSid) throw new Error("Falta contentSid");

  const payload = {
    from: ensureWhatsappPrefix(from),
    to: ensureWhatsappPrefix(to),
    contentSid: cleanContentSid,
  };

  const vars = normalizeTemplateVariables(contentVariables);
  if (Object.keys(vars).length) payload.contentVariables = JSON.stringify(vars);
  if (statusCallback) payload.statusCallback = statusCallback;

  return twilioClient.messages.create(payload);
}

function renderHtml() {
  return `<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>SCB Inbox</title>
  <style>
    *{box-sizing:border-box}
    body{font-family:Arial,sans-serif;margin:0;background:#f6f7f9;color:#111827;}
    header{background:#111827;color:#fff;padding:14px 16px;font-weight:700;display:flex;justify-content:space-between;align-items:center;gap:16px;}
    .headSmall{font-size:12px;color:#d1d5db;font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .wrap{display:flex;height:calc(100vh - 52px);}
    .left{width:410px;background:#fff;border-right:1px solid #e5e7eb;display:flex;flex-direction:column;}
    .right{flex:1;display:flex;flex-direction:column;min-width:0;}
    .toolbar{padding:10px;border-bottom:1px solid #e5e7eb;display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
    input,select{padding:10px;border:1px solid #e5e7eb;border-radius:10px;background:#fff;}
    #q{flex:1;min-width:180px;}
    #lineFilter{min-width:170px;}
    .list{overflow:auto;flex:1;}
    .item{padding:12px;border-bottom:1px solid #f0f1f3;cursor:pointer;}
    .item:hover{background:#f9fafb;}
    .item.active{background:#eef2ff;}
    .meta{font-size:12px;color:#6b7280;margin-top:6px;display:flex;justify-content:space-between;gap:10px;}
    .title{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .preview{color:#374151;margin-top:6px;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .chatHead{background:#fff;border-bottom:1px solid #e5e7eb;padding:12px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px;}
    .chatHeadLeft{min-width:0;}
    .chatSub{font-size:12px;color:#6b7280;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .pill{font-size:12px;padding:5px 10px;border-radius:999px;background:#f3f4f6;color:#111827;white-space:nowrap;}
    .btn{padding:10px 12px;border:1px solid #e5e7eb;border-radius:10px;background:#fff;cursor:pointer;}
    .btn:hover{background:#f9fafb;}
    .btnPrimary{background:#111827;color:#fff;border-color:#111827;}
    .btnDanger{background:#fff;color:#b91c1c;border-color:#fecaca;}
    .btnActive{outline:3px solid rgba(17,24,39,0.15);transform:translateY(-1px);}
    .btnDisabled{opacity:.5;cursor:not-allowed;}
    .chat{flex:1;overflow:auto;padding:14px;display:flex;flex-direction:column;gap:10px;}
    .leadCard{background:#fff;border:1px solid #e5e7eb;border-radius:14px;overflow:hidden;display:flex;gap:14px;align-items:stretch;}
    .leadImageWrap{width:220px;min-height:140px;background:#f3f4f6;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    .leadImage{width:100%;height:100%;object-fit:cover;display:block;}
    .leadBody{padding:14px;display:flex;flex-direction:column;gap:8px;min-width:0;}
    .leadBadge{display:inline-block;padding:4px 8px;border-radius:999px;background:#eef2ff;color:#3730a3;font-size:12px;font-weight:700;width:max-content;}
    .leadTitle{font-weight:700;font-size:18px;}
    .leadText{color:#374151;white-space:pre-wrap;}
    .leadMeta{font-size:12px;color:#6b7280;display:flex;gap:10px;flex-wrap:wrap;}
    .statusBadge{display:inline-flex;align-items:center;gap:5px;padding:4px 9px;border-radius:999px;font-size:11px;font-weight:700;line-height:1;border:1px solid transparent;vertical-align:middle;}
    .statusIcon{font-size:11px;line-height:1;display:inline-block;min-width:12px;text-align:center;}
    .st-read{background:#dcfce7;color:#166534;border-color:#bbf7d0;}
    .st-delivered{background:#dbeafe;color:#1d4ed8;border-color:#bfdbfe;}
    .st-sent{background:#e0e7ff;color:#4338ca;border-color:#c7d2fe;}
    .st-queued{background:#f3f4f6;color:#374151;border-color:#e5e7eb;}
    .st-undelivered,.st-failed{background:#fee2e2;color:#991b1b;border-color:#fecaca;}
    .st-accepted,.st-scheduled,.st-sending{background:#fef3c7;color:#92400e;border-color:#fde68a;}
    .bubbleWrap{display:flex;flex-direction:column;gap:5px;}
    .bubble{max-width:72%;padding:10px 12px;border-radius:14px;line-height:1.35;white-space:pre-wrap;word-break:break-word;box-shadow:0 1px 2px rgba(0,0,0,.06);}
    .in{align-self:flex-start;background:#fff;border:1px solid #e5e7eb;}
    .out{align-self:flex-end;background:#111827;color:#fff;}
    .metaMsg{font-size:11px;color:#6b7280;display:flex;flex-wrap:wrap;gap:6px;align-items:center;}
    .msgInfo{display:inline-flex;align-items:center;gap:6px;flex-wrap:wrap;}
    .templateBadge{display:inline-flex;align-items:center;gap:5px;padding:4px 9px;border-radius:999px;font-size:11px;font-weight:700;background:#ede9fe;color:#5b21b6;border:1px solid #ddd6fe;}
    .templateName{font-size:11px;color:#6b7280;opacity:.95;}
    .out + .metaMsg .templateName{color:#9ca3af;}
    .msgError{font-size:11px;margin-top:2px;color:#b91c1c;max-width:72%;align-self:flex-end;}
    .msgError.inErr{align-self:flex-start;max-width:72%;}
    .composer{background:#fff;border-top:1px solid #e5e7eb;padding:10px;display:flex;flex-direction:column;gap:8px;}
    .composerTop{display:flex;gap:8px;align-items:flex-end;}
    textarea{flex:1;min-height:44px;max-height:140px;resize:vertical;padding:10px;border:1px solid #e5e7eb;border-radius:10px;font-family:Arial,sans-serif;}
    .extraRow{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
    .fileName{font-size:12px;color:#374151;max-width:320px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .empty{padding:20px;color:#6b7280;}
    .mediaBox{margin-top:8px;display:flex;flex-direction:column;gap:8px;}
    .mediaThumb{max-width:240px;border-radius:10px;border:1px solid #e5e7eb;display:block;}
    .linkPlain{color:inherit;text-decoration:underline;}
    audio,video{max-width:260px;display:block;}
    .tag{display:inline-block;padding:3px 8px;border-radius:999px;background:#eef2ff;color:#3730a3;font-size:11px;margin-top:6px;}
    .hiddenFile{display:none;}
    .recordingBadge{font-size:12px;padding:6px 10px;border-radius:999px;background:#fee2e2;color:#991b1b;display:none;}
    .recordingBadge.show{display:inline-flex;align-items:center;gap:6px;}
    .modalBack{position:fixed;inset:0;background:rgba(17,24,39,.35);display:none;align-items:center;justify-content:center;padding:20px;z-index:50;}
    .modal{background:#fff;border-radius:16px;padding:16px;width:100%;max-width:520px;box-shadow:0 20px 50px rgba(0,0,0,.15);}
    .modalTitle{font-weight:700;font-size:18px;margin-bottom:12px;}
    .modalGrid{display:grid;gap:10px;}
    .label{font-size:12px;color:#6b7280;margin-bottom:4px;}
    .full{width:100%;}
  </style>
</head>
<body>
<header>
  <div>SCB Inbox</div>
  <div class="headSmall">Multi-línea WhatsApp + Dialogflow CX + adjuntos + plantillas + leído + Meta Ads</div>
</header>
<div class="wrap">
  <div class="left">
    <div class="toolbar">
      <input id="q" placeholder="Buscar cargados; Enter busca históricos..." />
      <button class="btn" onclick="searchHistorical()">Buscar histórico</button>
      <select id="lineFilter" onchange="renderList()">
        <option value="">Todas las líneas</option>
      </select>
      <button class="btn" onclick="openStartModal()">Iniciar conversación</button>
      <button class="btn" onclick="loadTemplates().then(loadConvos)">Refrescar</button>
    </div>
    <div id="list" class="list"></div>
    <div style="padding:8px;border-top:1px solid #e5e7eb;display:flex;gap:8px;align-items:center;">
      <button id="btnLoadMore" class="btn" style="flex:1;" onclick="loadMoreConvos()">Ver más conversaciones</button>
      <span id="convoCount" class="fileName"></span>
    </div>
  </div>
  <div class="right">
    <div class="chatHead">
      <div class="chatHeadLeft">
        <div class="title" id="chatTitle">Seleccioná una conversación</div>
        <div class="chatSub" id="chatSub"></div>
      </div>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <button id="btnHuman" class="btn btnDanger" onclick="setMode('HUMAN')">HUMAN</button>
        <button id="btnBot" class="btn btnPrimary" onclick="setMode('BOT')">BOT</button>
        <button id="btnTemplate" class="btn" onclick="sendTemplateSelected()">Plantilla</button>
        <div class="pill" id="chatPill">-</div>
      </div>
    </div>
    <div id="chat" class="chat">
      <div class="empty">Seleccioná una conversación para ver los mensajes.</div>
    </div>
    <div class="composer">
      <div class="composerTop">
        <textarea id="msg" placeholder="Escribí tu respuesta..."></textarea>
        <button id="btnSend" class="btn btnPrimary" onclick="sendMsg()">Enviar</button>
      </div>
      <div class="extraRow">
        <input id="fileInput" class="hiddenFile" type="file" accept=".pdf,image/jpeg,image/png,image/webp,audio/ogg,audio/mpeg,audio/mp3,audio/aac,audio/mp4,audio/webm" onchange="updateSelectedFile()" />
        <button id="btnAttach" class="btn" onclick="pickFile()">Adjuntar archivo</button>
        <button id="btnRecord" class="btn" onclick="toggleRecording()">🎤 Grabar audio</button>
        <button id="btnDiscardAudio" class="btn" onclick="discardRecordedAudio()">Descartar audio</button>
        <span id="recordingBadge" class="recordingBadge">● Grabando audio</span>
        <select id="templateSelect" style="min-width:240px;"></select>
        <button id="btnTemplateBottom" class="btn" onclick="sendTemplateSelected()">Enviar plantilla</button>
        <span id="selectedFileName" class="fileName">Sin archivo seleccionado</span>
        <button class="btn" onclick="clearSelectedFile()">Limpiar</button>
      </div>
    </div>
  </div>
</div>

<div id="startModalBack" class="modalBack">
  <div class="modal">
    <div class="modalTitle">Iniciar conversación con plantilla</div>
    <div class="modalGrid">
      <div>
        <div class="label">Número WhatsApp</div>
        <input id="startTo" class="full" placeholder="+5491130962554" />
      </div>
      <div>
        <div class="label">Nombre de contacto (opcional)</div>
        <input id="startName" class="full" placeholder="Facundo" />
      </div>
      <div>
        <div class="label">Plantilla aprobada</div>
        <select id="startTemplateSelect" class="full"></select>
      </div>
      <div>
        <div class="label">Variables JSON</div>
        <textarea id="startVars" class="full" placeholder="{}"></textarea>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;">
        <button class="btn" onclick="closeStartModal()">Cancelar</button>
        <button class="btn btnPrimary" onclick="startConversationTemplate()">Enviar plantilla</button>
      </div>
    </div>
  </div>
</div>

<script>
let selectedId = null;
let convos = [];
let timer = null;
let currentMode = 'BOT';
let templates = [];
let mediaRecorder = null;
let recordingStream = null;
let recordingChunks = [];
let recordedAudioFile = null;
let isRecording = false;
let pollingBusy = false;
let pollingCycle = 0;
let convosNextCursor = '';
let convosHasMore = true;
let convosLoading = false;

function esc(s){return (s||'').toString().replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
function fmtDate(v){try{let d=null;if(!v)return ''; if(typeof v==='string'||typeof v==='number') d=new Date(v); else if(v._seconds) d=new Date(v._seconds*1000); else if(v.seconds) d=new Date(v.seconds*1000); if(!d||isNaN(d.getTime())) return ''; return d.toLocaleString('es-AR');}catch{return '';}}
function lineDisplayLabel(v){const s=String(v||'').trim(); return s.replace(/^whatsapp:/i,'');}
async function api(path, opts){const r=await fetch(path, opts); const txt=await r.text(); if(!r.ok){alert('ERROR '+r.status+': '+txt); throw new Error(txt||('API error '+r.status));} try{return JSON.parse(txt);}catch{return txt;}}

function preferredRecordingMimeType(){
  const options = ['audio/ogg;codecs=opus','audio/webm;codecs=opus','audio/webm','audio/mp4','audio/mpeg'];
  for(const type of options){
    try{
      if(window.MediaRecorder && typeof MediaRecorder.isTypeSupported==='function' && MediaRecorder.isTypeSupported(type)) return type;
    }catch{}
  }
  return '';
}
function extFromMimeType(type){
  const lower=String(type||'').toLowerCase();
  if(lower.includes('ogg')) return 'ogg';
  if(lower.includes('webm')) return 'webm';
  if(lower.includes('mpeg') || lower.includes('mp3')) return 'mp3';
  if(lower.includes('aac')) return 'aac';
  if(lower.includes('mp4')) return 'mp4';
  return 'bin';
}
function stopRecordingStream(){
  if(recordingStream){
    try{recordingStream.getTracks().forEach(t=>t.stop());}catch{}
  }
  recordingStream = null;
}
function refreshAttachmentUi(){
  const selectedFileName=document.getElementById('selectedFileName');
  const btnRecord=document.getElementById('btnRecord');
  const btnDiscard=document.getElementById('btnDiscardAudio');
  const badge=document.getElementById('recordingBadge');
  const human=currentMode==='HUMAN';
  if(selectedFileName){
    const picked=document.getElementById('fileInput').files[0];
    if(picked) selectedFileName.innerText = picked.name;
    else if(recordedAudioFile) selectedFileName.innerText = recordedAudioFile.name + ' (audio grabado)';
    else selectedFileName.innerText = 'Sin archivo seleccionado';
  }
  if(btnRecord){
    btnRecord.disabled=!human;
    btnRecord.classList.toggle('btnDisabled',!human);
    btnRecord.innerText = isRecording ? '⏹️ Detener audio' : '🎤 Grabar audio';
  }
  if(btnDiscard){
    btnDiscard.disabled=!human || (!recordedAudioFile && !isRecording);
    btnDiscard.classList.toggle('btnDisabled',!human || (!recordedAudioFile && !isRecording));
  }
  if(badge) badge.classList.toggle('show', !!isRecording);
}
async function toggleRecording(){
  if(currentMode!=='HUMAN') return alert('Pasá primero a modo HUMAN');
  if(isRecording){
    if(mediaRecorder && mediaRecorder.state!=='inactive') mediaRecorder.stop();
    return;
  }
  if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return alert('Este navegador no permite grabar audio desde el micrófono');
  try{
    document.getElementById('fileInput').value='';
    recordedAudioFile = null;
    recordingChunks = [];
    recordingStream = await navigator.mediaDevices.getUserMedia({ audio:true });
    const mimeType = preferredRecordingMimeType();
    mediaRecorder = mimeType ? new MediaRecorder(recordingStream, { mimeType }) : new MediaRecorder(recordingStream);
    mediaRecorder.ondataavailable = (event) => { if(event.data && event.data.size > 0) recordingChunks.push(event.data); };
    mediaRecorder.onerror = () => {
      isRecording = false;
      stopRecordingStream();
      refreshAttachmentUi();
      alert('No se pudo grabar el audio');
    };
    mediaRecorder.onstop = () => {
      const blobType = (recordingChunks[0] && recordingChunks[0].type) || mediaRecorder.mimeType || mimeType || 'audio/webm';
      const blob = new Blob(recordingChunks, { type: blobType });
      const ext = extFromMimeType(blobType);
      recordedAudioFile = new File([blob], 'audio_' + Date.now() + '.' + ext, { type: blobType });
      recordingChunks = [];
      isRecording = false;
      stopRecordingStream();
      refreshAttachmentUi();
    };
    isRecording = true;
    mediaRecorder.start();
    refreshAttachmentUi();
  }catch(err){
    console.error('toggleRecording ERROR:', err);
    isRecording = false;
    stopRecordingStream();
    refreshAttachmentUi();
    alert('No se pudo acceder al micrófono');
  }
}
function discardRecordedAudio(){
  if(isRecording && mediaRecorder && mediaRecorder.state!=='inactive'){
    mediaRecorder.onstop = () => {
      recordingChunks = [];
      recordedAudioFile = null;
      isRecording = false;
      stopRecordingStream();
      refreshAttachmentUi();
    };
    mediaRecorder.stop();
    return;
  }
  recordedAudioFile = null;
  recordingChunks = [];
  refreshAttachmentUi();
}
function getSelectedOutgoingFile(){
  const picked=document.getElementById('fileInput').files[0];
  return picked || recordedAudioFile || null;
}


function statusBadge(status, msg, messages){
  const derivedStatus = (status || '').toLowerCase().trim();

  const map = {
    read: { label: 'Leído', icon: '✓✓' },
    delivered: { label: 'Entregado al cliente', icon: '✓✓' },
    sent: { label: 'Procesando entrega', icon: '📤' },
    queued: { label: 'En cola', icon: '⏳' },
    accepted: { label: 'Aceptado por Twilio', icon: '●' },
    scheduled: { label: 'Programado', icon: '◔' },
    sending: { label: 'Enviando', icon: '↻' },
    undelivered: { label: 'Error al entregar', icon: '❌' },
    failed: { label: 'Error al entregar', icon: '❌' }
  };

  const meta = map[derivedStatus] || { label: derivedStatus || 'Sin estado', icon: '•' };
  const cls = 'statusBadge st-' + (derivedStatus || 'unknown').replace(/[^a-z0-9_-]/g, '');

  return '<span class="' + cls + '">'
    + '<span class="statusIcon">' + esc(meta.icon) + '</span>'
    + '<span>' + esc(meta.label) + '</span>'
    + '</span>';
}











function updateModeButtons(mode){currentMode=(mode||'BOT'); const h=document.getElementById('btnHuman'); const b=document.getElementById('btnBot'); const send=document.getElementById('btnSend'); const msg=document.getElementById('msg'); const attach=document.getElementById('btnAttach'); const t1=document.getElementById('btnTemplate'); const t2=document.getElementById('btnTemplateBottom'); h.classList.remove('btnActive'); b.classList.remove('btnActive'); if(currentMode==='HUMAN') h.classList.add('btnActive'); else b.classList.add('btnActive'); const human=currentMode==='HUMAN'; send.disabled=!human; msg.disabled=!human; attach.disabled=!human; if(t1) t1.disabled=!human; if(t2) t2.disabled=!human; send.classList.toggle('btnDisabled',!human); attach.classList.toggle('btnDisabled',!human); if(t1) t1.classList.toggle('btnDisabled',!human); if(t2) t2.classList.toggle('btnDisabled',!human); if(!human){msg.value=''; clearSelectedFile(); msg.placeholder='Pasá la conversación a HUMAN para escribir manualmente';} else {msg.placeholder='Escribí tu respuesta...';} refreshAttachmentUi();}
function refreshLineOptions(){const sel=document.getElementById('lineFilter'); const current=sel.value; const lines=[...new Set(convos.map(c=>String(c.lineId||c.inboundTo||'').trim()).filter(Boolean))].sort(); sel.innerHTML='<option value="">Todas las líneas</option>'+lines.map(l=>'<option value="'+esc(l)+'">'+esc(l)+'</option>').join(''); if(lines.includes(current)) sel.value=current;}
function renderTemplateOptions(){ const options = templates.map(t => '<option value="'+esc(t.sid)+'">'+esc(t.name)+' ('+esc(t.language || '')+' • '+esc(t.category || '')+')</option>').join(''); document.getElementById('templateSelect').innerHTML = options || '<option value="">Sin plantillas aprobadas</option>'; document.getElementById('startTemplateSelect').innerHTML = options || '<option value="">Sin plantillas aprobadas</option>'; }
function renderList(){const q=(document.getElementById('q').value||'').trim().toLowerCase(); const line=(document.getElementById('lineFilter').value||'').trim(); const list=document.getElementById('list'); list.innerHTML=''; let filtered=convos.slice(); if(line){filtered=filtered.filter(c=>String(c.lineId||c.inboundTo||'').trim()===line);} if(q){filtered=filtered.filter(c=>(c.waFrom||'').toLowerCase().includes(q)||(c.inboundTo||'').toLowerCase().includes(q)||(c.lastMessagePreview||'').toLowerCase().includes(q)||(c.contactName||'').toLowerCase().includes(q)||(c.lineId||'').toLowerCase().includes(q));} if(!filtered.length){list.innerHTML='<div class="empty">No hay conversaciones.</div>'; return;} filtered.forEach(c=>{const src=(c.leadPlatform||c.leadAd?.platform||'').toLowerCase(); const sourceLabel = src==='instagram'?'Instagram Ad':src==='facebook'?'Facebook Ad':(c.sourceChannel==='meta_ad'?'Meta Ad':''); const lineLabel = lineDisplayLabel(c.inboundTo || c.lineId || ''); const div=document.createElement('div'); div.className='item'+(c.id===selectedId?' active':''); div.onclick=()=>selectConvo(c.id); div.innerHTML='<div class="title">'+esc(c.contactName||c.waFrom||c.id)+'</div><div class="preview">'+esc(c.lastMessagePreview||'')+'</div>'+(sourceLabel?'<div class="tag">'+esc(sourceLabel)+'</div>':'')+(lineLabel?'<div class="tag">Línea '+esc(lineLabel)+'</div>':'')+'<div class="meta"><span>'+esc(c.mode||'BOT')+' • '+esc(c.stage||'nuevo')+'</span><span>'+statusBadge(c.lastDeliveryStatus||'')+'</span></div>'; list.appendChild(div);});}
async function loadTemplates(){ const resp=await api('/api/templates'); templates = resp.templates || []; renderTemplateOptions(); }
function mergeConvoArrays(base, incoming){
  const map=new Map();
  [...(base||[]),...(incoming||[])].forEach(c=>{
    const key=String(c.canonicalConversationKey||c.id||'');
    if(!key) return;
    const prev=map.get(key);
    if(!prev){map.set(key,c);return;}
    const prevIds=Array.isArray(prev.duplicateConversationIds)?prev.duplicateConversationIds:[];
    const newIds=Array.isArray(c.duplicateConversationIds)?c.duplicateConversationIds:[];
    map.set(key,{...prev,...c,duplicateConversationIds:[...new Set([...prevIds,...newIds,prev.id,c.id].filter(Boolean))]});
  });
  return [...map.values()].sort((a,b)=>{const ta=new Date(a.lastMessageAt||a.updatedAt||0).getTime()||((a.lastMessageAt&&a.lastMessageAt._seconds)||0)*1000;const tb=new Date(b.lastMessageAt||b.updatedAt||0).getTime()||((b.lastMessageAt&&b.lastMessageAt._seconds)||0)*1000;return tb-ta;});
}
function refreshConversationFooter(){const btn=document.getElementById('btnLoadMore');const count=document.getElementById('convoCount');if(btn){btn.disabled=convosLoading||!convosHasMore;btn.classList.toggle('btnDisabled',btn.disabled);btn.innerText=convosLoading?'Cargando...':(convosHasMore?'Ver más conversaciones':'No hay más');}if(count)count.innerText=convos.length+' cargadas';}
async function loadConvos(reset=true){
  if(convosLoading) return;
  convosLoading=true; refreshConversationFooter();
  try{
    const params=new URLSearchParams();params.set('limit','100');if(!reset&&convosNextCursor)params.set('cursor',convosNextCursor);
    const resp=await api('/api/conversations?'+params.toString());
    const items=Array.isArray(resp)?resp:(resp.items||[]);
    convos=mergeConvoArrays(reset?convos:convos,items);
    convosNextCursor=String(resp.nextCursor||'');convosHasMore=resp.hasMore!==false&&!!convosNextCursor;
    refreshLineOptions();renderList();
  }finally{convosLoading=false;refreshConversationFooter();}
}
async function loadMoreConvos(){if(!convosHasMore||convosLoading)return;await loadConvos(false);}
async function searchHistorical(){
  const q=(document.getElementById('q').value||'').trim();
  if(!q)return alert('Escribí un teléfono, nombre o texto para buscar');
  const resp=await api('/api/conversations/search?q='+encodeURIComponent(q));
  const items=resp.items||[];
  convos=mergeConvoArrays(convos,items);refreshLineOptions();renderList();refreshConversationFooter();
  if(!items.length)alert('No se encontraron conversaciones históricas');
}
function renderLeadCard(data){
  const ad = data.leadAd || {};
  const referralHeadline = data.referralHeadline || '';
  const referralBody = data.referralBody || '';
  const referralAdId = data.referralAdId || ad.adId || '';
  const title = ad.title || referralHeadline || ad.adName || 'Lead desde Meta Ads';
  const body = ad.body || referralBody || '';
  const campaign = ad.campaignName || '';
  const adset = ad.adsetName || '';
  const imageUrl = ad.imageUrl || data.referralImageUrl || '';
  const platform = (data.leadPlatform || ad.platform || '').toLowerCase();
  const platformLabel = platform==='instagram'?'Instagram Ad':platform==='facebook'?'Facebook Ad':'Meta Ad';
  const hasAnything = !!(data.referralCtwaClid || referralAdId || imageUrl || referralHeadline || referralBody || campaign || adset || ad.adName || ad.title || ad.body);
  if(!hasAnything) return '';
  return '<div class="leadCard">'
    + '<div class="leadImageWrap">'
    + (imageUrl ? '<img class="leadImage" src="'+esc(imageUrl)+'" alt="anuncio">' : '<div style="padding:12px;color:#6b7280;">Anuncio detectado</div>')
    + '</div>'
    + '<div class="leadBody">'
    + '<div class="leadBadge">📣 '+esc(platformLabel)+'</div>'
    + '<div class="leadTitle">'+esc(title)+'</div>'
    + (body ? '<div class="leadText">'+esc(body)+'</div>' : '')
    + '<div class="leadMeta">'
    + (campaign ? '<span>Campaña: '+esc(campaign)+'</span>' : '')
    + (adset ? '<span>Ad Set: '+esc(adset)+'</span>' : '')
    + (ad.adName ? '<span>Anuncio: '+esc(ad.adName)+'</span>' : '')
    + (referralAdId ? '<span>Ad ID: '+esc(referralAdId)+'</span>' : '')
    + '</div>'
    + '</div>'
    + '</div>';
}
async function selectConvo(id){selectedId=id; renderList(); const c=convos.find(x=>x.id===id)||{}; const src=(c.leadPlatform||c.leadAd?.platform||'').toLowerCase(); const sourceLabel = src==='instagram'?'Instagram Ad':src==='facebook'?'Facebook Ad':(c.sourceChannel==='meta_ad'?'Meta Ad':''); document.getElementById('chatTitle').innerText=c.contactName||c.waFrom||id; let sub=(c.waFrom||'') + (c.inboundTo ? ('  →  ' + c.inboundTo) : ''); if(sourceLabel) sub += ' • ' + sourceLabel; document.getElementById('chatSub').innerText=sub; document.getElementById('chatPill').innerHTML=(esc(c.stage||'-'))+' • '+esc(c.mode||'BOT')+(c.lastDeliveryStatus?(' • '+statusBadge(c.lastDeliveryStatus)):''); updateModeButtons(c.mode||'BOT'); await loadMessages(); if(timer) clearInterval(timer); pollingCycle=0; timer=setInterval(async()=>{if(document.hidden || pollingBusy || !selectedId) return; pollingBusy=true; try{await loadMessages(); pollingCycle++; if(pollingCycle%6===0) await loadConvos(true); const c2=convos.find(x=>x.id===selectedId)||{}; document.getElementById('chatPill').innerHTML=(esc(c2.stage||'-'))+' • '+esc(c2.mode||'BOT')+(c2.lastDeliveryStatus?(' • '+statusBadge(c2.lastDeliveryStatus)):''); updateModeButtons(c2.mode||'BOT');}finally{pollingBusy=false;}},10000);}
function mediaHtml(file, isOut, messageId, sourceConversationId){const type=(file.contentType||'').toLowerCase(); const idx=Number(file._idx || 0); const source=(file.source||'').toLowerCase(); const mediaConversationId=sourceConversationId||selectedId; const url = source==='gcs' ? file.url : '/api/media/'+encodeURIComponent(mediaConversationId)+'/'+encodeURIComponent(messageId)+'/'+idx; if(type.startsWith('image/')) return '<a href="'+url+'" target="_blank" rel="noopener"><img class="mediaThumb" src="'+url+'" alt="adjunto"></a>'; if(type==='application/pdf') return '<a class="'+(isOut?'linkPlain':'')+'" href="'+url+'" target="_blank" rel="noopener">📄 Ver PDF</a>'; if(type.startsWith('audio/')) return '<audio controls src="'+url+'"></audio>'; if(type.startsWith('video/')) return '<video controls src="'+url+'"></video>'; return '<a class="'+(isOut?'linkPlain':'')+'" href="'+url+'" target="_blank" rel="noopener">📎 Abrir adjunto</a>'; }
async function loadMessages(){
  if(!selectedId) return;

  const selectedConvo = convos.find(x=>x.id===selectedId)||{};
  const relatedIds = Array.isArray(selectedConvo.duplicateConversationIds)
    ? selectedConvo.duplicateConversationIds.slice(0, 20)
    : [selectedId];
  const params = new URLSearchParams();
  params.set('relatedIds', JSON.stringify(relatedIds));
  const msgs=await api('/api/conversations/'+encodeURIComponent(selectedId)+'/messages?'+params.toString());
  const chat=document.getElementById('chat');
  const shouldStickToBottom = (chat.scrollHeight - chat.scrollTop - chat.clientHeight) < 80;

  chat.innerHTML='';
  const convo = convos.find(x=>x.id===selectedId)||{};
  const leadHtml = renderLeadCard(convo);
  if(leadHtml){ const wrap=document.createElement('div'); wrap.innerHTML=leadHtml; chat.appendChild(wrap.firstChild); }
  if(!msgs.length){ if(!leadHtml){ chat.innerHTML='<div class="empty">No hay mensajes.</div>'; } return;}
  msgs.forEach(m=>{
    const wrap=document.createElement('div');
    wrap.className='bubbleWrap';
    const isOut = m.direction==='OUT';
    const b=document.createElement('div');
    b.className='bubble '+(isOut?'out':'in');

    let html='';
    const msgLeadHtml = renderLeadCard(m);
    if(msgLeadHtml && !isOut){ html += msgLeadHtml; }
    if(m.text){html+='<div>'+esc(m.text)+'</div>';}
    if(Array.isArray(m.media) && m.media.length){
      html+='<div class="mediaBox">';
      m.media.forEach((file, idx)=>{ html += mediaHtml({...file,_idx:idx}, isOut, m.id, m.conversationId); });
      html+='</div>';
    }
    b.innerHTML=html || '<span style="opacity:.7">(sin texto)</span>';

    const meta=document.createElement('div');
    meta.className='metaMsg';

    const info = [];
    if(m.direction) info.push('<span>'+esc(m.direction)+'</span>');
    if(m.source) info.push('<span>'+esc(m.source)+'</span>');
    if(m.timestamp) info.push('<span>'+esc(fmtDate(m.timestamp))+'</span>');
    if(m.referralCtwaClid) info.push('<span class="templateBadge">📣 Meta Ad</span>');

    const templateSid = m.template && m.template.contentSid ? m.template.contentSid : '';
    const templateName = m.template && (m.template.friendlyName || m.template.name || m.template.contentSid) ? (m.template.friendlyName || m.template.name || m.template.contentSid) : '';
    if(templateSid){
      info.push('<span class="templateBadge">📨 Plantilla</span>');
      info.push('<span class="templateName">'+esc(templateName)+'</span>');
    }

    if(m.deliveryStatus){
      info.push(statusBadge(m.deliveryStatus, m, msgs));
    }

    meta.innerHTML = '<span class="msgInfo">'+info.join('<span>•</span>')+'</span>';

    wrap.style.alignItems=isOut?'flex-end':'flex-start';
    wrap.appendChild(b);
    wrap.appendChild(meta);

    const errorText = m.errorMessage || m.error || '';
    if(errorText){
      const err=document.createElement('div');
      err.className='msgError'+(isOut?'':' inErr');
      err.textContent='Error: '+errorText;
      wrap.appendChild(err);
    }

    chat.appendChild(wrap);
  });
  if(shouldStickToBottom){ chat.scrollTop=chat.scrollHeight; }}
async function setMode(mode){if(!selectedId) return alert('Elegí una conversación'); updateModeButtons(mode); await api('/api/conversations/'+encodeURIComponent(selectedId)+'/mode',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode})}); await loadConvos();}
function pickFile(){ if(currentMode!=='HUMAN') return alert('Pasá primero a modo HUMAN'); document.getElementById('fileInput').click(); }
function updateSelectedFile(){ recordedAudioFile = null; recordingChunks = []; refreshAttachmentUi(); }
function clearSelectedFile(){ document.getElementById('fileInput').value=''; recordedAudioFile = null; recordingChunks = []; if(isRecording && mediaRecorder && mediaRecorder.state!=='inactive') mediaRecorder.stop(); else { stopRecordingStream(); isRecording = false; refreshAttachmentUi(); } }
function openStartModal(){ document.getElementById('startModalBack').style.display='flex'; document.getElementById('startVars').value = '{}'; }
function closeStartModal(){ document.getElementById('startModalBack').style.display='none'; }
async function startConversationTemplate(){
  const to = (document.getElementById('startTo').value||'').trim();
  const contactName = (document.getElementById('startName').value||'').trim();
  const contentSid = (document.getElementById('startTemplateSelect').value||'').trim();
  const rawVars = (document.getElementById('startVars').value||'').trim() || '{}';
  if(!to) return alert('Falta número');
  if(!contentSid) return alert('No hay plantilla seleccionada');
  let contentVariables = {};
  try{ contentVariables = JSON.parse(rawVars); }catch(e){ return alert('Variables JSON inválidas'); }
  const resp = await api('/api/start-template',{ method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ to, contactName, contentSid, contentVariables }) });
  closeStartModal();
  await loadConvos();
  if(resp && resp.conversationId){ await selectConvo(resp.conversationId); }
  alert('Plantilla enviada y conversación creada');
}
async function sendTemplateSelected(){
  if(!selectedId) return alert('Elegí una conversación');
  if(currentMode!=='HUMAN') return alert('Pasá la conversación a HUMAN');
  const contentSid = (document.getElementById('templateSelect').value||'').trim();
  if(!contentSid) return alert('No hay plantilla seleccionada');
  const resp = await api('/api/conversations/'+encodeURIComponent(selectedId)+'/send-template',{ method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ contentSid, contentVariables: {} }) });
  if(resp && resp.ok){ await loadMessages(); await loadConvos(); alert('Plantilla enviada'); }
}
async function sendMsg(){
  if(!selectedId) return alert('Elegí una conversación');
  if(currentMode!=='HUMAN') return alert('Para enviar tenés que estar en modo HUMAN');
  const ta=document.getElementById('msg');
  const text=(ta.value||'').trim();
  const file=getSelectedOutgoingFile();
  if(!text && !file) return;
  if(!file){
    await api('/api/conversations/'+encodeURIComponent(selectedId)+'/send',{ method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({text, mediaUrls:[]}) });
  } else {
    const fd=new FormData();
    fd.append('text', text);
    fd.append('file', file);
    const r = await fetch('/api/conversations/'+encodeURIComponent(selectedId)+'/send-file',{ method:'POST', body:fd });
    const txt = await r.text();
    if(!r.ok){ alert('ERROR '+r.status+': '+txt); throw new Error(txt||('API error '+r.status)); }
  }
  ta.value='';
  clearSelectedFile();
  await loadMessages();
  await loadConvos();
}
document.getElementById('q').addEventListener('input', renderList);
document.getElementById('q').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchHistorical();}});
document.getElementById('msg').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault(); sendMsg();}});
document.getElementById('startModalBack').addEventListener('click',e=>{ if(e.target.id==='startModalBack') closeStartModal(); });
(async function boot(){ await loadTemplates(); await loadConvos(); updateModeButtons('BOT'); refreshAttachmentUi(); })();
</script>
</body>
</html>`;
}

app.post("/webhooks/twilio/whatsapp", async (req, res) => {
  try {
    const from = ensureWhatsappPrefix(req.body.From || "");
    const to = ensureWhatsappPrefix(req.body.To || TWILIO_WHATSAPP_FROM || "");
    const body = String(req.body.Body || "").trim();
    const messageSid = String(req.body.MessageSid || `in_${Date.now()}`);
    const profileName = String(req.body.ProfileName || "").trim();
    const numMedia = Number(req.body.NumMedia || 0);
    const referralPayload = extractReferralPayload(req.body);
    const referralCtwaClid = referralPayload.referralCtwaClid;
    const referralAdId = referralPayload.referralAdId;
    const referralSourceType = referralPayload.referralSourceType;
    const referralHeadline = referralPayload.referralHeadline;
    const referralBody = referralPayload.referralBody;
    const referralImageUrl = referralPayload.referralImageUrl;

    const media = [];
    for (let i = 0; i < numMedia; i++) {
      const url = String(req.body[`MediaUrl${i}`] || "").trim();
      const contentType = String(req.body[`MediaContentType${i}`] || "").trim();
      const filename = String(req.body[`MediaFilename${i}`] || "").trim();
      if (url) media.push({ url, contentType, filename, source: "twilio" });
    }

    if (!from || !to) return res.status(400).type("text/xml").send("<Response></Response>");

    const resolvedConversation = await resolveConversationRef(from, to);
    const conversationId = resolvedConversation.id;
    const convoRef = resolvedConversation.ref;
    const convoSnap = resolvedConversation.snap;
    const oldData = convoSnap.exists ? convoSnap.data() : {};
    const mode = normalizeMode(oldData?.mode || "BOT");

    const hasMetaLeadSignals = !!(
      referralCtwaClid ||
      referralAdId ||
      referralHeadline ||
      referralBody ||
      referralImageUrl ||
      referralSourceType
    );

    let leadAd = buildLeadAdFallback({
      oldLeadAd: oldData?.leadAd || null,
      referralPayload,
      messageMedia: media,
    });
    let leadPlatform = leadAd.platform || oldData?.leadPlatform || "";

    if (referralAdId && META_ACCESS_TOKEN) {
      try {
        const fetchedLeadAd = await fetchMetaAdDetails(referralAdId);

        if (fetchedLeadAd && hasLeadAdContent(fetchedLeadAd)) {
          leadAd = buildLeadAdFallback({
            oldLeadAd: {
              ...(oldData?.leadAd || {}),
              ...leadAd,
              ...fetchedLeadAd,
            },
            referralPayload,
            messageMedia: media,
          });

          leadPlatform = fetchedLeadAd.platform || leadPlatform || "meta";
        }
      } catch (metaErr) {
        console.error("META AD FETCH ERROR:", metaErr.response?.data || metaErr.message || metaErr);
      }
    }

    if (hasMetaLeadSignals) {
      console.log("META LEAD INBOUND:", JSON.stringify({
        conversationId,
        referralCtwaClid,
        referralAdId,
        referralSourceType,
        hasHeadline: !!referralHeadline,
        hasBody: !!referralBody,
        hasImage: !!referralImageUrl || !!leadAd?.imageUrl,
        hasMetaToken: !!META_ACCESS_TOKEN,
      }));
    }

    await convoRef.set({
      waFrom: from,
      inboundTo: to,
      lineId: cleanWhatsappNumber(to),
      contactName: profileName || oldData?.contactName || cleanWhatsappNumber(from),
      mode,
      stage: oldData?.stage || "nuevo",
      lastMessageAt: FieldValue.serverTimestamp(),
      lastMessagePreview: buildLastPreview(body, numMedia),
      updatedAt: FieldValue.serverTimestamp(),
      lastInboundHadMedia: numMedia > 0,
      lastInboundMediaCount: numMedia,
      lastMessageDirection: "IN",
      lastCustomerMessageAt: FieldValue.serverTimestamp(),
      hasUnread: true,
      unreadCount: FieldValue.increment(1),
      referralCtwaClid: referralCtwaClid || oldData?.referralCtwaClid || "",
      referralAdId: referralAdId || oldData?.referralAdId || "",
      referralSourceType: referralSourceType || oldData?.referralSourceType || "",
      referralHeadline: referralHeadline || oldData?.referralHeadline || "",
      referralBody: referralBody || oldData?.referralBody || "",
      referralImageUrl: referralImageUrl || oldData?.referralImageUrl || "",
      sourceChannel: hasMetaLeadSignals ? "meta_ad" : (oldData?.sourceChannel || "whatsapp"),
      leadAd: hasLeadAdContent(leadAd) ? leadAd : (oldData?.leadAd || null),
      leadPlatform: leadPlatform || oldData?.leadPlatform || (hasMetaLeadSignals ? "meta" : ""),
    }, { merge: true });

    await saveConversationLookup(
      getConversationCanonicalKey({ waFrom: from, inboundTo: to }, conversationId),
      [conversationId],
      conversationId
    );

    await saveMessage(convoRef, messageSid, {
      direction: "IN",
      text: body,
      source: "whatsapp",
      timestamp: FieldValue.serverTimestamp(),
      from,
      to,
      profileName,
      messageSid,
      numMedia,
      media,
      referralCtwaClid,
      referralAdId,
      referralSourceType,
      referralHeadline,
      referralBody,
      referralImageUrl,
      leadAd: hasLeadAdContent(leadAd) ? leadAd : null,
      leadPlatform: leadPlatform || (hasMetaLeadSignals ? "meta" : ""),
    });

    if (mode === "BOT" && body) {
      try {
        const bot = await detectIntentText({ conversationId, text: body, languageCode: DF_LANGUAGE_CODE });
        const botText = String(bot.text || "").trim();
        if (botText) {
          const sent = await sendWhatsappMessage({ from: to, to: from, body: botText, statusCallback: buildStatusCallbackUrl(req) });
          await saveMessage(convoRef, sent.sid, {
            direction: "OUT",
            text: botText,
            source: "bot",
            timestamp: FieldValue.serverTimestamp(),
            from: to,
            to: from,
            messageSid: sent.sid,
            numMedia: 0,
            media: [],
            deliveryStatus: sent.status || "queued",
          });
          await convoRef.set({
            lastMessageAt: FieldValue.serverTimestamp(),
            lastMessagePreview: buildLastPreview(botText, 0),
            updatedAt: FieldValue.serverTimestamp(),
            lastDeliveryStatus: sent.status || "queued",
            lastMessageDirection: "OUT"
          }, { merge: true });
        }
      } catch (botError) {
        console.error("Dialogflow BOT ERROR:", botError);
        await saveMessage(convoRef, `bot_error_${Date.now()}`, {
          direction: "OUT",
          text: "Error interno del bot",
          source: "bot-error",
          timestamp: FieldValue.serverTimestamp(),
        });
      }
    }

    return res.status(200).type("text/xml").send("<Response></Response>");
  } catch (e) {
    console.error("POST /webhooks/twilio/whatsapp ERROR:", e);
    return res.status(200).type("text/xml").send("<Response></Response>");
  }
});


app.post("/webhooks/twilio/status", async (req, res) => {
  try {
    const messageSid = String(
      (req.body && (req.body.MessageSid || req.body.SmsSid)) || ""
    ).trim();

    const messageStatus = String(
      (req.body && (req.body.MessageStatus || req.body.SmsStatus)) || ""
    )
      .trim()
      .toLowerCase();

    const errorCode = String((req.body && req.body.ErrorCode) || "").trim();
    const errorMessage = String((req.body && req.body.ErrorMessage) || "").trim();

    const to = String((req.body && req.body.To) || "").trim();
    const from = String((req.body && req.body.From) || "").trim();
    const pairConversationId = buildConversationId(to, from);
    const canonicalConversationId = buildCanonicalConversationId(to, from);
    const legacyConversationId = to.replace(/^whatsapp:/, "");

    console.log(
      "TWILIO STATUS:",
      JSON.stringify({
        messageSid,
        messageStatus,
        to,
        from,
        pairConversationId,
        canonicalConversationId,
        legacyConversationId,
        errorCode,
        errorMessage,
      })
    );

    if (!messageSid || (!pairConversationId && !canonicalConversationId && !legacyConversationId)) {
      return res.status(200).send("ok");
    }

    const patch = {
      deliveryStatus: messageStatus || "unknown",
      errorCode,
      errorMessage,
      statusUpdatedAt: FieldValue.serverTimestamp(),
    };

    if (messageStatus === "sent") {
      patch.sentAt = FieldValue.serverTimestamp();
    }

    if (messageStatus === "delivered") {
      patch.deliveredAt = FieldValue.serverTimestamp();
    }

    if (messageStatus === "read") {
      patch.readAt = FieldValue.serverTimestamp();
    }

    if (messageStatus === "failed" || messageStatus === "undelivered") {
      patch.failedAt = FieldValue.serverTimestamp();
    }

    const statusCanonicalKey = getConversationCanonicalKey({ waFrom: to, inboundTo: from }, "") || canonicalConversationId;
    const statusLookup = await readConversationLookup(statusCanonicalKey);
    const candidateConversationIds = uniqueStrings([
      statusLookup.primaryConversationId,
      ...statusLookup.conversationIds,
      ...buildConversationIdCandidates(to, from),
      pairConversationId,
      canonicalConversationId,
      legacyConversationId,
    ]).slice(0, MAX_RELATED_CONVERSATION_IDS);

    let foundConversationId = "";
    let msgRef = null;

    for (const candidateId of candidateConversationIds) {
      const candidateRef = db
        .collection("conversations")
        .doc(candidateId)
        .collection("messages")
        .doc(messageSid);
      const candidateSnap = await candidateRef.get();
      if (candidateSnap.exists) {
        foundConversationId = candidateId;
        msgRef = candidateRef;
        break;
      }
    }

    if (!msgRef) {
      console.log(
        "TWILIO STATUS MESSAGE NOT FOUND:",
        JSON.stringify({
          candidateConversationIds,
          messageSid,
        })
      );
      return res.status(200).send("ok");
    }

    await msgRef.set(patch, { merge: true });

    await db.collection("conversations").doc(foundConversationId).set(
      {
        updatedAt: FieldValue.serverTimestamp(),
        lastDeliveryStatus: patch.deliveryStatus || "",
        lastReadAt: patch.readAt || null,
      },
      { merge: true }
    );

    await saveConversationLookup(statusCanonicalKey, [foundConversationId], foundConversationId);

    console.log(
      "TWILIO STATUS UPDATED:",
      JSON.stringify({
        conversationId: foundConversationId,
        messageSid,
        messageStatus,
        updated: true,
      })
    );

    return res.status(200).send("ok");
  } catch (err) {
    console.error("TWILIO STATUS ERROR:", err);
    return res.status(200).send("ok");
  }
});






app.use((req, res, next) => {
  if (req.path.startsWith("/webhooks/twilio/")) return next();
  return basicAuth(req, res, next);
});

app.get("/", (req, res) => {
  res.status(200).type("text/html").send(renderHtml());
});

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    app: "bandeja-scb",
    hasTwilio: !!twilioClient,
    firestoreDb: "bsscb",
    filesBucket: FILES_BUCKET,
    whatsappFrom: TWILIO_WHATSAPP_FROM || null,
    hasMetaToken: !!META_ACCESS_TOKEN,
    publicBaseUrl: PUBLIC_BASE_URL || null,
    dialogflow: {
      projectId: DF_PROJECT_ID,
      location: DF_LOCATION,
      agentId: DF_AGENT_ID,
      languageCode: DF_LANGUAGE_CODE,
    },
  });
});






app.get("/api/templates", async (req, res) => {
  try {
    if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN) {
      return res.status(500).json({ ok: false, error: "Twilio no configurado" });
    }

    const templates = await listApprovedTemplates();
    res.json({ ok: true, templates });
  } catch (e) {
    console.error("GET /api/templates ERROR:", e.response?.data || e.message || e);
    res.status(500).json({ ok: false, error: "No se pudieron leer las plantillas de Twilio", details: e.response?.data || e.message || String(e) });
  }
});

app.get("/api/templates/:contentSid/preview", async (req, res) => {
  try {
    if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN) {
      return res.status(500).json({ ok: false, error: "Twilio no configurado" });
    }

    const contentSid = String(req.params?.contentSid || "").trim();
    if (!contentSid) {
      return res.status(400).json({ ok: false, error: "Falta contentSid" });
    }

    const item = await getTwilioTemplateBySid(contentSid);
    const preview = buildTwilioTemplatePreview(item);

    return res.json({
      ok: true,
      template: preview,
    });
  } catch (e) {
    console.error("GET /api/templates/:contentSid/preview ERROR:", e.response?.data || e.message || e);
    return res.status(500).json({
      ok: false,
      error: "No se pudo generar el preview de la plantilla",
      details: e.response?.data || e.message || String(e),
    });
  }
});

function groupConversationDocs(docs = []) {
  const grouped = new Map();
  for (const doc of docs) {
    const data = doc.data() || {};
    const item = { id: doc.id, ...data };
    const key = getConversationCanonicalKey(data, doc.id);
    if (!key) continue;
    const existing = grouped.get(key);
    const incoming = { ...item, duplicateConversationIds: uniqueStrings([doc.id]), canonicalConversationKey: key };
    grouped.set(key, mergeConversationForList(existing, incoming));
  }
  return Array.from(grouped.values())
    .sort((a, b) => docTimestampMillis(b.lastMessageAt || b.updatedAt) - docTimestampMillis(a.lastMessageAt || a.updatedAt));
}

app.get("/api/conversations", async (req, res) => {
  try {
    const requestedLimit = Number(req.query?.limit || CONVERSATIONS_PAGE_SIZE);
    const pageSize = Math.max(25, Math.min(requestedLimit || CONVERSATIONS_PAGE_SIZE, 300));
    const cursorId = String(req.query?.cursor || "").trim();
    let query = db.collection("conversations").orderBy("lastMessageAt", "desc").limit(pageSize);

    if (cursorId) {
      const cursorSnap = await db.collection("conversations").doc(cursorId).get();
      if (cursorSnap.exists) query = query.startAfter(cursorSnap);
    }

    const snap = await query.get();
    const items = groupConversationDocs(snap.docs);
    const nextCursor = snap.docs.length ? snap.docs[snap.docs.length - 1].id : "";
    res.json({ items, nextCursor, hasMore: snap.docs.length === pageSize });
  } catch (e) {
    console.error("GET /api/conversations ERROR:", e);
    res.status(500).send("Error leyendo conversaciones");
  }
});

app.get("/api/conversations/search", async (req, res) => {
  try {
    const q = String(req.query?.q || "").trim().toLowerCase();
    if (!q) return res.json({ items: [] });
    const qDigits = normalizeConversationNumber(q);
    const matches = [];
    const seen = new Set();

    // Buscar por teléfono con consulta selectiva primero.
    if (qDigits.length >= 6) {
      const variants = buildWaFromQueryVariants(qDigits);
      if (variants.length) {
        const phoneSnap = await db.collection("conversations").where("waFrom", "in", variants).limit(100).get();
        for (const doc of phoneSnap.docs) { if (!seen.has(doc.id)) { seen.add(doc.id); matches.push(doc); } }
      }
    }

    // La búsqueda histórica completa solo ocurre cuando el usuario la solicita,
    // nunca dentro del refresco automático.
    if (matches.length < 50) {
      const scan = await db.collection("conversations").orderBy("lastMessageAt", "desc").limit(15000).get();
      for (const doc of scan.docs) {
        if (seen.has(doc.id)) continue;
        const data = doc.data() || {};
        const haystack = [doc.id, data.waFrom, data.inboundTo, data.lineId, data.contactName, data.lastMessagePreview]
          .map((v) => String(v || "").toLowerCase()).join(" ");
        if (!haystack.includes(q)) continue;
        seen.add(doc.id); matches.push(doc);
        if (matches.length >= 100) break;
      }
    }

    res.json({ items: groupConversationDocs(matches) });
  } catch (e) {
    console.error("GET /api/conversations/search ERROR:", e);
    res.status(500).send("Error buscando conversaciones");
  }
});

app.get("/api/conversations/:id/messages", async (req, res) => {
  try {
    const conversationId = decodeURIComponent(req.params.id);

    let requestedRelatedIds = [];
    try {
      const parsed = JSON.parse(String(req.query?.relatedIds || "[]"));
      if (Array.isArray(parsed)) requestedRelatedIds = uniqueStrings(parsed).filter((id) => id.length <= 220);
    } catch {}

    const convoSnap = await db.collection("conversations").doc(conversationId).get();
    const convo = convoSnap.exists ? (convoSnap.data() || {}) : {};
    const pair = getConversationPairFromId(conversationId);
    const canonicalKey = getConversationCanonicalKey(convo, conversationId) || getConversationCanonicalKey({ waFrom: pair.customer, inboundTo: pair.line }, "");
    const lookup = await readConversationLookup(canonicalKey);
    const relatedIds = uniqueStrings([conversationId, ...requestedRelatedIds, lookup.primaryConversationId, ...lookup.conversationIds])
      .slice(0, MAX_RELATED_CONVERSATION_IDS);
    if (canonicalKey) await saveConversationLookup(canonicalKey, relatedIds, conversationId);

    const all = [];
    const seenMessageKeys = new Set();

    for (const relatedId of relatedIds) {
      const msgSnap = await db
        .collection("conversations")
        .doc(relatedId)
        .collection("messages")
        .orderBy("timestamp", "desc")
        .limit(MESSAGES_PER_CONVERSATION_LIMIT)
        .get();

      for (const d of msgSnap.docs) {
        const msg = d.data() || {};
        const key = msg.messageSid || `${relatedId}__${d.id}`;
        if (seenMessageKeys.has(key)) continue;
        seenMessageKeys.add(key);
        all.push({ id: d.id, conversationId: relatedId, ...msg });
      }
    }

    all.sort((a, b) => docTimestampMillis(a.timestamp || a.createdAt) - docTimestampMillis(b.timestamp || b.createdAt));
    res.json(all);
  } catch (e) {
    console.error("GET /api/conversations/:id/messages ERROR:", e);
    res.status(500).send("Error leyendo mensajes");
  }
});

app.get("/api/media/:conversationId/:messageId/:index", async (req, res) => {
  try {
    if (!twilioClient) return res.status(500).send("Twilio no configurado");

    const { conversationId, messageId, index } = req.params;
    const convoId = decodeURIComponent(conversationId);
    const msgId = decodeURIComponent(messageId);
    const mediaIndex = Number(index || 0);

    if (Number.isNaN(mediaIndex) || mediaIndex < 0) return res.status(400).send("Índice de media inválido");

    const msgRef = db.collection("conversations").doc(convoId).collection("messages").doc(msgId);
    const msgSnap = await msgRef.get();
    if (!msgSnap.exists) return res.status(404).send("Mensaje no encontrado");

    const msg = msgSnap.data() || {};
    const media = Array.isArray(msg.media) ? msg.media : [];
    const item = media[mediaIndex];
    if (!item || !item.url) return res.status(404).send("Adjunto no encontrado");

    if (String(item.source || "").toLowerCase() === "gcs") {
      const response = await fetch(item.url);
      if (!response.ok) return res.status(response.status).send("No se pudo leer media");
      const contentType = item.contentType || response.headers.get("content-type") || "application/octet-stream";
      res.setHeader("Content-Type", contentType);
      res.setHeader("Cache-Control", "private, max-age=300");
      const arrayBuffer = await response.arrayBuffer();
      return res.send(Buffer.from(arrayBuffer));
    }

    const response = await fetch(item.url, {
      headers: {
        Authorization: "Basic " + Buffer.from(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`).toString("base64"),
      },
    });

    if (!response.ok) {
      const txt = await response.text();
      return res.status(response.status).send(txt || "No se pudo leer media");
    }

    const contentType = item.contentType || response.headers.get("content-type") || "application/octet-stream";
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "private, max-age=300");
    const arrayBuffer = await response.arrayBuffer();
    return res.send(Buffer.from(arrayBuffer));
  } catch (e) {
    console.error("GET /api/media ERROR:", e);
    return res.status(500).send("Error obteniendo adjunto");
  }
});

app.post("/api/conversations/:id/mode", async (req, res) => {
  try {
    const conversationId = decodeURIComponent(req.params.id);
    const mode = normalizeMode(req.body?.mode);
    await db.collection("conversations").doc(conversationId).set({ mode, modeUpdatedAt: FieldValue.serverTimestamp() }, { merge: true });
    res.json({ ok: true, mode });
  } catch (e) {
    console.error("POST /api/conversations/:id/mode ERROR:", e);
    res.status(500).send("Error actualizando modo");
  }
});

app.post("/api/conversations/:id/send", async (req, res) => {
  try {
    if (!twilioClient) return res.status(500).send("Twilio no configurado");

    const conversationId = decodeURIComponent(req.params.id);
    const text = String(req.body?.text || "").trim();
    const mediaUrls = Array.isArray(req.body?.mediaUrls) ? req.body.mediaUrls.map((x) => String(x || "").trim()).filter(Boolean) : [];
    if (!text && !mediaUrls.length) return res.status(400).send("Falta text o mediaUrls");

    const convoRef = db.collection("conversations").doc(conversationId);
    const convoSnap = await convoRef.get();
    if (!convoSnap.exists) return res.status(404).send("Conversación no encontrada");

    const convo = convoSnap.data() || {};
    const mode = normalizeMode(convo.mode);
    if (mode !== "HUMAN") return res.status(409).send("La conversación no está en modo HUMAN");

    const from = ensureWhatsappPrefix(convo.inboundTo || TWILIO_WHATSAPP_FROM);
    const to = ensureWhatsappPrefix(convo.waFrom);
    if (!from || !to) return res.status(500).send("Falta from o to");

    const sent = await sendWhatsappMessage({ from, to, body: text, mediaUrls, statusCallback: buildStatusCallbackUrl(req) });

    await saveMessage(convoRef, sent.sid, {
      direction: "OUT",
      text,
      source: "human",
      timestamp: FieldValue.serverTimestamp(),
      from,
      to,
      messageSid: sent.sid,
      numMedia: mediaUrls.length,
      media: normalizeMediaArray(mediaUrls.map((url) => ({ url, source: "gcs" }))),
      deliveryStatus: sent.status || "queued",
    });

    await convoRef.set({
      lastMessageAt: FieldValue.serverTimestamp(),
      lastMessagePreview: buildLastPreview(text, mediaUrls.length),
      updatedAt: FieldValue.serverTimestamp(),
      lastDeliveryStatus: sent.status || "queued",
      lastMessageDirection: "OUT",
      lastHumanMessageAt: FieldValue.serverTimestamp(),
      hasUnread: false,
      unreadCount: 0,
    }, { merge: true });
    res.json({ ok: true, sid: sent.sid });
  } catch (e) {
    console.error("POST /api/conversations/:id/send ERROR:", e);
    res.status(500).send("Error enviando mensaje");
  }
});

app.post("/api/conversations/:id/send-file", async (req, res) => {
  try {
    if (!twilioClient) return res.status(500).send("Twilio no configurado");

    const conversationId = decodeURIComponent(req.params.id);
    const contentType = req.headers["content-type"] || "";
    if (!contentType.toLowerCase().includes("multipart/form-data")) return res.status(400).send("Content-Type inválido");

    const parsed = await new Promise((resolve, reject) => {
      const bb = Busboy({ headers: req.headers, limits: { fileSize: 15 * 1024 * 1024, files: 1 } });
      let text = "";
      let fileData = null;
      let finished = false;

      bb.on("field", (name, value) => {
        if (name === "text") text = String(value || "").trim();
      });

      bb.on("file", (name, file, info) => {
        const { filename, mimeType } = info;
        const chunks = [];
        let totalSize = 0;
        file.on("data", (chunk) => { chunks.push(chunk); totalSize += chunk.length; });
        file.on("limit", () => reject(new Error("El archivo supera el tamaño máximo permitido")));
        file.on("end", () => {
          fileData = {
            fieldname: name,
            originalname: filename || "archivo",
            mimetype: mimeType || "application/octet-stream",
            buffer: Buffer.concat(chunks),
            size: totalSize,
          };
        });
      });

      bb.on("error", (err) => reject(err));
      bb.on("finish", () => {
        if (finished) return;
        finished = true;
        resolve({ text, file: fileData });
      });

      if (req.rawBody) bb.end(req.rawBody);
      else req.pipe(bb);
    });

    const text = String(parsed.text || "").trim();
    const uploadedFile = parsed.file || null;
    if (!text && !uploadedFile) return res.status(400).send("Falta texto o archivo");

    const convoRef = db.collection("conversations").doc(conversationId);
    const convoSnap = await convoRef.get();
    if (!convoSnap.exists) return res.status(404).send("Conversación no encontrada");

    const convo = convoSnap.data() || {};
    const mode = normalizeMode(convo.mode);
    if (mode !== "HUMAN") return res.status(409).send("La conversación no está en modo HUMAN");

    const from = ensureWhatsappPrefix(convo.inboundTo || TWILIO_WHATSAPP_FROM);
    const to = ensureWhatsappPrefix(convo.waFrom);
    if (!from || !to) return res.status(500).send("Falta from o to");

    const allowedMimeTypes = ["application/pdf", "image/jpeg", "image/png", "image/webp", "audio/ogg", "audio/mpeg", "audio/mp3", "audio/aac", "audio/mp4", "audio/webm"];
    let media = [];

    if (uploadedFile) {
      if (!allowedMimeTypes.includes(uploadedFile.mimetype)) return res.status(400).send("Tipo de archivo no permitido");

      let fileToUpload = uploadedFile;
      if (isAudioMime(uploadedFile.mimetype)) {
        fileToUpload = await convertAudioToWhatsappMp3({
          buffer: uploadedFile.buffer,
          mimeType: uploadedFile.mimetype,
          originalName: uploadedFile.originalname,
        });
      }

      const uploaded = await uploadBufferToGCS({
        buffer: fileToUpload.buffer,
        mimeType: fileToUpload.mimetype,
        originalName: fileToUpload.originalname,
        folder: "whatsapp-out"
      });
      media.push(uploaded);
    }

    const mediaUrls = media.map((m) => m.url);
    const sent = await sendWhatsappMessage({ from, to, body: text, mediaUrls, statusCallback: buildStatusCallbackUrl(req) });

    await saveMessage(convoRef, sent.sid, {
      direction: "OUT",
      text,
      source: "human",
      timestamp: FieldValue.serverTimestamp(),
      from,
      to,
      messageSid: sent.sid,
      numMedia: media.length,
      media,
      deliveryStatus: sent.status || "queued",
    });

    await convoRef.set({
      lastMessageAt: FieldValue.serverTimestamp(),
      lastMessagePreview: buildLastPreview(text, media.length),
      updatedAt: FieldValue.serverTimestamp(),
      lastDeliveryStatus: sent.status || "queued",
      lastMessageDirection: "OUT",
      lastHumanMessageAt: FieldValue.serverTimestamp(),
      hasUnread: false,
      unreadCount: 0,
    }, { merge: true });
    res.json({ ok: true, sid: sent.sid, mediaCount: media.length });
  } catch (e) {
    console.error("POST /api/conversations/:id/send-file ERROR:", e);
    res.status(500).send(e?.message || "Error enviando archivo");
  }
});

app.post("/api/conversations/:id/send-template", async (req, res) => {
  try {
    if (!twilioClient) return res.status(500).send("Twilio no configurado");

    const conversationId = decodeURIComponent(req.params.id);
    const contentSid = String(req.body?.contentSid || "").trim();
    const contentVariables = req.body?.contentVariables || {};
    if (!contentSid) return res.status(400).send("Falta contentSid");

    const convoRef = db.collection("conversations").doc(conversationId);
    const convoSnap = await convoRef.get();
    if (!convoSnap.exists) return res.status(404).send("Conversación no encontrada");

    const convo = convoSnap.data() || {};
    const mode = normalizeMode(convo.mode);
    if (mode !== "HUMAN") return res.status(409).send("La conversación no está en modo HUMAN");

    const from = ensureWhatsappPrefix(convo.inboundTo || TWILIO_WHATSAPP_FROM);
    const to = ensureWhatsappPrefix(convo.waFrom);
    if (!from || !to) return res.status(500).send("Falta from o to");

    const sent = await sendWhatsappTemplate({ from, to, contentSid, contentVariables, statusCallback: buildStatusCallbackUrl(req) });
    const preview = `Plantilla enviada (${contentSid})`;

    await saveMessage(convoRef, sent.sid, {
      direction: "OUT",
      text: preview,
      source: "human-template",
      timestamp: FieldValue.serverTimestamp(),
      from,
      to,
      messageSid: sent.sid,
      numMedia: 0,
      media: [],
      template: { contentSid, contentVariables },
      lineId: cleanWhatsappNumber(from),
      inboundTo: from,
      deliveryStatus: sent.status || "queued",
    });

    await convoRef.set({
      lastMessageAt: FieldValue.serverTimestamp(),
      lastMessagePreview: preview,
      updatedAt: FieldValue.serverTimestamp(),
      lastDeliveryStatus: sent.status || "queued",
      lastMessageDirection: "OUT",
      lastHumanMessageAt: FieldValue.serverTimestamp(),
      hasUnread: false,
      unreadCount: 0,
    }, { merge: true });
    res.json({ ok: true, sid: sent.sid, contentSid });
  } catch (e) {
    console.error("POST /api/conversations/:id/send-template ERROR:", e);
    res.status(500).send(e?.message || "Error enviando plantilla");
  }
});

app.post("/api/start-template", async (req, res) => {
  try {
    if (!twilioClient) return res.status(500).send("Twilio no configurado");

    const rawTo = String(req.body?.to || "").trim();
    const contentSid = String(req.body?.contentSid || "").trim();
    const contentVariables = req.body?.contentVariables || {};
    const contactName = String(req.body?.contactName || "").trim();

    const requestedLineRaw = String(
      req.body?.lineId ||
      req.body?.inboundTo ||
      ""
    ).trim();

    const lineSource = req.body?.lineId
      ? "lineId"
      : (req.body?.inboundTo ? "inboundTo" : "default");

    if (!rawTo) return res.status(400).send("Falta to");
    if (!contentSid) return res.status(400).send("Falta contentSid");

    const to = ensureWhatsappPrefix(rawTo);
    const outboundLine = normalizeOutboundLineForTwilio(requestedLineRaw || TWILIO_WHATSAPP_FROM);
    const from = ensureWhatsappPrefix(outboundLine);
    if (!from || !to) return res.status(500).send("Falta from o to");

    const resolvedConversation = await resolveConversationRef(to, from);
    const conversationId = resolvedConversation.id;
    const convoRef = resolvedConversation.ref;
    const existingConversation = resolvedConversation.snap && resolvedConversation.snap.exists
      ? (resolvedConversation.snap.data() || {})
      : {};

    const sent = await sendWhatsappTemplate({ from, to, contentSid, contentVariables, statusCallback: buildStatusCallbackUrl(req) });
    const preview = `Plantilla enviada (${contentSid})`;

    const conversationExists = !!(resolvedConversation.snap && resolvedConversation.snap.exists);
    const conversationPatch = {
      waFrom: existingConversation.waFrom || to,
      inboundTo: existingConversation.inboundTo || from,
      lineId: existingConversation.lineId || cleanWhatsappNumber(from),
      lineSource,
      requestedLineId: cleanWhatsappNumber(requestedLineRaw || ""),
      contactName: existingConversation.contactName || contactName || cleanWhatsappNumber(to),
      mode: "HUMAN",
      mergedLookupCandidates: resolvedConversation.candidateIds || [],
      reusedExistingConversation: !!resolvedConversation.reusedExisting,
      lastMessageAt: FieldValue.serverTimestamp(),
      lastMessagePreview: preview,
      updatedAt: FieldValue.serverTimestamp(),
      lastDeliveryStatus: sent.status || "queued",
      lastMessageDirection: "OUT",
      lastHumanMessageAt: FieldValue.serverTimestamp(),
    };

    // SAFE MERGE:
    // If the conversation already exists, do not overwrite commercial/source fields
    // from the original inbound lead. Only update operational last-message fields.
    if (!conversationExists) {
      Object.assign(conversationPatch, {
        stage: "nuevo",
        sourceChannel: "outbound-template",
        hasUnread: false,
        unreadCount: 0,
      });
    }

    await convoRef.set(conversationPatch, { merge: true });
    await saveConversationLookup(
      getConversationCanonicalKey({ waFrom: to, inboundTo: from }, conversationId),
      [conversationId],
      conversationId
    );

    await saveMessage(convoRef, sent.sid, {
      direction: "OUT",
      text: preview,
      source: "human-template",
      timestamp: FieldValue.serverTimestamp(),
      from,
      to,
      messageSid: sent.sid,
      numMedia: 0,
      media: [],
      template: { contentSid, contentVariables },
      deliveryStatus: sent.status || "queued",
    });

    res.json({
      ok: true,
      conversationId,
      sid: sent.sid,
      lineRequested: cleanWhatsappNumber(requestedLineRaw || ""),
      lineUsed: cleanWhatsappNumber(from),
      inboundTo: from,
      lineSource,
      reusedExistingConversation: !!resolvedConversation.reusedExisting,
      mergedLookupCandidates: resolvedConversation.candidateIds || []
    });
  } catch (e) {
    console.error("POST /api/start-template ERROR:", e);
    res.status(500).send(e?.message || "Error iniciando conversación");
  }
});

functions.http("helloHttp", app);
