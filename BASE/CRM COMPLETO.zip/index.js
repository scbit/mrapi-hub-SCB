// =====================================================
// CRM SCB - INDEX ORGANIZADO (v8)
// Reordenado visualmente en subbloques internos.
// No cambia rutas ni lógica.
// =====================================================

// =====================================================
// BLOQUE 1 - CONFIG / HELPERS
// =====================================================

// =====================================================
// BLOQUE 1A - LIBRERÍAS
// =====================================================
const functions = require("@google-cloud/functions-framework");
const express = require("express");
const cors = require("cors");
const admin = require("firebase-admin");
const { Storage } = require("@google-cloud/storage");
const { getFirestore } = require("firebase-admin/firestore");
const crypto = require("crypto");
const https = require("https");

// =====================================================
// BLOQUE 1B - FIREBASE / STORAGE / APP
// =====================================================

if (!admin.apps.length) {
  admin.initializeApp();
}

const db = getFirestore(admin.app(), "bscrmscb");
const dbInbox = getFirestore(admin.app(), "bsscb");
const HUB_BASE_URL =
  process.env.HUB_BASE_URL ||
  "https://hub.sentirecustomsbroker.com";
const CORE_BASE_URL =
  process.env.CORE_BASE_URL ||
  process.env.HUB_CORE_BASE_URL ||
  "https://hub.sentirecustomsbroker.com";
const app = express();
const gcs = new Storage();

const DESK_BASE_URL = String(
  process.env.DESK_BASE_URL || "https://scb-desk-604957912671.us-central1.run.app"
).replace(/\/$/, "");
const DESK_SSO_SECRET = String(process.env.DESK_SSO_SECRET || "").trim();
const DESK_SSO_TTL_SECONDS = Math.max(15, Math.min(Number(process.env.DESK_SSO_TTL_SECONDS || 60), 300));

// MRAPI WhatsApp — alerta automática cuando un trato entra a Horno.
const MRAPI_WHATSAPP_BASE_URL = String(
  process.env.MRAPI_WHATSAPP_BASE_URL || "https://mrapi-wp-604957912671.us-central1.run.app"
).replace(/\/$/, "");
const MRAPI_WHATSAPP_SYSTEM_TOKEN = String(process.env.MRAPI_WHATSAPP_SYSTEM_TOKEN || "").trim();

const ATTACHMENTS_BUCKET =
  process.env.ATTACHMENTS_BUCKET ||
  process.env.FILES_BUCKET ||
  process.env.BUCKET_NAME ||
  (process.env.GOOGLE_CLOUD_PROJECT ? `${process.env.GOOGLE_CLOUD_PROJECT}.appspot.com` : "");

const ALLOWED_UPLOAD_TYPES = [
  "application/pdf",
  "image/jpeg",
  "image/png"
];

// =====================================================
// META CONVERSIONS API / CRM LEAD QUALITY
// =====================================================
const META_CAPI_ENABLED = String(process.env.META_CAPI_ENABLED || "false").trim().toLowerCase() === "true";
const META_DATASET_ID = String(process.env.META_DATASET_ID || process.env.META_PIXEL_ID || "").trim();
const META_ACCESS_TOKEN = String(process.env.META_ACCESS_TOKEN || "").trim();
const META_GRAPH_API_VERSION = String(process.env.META_GRAPH_API_VERSION || "v20.0").trim();
const META_TEST_EVENT_CODE = String(process.env.META_TEST_EVENT_CODE || "").trim();
const META_LEAD_EVENTS_COLLECTION = "meta_lead_events";

app.use(cors());
app.use(express.json({ limit: "15mb" }));

app.use((req, res, next) => {
  res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.set("Pragma", "no-cache");
  res.set("Expires", "0");
  res.set("Surrogate-Control", "no-store");
  next();
});


// =====================================================
// CAPA MOBILE / PWA (aislada, sin modificar lógica existente)
// =====================================================
const MOBILE_UI_CSS = String.raw`
:root{--scb-blue:#1a73e8;--scb-blue-dark:#1558b0;--scb-bg:#f5f7fb;--scb-text:#111827;--scb-muted:#667085;--scb-border:#e5e7eb;--scb-safe-bottom:env(safe-area-inset-bottom,0px)}
html{-webkit-text-size-adjust:100%;scroll-behavior:smooth}
body{color:var(--scb-text);padding-bottom:0}
button,input,select,textarea{font-size:16px;touch-action:manipulation}
button{min-height:42px}
.scb-mobile-nav,.scb-mobile-menu-button,.scb-mobile-overlay{display:none}
.scb-install-hint{display:none}
@media(max-width:780px){
  body{padding-bottom:calc(72px + var(--scb-safe-bottom))!important;overflow-x:hidden}
  body.scb-login-page{padding-bottom:0!important}
  .topbar{position:sticky!important;top:0;z-index:800;padding:11px 14px!important;min-height:54px;box-shadow:0 2px 12px rgba(0,0,0,.12)}
  .topbar>div:first-child{font-size:15px;max-width:72%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .topbar>div:last-child{display:none!important}
  .container{padding:12px!important;width:auto!important;max-width:none!important}
  .box,.card{border-radius:14px!important;padding:15px!important;margin-bottom:12px!important;box-shadow:0 2px 12px rgba(16,24,40,.08)!important}
  h1{font-size:24px}h2{font-size:20px;margin:5px 0 12px}h3{font-size:17px}
  .cards{grid-template-columns:1fr 1fr!important;gap:10px!important;margin-top:12px!important}
  .cards .card{min-height:90px!important;padding:14px!important}
  .cards .card h3{margin:0 0 6px;font-size:15px}.cards .card p{font-size:12px;margin:0;color:var(--scb-muted)}
  .grid,.grid2,.grid3,.row,.filters,.template-row,.summary,.modal-grid,.customDates{grid-template-columns:1fr!important;gap:10px!important}
  .toolbar,.actions,.row-actions,.tabs{gap:8px!important}
  .toolbar>*{max-width:none!important;width:100%!important}
  .tabs{display:grid!important;grid-template-columns:1fr 1fr!important}
  .tabs button{width:100%!important;padding:9px 7px!important;font-size:13px!important}
  input,select,textarea{min-height:44px!important;padding:11px!important}
  textarea{min-height:92px!important}
  .actions>button,.row-actions>button{flex:1 1 auto}
  .mini-btn{min-height:38px!important}
  .modalBack,.modal-bg{padding:0!important;align-items:flex-end!important}
  .modal{max-width:none!important;width:100%!important;max-height:92dvh!important;border-radius:20px 20px 0 0!important;padding-bottom:calc(12px + var(--scb-safe-bottom))!important}
  .modalBody{padding:14px!important}.modalHead{padding:14px 16px!important}
  table{box-shadow:none!important;background:transparent!important}
  table thead{display:none!important}
  table tbody,table tr,table td{display:block!important;width:100%!important;box-sizing:border-box}
  table tr{background:#fff;border:1px solid var(--scb-border);border-radius:14px;margin-bottom:10px;padding:9px 12px;box-shadow:0 1px 5px rgba(16,24,40,.05)}
  table td{border:0!important;border-bottom:1px solid #f0f2f5!important;padding:9px 0!important;min-height:32px;overflow-wrap:anywhere}
  table td:last-child{border-bottom:0!important}
  table td[data-label]::before{content:attr(data-label);display:block;font-size:11px;line-height:1.2;font-weight:700;text-transform:uppercase;letter-spacing:.03em;color:#667085;margin-bottom:4px}
  .contacts-table-wrap{max-height:none!important;overflow:visible!important}
  .deal-chip-list{min-width:0!important}.deal-chip{max-width:100%!important}
  .item{grid-template-columns:1fr!important;padding:12px!important}.item .actions{margin-top:8px}
  .group-head{padding:11px!important}
  .metric{padding:11px!important}.metric .value{font-size:20px!important}
  .search-input{max-width:none!important}

  /* Pipeline móvil: usa lista vertical y evita el Kanban comprimido */
  body.scb-pipeline-page .layout{display:block!important}
  body.scb-pipeline-page .sidebar{width:auto!important;min-width:0!important;position:static!important}
  body.scb-pipeline-page .main{width:100%!important;min-width:0!important}
  body.scb-pipeline-page .kanban-scroll,body.scb-pipeline-page #kanbanView{display:none!important}
  body.scb-pipeline-page #btnKanban{display:none!important}
  body.scb-pipeline-page #btnLista{width:100%!important}
  body.scb-pipeline-page .view-buttons{display:block!important;margin-bottom:10px!important}
  body.scb-pipeline-page #listView{display:block!important;width:100%!important;min-width:0!important}
  body.scb-pipeline-page #listView>table{width:100%!important;table-layout:fixed!important}
  body.scb-pipeline-page #listView table tr{padding:12px!important;overflow:hidden!important}
  body.scb-pipeline-page #listView table td{max-width:100%!important;overflow:hidden!important}
  body.scb-pipeline-page #listView select,body.scb-pipeline-page #listView input,body.scb-pipeline-page #listView textarea{max-width:100%!important;width:100%!important}
  body.scb-pipeline-page #listView .value-edit-wrap,body.scb-pipeline-page #listView .type-edit-wrap,body.scb-pipeline-page #listView .upload-row{display:grid!important;grid-template-columns:1fr!important}
  body.scb-pipeline-page #listView .value-input,body.scb-pipeline-page #listView .inline-select{width:100%!important}
  body.scb-pipeline-page .bulk-actions{display:none!important}
  body.scb-pipeline-page .pipeline-summary{grid-template-columns:1fr!important}
  body.scb-pipeline-page .scb-pipeline-toggle{display:flex;width:100%;justify-content:space-between;align-items:center;background:#fff;color:var(--scb-blue);border:1px solid var(--scb-blue);margin-bottom:10px;font-weight:800}
  body.scb-pipeline-page .scb-pipeline-collapsible.scb-collapsed{display:none!important}
  body.scb-pipeline-page .scb-mobile-menu-button{right:14px;bottom:calc(76px + var(--scb-safe-bottom));width:44px;height:44px}
  body.scb-pipeline-page .actions{padding-bottom:2px}
  body.scb-pipeline-page .actions>button{min-width:0!important}
  body.scb-pipeline-page #mobileStageFilterWrap{display:block!important;background:#eef4ff;border:1px solid #cfe0ff;border-radius:12px;padding:12px;margin-bottom:14px}
  body.scb-pipeline-page #mobileStageFilterWrap .deal-label{font-size:13px;font-weight:800;color:#174ea6;margin-bottom:7px}
  body.scb-pipeline-page #mobileStageFilter{font-weight:700;border-color:#1a73e8;background:#fff}

  .scb-mobile-menu-button{display:flex;position:fixed;right:14px;bottom:calc(84px + var(--scb-safe-bottom));width:48px;height:48px;border-radius:50%;z-index:910;align-items:center;justify-content:center;background:var(--scb-blue);color:#fff;border:0;box-shadow:0 5px 18px rgba(26,115,232,.4);font-size:22px;padding:0;min-height:0}
  .scb-mobile-overlay{position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:920;align-items:flex-end;padding:12px 12px calc(84px + var(--scb-safe-bottom));box-sizing:border-box}
  .scb-mobile-overlay.open{display:flex}
  .scb-mobile-sheet{background:#fff;border-radius:18px;width:100%;max-height:70vh;overflow:auto;padding:12px;box-shadow:0 15px 50px rgba(0,0,0,.25)}
  .scb-mobile-sheet-title{font-weight:800;padding:6px 8px 12px}
  .scb-mobile-sheet-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .scb-mobile-sheet a{display:flex;align-items:center;gap:8px;padding:12px 10px;border-radius:11px;background:#f7f9fc;color:#1f2937;text-decoration:none;font-weight:700;font-size:13px}
  .scb-mobile-nav{display:flex;position:fixed;left:0;right:0;bottom:0;height:calc(64px + var(--scb-safe-bottom));padding:4px 6px var(--scb-safe-bottom);background:rgba(255,255,255,.97);border-top:1px solid var(--scb-border);z-index:900;box-shadow:0 -4px 16px rgba(16,24,40,.09);box-sizing:border-box;backdrop-filter:blur(10px)}
  .scb-mobile-nav a{flex:1;color:#667085;text-decoration:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;font-size:10px;font-weight:700;border-radius:10px}
  .scb-mobile-nav a .ico{font-size:20px;line-height:1}
  .scb-mobile-nav a.active{color:var(--scb-blue);background:#eef4ff}
}
@media(max-width:390px){.cards{grid-template-columns:1fr!important}.scb-mobile-sheet-grid{grid-template-columns:1fr}.scb-mobile-nav a{font-size:9px}}
`;

const MOBILE_UI_JS = String.raw`
(function(){
  if(window.__SCB_MOBILE_UI_LOADED__) return;
  window.__SCB_MOBILE_UI_LOADED__=true;
  var path=window.location.pathname||'/';
  if(path==='/'){document.body.classList.add('scb-login-page');return;}
  function esc(v){return String(v||'').replace(/[&<>\"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[m];});}
  function applyTableLabels(root){
    (root||document).querySelectorAll('table').forEach(function(table){
      var headers=Array.from(table.querySelectorAll('thead th')).map(function(th){return (th.innerText||'').trim();});
      table.querySelectorAll('tbody tr').forEach(function(tr){Array.from(tr.children).forEach(function(td,i){if(headers[i]&&!td.dataset.label)td.dataset.label=headers[i];});});
    });
  }

  function initPipelineMobile(){
    if(path!=='/pipeline'||!window.matchMedia('(max-width:780px)').matches)return;
    document.body.classList.add('scb-pipeline-page');

    function addToggle(target,title,startCollapsed){
      if(!target||target.dataset.scbMobileToggle==='1')return;
      target.dataset.scbMobileToggle='1';
      target.classList.add('scb-pipeline-collapsible');
      var btn=document.createElement('button');
      btn.type='button';btn.className='scb-pipeline-toggle';
      btn.innerHTML='<span>'+esc(title)+'</span><span aria-hidden="true">'+(startCollapsed?'＋':'−')+'</span>';
      target.parentNode.insertBefore(btn,target);
      if(startCollapsed)target.classList.add('scb-collapsed');
      btn.addEventListener('click',function(){
        var collapsed=target.classList.toggle('scb-collapsed');
        btn.lastElementChild.textContent=collapsed?'＋':'−';
      });
    }

    var sidebarBox=document.querySelector('.sidebar>.box');
    addToggle(sidebarBox,'Filtros',true);
    var newDealBox=document.querySelector('.main>.box');
    addToggle(newDealBox,'Nuevo trato',true);

    try{
      if(typeof window.cambiarVista==='function'){
        window.cambiarVista('lista');
      }else{
        var kanban=document.getElementById('kanbanView');
        var list=document.getElementById('listView');
        if(kanban)kanban.style.display='none';
        if(list)list.style.display='block';
      }
    }catch(e){}
  }

  var navItems=[
    {href:'/crm',icon:'⌂',label:'Inicio',match:['/crm']},
    {href:'/contacts',icon:'👤',label:'Contactos',match:['/contacts']},
    {href:'/pipeline',icon:'▦',label:'Tratos',match:['/pipeline']},
    {href:'/agenda',icon:'✓',label:'Tareas',match:['/agenda','/vencimientos']}
  ];
  var nav=document.createElement('nav');nav.className='scb-mobile-nav';nav.setAttribute('aria-label','Navegación móvil');
  nav.innerHTML=navItems.map(function(item){var active=item.match.some(function(p){return path===p||path.indexOf(p+'/')===0;});return '<a href="'+item.href+'" class="'+(active?'active':'')+'"><span class="ico">'+item.icon+'</span><span>'+item.label+'</span></a>';}).join('');
  document.body.appendChild(nav);
  var menuBtn=document.createElement('button');menuBtn.className='scb-mobile-menu-button';menuBtn.type='button';menuBtn.setAttribute('aria-label','Abrir más opciones');menuBtn.innerHTML='☰';document.body.appendChild(menuBtn);
  var overlay=document.createElement('div');overlay.className='scb-mobile-overlay';
  var extra=[['/mi-estado','Mi estado'],['/plan-produccion','Plan de Producción'],['/busqueda-productos','Búsqueda de Productos'],['/conocimiento','Base de Conocimiento'],['/reportes','Reportes / KPI'],['/campanas','Campañas'],['/users','Usuarios'],['/importador','Importador CSV'],['/vencimientos','Vencimientos'],['/crm','Panel principal']];
  overlay.innerHTML='<div class="scb-mobile-sheet"><div class="scb-mobile-sheet-title">Más opciones</div><div class="scb-mobile-sheet-grid">'+extra.map(function(x){return '<a href="'+x[0]+'">'+esc(x[1])+'</a>';}).join('')+'<a href="#" id="scbMobileLogout">Cerrar sesión</a></div></div>';
  document.body.appendChild(overlay);
  menuBtn.addEventListener('click',function(){overlay.classList.add('open');});
  overlay.addEventListener('click',function(e){if(e.target===overlay)overlay.classList.remove('open');});
  var logout=overlay.querySelector('#scbMobileLogout');if(logout)logout.addEventListener('click',function(e){e.preventDefault();localStorage.removeItem('crmscb_user');window.location.href='/';});
  try{
    var currentUser=JSON.parse(localStorage.getItem('crmscb_user')||'{}');
    if(String(currentUser.role||'').trim().toLowerCase()!=='admin'){
      document.querySelectorAll('a[href="/vencimientos"]').forEach(function(link){link.remove();});
    }
  }catch(e){}
  initPipelineMobile();
  applyTableLabels(document);
  var observer=new MutationObserver(function(mutations){var should=false;mutations.forEach(function(m){if(m.addedNodes&&m.addedNodes.length)should=true;});if(should)applyTableLabels(document);});
  observer.observe(document.body,{childList:true,subtree:true});
  if('serviceWorker' in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register('/sw.js').catch(function(){});});}
})();
`;

app.get('/mobile.css', (req, res) => {
  res.type('text/css').set('Cache-Control', 'public, max-age=300').send(MOBILE_UI_CSS);
});

app.get('/mobile.js', (req, res) => {
  res.type('application/javascript').set('Cache-Control', 'public, max-age=300').send(MOBILE_UI_JS);
});

app.get('/manifest.webmanifest', (req, res) => {
  res.type('application/manifest+json').send({
    name: 'CRM SCB', short_name: 'CRM SCB', start_url: '/crm', display: 'standalone',
    background_color: '#f5f7fb', theme_color: '#1a73e8',
    description: 'CRM comercial de Sentire Customs Broker'
  });
});

app.get('/sw.js', (req, res) => {
  res.type('application/javascript').set('Cache-Control', 'no-cache').send(
    "const C='crmscb-mobile-v5';self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(C).then(c=>c.addAll(['/mobile.css','/mobile.js','/manifest.webmanifest'])))});self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;const u=new URL(e.request.url);if(u.pathname==='/mobile.css'||u.pathname==='/mobile.js'||u.pathname==='/manifest.webmanifest'){e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));}});"
  );
});

app.use((req, res, next) => {
  const originalSend = res.send.bind(res);
  res.send = function(body) {
    if (typeof body === 'string' && /<!DOCTYPE html>|<html/i.test(body)) {
      if (!body.includes('/manifest.webmanifest')) {
        body = body.replace(/<head([^>]*)>/i, '<head$1><meta name="theme-color" content="#1a73e8"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="default"><link rel="manifest" href="/manifest.webmanifest"><link rel="stylesheet" href="/mobile.css?v=8">');
      }
      if (!body.includes('/mobile.js')) {
        body = body.replace(/<\/body>/i, '<script src="/mobile.js?v=9" defer><\/script><script src="/production.js?v=9" defer><\/script><script src="/production-teams.js?v=9" defer><\/script></body>');
      }
    }
    return originalSend(body);
  };
  next();
});

// =====================================================
// BLOQUE 1C - CONSTANTES DEL CRM
// =====================================================

const PIPELINE_STAGES = [
  "Nuevos Prospectos",
  "No responde",
  "Seguimiento",
  "Marca personal",
  "Esperando PI",
  "Para cotizar",
  "Cotizado para enviar",
  "Horno",
  "Pendiente de pago",
  "Ganado courier",
  "Ganado maritimo",
  "Perdido",
  "Descartado",
  "Buscar Producto",
  "Busqueda en Proceso",
  "REVISAR ZOHO",
  "SEGUIMIENTO ZOHO",
  "Base Importadores",
  "RECUPERO ZOHO",
];



const DEAL_TYPES = [
  "LCL_PROPIO",
  "LCL_CONVENCIONAL",
  "FCL",
  "AEREO_COURIER",
  "AEREO_CARGA"
];

const DEAL_TYPE_LABELS = {
  LCL_PROPIO: "LCL Propio",
  LCL_CONVENCIONAL: "LCL Convencional",
  FCL: "FCL",
  AEREO_COURIER: "Aéreo Courier",
  AEREO_CARGA: "Aéreo Carga"
};

const LEAD_QUALITY_VALUES = [
  "DESCARTADO",
  "NO_RESPONDE",
  "REGULAR",
  "BUENO",
  "EXCELENTE"
];

const LEAD_QUALITY_LABELS = {
  DESCARTADO: "Descartado",
  NO_RESPONDE: "No Responde",
  REGULAR: "Regular",
  BUENO: "Bueno",
  EXCELENTE: "Excelente"
};

const KPI_PERIOD_TYPES = ["weekly", "monthly"];
const NOTE_SAVE_DEDUP_WINDOW_MS = 15000;

// =====================================================
// BLOQUE 1D - HELPERS GENERALES
// =====================================================

function esc(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function sanitizeFilename(filename) {
  return String(filename || "archivo")
    .replace(/[^a-zA-Z0-9._-]/g, "_")
    .replace(/_+/g, "_")
    .slice(0, 120);
}

function makeId(prefix) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

function base64UrlEncode(value) {
  return Buffer.from(String(value), "utf8").toString("base64url");
}

function createDeskSsoToken(user) {
  if (!DESK_SSO_SECRET) throw new Error("Falta configurar DESK_SSO_SECRET");
  const now = Math.floor(Date.now() / 1000);
  const payload = {
    sub: String(user.id || ""),
    email: String(user.email || "").trim().toLowerCase(),
    name: String(user.name || ""),
    role: normalizeRole(user.role),
    iat: now,
    exp: now + DESK_SSO_TTL_SECONDS,
    nonce: crypto.randomBytes(12).toString("hex")
  };
  const encodedPayload = base64UrlEncode(JSON.stringify(payload));
  const signature = crypto.createHmac("sha256", DESK_SSO_SECRET).update(encodedPayload).digest("base64url");
  return `${encodedPayload}.${signature}`;
}

function getBucket() {
  if (!ATTACHMENTS_BUCKET) {
    throw new Error("No está configurado ATTACHMENTS_BUCKET, FILES_BUCKET ni BUCKET_NAME");
  }
  return gcs.bucket(ATTACHMENTS_BUCKET);
}

function timestampToMillis(value) {
  if (!value) return 0;
  if (typeof value.toMillis === "function") return Number(value.toMillis() || 0);
  if (value instanceof Date) return Number(value.getTime() || 0);
  if (typeof value._seconds === "number") return Number(value._seconds * 1000);
  if (typeof value.seconds === "number") return Number(value.seconds * 1000);
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? 0 : parsed.getTime();
}

const CRM_STATS_COLLECTION = "stats";
const CRM_STATS_DOC_ID = "totals";

function getStatsRef() {
  return db.collection(CRM_STATS_COLLECTION).doc(CRM_STATS_DOC_ID);
}

async function getStoredTotal(statKey, fallbackCollectionName) {
  const cleanKey = String(statKey || "").trim();
  if (!cleanKey) return 0;

  const statsRef = getStatsRef();
  const statsSnap = await statsRef.get();
  const statsData = statsSnap.exists ? (statsSnap.data() || {}) : {};
  const currentValue = Number(statsData[cleanKey]);

  if (Number.isFinite(currentValue) && currentValue >= 0) {
    return Math.floor(currentValue);
  }

  const countSnap = await db.collection(String(fallbackCollectionName || "")).count().get();
  const computed = Number((countSnap && countSnap.data && countSnap.data().count) || 0);

  await statsRef.set({
    [cleanKey]: computed,
    updatedAt: new Date()
  }, { merge: true });

  return computed;
}

async function incrementStoredTotal(statKey, delta) {
  const cleanKey = String(statKey || "").trim();
  const safeDelta = Number(delta || 0);
  if (!cleanKey || !Number.isFinite(safeDelta) || !safeDelta) return;

  await getStatsRef().set({
    [cleanKey]: admin.firestore.FieldValue.increment(safeDelta),
    updatedAt: new Date()
  }, { merge: true });
}

const USERS_LIST_CACHE_TTL_MS = 30 * 1000;
let USERS_LIST_CACHE = {
  expiresAt: 0,
  data: null
};

async function getUsersList(forceFresh = false) {
  const now = Date.now();
  if (!forceFresh && USERS_LIST_CACHE.data && USERS_LIST_CACHE.expiresAt > now) {
    return USERS_LIST_CACHE.data;
  }

  const snapshot = await db.collection("users").get();
  const users = snapshot.docs.map((doc) => {
    const data = doc.data() || {};
    return {
      id: doc.id,
      name: data.name || "",
      email: data.email || "",
      password: data.password || "",
      role: data.role || "",
      teamLeaderId: data.teamLeaderId || ""
    };
  });

  USERS_LIST_CACHE = {
    expiresAt: now + USERS_LIST_CACHE_TTL_MS,
    data: users
  };

  return users;
}


async function syncOwnerForContactAndDeals(contactId, owner) {
  const normalizedOwner = typeof owner === "string" ? owner : "";
  const batch = db.batch();

  const contactRef = db.collection("contacts").doc(contactId);
  batch.update(contactRef, { owner: normalizedOwner, updatedAt: new Date() });

  const dealsSnapshot = await db.collection("deals").where("contactId", "==", contactId).get();
  dealsSnapshot.docs.forEach((doc) => {
    batch.update(doc.ref, { owner: normalizedOwner, updatedAt: new Date() });
  });

  await batch.commit();
  return { updatedDeals: dealsSnapshot.size };
}

/// =====================================================
// BLOQUE 1E - HELPERS DE ROLES / PERMISOS
// =====================================================

function normalizeRole(role) {
  const value = String(role || "").trim().toLowerCase();
  if (value === "admin") return "admin";
  if (value === "backoffice") return "backoffice";
  if (value === "team_leader") return "team_leader";
  if (value === "field_sales") return "field_sales";
  return "field_sales";
}

function normalizeDealType(value) {
  const clean = String(value || "").trim().toUpperCase();
  if (DEAL_TYPES.includes(clean)) return clean;
  return "LCL_PROPIO";
}

function getDealTypeLabel(value) {
  const normalized = normalizeDealType(value);
  return DEAL_TYPE_LABELS[normalized] || normalized;
}

function normalizeLeadQuality(value) {
  const clean = String(value || "").trim().toUpperCase();
  if (LEAD_QUALITY_VALUES.includes(clean)) return clean;
  const textKey = normalizeTextKey(value || "").replace(/\s+/g, "_");
  if (textKey === "descartado") return "DESCARTADO";
  if (textKey === "no_responde" || textKey === "no_respuesta") return "NO_RESPONDE";
  if (textKey === "regular") return "REGULAR";
  if (textKey === "bueno") return "BUENO";
  if (textKey === "excelente") return "EXCELENTE";
  return "NO_RESPONDE";
}

function getLeadQualityLabel(value) {
  const normalized = normalizeLeadQuality(value);
  return LEAD_QUALITY_LABELS[normalized] || normalized;
}

function getMetaEventNameForLeadQuality(leadQuality) {
  const quality = normalizeLeadQuality(leadQuality);
  if (quality === "BUENO" || quality === "EXCELENTE") return "QualifiedLead";
  if (quality === "DESCARTADO" || quality === "NO_RESPONDE") return "DisqualifiedLead";
  return "";
}

function isMetaLeadQualityReportable(leadQuality) {
  return !!getMetaEventNameForLeadQuality(leadQuality);
}

function normalizeMetaHashInput(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}

function sha256Meta(value) {
  const clean = normalizeMetaHashInput(value);
  if (!clean) return "";
  return crypto.createHash("sha256").update(clean).digest("hex");
}

function normalizePhoneForMeta(value) {
  return String(value || "").replace(/[^0-9]/g, "").trim();
}

function splitNameForMeta(fullName) {
  const parts = String(fullName || "").trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return { firstName: "", lastName: "" };
  if (parts.length === 1) return { firstName: parts[0], lastName: "" };
  return { firstName: parts[0], lastName: parts.slice(1).join(" ") };
}

function makeMetaLeadEventId(dealId, eventName, leadQuality) {
  return ["scb", "lead_quality", dealId, eventName, normalizeLeadQuality(leadQuality)]
    .map((part) => String(part || "").replace(/[^a-zA-Z0-9_-]/g, "_"))
    .filter(Boolean)
    .join("_")
    .slice(0, 240);
}

function postJsonHttps(urlString, payload, headers = {}) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(urlString);
    } catch (error) {
      reject(error);
      return;
    }

    const body = JSON.stringify(payload || {});
    const req = https.request({
      protocol: parsed.protocol,
      hostname: parsed.hostname,
      port: parsed.port || 443,
      path: `${parsed.pathname}${parsed.search}`,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(body),
        ...headers
      },
      timeout: 15000
    }, (res) => {
      let raw = "";
      res.setEncoding("utf8");
      res.on("data", (chunk) => { raw += chunk; });
      res.on("end", () => {
        let data = raw;
        try { data = raw ? JSON.parse(raw) : {}; } catch (error) {}
        resolve({ statusCode: res.statusCode, data, raw });
      });
    });

    req.on("timeout", () => req.destroy(new Error("Timeout enviando evento a Meta")));
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

async function buildHornoHubUrl(dealId, deal) {
  const storedConversationId = String((deal && deal.conversationId) || "").trim();
  if (storedConversationId) {
    return `${HUB_BASE_URL}/?conversationId=${encodeURIComponent(storedConversationId)}`;
  }

  try {
    const conversationsSnap = await dbInbox
      .collection("conversations")
      .where("dealId", "==", String(dealId || ""))
      .limit(20)
      .get();

    if (!conversationsSnap.empty) {
      const conversations = conversationsSnap.docs.map((doc) => ({
        id: doc.id,
        ...(doc.data() || {})
      }));
      conversations.sort((a, b) => (getDocCreatedAtMillis(b) || 0) - (getDocCreatedAtMillis(a) || 0));
      const conversationId = String((conversations[0] && conversations[0].id) || "").trim();
      if (conversationId) {
        return `${HUB_BASE_URL}/?conversationId=${encodeURIComponent(conversationId)}`;
      }
    }
  } catch (error) {
    console.error("ERROR buscando link HUB para alerta Horno:", error.message || error);
  }

  return HUB_BASE_URL;
}

async function sendCrmHornoWhatsAppAlert(dealId, deal, actorUser) {
  if (!MRAPI_WHATSAPP_SYSTEM_TOKEN) {
    return { ok: false, skipped: true, reason: "missing_MRAPI_WHATSAPP_SYSTEM_TOKEN" };
  }

  const hubUrl = await buildHornoHubUrl(dealId, deal);
  const payload = {
    usuario: String((actorUser && (actorUser.name || actorUser.email)) || "Usuario CRM").trim(),
    trato: String((deal && deal.title) || "Trato sin nombre").trim(),
    cliente: String((deal && (deal.contactName || deal.clientName || deal.company)) || "Cliente sin nombre").trim(),
    hubUrl
  };

  try {
    const result = await postJsonHttps(
      `${MRAPI_WHATSAPP_BASE_URL}/api/system/alerts/crm-horno`,
      payload,
      { Authorization: `Bearer ${MRAPI_WHATSAPP_SYSTEM_TOKEN}` }
    );

    const ok = result.statusCode >= 200 && result.statusCode < 300 && (!result.data || result.data.ok !== false);
    if (!ok) {
      console.error("MRAPI WhatsApp rechazó alerta Horno:", result.statusCode, result.data || result.raw);
    }
    return {
      ok,
      statusCode: result.statusCode,
      response: result.data,
      hubUrl
    };
  } catch (error) {
    console.error("ERROR enviando alerta Horno a MRAPI WhatsApp:", error.message || error);
    return { ok: false, error: error.message || String(error), hubUrl };
  }
}

function formatDealValueForWhatsApp(value) {
  const amount = Number(value || 0);
  return `USD ${amount.toLocaleString("es-AR", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

async function getDealOwnerDisplayName(deal) {
  const ownerEmail = String((deal && deal.owner) || "").trim().toLowerCase();
  if (!ownerEmail) return "Dueño sin asignar";

  try {
    const users = await getUsersList();
    const ownerUser = users.find((user) => String(user.email || "").trim().toLowerCase() === ownerEmail);
    return String((ownerUser && (ownerUser.name || ownerUser.email)) || ownerEmail).trim();
  } catch (error) {
    console.error("ERROR resolviendo dueño del trato para WhatsApp:", error.message || error);
    return ownerEmail;
  }
}

async function sendCrmCotizadoParaEnviarWhatsAppAlert(dealId, deal, actorUser) {
  if (!MRAPI_WHATSAPP_SYSTEM_TOKEN) {
    return { ok: false, skipped: true, reason: "missing_MRAPI_WHATSAPP_SYSTEM_TOKEN" };
  }

  const hubUrl = await buildHornoHubUrl(dealId, deal);
  const ownerDisplayName = await getDealOwnerDisplayName(deal);
  const payload = {
    // La plantilla conserva el campo "usuario", pero ahora recibe al dueño del trato,
    // no al usuario que movió la etapa (habitualmente Backoffice/Thiago).
    usuario: ownerDisplayName,
    trato: String((deal && deal.title) || "Trato sin nombre").trim(),
    cliente: String((deal && (deal.contactName || deal.clientName || deal.company)) || "Cliente sin nombre").trim(),
    valorTrato: formatDealValueForWhatsApp(deal && deal.value),
    hubUrl
  };

  try {
    const result = await postJsonHttps(
      `${MRAPI_WHATSAPP_BASE_URL}/api/system/alerts/crm-cotizado-para-enviar`,
      payload,
      { Authorization: `Bearer ${MRAPI_WHATSAPP_SYSTEM_TOKEN}` }
    );

    const ok = result.statusCode >= 200 && result.statusCode < 300 && (!result.data || result.data.ok !== false);
    if (!ok) {
      console.error("MRAPI WhatsApp rechazó alerta Cotizado para enviar:", result.statusCode, result.data || result.raw);
    }
    return {
      ok,
      statusCode: result.statusCode,
      response: result.data,
      hubUrl
    };
  } catch (error) {
    console.error("ERROR enviando alerta Cotizado para enviar a MRAPI WhatsApp:", error.message || error);
    return { ok: false, error: error.message || String(error), hubUrl };
  }
}

async function sendMetaLeadQualityEventForDeal(dealId, leadQuality, actorUser) {
  const quality = normalizeLeadQuality(leadQuality);
  const eventName = getMetaEventNameForLeadQuality(quality);
  if (!eventName) {
    return { ok: true, skipped: true, reason: "quality_not_reportable", leadQuality: quality };
  }

  const cleanDealId = String(dealId || "").trim();
  if (!cleanDealId) return { ok: false, skipped: true, reason: "missing_deal_id" };

  const eventId = makeMetaLeadEventId(cleanDealId, eventName, quality);
  const logRef = db.collection(META_LEAD_EVENTS_COLLECTION).doc(eventId);
  const existingLog = await logRef.get();
  if (existingLog.exists) {
    const existing = existingLog.data() || {};
    if (existing.status === "sent") {
      return { ok: true, skipped: true, reason: "already_sent", eventId, eventName, leadQuality: quality };
    }
  }

  const dealSnap = await db.collection("deals").doc(cleanDealId).get();
  if (!dealSnap.exists) return { ok: false, skipped: true, reason: "deal_not_found", eventId, eventName, leadQuality: quality };
  const deal = dealSnap.data() || {};
  const contactId = String(deal.contactId || "").trim();

  let contact = {};
  if (contactId) {
    const contactSnap = await db.collection("contacts").doc(contactId).get();
    if (contactSnap.exists) contact = contactSnap.data() || {};
  }

  const phone = normalizePhoneForMeta(contact.phone || deal.phone || "");
  const email = String(contact.email || deal.email || "").trim().toLowerCase();
  const fullName = contact.name || deal.contactName || "";
  const nameParts = splitNameForMeta(fullName);
  const province = contact.province || deal.province || "";

  const userData = {
    external_id: [sha256Meta(contactId || cleanDealId)],
    client_user_agent: "SCB CRM"
  };
  if (phone) userData.ph = [sha256Meta(phone)];
  if (email) userData.em = [sha256Meta(email)];
  if (nameParts.firstName) userData.fn = [sha256Meta(nameParts.firstName)];
  if (nameParts.lastName) userData.ln = [sha256Meta(nameParts.lastName)];
  if (province) userData.st = [sha256Meta(province)];
  userData.country = [sha256Meta("ar")];

  const metaLeadId = String(deal.metaLeadId || deal.facebookLeadId || contact.metaLeadId || contact.facebookLeadId || "").trim();
  if (metaLeadId) userData.lead_id = metaLeadId;

  const event = {
    event_name: eventName,
    event_time: Math.floor(Date.now() / 1000),
    event_id: eventId,
    action_source: "system_generated",
    user_data: userData,
    custom_data: {
      lead_quality: quality,
      lead_quality_label: getLeadQualityLabel(quality),
      crm_event_source: "SCB_CRM",
      deal_id: cleanDealId,
      contact_id: contactId,
      owner: String(deal.owner || ""),
      stage: String(deal.stage || ""),
      currency: "USD",
      value: Number(deal.value || 0) || 0
    }
  };

  const baseLog = {
    dealId: cleanDealId,
    contactId,
    leadQuality: quality,
    leadQualityLabel: getLeadQualityLabel(quality),
    eventName,
    eventId,
    owner: String(deal.owner || ""),
    stage: String(deal.stage || ""),
    createdBy: actorUser ? String(actorUser.email || actorUser.id || "") : "",
    updatedAt: new Date()
  };

  if (!META_CAPI_ENABLED) {
    await logRef.set({ ...baseLog, status: "disabled", skipped: true, reason: "META_CAPI_ENABLED_false", createdAt: new Date() }, { merge: true });
    return { ok: true, skipped: true, reason: "META_CAPI_ENABLED_false", eventId, eventName, leadQuality: quality };
  }

  if (!META_DATASET_ID || !META_ACCESS_TOKEN) {
    await logRef.set({ ...baseLog, status: "config_missing", skipped: true, reason: "missing_META_DATASET_ID_or_META_ACCESS_TOKEN", createdAt: new Date() }, { merge: true });
    return { ok: false, skipped: true, reason: "missing_META_DATASET_ID_or_META_ACCESS_TOKEN", eventId, eventName, leadQuality: quality };
  }

  const payload = { data: [event] };
  if (META_TEST_EVENT_CODE) payload.test_event_code = META_TEST_EVENT_CODE;

  const url = `https://graph.facebook.com/${encodeURIComponent(META_GRAPH_API_VERSION)}/${encodeURIComponent(META_DATASET_ID)}/events?access_token=${encodeURIComponent(META_ACCESS_TOKEN)}`;

  try {
    const response = await postJsonHttps(url, payload);
    const ok = response.statusCode >= 200 && response.statusCode < 300 && !(response.data && response.data.error);
    await logRef.set({
      ...baseLog,
      status: ok ? "sent" : "error",
      sentAt: ok ? new Date() : null,
      createdAt: existingLog.exists ? (existingLog.data() || {}).createdAt || new Date() : new Date(),
      metaStatusCode: response.statusCode,
      metaResponse: response.data || response.raw || null
    }, { merge: true });
    return { ok, skipped: false, eventId, eventName, leadQuality: quality, statusCode: response.statusCode, metaResponse: response.data };
  } catch (error) {
    await logRef.set({
      ...baseLog,
      status: "error",
      createdAt: existingLog.exists ? (existingLog.data() || {}).createdAt || new Date() : new Date(),
      error: error.message || String(error)
    }, { merge: true });
    return { ok: false, skipped: false, eventId, eventName, leadQuality: quality, error: error.message || String(error) };
  }
}

function emptyLeadQualityCounts() {
  return LEAD_QUALITY_VALUES.reduce((acc, quality) => {
    acc[quality] = 0;
    return acc;
  }, {});
}

function buildLeadQualityOptions(selectedValue) {
  const current = normalizeLeadQuality(selectedValue || "NO_RESPONDE");
  return LEAD_QUALITY_VALUES.map((quality) => {
    const selected = quality === current ? " selected" : "";
    return `<option value="${esc(quality)}"${selected}>${esc(getLeadQualityLabel(quality))}</option>`;
  }).join("");
}

function buildDealTypeOptions(selectedValue) {
  const current = normalizeDealType(selectedValue || "LCL_PROPIO");
  return DEAL_TYPES.map((type) => {
    const selected = type === current ? " selected" : "";
    return `<option value="${esc(type)}"${selected}>${esc(getDealTypeLabel(type))}</option>`;
  }).join("");
}

function emptyDealTypeTargets() {
  return {
    LCL_PROPIO: 0,
    LCL_CONVENCIONAL: 0,
    FCL: 0,
    AEREO_COURIER: 0,
    AEREO_CARGA: 0
  };
}

function sanitizeTargets(input) {
  const base = emptyDealTypeTargets();
  const source = input && typeof input === "object" ? input : {};
  DEAL_TYPES.forEach((type) => {
    const raw = source[type];
    const n = Number(raw || 0);
    base[type] = Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
  });
  return base;
}

function sumTargets(targets) {
  const safe = sanitizeTargets(targets || {});
  return DEAL_TYPES.reduce((acc, type) => acc + Number(safe[type] || 0), 0);
}

function normalizePeriodType(value) {
  const clean = String(value || "").trim().toLowerCase();
  return clean === "monthly" ? "monthly" : "weekly";
}

function isAdmin(user) {
  return normalizeRole(user && user.role) === "admin";
}

function isBackoffice(user) {
  return normalizeRole(user && user.role) === "backoffice";
}

function isTeamLeader(user) {
  return normalizeRole(user && user.role) === "team_leader";
}

function isFieldSales(user) {
  return normalizeRole(user && user.role) === "field_sales";
}

function isSeller(user) {
  return isTeamLeader(user) || isFieldSales(user);
}

async function getUserById(userId) {
  const cleanId = String(userId || "").trim();
  if (!cleanId) return null;
  const doc = await db.collection("users").doc(cleanId).get();
  if (!doc.exists) return null;
  return { id: doc.id, ...(doc.data() || {}) };
}

async function getFieldSalesByLeader(teamLeaderId) {
  const cleanLeaderId = String(teamLeaderId || "").trim();
  if (!cleanLeaderId) return [];
  const snap = await db.collection("users")
    .where("role", "==", "field_sales")
    .where("teamLeaderId", "==", cleanLeaderId)
    .get();

  return snap.docs.map((doc) => ({ id: doc.id, ...(doc.data() || {}) }));
}

async function getVisibleOwnerEmails(user) {
  if (!user) return [];

  if (isAdmin(user) || isBackoffice(user)) {
    return null;
  }

  if (isFieldSales(user)) {
    return [String(user.email || "").trim().toLowerCase()].filter(Boolean);
  }

  if (isTeamLeader(user)) {
    const fieldSales = await getFieldSalesByLeader(user.id);
    const emails = [
      String(user.email || "").trim().toLowerCase(),
      ...fieldSales.map((item) => String(item.email || "").trim().toLowerCase())
    ].filter(Boolean);

    return Array.from(new Set(emails));
  }

  return [String(user.email || "").trim().toLowerCase()].filter(Boolean);
}

async function getAssignableOwnerEmails(user) {
  if (!user) return [];

  if (isAdmin(user) || isBackoffice(user)) {
    const users = await getUsersList();
    return Array.from(new Set(
      users.map((u) => String(u.email || "").trim().toLowerCase()).filter(Boolean)
    ));
  }

  if (isTeamLeader(user)) {
    const fieldSales = await getFieldSalesByLeader(user.id);
    return Array.from(new Set([
      String(user.email || "").trim().toLowerCase(),
      ...fieldSales.map((item) => String(item.email || "").trim().toLowerCase())
    ].filter(Boolean)));
  }

  if (isFieldSales(user)) {
    return [String(user.email || "").trim().toLowerCase()].filter(Boolean);
  }

  return [];
}

async function canAssignOwner(user, targetOwnerEmail) {
  const cleanTarget = String(targetOwnerEmail || "").trim().toLowerCase();
  if (!cleanTarget) return true;

  const assignable = await getAssignableOwnerEmails(user);
  return assignable.includes(cleanTarget);
}

async function canSeeOwner(user, ownerEmail) {
  if (isAdmin(user) || isBackoffice(user)) return true;

  const visibleEmails = await getVisibleOwnerEmails(user);
  if (visibleEmails === null) return true;

  const cleanOwner = String(ownerEmail || "").trim().toLowerCase();
  return visibleEmails.includes(cleanOwner);
}

async function canEditOwner(user, ownerEmail) {
  if (isAdmin(user) || isBackoffice(user)) return true;
  return await canSeeOwner(user, ownerEmail);
}





function normalizeTextKey(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeContactStatus(value) {
  const clean = normalizeTextKey(value);
  if (["lead", "prospecto", "cliente", "inactivo"].includes(clean)) return clean;
  return "lead";
}

function normalizePipelineStage(value) {
  const clean = normalizeTextKey(value);
  const found = PIPELINE_STAGES.find((stage) => normalizeTextKey(stage) === clean);
  return found || "";
}

function detectCsvDelimiter(text) {
  const firstLine = String(text || "").split(/\r?\n/).find((line) => String(line || "").trim());
  if (!firstLine) return ",";
  const commas = (firstLine.match(/,/g) || []).length;
  const semicolons = (firstLine.match(/;/g) || []).length;
  return semicolons > commas ? ";" : ",";
}

function parseCsvText(text) {
  const source = String(text || "").replace(/^\uFEFF/, "");
  const delimiter = detectCsvDelimiter(source);
  const rows = [];
  let row = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    const next = source[i + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === delimiter && !inQuotes) {
      row.push(current);
      current = "";
      continue;
    }

    if ((char === "\n" || char === "\r") && !inQuotes) {
      if (char === "\r" && next === "\n") i += 1;
      row.push(current);
      rows.push(row);
      row = [];
      current = "";
      continue;
    }

    current += char;
  }

  row.push(current);
  rows.push(row);

  const cleaned = rows
    .map((cols) => cols.map((cell) => String(cell || "").trim()))
    .filter((cols) => cols.some((cell) => cell !== ""));

  if (!cleaned.length) return { delimiter, headers: [], records: [] };

  const headers = cleaned[0].map((value) => String(value || "").trim());
  const records = cleaned.slice(1).map((cols, idx) => {
    const record = { __rowNumber: idx + 2 };
    headers.forEach((header, hIdx) => {
      record[header] = typeof cols[hIdx] === "undefined" ? "" : String(cols[hIdx] || "").trim();
    });
    return record;
  });

  return { delimiter, headers, records };
}

function detectMasterImportColumnMap(headers) {
  const headerMap = {};
  (headers || []).forEach((header) => {
    headerMap[normalizeTextKey(header)] = header;
  });

  function pick(...aliases) {
    for (const alias of aliases) {
      const found = headerMap[normalizeTextKey(alias)];
      if (found) return found;
    }
    return "";
  }

  return {
    name: pick("contacto", "nombre", "contact name", "cliente", "contact_name", "name"),
    company: pick("empresa", "company"),
    title: pick("trato", "deal", "oportunidad", "titulo trato", "title", "deal title"),
    stage: pick("etapa", "stage", "estado trato", "pipeline"),
    owner: pick("dueno del contacto", "dueño del contacto", "owner", "propietario", "dueno", "dueño"),
    phone: pick("telefono", "teléfono", "phone", "celular", "whatsapp"),
    email: pick("email", "mail", "correo"),
    province: pick("provincia", "province"),
    contactStatus: pick("estado contacto", "contact status", "status contacto", "contactstatus"),
    dueDate: pick("fecha", "fecha trato", "due date", "vencimiento", "fecha vencimiento"),
    notes: pick("notes", "notas", "observaciones", "comments", "comentarios")
  };
}

function parseImportDate(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
  const matchLatam = raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (matchLatam) {
    const day = String(matchLatam[1]).padStart(2, "0");
    const month = String(matchLatam[2]).padStart(2, "0");
    return `${matchLatam[3]}-${month}-${day}`;
  }
  if (/^\d+(\.\d+)?$/.test(raw)) {
    const excelBase = new Date(Date.UTC(1899, 11, 30));
    excelBase.setUTCDate(excelBase.getUTCDate() + Number(raw));
    return excelBase.toISOString().slice(0, 10);
  }
  const parsed = new Date(raw);
  if (!Number.isNaN(parsed.getTime())) return parsed.toISOString().slice(0, 10);
  return "";
}

function canUseMasterImporter(user) {
  return isAdmin(user) || isBackoffice(user);
}

function buildOwnerLookup(users) {
  const byKey = new Map();
  (users || []).forEach((user) => {
    const email = String(user.email || "").trim().toLowerCase();
    const name = String(user.name || "").trim();
    if (email) byKey.set(normalizeTextKey(email), email);
    if (name) byKey.set(normalizeTextKey(name), email);
  });
  return byKey;
}

function splitRowsForBatch(items, size) {
  const safeSize = Math.max(1, Number(size || 400));
  const chunks = [];
  for (let i = 0; i < items.length; i += safeSize) {
    chunks.push(items.slice(i, i + safeSize));
  }
  return chunks;
}

function normalizeImportPhone(value) {
  return String(value || "").replace(/[^0-9]/g, "").trim();
}

function normalizeImportEmail(value) {
  return String(value || "").trim().toLowerCase();
}

function encodeFirestoreCursor(doc) {
  if (!doc) return "";
  const data = typeof doc.data === "function" ? (doc.data() || {}) : (doc || {});
  const createdAt = data.createdAt;
  let millis = "";
  if (createdAt && typeof createdAt.toMillis === "function") millis = String(createdAt.toMillis());
  else if (createdAt instanceof Date) millis = String(createdAt.getTime());
  else if (createdAt && typeof createdAt._seconds === "number") millis = String(createdAt._seconds * 1000);
  else if (createdAt && typeof createdAt.seconds === "number") millis = String(createdAt.seconds * 1000);
  if (!millis || !doc.id) return "";
  return Buffer.from(JSON.stringify({ millis, id: String(doc.id) })).toString("base64");
}

function decodeFirestoreCursor(cursor) {
  try {
    const raw = Buffer.from(String(cursor || ""), "base64").toString("utf8");
    const parsed = JSON.parse(raw || "{}");
    const millis = Number(parsed.millis || 0);
    const id = String(parsed.id || "").trim();
    if (!millis || !id) return null;
    return {
      createdAt: new Date(millis),
      id
    };
  } catch (error) {
    return null;
  }
}

function encodeIndexFreeDealsCursor(docId) {
  const id = String(docId || "").trim();
  if (!id) return "";
  try {
    return Buffer.from(JSON.stringify({ type: "deals_docid", id })).toString("base64");
  } catch (error) {
    return "";
  }
}

function decodeIndexFreeDealsCursor(cursor) {
  try {
    const raw = Buffer.from(String(cursor || ""), "base64").toString("utf8");
    const parsed = JSON.parse(raw || "{}");
    if (!parsed || parsed.type !== "deals_docid") return null;
    const id = String(parsed.id || "").trim();
    return id ? { id } : null;
  } catch (error) {
    return null;
  }
}


function encodeCompositeFirestoreCursor(cursorMap) {
  try {
    const payload = {
      type: "multi_owner",
      cursors: cursorMap && typeof cursorMap === "object" ? cursorMap : {}
    };
    return Buffer.from(JSON.stringify(payload)).toString("base64");
  } catch (error) {
    return "";
  }
}

function decodeCompositeFirestoreCursor(cursor) {
  try {
    const raw = Buffer.from(String(cursor || ""), "base64").toString("utf8");
    const parsed = JSON.parse(raw || "{}");
    if (!parsed || parsed.type !== "multi_owner" || !parsed.cursors || typeof parsed.cursors !== "object") return null;
    return parsed.cursors;
  } catch (error) {
    return null;
  }
}

function getDocCreatedAtMillis(data) {
  const createdAt = data && data.createdAt;
  if (createdAt && typeof createdAt.toMillis === "function") return Number(createdAt.toMillis() || 0);
  if (createdAt instanceof Date) return Number(createdAt.getTime() || 0);
  if (createdAt && typeof createdAt._seconds === "number") return Number(createdAt._seconds * 1000);
  if (createdAt && typeof createdAt.seconds === "number") return Number(createdAt.seconds * 1000);
  return 0;
}

function compareFirestoreDocsDesc(a, b) {
  const aData = a && typeof a.data === "function" ? (a.data() || {}) : (a || {});
  const bData = b && typeof b.data === "function" ? (b.data() || {}) : (b || {});
  const aMillis = getDocCreatedAtMillis(aData);
  const bMillis = getDocCreatedAtMillis(bData);
  if (aMillis !== bMillis) return bMillis - aMillis;
  const aId = String(a && a.id || "");
  const bId = String(b && b.id || "");
  if (aId === bId) return 0;
  return aId < bId ? 1 : -1;
}

function chunkArray(items, size) {
  const safe = Math.max(1, Number(size || 10));
  const source = Array.isArray(items) ? items : [];
  const out = [];
  for (let i = 0; i < source.length; i += safe) out.push(source.slice(i, i + safe));
  return out;
}

function buildImportedDuplicateName(baseName, existingContacts) {
  const cleanBase = String(baseName || "").trim();
  if (!cleanBase) return "";

  const used = new Set();
  (existingContacts || []).forEach((item) => {
    const candidate = String(item && item.name || "").trim();
    if (candidate) used.add(normalizeTextKey(candidate));
  });

  if (!used.has(normalizeTextKey(cleanBase))) return cleanBase;

  let suffix = 2;
  while (used.has(normalizeTextKey(`${cleanBase} ${suffix}`))) {
    suffix += 1;
  }
  return `${cleanBase} ${suffix}`;
}

function normalizeContactForList(id, data) {
  const source = data && typeof data === "object" ? data : {};
  return {
    id: String(id || "").trim(),
    ...source,
    contactStatus: String(source.contactStatus || "lead").trim().toLowerCase() || "lead",
    dealsCount: Number(source.dealsCount || 0) || 0,
    dealTitles: Array.isArray(source.dealTitles) ? source.dealTitles : [],
    dealLinks: Array.isArray(source.dealLinks) ? source.dealLinks : []
  };
}

function contactMatchesSearch(contact, q) {
  const needle = String(q || "").trim().toLowerCase();
  if (!needle) return true;
  return [
    contact && contact.name,
    contact && contact.company,
    contact && contact.phone,
    contact && contact.email,
    contact && contact.province,
    contact && contact.owner,
    contact && contact.contactStatus
  ].join(" ").toLowerCase().includes(needle);
}

async function enrichContactsPageWithDeals(contacts) {
  const safeContacts = Array.isArray(contacts) ? contacts : [];
  if (!safeContacts.length) return [];

  const ids = Array.from(new Set(
    safeContacts.map((contact) => String(contact && contact.id || "").trim()).filter(Boolean)
  ));

  const dealsMap = new Map();
  ids.forEach((id) => {
    dealsMap.set(id, { count: 0, titles: [], links: [] });
  });

  const chunks = splitRowsForBatch(ids, 10);
  for (const chunk of chunks) {
    if (!chunk.length) continue;
    const snap = await db.collection("deals").where("contactId", "in", chunk).get();
    snap.docs.forEach((doc) => {
      const deal = doc.data() || {};
      const contactId = String(deal.contactId || "").trim();
      if (!contactId) return;
      if (!dealsMap.has(contactId)) {
        dealsMap.set(contactId, { count: 0, titles: [], links: [] });
      }
      const entry = dealsMap.get(contactId);
      entry.count += 1;
      const title = String(deal.title || "").trim();
      if (title) {
        entry.titles.push(title);
        entry.links.push({ id: doc.id, title });
      }
    });
  }

  return safeContacts.map((contact) => {
    const contactId = String(contact && contact.id || "").trim();
    const entry = dealsMap.get(contactId) || { count: 0, titles: [], links: [] };
    const fallbackCount = Number(contact && contact.dealsCount || 0) || 0;
    return {
      ...contact,
      dealsCount: Math.max(entry.count, fallbackCount),
      dealTitles: entry.titles,
      dealLinks: entry.links
    };
  });
}

async function buildMasterImportAnalysis(csvText) {
  const parsed = parseCsvText(csvText);
  const columnMap = detectMasterImportColumnMap(parsed.headers || []);
  const missingColumns = [];
  if (!columnMap.name) missingColumns.push("contacto");
  if (!columnMap.owner) missingColumns.push("dueño del contacto");

  if (missingColumns.length) {
    return {
      ok: false,
      error: `Faltan columnas obligatorias: ${missingColumns.join(", ")}`,
      parsed,
      columnMap
    };
  }

  const users = await getUsersList();
  const ownerLookup = buildOwnerLookup(users);

  const contactsSnap = await db.collection("contacts").get();
  const contactsByName = new Map();
  const contactsByPhone = new Map();
  const contactsByEmail = new Map();
  const allVirtualContacts = [];

  function addMapItem(map, key, value) {
    if (!key) return;
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(value);
  }

  function registerVirtualContact(contact) {
    if (!contact) return;
    allVirtualContacts.push(contact);

    const nameKey = normalizeTextKey(contact.name || "");
    if (nameKey) addMapItem(contactsByName, nameKey, contact);

    const phoneKey = normalizeImportPhone(contact.phone || "");
    if (phoneKey) addMapItem(contactsByPhone, phoneKey, contact);

    const emailKey = normalizeImportEmail(contact.email || "");
    if (emailKey) addMapItem(contactsByEmail, emailKey, contact);
  }

  contactsSnap.docs.forEach((doc) => {
    const data = doc.data() || {};
    registerVirtualContact({ id: doc.id, ...data });
  });

  const dealsSnap = await db.collection("deals").get();
  const dealsByKey = new Map();
  dealsSnap.docs.forEach((doc) => {
    const data = doc.data() || {};
    const dealKey = `${String(data.contactId || "").trim()}__${normalizeTextKey(data.title || "")}__${normalizeTextKey(data.stage || "")}`;
    if (dealKey && String(data.contactId || "").trim()) {
      dealsByKey.set(dealKey, { id: doc.id, ...data });
    }
  });

  function rebuildVirtualContactsByName() {
    const map = new Map();
    allVirtualContacts.forEach((item) => {
      const key = normalizeTextKey(item.name || "");
      if (!key) return;
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(item);
    });
    return map;
  }

  function getContactsByPhone(phone) {
    const key = normalizeImportPhone(phone || "");
    return key ? (contactsByPhone.get(key) || []) : [];
  }

  function getContactsByEmail(email) {
    const key = normalizeImportEmail(email || "");
    return key ? (contactsByEmail.get(key) || []) : [];
  }

  let virtualContactsByName = rebuildVirtualContactsByName();

  const rows = [];
  let tempContactCounter = 1;
  let tempDealCounter = 1;

  for (const rawRow of parsed.records) {
    const rowNumber = rawRow.__rowNumber;
    const name = String(rawRow[columnMap.name] || "").trim();
    const ownerRaw = String(rawRow[columnMap.owner] || "").trim();
    const title = columnMap.title ? String(rawRow[columnMap.title] || "").trim() : "";
    const stageRaw = columnMap.stage ? String(rawRow[columnMap.stage] || "").trim() : "";
    const phone = columnMap.phone ? String(rawRow[columnMap.phone] || "").trim() : "";
    const email = columnMap.email ? String(rawRow[columnMap.email] || "").trim() : "";
    const province = columnMap.province ? String(rawRow[columnMap.province] || "").trim() : "";
    const contactStatus = columnMap.contactStatus ? normalizeContactStatus(rawRow[columnMap.contactStatus] || "") : "lead";
    const dueDate = columnMap.dueDate ? parseImportDate(rawRow[columnMap.dueDate] || "") : "";
    const notes = columnMap.notes ? String(rawRow[columnMap.notes] || "").trim() : "";
    const company = columnMap.company ? String(rawRow[columnMap.company] || "").trim() : "";

    if (!name && !title && !ownerRaw && !stageRaw && !phone && !email && !province && !notes && !company) {
      continue;
    }

    const errors = [];
    if (!name) errors.push("Falta contacto");
    if (!ownerRaw) errors.push("Falta dueño del contacto");

    const ownerEmail = ownerLookup.get(normalizeTextKey(ownerRaw)) || "";
    if (ownerRaw && !ownerEmail) {
      errors.push(`Owner inexistente: ${ownerRaw}`);
    }

    const normalizedStage = title ? normalizePipelineStage(stageRaw) : "";
    if (title && !stageRaw) {
      errors.push("Falta etapa para el trato");
    } else if (title && !normalizedStage) {
      errors.push(`Etapa inválida: ${stageRaw}`);
    }

    const nameKey = normalizeTextKey(name);
    let contactRef = null;
    let contactAction = "none";
    let contactPayload = null;

    if (!errors.length) {
      const phoneMatches = getContactsByPhone(phone);
      const emailMatches = getContactsByEmail(email);
      const matches = virtualContactsByName.get(nameKey) || [];

      let matchedContact = null;

      if (phone && phoneMatches.length === 1) {
        matchedContact = phoneMatches[0];
      } else if (phone && phoneMatches.length > 1) {
        errors.push(`Teléfono ambiguo: ${phone}`);
      } else if (email && emailMatches.length === 1) {
        matchedContact = emailMatches[0];
      } else if (email && emailMatches.length > 1) {
        errors.push(`Email ambiguo: ${email}`);
      } else if (matches.length === 1 && !phone && !email) {
        matchedContact = matches[0];
      }

      if (!errors.length && matchedContact) {
        contactRef = matchedContact;
        const payload = {
          name: String(matchedContact.name || name || "").trim() || name,
          company: company || String(matchedContact.company || "").trim(),
          province: province || String(matchedContact.province || "").trim(),
          phone: phone || String(matchedContact.phone || "").trim(),
          email: email || String(matchedContact.email || "").trim(),
          owner: ownerEmail,
          contactStatus: contactStatus || normalizeContactStatus(matchedContact.contactStatus || "lead")
        };
        const hasChanges =
          String(matchedContact.name || "").trim() !== payload.name ||
          String(matchedContact.company || "").trim() !== payload.company ||
          String(matchedContact.province || "").trim() !== payload.province ||
          String(matchedContact.phone || "").trim() !== payload.phone ||
          String(matchedContact.email || "").trim() !== payload.email ||
          String(matchedContact.owner || "").trim().toLowerCase() !== payload.owner ||
          normalizeContactStatus(matchedContact.contactStatus || "lead") !== payload.contactStatus;

        contactAction = hasChanges ? "update" : "match";
        contactPayload = payload;
        Object.assign(matchedContact, payload);
        virtualContactsByName = rebuildVirtualContactsByName();
      } else if (!errors.length) {
        const tempId = `temp_contact_${tempContactCounter++}`;
        const finalName = buildImportedDuplicateName(name, allVirtualContacts);
        const newContact = {
          id: tempId,
          name: finalName,
          company,
          province,
          phone,
          email,
          owner: ownerEmail,
          contactStatus: contactStatus || "lead",
          __isNew: true
        };
        registerVirtualContact(newContact);
        virtualContactsByName = rebuildVirtualContactsByName();
        contactRef = newContact;
        contactAction = "create";
        contactPayload = {
          name: finalName,
          company,
          province,
          phone,
          email,
          owner: ownerEmail,
          contactStatus: contactStatus || "lead"
        };
      }
    }

    let dealAction = "none";
    let dealPayload = null;
    let dealRef = null;

    if (!errors.length && title) {
      const dealKey = `${String(contactRef.id || "").trim()}__${normalizeTextKey(title)}__${normalizeTextKey(normalizedStage)}`;
      const existingDeal = dealsByKey.get(dealKey);
      const payload = {
        title,
        stage: normalizedStage,
        owner: ownerEmail,
        dueDate,
        notes,
        value: 0,
        dealType: "LCL_PROPIO"
      };

      if (existingDeal) {
        dealAction = "update";
        dealRef = existingDeal;
        dealPayload = payload;
        dealsByKey.set(dealKey, { ...existingDeal, ...payload });
      } else {
        dealAction = "create";
        dealRef = { id: `temp_deal_${tempDealCounter++}`, contactId: contactRef.id };
        dealPayload = payload;
        dealsByKey.set(dealKey, { id: dealRef.id, contactId: contactRef.id, ...payload });
      }
    }

    rows.push({
      rowNumber,
      raw: rawRow,
      status: errors.length ? "error" : "ok",
      errors,
      contact: {
        name,
        owner: ownerEmail,
        action: contactAction,
        refId: contactRef ? contactRef.id : "",
        payload: contactPayload
      },
      deal: {
        title,
        stage: normalizedStage,
        action: dealAction,
        refId: dealRef ? dealRef.id : "",
        payload: dealPayload
      }
    });
  }

  const summary = {
    totalRows: rows.length,
    okRows: rows.filter((row) => row.status === "ok").length,
    errorRows: rows.filter((row) => row.status === "error").length,
    contactsToCreate: rows.filter((row) => row.status === "ok" && row.contact.action === "create").length,
    contactsToUpdate: rows.filter((row) => row.status === "ok" && row.contact.action === "update").length,
    dealsToCreate: rows.filter((row) => row.status === "ok" && row.deal.action === "create").length,
    dealsToUpdate: rows.filter((row) => row.status === "ok" && row.deal.action === "update").length
  };

  return {
    ok: true,
    parsed,
    columnMap,
    rows,
    summary
  };
}

async function commitMasterImportAnalysis(analysis) {
  const okRows = (analysis.rows || []).filter((row) => row.status === "ok");
  const contactOps = new Map();

  okRows.forEach((row) => {
    const refId = String(row.contact && row.contact.refId || "").trim();
    if (!refId || !row.contact || !row.contact.payload) return;
    const existing = contactOps.get(refId) || {
      action: row.contact.action,
      payload: { ...row.contact.payload },
      name: row.contact.name || ""
    };
    existing.action = existing.action === "create" || row.contact.action === "create" ? "create" : row.contact.action;
    existing.payload = { ...existing.payload, ...row.contact.payload };
    contactOps.set(refId, existing);
  });

  const tempContactToRealId = new Map();
  const contactWriteItems = [];

  contactOps.forEach((op, refId) => {
    if (op.action === "create") {
      const ref = db.collection("contacts").doc();
      tempContactToRealId.set(refId, ref.id);
      contactWriteItems.push({
        type: "set",
        ref,
        payload: {
          ...op.payload,
          createdAt: new Date(),
          updatedAt: new Date(),
          convertedToClientAt: op.payload.contactStatus === "cliente" ? new Date() : undefined
        }
      });
    } else if (op.action === "update") {
      contactWriteItems.push({
        type: "update",
        ref: db.collection("contacts").doc(refId),
        payload: {
          ...op.payload,
          updatedAt: new Date(),
          convertedToClientAt: op.payload.contactStatus === "cliente" ? new Date() : undefined
        }
      });
    }
  });

  for (const chunk of splitRowsForBatch(contactWriteItems, 400)) {
    const batch = db.batch();
    chunk.forEach((item) => {
      const payload = { ...item.payload };
      if (typeof payload.convertedToClientAt === "undefined") delete payload.convertedToClientAt;
      if (item.type === "set") batch.set(item.ref, payload);
      else batch.update(item.ref, payload);
    });
    if (chunk.length) await batch.commit();
  }

  const dealOps = new Map();
  okRows.forEach((row) => {
    if (!row.deal || row.deal.action === "none" || !row.deal.payload) return;
    const sourceContactId = String(row.contact && row.contact.refId || "").trim();
    const finalContactId = tempContactToRealId.get(sourceContactId) || sourceContactId;
    const uniqueKey = `${finalContactId}__${normalizeTextKey(row.deal.payload.title || "")}__${normalizeTextKey(row.deal.payload.stage || "")}`;
    dealOps.set(uniqueKey, {
      action: row.deal.action,
      refId: row.deal.refId,
      contactId: finalContactId,
      contactName: row.contact && row.contact.payload ? row.contact.payload.name : row.contact.name,
      payload: { ...row.deal.payload }
    });
  });

  const dealWriteItems = [];
  dealOps.forEach((op) => {
    if (op.action === "create") {
      const ref = db.collection("deals").doc();
      dealWriteItems.push({
        type: "set",
        ref,
        payload: {
          title: op.payload.title || "",
          contactId: op.contactId,
          contactName: op.contactName || "",
          value: 0,
          dueDate: op.payload.dueDate || "",
          stage: op.payload.stage || "No responde",
          dealType: "LCL_PROPIO",
          owner: op.payload.owner || "",
          notes: op.payload.notes || "",
          files: [],
          createdAt: new Date(),
          updatedAt: new Date()
        }
      });
    } else if (op.action === "update") {
      dealWriteItems.push({
        type: "update",
        ref: db.collection("deals").doc(op.refId),
        payload: {
          title: op.payload.title || "",
          contactId: op.contactId,
          contactName: op.contactName || "",
          dueDate: op.payload.dueDate || "",
          stage: op.payload.stage || "No responde",
          owner: op.payload.owner || "",
          notes: op.payload.notes || "",
          updatedAt: new Date()
        }
      });
    }
  });

  for (const chunk of splitRowsForBatch(dealWriteItems, 400)) {
    const batch = db.batch();
    chunk.forEach((item) => {
      if (item.type === "set") batch.set(item.ref, item.payload);
      else batch.update(item.ref, item.payload);
    });
    if (chunk.length) await batch.commit();
  }

  return {
    contactsCreated: contactWriteItems.filter((item) => item.type === "set").length,
    contactsUpdated: contactWriteItems.filter((item) => item.type === "update").length,
    dealsCreated: dealWriteItems.filter((item) => item.type === "set").length,
    dealsUpdated: dealWriteItems.filter((item) => item.type === "update").length
  };
}

// =====================================================
// BLOQUE 1F - HELPERS DE FECHAS / KPI
// =====================================================

function nowInBuenosAiresParts() {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Argentina/Buenos_Aires",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  });
  const parts = fmt.formatToParts(new Date());
  const map = {};
  parts.forEach((p) => {
    if (p.type !== "literal") map[p.type] = p.value;
  });
  return {
    year: Number(map.year),
    month: Number(map.month),
    day: Number(map.day)
  };
}

function getTodayISOInBuenosAires() {
  const p = nowInBuenosAiresParts();
  return `${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
}

function isoToDateUTC(iso) {
  const value = String(iso || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  return new Date(value + "T00:00:00Z");
}

function dateToISOUTC(date) {
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, "0");
  const d = String(date.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function addDaysUTC(date, days) {
  const copy = new Date(date.getTime());
  copy.setUTCDate(copy.getUTCDate() + days);
  return copy;
}

function getISODayOfWeek(date) {
  const jsDay = date.getUTCDay();
  return jsDay === 0 ? 7 : jsDay;
}

function getISOWeekDataFromDate(date) {
  const target = new Date(date.getTime());
  const dayNr = getISODayOfWeek(target);
  target.setUTCDate(target.getUTCDate() + 4 - dayNr);
  const yearStart = new Date(Date.UTC(target.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((target - yearStart) / 86400000) + 1) / 7);
  return {
    year: target.getUTCFullYear(),
    week: weekNo
  };
}

function getISOWeekDataFromISO(iso) {
  const date = isoToDateUTC(iso);
  if (!date) return null;
  return getISOWeekDataFromDate(date);
}

function getWeeklyPeriodFromISO(iso) {
  const date = isoToDateUTC(iso);
  if (!date) return null;
  const dayOfWeek = getISODayOfWeek(date);
  const startDate = addDaysUTC(date, 1 - dayOfWeek);
  const endDate = addDaysUTC(startDate, 6);
  const weekData = getISOWeekDataFromDate(date);
  return {
    periodType: "weekly",
    periodKey: `${weekData.year}-W${String(weekData.week).padStart(2, "0")}`,
    startDate: dateToISOUTC(startDate),
    endDate: dateToISOUTC(endDate)
  };
}

function getMonthlyPeriodFromISO(iso) {
  const date = isoToDateUTC(iso);
  if (!date) return null;
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth();
  const startDate = new Date(Date.UTC(year, month, 1));
  const endDate = new Date(Date.UTC(year, month + 1, 0));
  return {
    periodType: "monthly",
    periodKey: `${year}-${String(month + 1).padStart(2, "0")}`,
    startDate: dateToISOUTC(startDate),
    endDate: dateToISOUTC(endDate)
  };
}

function getPeriodInfo(periodType, refDateIso) {
  const safeDate = /^\d{4}-\d{2}-\d{2}$/.test(String(refDateIso || "")) ? String(refDateIso) : getTodayISOInBuenosAires();
  const normalizedType = normalizePeriodType(periodType);
  if (normalizedType === "monthly") {
    return getMonthlyPeriodFromISO(safeDate);
  }
  return getWeeklyPeriodFromISO(safeDate);
}

function parsePeriodKey(periodType, periodKey) {
  const type = normalizePeriodType(periodType);
  const key = String(periodKey || "").trim();

  if (type === "monthly") {
    const match = key.match(/^(\d{4})-(\d{2})$/);
    if (!match) return null;
    const year = Number(match[1]);
    const month = Number(match[2]);
    if (month < 1 || month > 12) return null;
    const startDate = new Date(Date.UTC(year, month - 1, 1));
    const endDate = new Date(Date.UTC(year, month, 0));
    return {
      periodType: "monthly",
      periodKey: `${year}-${String(month).padStart(2, "0")}`,
      startDate: dateToISOUTC(startDate),
      endDate: dateToISOUTC(endDate)
    };
  }

  const match = key.match(/^(\d{4})-W(\d{2})$/);
  if (!match) return null;
  const year = Number(match[1]);
  const week = Number(match[2]);
  if (week < 1 || week > 53) return null;

  const jan4 = new Date(Date.UTC(year, 0, 4));
  const jan4Day = getISODayOfWeek(jan4);
  const week1Start = addDaysUTC(jan4, 1 - jan4Day);
  const startDate = addDaysUTC(week1Start, (week - 1) * 7);
  const endDate = addDaysUTC(startDate, 6);

  return {
    periodType: "weekly",
    periodKey: `${year}-W${String(week).padStart(2, "0")}`,
    startDate: dateToISOUTC(startDate),
    endDate: dateToISOUTC(endDate)
  };
}

function isDateWithinISO(dateIso, startIso, endIso) {
  const d = String(dateIso || "");
  return !!d && d >= String(startIso || "") && d <= String(endIso || "");
}

function docDateToISO(value) {
  if (!value) return "";
  if (typeof value === "string") {
    const raw = value.trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
    const dt = new Date(raw);
    if (!Number.isNaN(dt.getTime())) return dt.toISOString().slice(0, 10);
    return "";
  }
  if (value instanceof Date) {
    return value.toISOString().slice(0, 10);
  }
  if (typeof value.toDate === "function") {
    const dt = value.toDate();
    if (dt instanceof Date && !Number.isNaN(dt.getTime())) return dt.toISOString().slice(0, 10);
  }
  return "";
}

function buildKpiTargetDocId(userId, periodType, periodKey) {
  return `${String(userId || "").trim()}__${normalizePeriodType(periodType)}__${String(periodKey || "").trim()}`;
}

function canManageKpiTargets(user) {
  return isAdmin(user);
}

function canViewKpiReports(user) {
  return isAdmin(user) || isBackoffice(user) || isSeller(user);
}

function generateSessionToken() {
  return "sess_" + Date.now() + "_" + Math.random().toString(36).slice(2, 18);
}

async function getAuthUserFromRequest(req) {
  const userId = String(
    req.headers["x-user-id"] ||
    req.query.userId ||
    ""
  ).trim();

  const token = String(
    req.headers["x-auth-token"] ||
    req.query.token ||
    ""
  ).trim();

  if (!userId || !token) return null;

  const snap = await db.collection("users").doc(userId).get();
  if (!snap.exists) return null;

  const data = snap.data() || {};
  
const sessions = data.sessions || [];
const validSession = (data.sessionToken && data.sessionToken === token) || sessions.some(s => s.token === token);
if (!validSession) return null;


  return {
    id: snap.id,
    name: data.name || "",
    email: data.email || "",
    role: normalizeRole(data.role),
    password: data.password || ""
  };
}

async function authRequired(req, res, next) {
  try {
    const user = await getAuthUserFromRequest(req);
    if (!user) return res.status(401).json({ ok: false, error: "Sesión inválida o vencida" });
    req.authUser = user;
    return next();
  } catch (error) {
    console.error("ERROR authRequired:", error);
    return res.status(500).json({ ok: false, error: "Error validando sesión" });
  }
}

function adminOnly(req, res, next) {
  if (!req.authUser || !isAdmin(req.authUser)) {
    return res.status(403).json({ ok: false, error: "Acceso exclusivo para administradores" });
  }
  return next();
}


// =====================================================
// BLOQUE 2 - LOGIN
// =====================================================

// =====================================================
// BLOQUE 2A - PÁGINA LOGIN
// =====================================================
app.get("/", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;padding:0}
    .box{width:360px;max-width:92vw;margin:80px auto;background:#fff;padding:30px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08)}
    h2{margin-top:0;text-align:center}
    input{width:100%;padding:12px;margin-bottom:12px;border:1px solid #ccc;border-radius:8px;box-sizing:border-box}
    button{width:100%;padding:12px;border:none;border-radius:8px;background:#1a73e8;color:#fff;font-size:16px;cursor:pointer}
    .error{color:#d93025;margin-top:10px;text-align:center}
  </style>
</head>
<body>
  <div class="box">
    <h2>CRM SCB</h2>
    <input id="email" placeholder="Email" value="admin@scb.com">
    <input id="password" type="password" placeholder="Password" value="123456">
    <button onclick="login()">Entrar</button>
    <div id="msg" class="error"></div>
  </div>

  <div id="taskViewModal" class="modalBack">
    <div class="modal" style="max-width:760px">
      <div class="modalHead">Ver tarea</div>
      <div class="modalBody">
        <div class="box" style="box-shadow:none;border:1px solid #e5e7eb">
          <div id="taskViewContent" class="small">Cargando...</div>
        </div>
      </div>
      <div class="modalFoot">
        <button class="secondary" onclick="closeTaskViewModal()">Cerrar</button>
      </div>
    </div>
  </div>

  <script>
    function getSafeRedirectTarget() {
      const params = new URLSearchParams(window.location.search || "");
      const redirect = String(params.get("redirect") || "").trim();
      if (!redirect) return "/crm";
      if (!redirect.startsWith("/")) return "/crm";
      if (redirect.startsWith("//")) return "/crm";
      return redirect;
    }

    function goToLoginWithRedirect() {
      const target = window.location.pathname + window.location.search;
      window.location.href = "/?redirect=" + encodeURIComponent(target);
    }

    (function autoRedirectIfLoggedIn() {
      const userRaw = localStorage.getItem("crmscb_user");
      if (!userRaw) return;
      window.location.href = getSafeRedirectTarget();
    })();

    async function login() {
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();
      const msg = document.getElementById("msg");
      msg.innerText = "";
      try {
        const r = await fetch("/api/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: email, password: password })
        });
        const data = await r.json();
        if (data.ok) {
          localStorage.setItem("crmscb_user", JSON.stringify(data.user));
          window.location.href = getSafeRedirectTarget();
        } else {
          msg.innerText = data.error || "Login incorrecto";
        }
      } catch (err) {
        msg.innerText = "Error conectando con el servidor";
        console.error(err);
      }
    }
  </script>
</body>
</html>
  `);
});

// BLOQUE 2B - PÁGINA PANEL CRM
// =====================================================

app.get("/crm", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;padding:0}
    .topbar{background:#1a73e8;color:white;padding:16px 24px;display:flex;justify-content:space-between;align-items:center}
    .container{padding:24px}
    .cards{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:20px}
    .card{background:white;padding:20px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08);min-height:100px;cursor:pointer}
    .logout{background:#fff;color:#1a73e8;border:none;padding:10px 16px;border-radius:8px;cursor:pointer;font-weight:bold}
    .muted{color:#666}
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>CRMSCB</strong></div>
    <button class="logout" onclick="logout()">Salir</button>
  </div>

  <div class="container">
    <h2 id="welcome">Bienvenido</h2>
    <p class="muted">Panel inicial del CRM MVP</p>

    <div class="cards">
      <div class="card" onclick="window.location='/contacts'">
        <h3>Contactos</h3>
        <p>Gestionar clientes</p>
      </div>

      <div class="card" onclick="window.location='/pipeline'">
        <h3>Tratos / Pipeline</h3>
        <p>Gestionar oportunidades</p>
      </div>

      <div class="card" id="cardVencimientos" style="display:none" onclick="window.location='/vencimientos'">
        <h3>Seguimientos por Vencimiento</h3>
        <p>Vencidos, hoy y próximos 7 días</p>
      </div>

      <div class="card" onclick="window.location='/agenda'">
        <h3>Agenda Comercial</h3>
        <p>Tareas, vencimientos y seguimiento semanal</p>
      </div>

      <div class="card" id="cardKpi" style="display:none" onclick="window.location='/reportes'">
        <h3>Reportes / KPI</h3>
        <p>Ver objetivos y resultados</p>
      </div>

      <div class="card" id="cardProduction" onclick="window.location='/plan-produccion'">
        <h3>Plan de Producción Comercial</h3>
        <p>Objetivos, m³, escalas y comisiones</p>
      </div>

      <div class="card" onclick="window.location='/mi-estado'">
        <h3>Mi Estado</h3>
        <p>Prioridades, vencidos, horno y leads</p>
      </div>

      <div class="card" id="cardUsers" style="display:none" onclick="window.location='/users'">
        <h3>Usuarios</h3>
        <p>Admin / Backoffice / Vendedores</p>
      </div>

      <div class="card" id="cardImport" style="display:none" onclick="window.location='/importador'">
        <h3>Importador CSV</h3>
        <p>Contactos + tratos desde archivo maestro</p>
      </div>

      <div class="card" onclick="window.location='/busqueda-productos'">
        <h3>Búsqueda de Productos</h3>
        <p>Solicitudes, requisitos y seguimiento con Shenzhen</p>
      </div>

      <div class="card" onclick="window.location='/conocimiento'">
        <h3>Base de Conocimiento SCB</h3>
        <p>Temas, preguntas y respuestas, y capacitaciones</p>
      </div>

      <div class="card" onclick="openDesk()">
        <h3>SCB Desk</h3>
        <p>Tickets, tareas y recordatorios internos</p>
      </div>
    </div>
  </div>

  <script>
    const userRaw = localStorage.getItem("crmscb_user");
    const __originalFetch = window.fetch.bind(window);

    function normalizeRoleFront(role) {
      const value = String(role || "").trim().toLowerCase();
      if (value === "admin") return "admin";
      if (value === "backoffice") return "backoffice";
      if (value === "team_leader") return "team_leader";
      return "field_sales";
    }

    window.fetch = function(url, options) {
      const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
      options = options || {};
      options.headers = Object.assign({}, options.headers || {}, {
        "x-user-id": user.id || "",
        "x-auth-token": user.token || ""
      });
      return __originalFetch(url, options);
    };

    if (!userRaw) {
      window.location.href = "/?redirect=" + encodeURIComponent(window.location.pathname + window.location.search);
    } else {
      const user = JSON.parse(userRaw);
      const role = normalizeRoleFront(user.role);
      document.getElementById("welcome").innerText = "Bienvenido " + (user.name || user.email || "");

      if (role === "admin" || role === "backoffice") {
        document.getElementById("cardKpi").style.display = "block";
        document.getElementById("cardImport").style.display = "block";
      }

      if (role === "admin") {
        document.getElementById("cardUsers").style.display = "block";
        document.getElementById("cardVencimientos").style.display = "block";
      }
    }

    async function openDesk() {
      const deskWindow = window.open("about:blank", "_blank");
      try {
        const r = await fetch("/api/desk/sso", { method: "POST" });
        const data = await r.json();
        if (!r.ok || !data.ok || !data.url) throw new Error(data.error || "No se pudo iniciar SCB Desk");
        if (deskWindow) deskWindow.location.href = data.url;
        else window.location.href = data.url;
      } catch (error) {
        if (deskWindow) deskWindow.close();
        alert(error.message || "No se pudo abrir SCB Desk");
      }
    }

    function logout() {
      localStorage.removeItem("crmscb_user");
      window.location.href = "/";
    }
  </script>
</body>
</html>
  `);
});

// =====================================================
// BLOQUE 2C - PÁGINA IMPORTADOR CSV
// =====================================================

app.get("/importador", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Importador CSV</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;padding:0}
    .topbar{background:#1a73e8;color:white;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
    .topbar-left{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
    .btn{border:none;border-radius:8px;padding:10px 14px;cursor:pointer;font-weight:bold}
    .btn-white{background:#fff;color:#1a73e8}
    .btn-primary{background:#1a73e8;color:#fff}
    .btn-green{background:#128a42;color:#fff}
    .btn:disabled{opacity:.6;cursor:not-allowed}
    .container{padding:24px;max-width:1280px;margin:0 auto}
    .card{background:#fff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.08);padding:20px;margin-bottom:18px}
    .muted{color:#666}
    .row{display:grid;grid-template-columns:1.2fr 1fr;gap:18px}
    .summary{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:16px}
    .metric{background:#f7f9fc;border:1px solid #e3e8f0;border-radius:10px;padding:14px}
    .metric strong{display:block;font-size:22px;margin-top:6px}
    table{width:100%;border-collapse:collapse;margin-top:14px}
    th,td{padding:10px;border-bottom:1px solid #e9edf3;font-size:14px;text-align:left;vertical-align:top}
    th{background:#f8fafc;position:sticky;top:0}
    .ok{color:#128a42;font-weight:bold}
    .error{color:#c62828;font-weight:bold}
    .pill{display:inline-block;padding:4px 8px;border-radius:999px;background:#eef3fb;color:#1a73e8;font-size:12px;font-weight:bold}
    .hidden{display:none}
    .hint{font-size:13px;color:#666;margin-top:8px}
    .danger{color:#c62828}
    .mono{font-family:Consolas,monospace}
    @media (max-width: 980px){.row,.summary{grid-template-columns:1fr}}
  </style>
</head>
<body>
  <div class="topbar">
    <div class="topbar-left">
      <button class="btn btn-white" onclick="window.location='/crm'">← Volver al panel</button>
      <div><strong>Importador CSV maestro</strong></div>
    </div>
    <button class="btn btn-white" onclick="logout()">Salir</button>
  </div>

  <div class="container">
    <div class="card">
      <h2 style="margin-top:0">Archivo maestro</h2>
      <p class="muted">Exportá tu Excel como CSV UTF-8. Columnas mínimas: <span class="mono">contacto, trato, etapa, dueño del contacto</span>.</p>
      <div class="row">
        <div>
          <input id="fileInput" type="file" accept=".csv" />
          <div class="hint">Opcionales admitidas: teléfono, email, provincia, estado contacto, fecha, notas.</div>
        </div>
        <div>
          <button id="btnPreview" class="btn btn-primary" onclick="previewImport()">Previsualizar</button>
          <button id="btnCommit" class="btn btn-green" onclick="commitImport()" disabled>Importar al CRM</button>
        </div>
      </div>
      <div id="msg" style="margin-top:14px"></div>
    </div>

    <div id="summaryCard" class="card hidden">
      <h3 style="margin-top:0">Resumen</h3>
      <div class="summary">
        <div class="metric"><div>Filas analizadas</div><strong id="sumRows">0</strong></div>
        <div class="metric"><div>Filas OK</div><strong id="sumOk">0</strong></div>
        <div class="metric"><div>Filas con error</div><strong id="sumError">0</strong></div>
        <div class="metric"><div>Contactos a crear</div><strong id="sumContactsCreate">0</strong></div>
        <div class="metric"><div>Contactos a actualizar</div><strong id="sumContactsUpdate">0</strong></div>
        <div class="metric"><div>Tratos a crear/actualizar</div><strong id="sumDeals">0</strong></div>
      </div>
      <div id="columnMap" class="hint" style="margin-top:14px"></div>
    </div>

    <div id="tableCard" class="card hidden">
      <h3 style="margin-top:0">Vista previa de filas</h3>
      <div class="hint">Se muestran las primeras 120 filas de la vista previa.</div>
      <div style="overflow:auto;max-height:65vh">
        <table>
          <thead>
            <tr>
              <th>Fila</th>
              <th>Contacto</th>
              <th>Trato</th>
              <th>Etapa</th>
              <th>Owner</th>
              <th>Acción</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody id="previewBody"></tbody>
        </table>
      </div>
    </div>
  </div>

  <script>
    const userRaw = localStorage.getItem("crmscb_user");
    const __originalFetch = window.fetch.bind(window);
    let CURRENT_CSV_TEXT = "";
    let LAST_PREVIEW_OK = false;

    const __ACTION_LOCKS = window.__ACTION_LOCKS || (window.__ACTION_LOCKS = {});
    async function withActionLock(actionKey, callback) {
      const key = String(actionKey || "").trim();
      if (!key) return await callback();
      if (__ACTION_LOCKS[key]) return false;
      __ACTION_LOCKS[key] = true;
      try {
        await callback();
        return true;
      } finally {
        delete __ACTION_LOCKS[key];
      }
    }
    function setButtonBusy(button, busyText, isBusy) {
      if (!button) return;
      if (typeof button.dataset.originalText === "undefined") {
        button.dataset.originalText = button.innerText || button.textContent || "";
      }
      button.disabled = !!isBusy;
      button.innerText = isBusy ? String(busyText || "Guardando...") : String(button.dataset.originalText || "");
    }

    window.fetch = function(url, options) {
      const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
      options = options || {};
      options.headers = Object.assign({}, options.headers || {}, {
        "x-user-id": user.id || "",
        "x-auth-token": user.token || ""
      });
      return __originalFetch(url, options);
    };

    function logout() {
      localStorage.removeItem("crmscb_user");
      window.location.href = "/";
    }

    function normalizeRoleFront(role) {
      const value = String(role || "").trim().toLowerCase();
      if (value === "admin") return "admin";
      if (value === "backoffice") return "backoffice";
      if (value === "team_leader") return "team_leader";
      return "field_sales";
    }

    if (!userRaw) {
      window.location.href = "/?redirect=" + encodeURIComponent(window.location.pathname + window.location.search);
    } else {
      const user = JSON.parse(userRaw);
      const role = normalizeRoleFront(user.role);
      if (!(role === "admin" || role === "backoffice")) {
        alert("No tenés permiso para usar el importador");
        window.location.href = "/crm";
      }
    }

    async function readSelectedFileText() {
      const file = document.getElementById("fileInput").files[0];
      if (!file) throw new Error("Seleccioná un archivo CSV");
      return await file.text();
    }

    function setMessage(html, isError) {
      const el = document.getElementById("msg");
      el.innerHTML = html || "";
      el.className = isError ? "danger" : "";
    }

    function renderPreview(data) {
      const summary = data.summary || {};
      document.getElementById("summaryCard").classList.remove("hidden");
      document.getElementById("tableCard").classList.remove("hidden");
      document.getElementById("sumRows").innerText = summary.totalRows || 0;
      document.getElementById("sumOk").innerText = summary.okRows || 0;
      document.getElementById("sumError").innerText = summary.errorRows || 0;
      document.getElementById("sumContactsCreate").innerText = summary.contactsToCreate || 0;
      document.getElementById("sumContactsUpdate").innerText = summary.contactsToUpdate || 0;
      document.getElementById("sumDeals").innerText = (summary.dealsToCreate || 0) + " / " + (summary.dealsToUpdate || 0);

      const map = data.columnMap || {};
      const lines = [];
      Object.keys(map).forEach((key) => {
        if (map[key]) lines.push('<span class="pill">' + key + ': ' + map[key] + '</span>');
      });
      document.getElementById("columnMap").innerHTML = lines.join(" ");

      const rows = (data.rows || []).slice(0, 120);
      const body = document.getElementById("previewBody");
      body.innerHTML = rows.map((row) => {
        const isOk = row.status === "ok";
        const errors = (row.errors || []).join(" | ");
        const action = [];
        if (row.contact && row.contact.action && row.contact.action !== "none") action.push('Contacto: ' + row.contact.action);
        if (row.deal && row.deal.action && row.deal.action !== "none") action.push('Trato: ' + row.deal.action);
        return '<tr>' +
          '<td>' + row.rowNumber + '</td>' +
          '<td>' + (row.contact && row.contact.name ? row.contact.name : '') + '</td>' +
          '<td>' + (row.deal && row.deal.title ? row.deal.title : '') + '</td>' +
          '<td>' + (row.deal && row.deal.stage ? row.deal.stage : '') + '</td>' +
          '<td>' + (row.contact && row.contact.owner ? row.contact.owner : '') + '</td>' +
          '<td>' + action.join(' | ') + '</td>' +
          '<td class="' + (isOk ? 'ok' : 'error') + '">' + (isOk ? 'OK' : errors || 'Error') + '</td>' +
        '</tr>';
      }).join("");
    }

    async function previewImport() {
      const btnPreview = document.getElementById("btnPreview");
      const btnCommit = document.getElementById("btnCommit");
      await withActionLock("import_preview", async function() {
        setButtonBusy(btnPreview, "Analizando...", true);
        try {
          setMessage("Leyendo archivo...", false);
          btnCommit.disabled = true;
          CURRENT_CSV_TEXT = await readSelectedFileText();
          const r = await fetch("/api/import/master/preview", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ csvText: CURRENT_CSV_TEXT })
          });
          const data = await r.json();
          if (!r.ok || !data.ok) throw new Error(data.error || "No se pudo analizar el CSV");
          renderPreview(data);
          LAST_PREVIEW_OK = true;
          btnCommit.disabled = data.summary && data.summary.okRows > 0 ? false : true;
          setMessage("Vista previa generada correctamente.", false);
        } catch (error) {
          LAST_PREVIEW_OK = false;
          setMessage(error.message || "Error analizando archivo", true);
        } finally {
          setButtonBusy(btnPreview, "Analizando...", false);
        }
      });
    }

    async function commitImport() {
      const btnCommit = document.getElementById("btnCommit");
      await withActionLock("import_commit", async function() {
        setButtonBusy(btnCommit, "Importando...", true);
        try {
          if (!LAST_PREVIEW_OK || !CURRENT_CSV_TEXT) throw new Error("Primero generá la vista previa");
          if (!confirm("¿Querés importar las filas válidas al CRM?")) return;
          setMessage("Importando al CRM...", false);
          const r = await fetch("/api/import/master/commit", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ csvText: CURRENT_CSV_TEXT })
          });
          const data = await r.json();
          if (!r.ok || !data.ok) throw new Error(data.error || "No se pudo importar");
          setMessage(
            'Importación completa. Contactos creados: <strong>' + (data.result.contactsCreated || 0) +
            '</strong> | Contactos actualizados: <strong>' + (data.result.contactsUpdated || 0) +
            '</strong> | Tratos creados: <strong>' + (data.result.dealsCreated || 0) +
            '</strong> | Tratos actualizados: <strong>' + (data.result.dealsUpdated || 0) + '</strong>',
            false
          );
          await previewImport();
        } catch (error) {
          setMessage(error.message || "Error importando archivo", true);
        } finally {
          setButtonBusy(btnCommit, "Importando...", false);
        }
      });
    }
  </script>
</body>
</html>
  `);
});


// =====================================================
// BLOQUE 3 - USERS
// =====================================================

// =====================================================
// BLOQUE 3A - PÁGINA USUARIOS


// =====================================================
// BLOQUE 3A - PÁGINA USUARIOS
// =====================================================
app.get("/users", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Usuarios</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;padding:0}
    .topbar{background:#1a73e8;color:white;padding:16px 24px;display:flex;justify-content:space-between;align-items:center}
    .container{padding:24px;max-width:1200px;margin:0 auto}
    .box{background:#fff;padding:20px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08);margin-bottom:20px}
    .grid{display:grid;grid-template-columns:repeat(5,1fr);gap:12px}
    input,select,button{width:100%;padding:12px;border-radius:8px;box-sizing:border-box}
    input,select{border:1px solid #ccc}
    button{border:none;background:#1a73e8;color:#fff;cursor:pointer}
    .secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}
    table{width:100%;border-collapse:collapse;background:#fff}
    th,td{padding:12px;border-bottom:1px solid #eee;text-align:left;vertical-align:top}
    th{background:#f0f4fb}
    .row-actions{display:flex;gap:8px;flex-wrap:wrap}
    .msg{margin-top:12px;color:#d93025}
    .muted{color:#666;font-size:12px}
    @media (max-width: 980px){
      .grid{grid-template-columns:repeat(2,1fr)}
    }
    @media (max-width: 560px){
      .grid{grid-template-columns:1fr}
    }
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>CRMSCB</strong> / Usuarios</div>
    <div><button class="secondary" onclick="window.location='/campanas'">Campañas</button>
      <button class="secondary" onclick="window.location='/crm'">Volver al panel</button></div>
  </div>

  <div class="container">
    <div class="box" id="userFormBox">
      <h2>Crear usuario</h2>
      <div class="grid">
        <input id="uName" placeholder="Nombre">
        <input id="uEmail" placeholder="Email">
        <input id="uPassword" placeholder="Password">
        <select id="uRole" onchange="toggleTeamLeaderField()">
          <option value="field_sales">Field Sales</option>
          <option value="team_leader">Team Leader</option>
          <option value="backoffice">Backoffice</option>
          <option value="admin">Admin</option>
        </select>
        <select id="uTeamLeaderId" style="display:none;">
          <option value="">Seleccionar Team Leader</option>
        </select>
      </div>
      <div class="muted" id="teamLeaderHelp" style="display:none;margin-top:10px;">
        Si el rol es Field Sales, debés asignarle un Team Leader.
      </div>
      <div style="display:flex;gap:10px;margin-top:12px">
        <button onclick="crearUsuario()">Guardar usuario</button>
      </div>
      <div id="msg" class="msg"></div>
    </div>

    <div class="box">
      <h2>Lista de usuarios</h2>
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Rol</th>
            <th>Team Leader</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody id="usersBody"><tr><td colspan="5">Cargando usuarios...</td></tr></tbody>
      </table>
    </div>
  </div>

  <script>
    const userRaw = localStorage.getItem("crmscb_user");
    if (!userRaw) window.location.href = "/?redirect=" + encodeURIComponent(window.location.pathname + window.location.search);
    const CURRENT_USER = JSON.parse(userRaw || "{}");

    const __originalFetch = window.fetch.bind(window);
    window.fetch = function(url, options) {
      const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
      options = options || {};
      options.headers = Object.assign({}, options.headers || {}, {
        "x-user-id": user.id || "",
        "x-auth-token": user.token || ""
      });
      return __originalFetch(url, options);
    };

    function esAdmin() { return (CURRENT_USER.role || "") === "admin"; }

    if (!esAdmin()) {
      document.getElementById("userFormBox").style.display = "none";
    }

    let USERS = [];
    let PENDING_DUE_SEND = null;
    let ACTIVE_DUE_JOB = null;
    let ACTIVE_DUE_JOB_STOP = false;

    const __ACTION_LOCKS = window.__ACTION_LOCKS || (window.__ACTION_LOCKS = {});
    async function withActionLock(actionKey, callback) {
      const key = String(actionKey || "").trim();
      if (!key) return await callback();
      if (__ACTION_LOCKS[key]) return false;
      __ACTION_LOCKS[key] = true;
      try {
        await callback();
        return true;
      } finally {
        delete __ACTION_LOCKS[key];
      }
    }
    function setButtonBusy(button, busyText, isBusy) {
      if (!button) return;
      if (typeof button.dataset.originalText === "undefined") {
        button.dataset.originalText = button.innerText || button.textContent || "";
      }
      button.disabled = !!isBusy;
      button.innerText = isBusy ? String(busyText || "Guardando...") : String(button.dataset.originalText || "");
    }

    function roleLabel(role) {
      const r = String(role || "").trim().toLowerCase();
      if (r === "admin") return "Admin";
      if (r === "backoffice") return "Backoffice";
      if (r === "team_leader") return "Team Leader";
      if (r === "field_sales") return "Field Sales";
      return r || "-";
    }

    function getTeamLeaderOptions(selectedId) {
      let html = '<option value="">Seleccionar Team Leader</option>';
      USERS
        .filter(function(u) { return (u.role || "") === "team_leader"; })
        .forEach(function(u) {
          const id = u.id || "";
          const label = (u.name || u.email || "") + (u.email ? " (" + u.email + ")" : "");
          html += '<option value="' + id + '"' + (id === (selectedId || "") ? ' selected' : '') + '>' + label + '</option>';
        });
      return html;
    }

    function renderTeamLeaderSelect(selectedId) {
      const select = document.getElementById("uTeamLeaderId");
      select.innerHTML = getTeamLeaderOptions(selectedId || "");
    }

    function toggleTeamLeaderField() {
      const role = document.getElementById("uRole").value || "";
      const show = role === "field_sales";
      document.getElementById("uTeamLeaderId").style.display = show ? "block" : "none";
      document.getElementById("teamLeaderHelp").style.display = show ? "block" : "none";
      if (!show) {
        document.getElementById("uTeamLeaderId").value = "";
      }
    }

    function getUserNameById(userId) {
      const u = USERS.find(function(item) { return item.id === userId; }) || null;
      if (!u) return "";
      return u.name || u.email || "";
    }

    async function fetchUsersCached(forceFresh) {
      const cacheKey = "crmscb_users_cache_v1";
      const now = Date.now();
      if (!forceFresh) {
        try {
          const cached = JSON.parse(sessionStorage.getItem(cacheKey) || "null");
          if (cached && Array.isArray(cached.data) && Number(cached.expiresAt || 0) > now) {
            return cached.data;
          }
        } catch (e) {}
      }
      const r = await fetch("/api/users?ts=" + Date.now());
      const data = await r.json();
      const list = Array.isArray(data) ? data : [];
      try {
        sessionStorage.setItem(cacheKey, JSON.stringify({ expiresAt: now + 30000, data: list }));
      } catch (e) {}
      return list;
    }

    async function cargarUsuarios(forceFresh) {
      try {
        USERS = await fetchUsersCached(!!forceFresh);
        renderTeamLeaderSelect("");

        const body = document.getElementById("usersBody");
        if (!USERS.length) {
          body.innerHTML = '<tr><td colspan="5">No hay usuarios</td></tr>';
          return;
        }

        body.innerHTML = USERS.map(function(u) {
          const teamLeaderName = u.teamLeaderId ? getUserNameById(u.teamLeaderId) : "";
          return '<tr>' +
            '<td>' + (u.name || '') + '</td>' +
            '<td>' + (u.email || '') + '</td>' +
            '<td>' + roleLabel(u.role || '') + '</td>' +
            '<td>' + (teamLeaderName || '-') + '</td>' +
            '<td><div class="row-actions">' +
              (esAdmin()
                ? '<button onclick="editarUsuario(' + "'" + u.id + "'" + ')">Editar</button><button style="background:#d93025" onclick="borrarUsuario(' + "'" + u.id + "'" + ')">Borrar</button>'
                : '') +
            '</div></td>' +
          '</tr>';
        }).join("");
      } catch (err) {
        console.error(err);
      }
      toggleTeamLeaderField();
    }

    async function crearUsuario() {
      const msg = document.getElementById("msg");
      const btn = document.querySelector('#userFormBox button[onclick="crearUsuario()"]');
      await withActionLock("crear_usuario", async function() {
        msg.innerText = "";
        setButtonBusy(btn, "Guardando...", true);

        const name = document.getElementById("uName").value.trim();
        const email = document.getElementById("uEmail").value.trim();
        const password = document.getElementById("uPassword").value.trim();
        const role = document.getElementById("uRole").value;
        const teamLeaderId = document.getElementById("uTeamLeaderId").value || "";

        try {
          const r = await fetch("/api/users", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password, role, teamLeaderId })
          });
          const data = await r.json();

          if (!data.ok) {
            msg.innerText = data.error || "No se pudo crear el usuario";
            return;
          }

          document.getElementById("uName").value = "";
          document.getElementById("uEmail").value = "";
          document.getElementById("uPassword").value = "";
          document.getElementById("uRole").value = "field_sales";
          document.getElementById("uTeamLeaderId").value = "";
          toggleTeamLeaderField();

          await cargarUsuarios(true);
        } catch (err) {
          msg.innerText = "Error conectando con el servidor";
        } finally {
          setButtonBusy(btn, "Guardando...", false);
        }
      });
    }

    async function editarUsuario(id) {
      const u = USERS.find(function(item){ return item.id === id; }) || null;
      if (!u) return;

      const name = prompt("Nombre", u.name || "");
      if (name === null) return;

      const email = prompt("Email", u.email || "");
      if (email === null) return;

      const role = prompt("Rol (admin / backoffice / team_leader / field_sales)", u.role || "field_sales");
      if (role === null) return;

      let teamLeaderId = u.teamLeaderId || "";
      if (String(role).trim().toLowerCase() === "field_sales") {
        const teamLeaderPrompt = prompt("ID del Team Leader", teamLeaderId || "");
        if (teamLeaderPrompt === null) return;
        teamLeaderId = teamLeaderPrompt.trim();
      } else {
        teamLeaderId = "";
      }

      const password = prompt("Password nueva (dejá vacío para mantener)", "");

      try {
        const r = await fetch("/api/users/" + id, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, email, role, password, teamLeaderId })
        });
        const data = await r.json();

        if (!data.ok) {
          alert(data.error || "No se pudo editar el usuario");
          return;
        }

        await cargarUsuarios(true);
      } catch (err) {
        alert("Error conectando con el servidor");
      }
    }

    async function borrarUsuario(id) {
      if (!confirm("¿Seguro que querés borrar este usuario?")) return;

      try {
        const r = await fetch("/api/users/" + id, { method: "DELETE" });
        const data = await r.json();

        if (!data.ok) {
          alert(data.error || "No se pudo borrar el usuario");
          return;
        }

        await cargarUsuarios(true);
      } catch (err) {
        alert("Error conectando con el servidor");
      }
    }

    cargarUsuarios();
  </script>
</body>
</html>
  `);
});


// =====================================================
// BLOQUE 4 - CONTACTS
// =====================================================


// =====================================================
// BLOQUE 4A - PÁGINA CONTACTOS
// =====================================================
app.get("/contacts", (req, res) => {
  const stageOptions = PIPELINE_STAGES.map((stage) => `<option value="${esc(stage)}">${esc(stage)}</option>`).join("");
  const provinceOptions = [
    "",
    "Buenos Aires",
    "CABA",
    "Catamarca",
    "Chaco",
    "Chubut",
    "Córdoba",
    "Corrientes",
    "Entre Ríos",
    "Formosa",
    "Jujuy",
    "La Pampa",
    "La Rioja",
    "Mendoza",
    "Misiones",
    "Neuquén",
    "Río Negro",
    "Salta",
    "San Juan",
    "San Luis",
    "Santa Cruz",
    "Santa Fe",
    "Santiago del Estero",
    "Tierra del Fuego",
    "Tucumán"
  ].map((p) => `<option value="${esc(p)}">${esc(p || "Seleccionar provincia")}</option>`).join("");

  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Contactos</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;padding:0}
    .topbar{background:#1a73e8;color:white;padding:16px 24px;display:flex;justify-content:space-between;align-items:center}
    .container{padding:24px;max-width:1480px;margin:0 auto}
    .box{background:#fff;padding:20px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08);margin-bottom:20px}
    .grid{display:grid;grid-template-columns:repeat(7,1fr);gap:12px}
    .toolbar{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:16px}
    input,select,textarea{width:100%;padding:12px;border:1px solid #ccc;border-radius:8px;box-sizing:border-box;font-family:Arial,sans-serif}
    textarea{min-height:90px;resize:vertical}
    .search-input{max-width:420px}
    button{padding:12px 16px;border:none;border-radius:8px;background:#1a73e8;color:#fff;cursor:pointer}
    .secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}
    .success{background:#188038;color:#fff}
    table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08)}
    .contacts-table-wrap{max-height:60vh;overflow-y:scroll;overflow-x:auto;border-radius:12px;scrollbar-gutter:stable}
    th,td{padding:12px;border-bottom:1px solid #eee;text-align:left;font-size:14px;vertical-align:top}
    th{background:#f0f4fb}
    .actions{display:flex;gap:10px;margin-top:16px;flex-wrap:wrap}
    .msg{margin-top:12px;color:#d93025}
    .row-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
    .mini-btn{padding:8px 10px;font-size:12px;border-radius:8px}
    .mini-select{min-width:160px;padding:8px;border-radius:8px;border:1px solid #ccc}
    .status-badge{display:inline-block;padding:5px 10px;border-radius:999px;font-size:12px;font-weight:bold}
    .status-lead{background:#eef3fb;color:#174ea6}
    .status-prospecto{background:#fff3cd;color:#8a6d3b}
    .status-cliente{background:#e6f4ea;color:#137333}
    .status-inactivo{background:#f1f3f4;color:#5f6368}
    .deal-chip-list{display:flex;flex-direction:column;gap:6px;min-width:220px}
    .deal-chip{display:inline-block;padding:6px 10px;border-radius:999px;background:#eef3fb;color:#174ea6;font-size:12px;font-weight:bold;max-width:260px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-decoration:none;cursor:pointer}
    .deal-chip-empty{font-size:12px;color:#777}
    .modal-bg{position:fixed;inset:0;background:rgba(0,0,0,0.35);display:none;align-items:center;justify-content:center;padding:20px;z-index:999}
    .modal{background:#fff;width:100%;max-width:760px;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,0.2);padding:20px}
    .modal h3{margin-top:0}
    .modal-grid{display:grid;grid-template-columns:2fr 1fr 1fr;gap:12px}
    .modal-msg{margin-top:12px;color:#d93025}
    .muted{color:#666;font-size:13px}
    @media (max-width: 1200px){
      .grid{grid-template-columns:repeat(3,1fr)}
    }
    @media (max-width: 800px){
      .grid{grid-template-columns:repeat(2,1fr)}
    }
    @media (max-width: 560px){
      .grid{grid-template-columns:1fr}
    }
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>CRMSCB</strong> / Contactos</div>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <button class="secondary" onclick="window.location='/pipeline'">Pipeline</button>
      <button class="secondary" onclick="window.location='/pipeline?view=lista'">Tratos</button>
      <button class="secondary" onclick="window.location='/reportes'">Reportes / KPI</button>
      <button class="secondary" onclick="window.location='/crm'">Volver al panel</button>
    </div>
  </div>

  <div class="container">
    <div class="box">
      <h2>Nuevo contacto</h2>
      <div class="grid">
        <input id="name" placeholder="Nombre">
        <input id="company" placeholder="Empresa">
        <input id="phone" placeholder="Teléfono">
        <input id="email" placeholder="Email">
        <select id="province">${provinceOptions}</select>
        <select id="owner"></select>
        <select id="contactStatus">
          <option value="lead">Lead</option>
          <option value="prospecto">Prospecto</option>
          <option value="cliente">Cliente</option>
          <option value="inactivo">Inactivo</option>
        </select>
      </div>
      <div class="actions">
        <button onclick="crearContacto()">Guardar contacto</button>
        <button class="secondary" onclick="limpiarFormulario()">Limpiar</button>
      </div>
      <div id="msg" class="msg"></div>
    </div>

    <div class="box">
      <h2>Filtros</h2>
      <div class="toolbar">
        <input id="contactsSearch" class="search-input" placeholder="Buscar por nombre, empresa, teléfono, email, provincia o owner">
        <select id="filterStatus" style="max-width:220px;">
          <option value="">Todos los estados</option>
          <option value="lead">Lead</option>
          <option value="prospecto">Prospecto</option>
          <option value="cliente">Cliente</option>
          <option value="inactivo">Inactivo</option>
        </select>
        <select id="filterOwner" style="max-width:260px;">
          <option value="">Todos los owners</option>
        </select>
        <button class="secondary" onclick="limpiarBusquedaContactos()">Limpiar filtros</button>
        <div class="muted" id="contactsSummary">Mostrando todos los contactos</div>
      </div>
    </div>

    <h2>Lista de contactos</h2>
    <div class="contacts-table-wrap">
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Empresa</th>
            <th>Provincia</th>
            <th>Teléfono</th>
            <th>Email</th>
            <th>Estado</th>
            <th>Owner</th>
            <th>Tratos</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody id="contactsBody">
          <tr><td colspan="9">Cargando contactos...</td></tr>
        </tbody>
      </table>
    </div>
    <div class="actions" style="justify-content:center;margin-top:14px;">
      <button id="contactsLoadMoreBtn" class="secondary" style="display:none;" onclick="verMasContactos()">Ver 25 más contactos</button>
    </div>
  </div>

  <div class="modal-bg" id="dealModalBg">
    <div class="modal">
      <h3>Crear trato para contacto</h3>
      <div class="actions" style="margin-top:0;margin-bottom:12px">
        <div><strong>Contacto:</strong> <span id="dealContactName"></span></div>
      </div>
      <div class="modal-grid">
        <input id="dealTitle" placeholder="Título del trato">
        <input id="dealValue" type="number" min="0" step="0.01" placeholder="Valor del trato">
        <input id="dealDueDate" type="date">
      </div>
      <div class="actions" style="margin-top:12px">
        <select id="dealStage">${stageOptions}</select>
      </div>
      <div class="actions" style="margin-top:12px">
        <textarea id="dealNotes" placeholder="Notas del trato"></textarea>
      </div>
      <div class="actions">
        <button class="success" onclick="guardarTratoDesdeContacto()">Guardar trato</button>
        <button class="secondary" onclick="cerrarModalTrato()">Cancelar</button>
      </div>
      <div id="dealModalMsg" class="modal-msg"></div>
    </div>
  </div>

  <script>
    const userRaw = localStorage.getItem("crmscb_user");
    if (!userRaw) window.location.href = "/?redirect=" + encodeURIComponent(window.location.pathname + window.location.search);
    const CURRENT_USER = JSON.parse(userRaw || "{}");
    const __originalFetch = window.fetch.bind(window);
    window.fetch = function(url, options) {
      const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
      options = options || {};
      options.headers = Object.assign({}, options.headers || {}, {
        "x-user-id": user.id || "",
        "x-auth-token": user.token || ""
      });
      return __originalFetch(url, options);
    };

    function normalizeRoleFront(role) {
      const value = String(role || "").trim().toLowerCase();
      if (value === "admin") return "admin";
      if (value === "backoffice") return "backoffice";
      if (value === "team_leader") return "team_leader";
      return "field_sales";
    }

    function esAdmin() { return normalizeRoleFront(CURRENT_USER.role) === "admin"; }
    function esBackoffice() { return normalizeRoleFront(CURRENT_USER.role) === "backoffice"; }
    function esSeller() {
      const role = normalizeRoleFront(CURRENT_USER.role);
      return role === "team_leader" || role === "field_sales";
    }

    const CONTACTS_PAGE_SIZE = 25;
    let USERS = [];
    let PENDING_DUE_SEND = null;
    let CONTACTS = [];
    let FILTERED_CONTACTS = [];
    let CONTACTS_TOTAL = 0;
    let CONTACTS_OFFSET = 0;
    let CONTACTS_CURSOR = "";
    let CONTACTS_HAS_MORE = false;
    let CONTACTS_LOADING = false;
    let CONTACT_ID_SELECCIONADO = "";
    let CONTACT_NAME_SELECCIONADO = "";
    let CONTACT_ID_FROM_URL = "";
    let CONTACT_NAME_FROM_URL = "";

    const __ACTION_LOCKS = window.__ACTION_LOCKS || (window.__ACTION_LOCKS = {});
    async function withActionLock(actionKey, callback) {
      const key = String(actionKey || "").trim();
      if (!key) return await callback();
      if (__ACTION_LOCKS[key]) return false;
      __ACTION_LOCKS[key] = true;
      try {
        await callback();
        return true;
      } finally {
        delete __ACTION_LOCKS[key];
      }
    }
    function setButtonBusy(button, busyText, isBusy) {
      if (!button) return;
      if (typeof button.dataset.originalText === "undefined") {
        button.dataset.originalText = button.innerText || button.textContent || "";
      }
      button.disabled = !!isBusy;
      button.innerText = isBusy ? String(busyText || "Guardando...") : String(button.dataset.originalText || "");
    }

    function normalizeContactStatusFront(value) {
      const clean = String(value || "").trim().toLowerCase();
      if (clean === "prospecto") return "prospecto";
      if (clean === "cliente") return "cliente";
      if (clean === "inactivo") return "inactivo";
      return "lead";
    }

    function getStatusLabel(status) {
      const value = normalizeContactStatusFront(status);
      if (value === "prospecto") return "Prospecto";
      if (value === "cliente") return "Cliente";
      if (value === "inactivo") return "Inactivo";
      return "Lead";
    }

    function getStatusBadgeHtml(status) {
      const value = normalizeContactStatusFront(status);
      const classMap = {
        lead: "status-lead",
        prospecto: "status-prospecto",
        cliente: "status-cliente",
        inactivo: "status-inactivo"
      };
      return '<span class="status-badge ' + classMap[value] + '">' + getStatusLabel(value) + '</span>';
    }

    function aplicarFiltroContactoDesdeURL() {
      const params = new URLSearchParams(window.location.search || "");
      CONTACT_ID_FROM_URL = String(params.get("contactId") || "").trim();
      CONTACT_NAME_FROM_URL = String(params.get("contactName") || "").trim();

      if (CONTACT_ID_FROM_URL) {
        const searchInput = document.getElementById("contactsSearch");
        if (searchInput && CONTACT_NAME_FROM_URL) {
          searchInput.value = CONTACT_NAME_FROM_URL;
        }
      }
    }

    function limpiarFiltroContactoDesdeURL() {
      CONTACT_ID_FROM_URL = "";
      CONTACT_NAME_FROM_URL = "";
      const cleanUrl = window.location.pathname;
      window.history.replaceState({}, "", cleanUrl);
    }

    function contactoVieneFiltradoDesdeURL(contact) {
      if (!CONTACT_ID_FROM_URL) return true;
      return String((contact && contact.id) || "") === CONTACT_ID_FROM_URL;
    }

    function scrollToFilteredContact() {
      if (!CONTACT_ID_FROM_URL) return;
      const row = document.getElementById("contact-row-" + CONTACT_ID_FROM_URL);
      if (!row) return;
      setTimeout(function() {
        row.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 120);
    }

    function renderDealTitlesHtml(contact) {
      const links = Array.isArray(contact.dealLinks) ? contact.dealLinks : [];
      if (!links.length) {
        return '<div class="deal-chip-empty">Sin tratos</div>';
      }
      return '<div class="deal-chip-list">' + links.map(function(deal) {
        const safeTitle = String(deal && deal.title ? deal.title : "");
        const safeId = encodeURIComponent((deal && deal.id) || "");
        return '<a class="deal-chip" href="/pipeline?dealId=' + safeId + '&view=lista" title="Ver trato: ' + safeTitle.replace(/"/g, '&quot;') + '">' + safeTitle + '</a>';
      }).join("") + '</div>';
    }

    function textoContacto(c) {
      return [
        c.name,
        c.company,
        c.phone,
        c.email,
        c.province,
        c.owner,
        c.contactStatus,
        Array.isArray(c.dealTitles) ? c.dealTitles.join(" ") : ""
      ].join(" ").toLowerCase();
    }

    function armarOpcionesOwner(selectedOwner) {
      let html = '<option value="">Sin owner</option>';
      USERS.forEach(function(user) {
        const email = user.email || "";
        const label = (user.name || user.email || "") + (user.email ? " (" + user.email + ")" : "");
        html += '<option value="' + email + '"' + (email === (selectedOwner || "") ? ' selected' : '') + '>' + label + '</option>';
      });
      return html;
    }

    function renderOwnerNuevoContacto() {
      const select = document.getElementById("owner");
      const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
      select.innerHTML = armarOpcionesOwner(user.email || "");
      if (normalizeRoleFront(user.role) === "field_sales") {
        select.value = user.email || "";
        select.disabled = true;
      } else {
        select.disabled = false;
      }
    }

    function renderOwnerFilter() {
      const select = document.getElementById("filterOwner");
      const current = select.value || "";
      select.innerHTML = '<option value="">Todos los owners</option>';
      USERS.forEach(function(user) {
        const option = document.createElement("option");
        option.value = user.email || "";
        option.text = (user.name || user.email || "") + (user.email ? " (" + user.email + ")" : "");
        select.appendChild(option);
      });
      select.value = current;
    }

    function renderContactos() {
      const body = document.getElementById("contactsBody");
      if (!FILTERED_CONTACTS.length) {
        body.innerHTML = '<tr><td colspan="9">No hay contactos para mostrar</td></tr>';
        document.getElementById("contactsSummary").innerText = "Mostrando 0 de " + CONTACTS.length + " contactos";
        return;
      }

      let html = "";
      FILTERED_CONTACTS.forEach(function(c) {
        const safeName = String(c.name || "").replace(/'/g, "\\'");
        const isTarget = CONTACT_ID_FROM_URL && String(c.id || "") === CONTACT_ID_FROM_URL;
        const rowStyle = isTarget ? 'background:#e8f0fe; box-shadow: inset 0 0 0 2px #1a73e8;' : '';

        html += '<tr id="contact-row-' + (c.id || '') + '" style="' + rowStyle + '">' +
          '<td>' + (c.name || '') + '</td>' +
          '<td>' + (c.company || '') + '</td>' +
          '<td>' + (c.province || '-') + '</td>' +
          '<td>' + (c.phone || '') + '</td>' +
          '<td>' + (c.email || '') + '</td>' +
          '<td>' +
            '<div style="margin-bottom:8px;">' + getStatusBadgeHtml(c.contactStatus || "lead") + '</div>' +
            '<select class="mini-select" onchange="cambiarEstadoContacto(' + "'" + (c.id || '') + "'" + ', this.value)">' +
              '<option value="lead"' + (normalizeContactStatusFront(c.contactStatus) === "lead" ? ' selected' : '') + '>Lead</option>' +
              '<option value="prospecto"' + (normalizeContactStatusFront(c.contactStatus) === "prospecto" ? ' selected' : '') + '>Prospecto</option>' +
              '<option value="cliente"' + (normalizeContactStatusFront(c.contactStatus) === "cliente" ? ' selected' : '') + '>Cliente</option>' +
              '<option value="inactivo"' + (normalizeContactStatusFront(c.contactStatus) === "inactivo" ? ' selected' : '') + '>Inactivo</option>' +
            '</select>' +
          '</td>' +
          '<td><select class="mini-select" ' + (normalizeRoleFront(CURRENT_USER.role) === "field_sales" ? 'disabled' : '') + ' onchange="cambiarOwnerContacto(' + "'" + (c.id || '') + "'" + ', this.value)">' + armarOpcionesOwner(c.owner || '') + '</select></td>' +
          '<td>' +
            '<div style="font-weight:bold;margin-bottom:8px;">' + (c.dealsCount || 0) + ' trato(s)</div>' +
            renderDealTitlesHtml(c) +
          '</td>' +
          '<td><div class="row-actions">' +
            '<button class="mini-btn" onclick="abrirModalTrato(' + "'" + (c.id || '') + "'" + ',' + "'" + safeName + "'" + ')">Crear trato</button>' +
            '<button class="mini-btn secondary" onclick="editarContactoPrompt(' + "'" + (c.id || '') + "'" + ')">Editar</button>' +
            (esAdmin() ? '<button class="mini-btn" style="background:#d93025" onclick="borrarContacto(' + "'" + (c.id || '') + "'" + ')">Borrar</button>' : '') +
          '</div></td>' +
        '</tr>';
      });

      body.innerHTML = html;
      document.getElementById("contactsSummary").innerText = "Mostrando " + FILTERED_CONTACTS.length + " de " + CONTACTS_TOTAL + " contactos";
      const moreBtn = document.getElementById("contactsLoadMoreBtn");
      if (moreBtn) moreBtn.style.display = CONTACTS_HAS_MORE ? "inline-block" : "none";
      scrollToFilteredContact();
    }

    function buildContactsQueryParams(cursor, offset) {
      const params = new URLSearchParams();
      params.set("ts", Date.now());
      params.set("limit", String(CONTACTS_PAGE_SIZE));
      params.set("offset", String(Math.max(0, Number(offset || 0))));
      if (cursor) params.set("cursor", String(cursor));
      const q = (document.getElementById("contactsSearch").value || "").trim();
      const status = document.getElementById("filterStatus").value || "";
      const owner = document.getElementById("filterOwner").value || "";
      const ownerValues = String(owner || "")
        .split(",")
        .map(function(value) { return String(value || "").trim().toLowerCase(); })
        .filter(Boolean);
      if (q) params.set("q", q);
      if (status) params.set("contactStatus", status);
      if (ownerValues.length) params.set("owner", ownerValues.join(","));
      if (CONTACT_ID_FROM_URL) params.set("contactId", CONTACT_ID_FROM_URL);
      return params;
    }

    async function cargarContactos(reset) {
      if (CONTACTS_LOADING) return;
      CONTACTS_LOADING = true;
      try {
        const nextOffset = reset ? 0 : CONTACTS_OFFSET;
        const nextCursor = reset ? "" : CONTACTS_CURSOR;
        const r = await fetch("/api/contacts?" + buildContactsQueryParams(nextCursor, nextOffset).toString());
        const data = await r.json();
        const body = document.getElementById("contactsBody");
        if (!data.ok) {
          body.innerHTML = '<tr><td colspan="9">Error cargando contactos</td></tr>';
          return;
        }
        const rows = Array.isArray(data.contacts) ? data.contacts : [];
        CONTACTS_TOTAL = Number(data.total || 0);
        CONTACTS_HAS_MORE = !!data.hasMore;
        CONTACTS_OFFSET = Number(data.nextOffset || (nextOffset + rows.length));
        CONTACTS_CURSOR = String(data.nextCursor || "");
        CONTACTS = reset ? rows : CONTACTS.concat(rows);
        FILTERED_CONTACTS = CONTACTS.slice();
        aplicarFiltroContactoDesdeURL();
        renderContactos();
      } catch (err) {
        document.getElementById("contactsBody").innerHTML = '<tr><td colspan="9">Error conectando con el servidor</td></tr>';
        console.error(err);
      } finally {
        CONTACTS_LOADING = false;
      }
    }

    function aplicarBusquedaContactos() {
      aplicarFiltroContactoDesdeURL();
      CONTACTS_OFFSET = 0;
      CONTACTS_CURSOR = "";
      CONTACTS_TOTAL = 0;
      CONTACTS_HAS_MORE = false;
      CONTACTS = [];
      FILTERED_CONTACTS = [];
      renderContactos();
      cargarContactos(true);
    }

    function verMasContactos() {
      if (!CONTACTS_HAS_MORE) return;
      cargarContactos(false);
    }

    function limpiarBusquedaContactos() {
      document.getElementById("contactsSearch").value = "";
      document.getElementById("filterStatus").value = "";
      document.getElementById("filterOwner").value = "";
      limpiarFiltroContactoDesdeURL();
      aplicarBusquedaContactos();
    }

    async function fetchUsersCached(forceFresh) {
      const cacheKey = "crmscb_users_cache_v1";
      const now = Date.now();
      if (!forceFresh) {
        try {
          const cached = JSON.parse(sessionStorage.getItem(cacheKey) || "null");
          if (cached && Array.isArray(cached.data) && Number(cached.expiresAt || 0) > now) {
            return cached.data;
          }
        } catch (e) {}
      }
      const r = await fetch("/api/users?ts=" + Date.now());
      const data = await r.json();
      const list = Array.isArray(data) ? data : [];
      try {
        sessionStorage.setItem(cacheKey, JSON.stringify({ expiresAt: now + 30000, data: list }));
      } catch (e) {}
      return list;
    }

    async function cargarUsuarios(forceFresh) {
      try {
        USERS = await fetchUsersCached(!!forceFresh);
      } catch (err) {
        USERS = [];
        console.error(err);
      }
      renderOwnerNuevoContacto();
      renderOwnerFilter();
    }


    async function crearContacto() {
      const msg = document.getElementById("msg");
      const btn = document.querySelector('.box button[onclick="crearContacto()"]');
      await withActionLock("crear_contacto", async function() {
        msg.innerText = "";
        setButtonBusy(btn, "Guardando...", true);
        const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
        const name = document.getElementById("name").value.trim();
        const company = document.getElementById("company").value.trim();
        const phone = document.getElementById("phone").value.trim();
        const email = document.getElementById("email").value.trim();
        const province = document.getElementById("province").value || "";
        const owner = document.getElementById("owner").value || user.email || "";
        const contactStatus = document.getElementById("contactStatus").value || "lead";

        if (!name) {
          msg.innerText = "El nombre es obligatorio";
          return;
        }

        try {
          const r = await fetch("/api/contacts", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, company, phone, email, province, owner, contactStatus })
          });
          const data = await r.json();
          if (!data.ok) {
            msg.innerText = data.error || "No se pudo guardar el contacto";
            return;
          }
          limpiarFormulario();
          await cargarContactos(true);
        } catch (err) {
          msg.innerText = "Error conectando con el servidor";
          console.error(err);
        } finally {
          setButtonBusy(btn, "Guardando...", false);
        }
      });
    }

    async function cambiarOwnerContacto(contactId, owner) {
      try {
        const r = await fetch("/api/contacts/" + contactId + "/owner", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ owner })
        });
        const data = await r.json();
        if (!data.ok) {
          alert(data.error || "No se pudo cambiar el owner");
          return;
        }
        await cargarContactos(true);
      } catch (err) {
        console.error(err);
        alert("Error conectando con el servidor");
      }
    }

    async function cambiarEstadoContacto(contactId, contactStatus) {
      try {
        const r = await fetch("/api/contacts/" + contactId + "/status", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ contactStatus })
        });
        const data = await r.json();
        if (!data.ok) {
          alert(data.error || "No se pudo cambiar el estado");
          return;
        }
        await cargarContactos(true);
      } catch (err) {
        console.error(err);
        alert("Error conectando con el servidor");
      }
    }

   async function editarContactoPrompt(contactId) {
  const contacto = CONTACTS.find(function(item) { return item.id === contactId; }) || null;
  if (!contacto) return;

  const name = prompt("Nombre", contacto.name || "");
  if (name === null) return;

  const company = prompt("Empresa", contacto.company || "");
  if (company === null) return;

  const province = prompt("Provincia", contacto.province || "");
  if (province === null) return;

  const phone = prompt("Teléfono", contacto.phone || "");
  if (phone === null) return;

  const email = prompt("Email", contacto.email || "");
  if (email === null) return;

  const status = prompt(
    "Estado (lead / prospecto / cliente / inactivo)",
    normalizeContactStatusFront(contacto.contactStatus || "lead")
  );
  if (status === null) return;

  try {
    const r = await fetch("/api/contacts/" + contactId, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        company,
        province,
        phone,
        email,
        contactStatus: status
      })
    });

    const data = await r.json();
    if (!data.ok) {
      alert(data.error || "No se pudo editar el contacto");
      return;
    }

    await cargarContactos(true);
  } catch (err) {
    console.error(err);
    alert("Error conectando con el servidor");
  }
}




    async function borrarContacto(contactId) {
      if (!confirm("¿Seguro que querés borrar este contacto? También se borrarán sus tratos.")) return;
      try {
        const r = await fetch("/api/contacts/" + contactId, { method: "DELETE" });
        const data = await r.json();
        if (!data.ok) {
          alert(data.error || "No se pudo borrar el contacto");
          return;
        }
        await cargarContactos(true);
      } catch (err) {
        console.error(err);
        alert("Error conectando con el servidor");
      }
    }

    function limpiarFormulario() {
      document.getElementById("name").value = "";
      document.getElementById("company").value = "";
      document.getElementById("phone").value = "";
      document.getElementById("email").value = "";
      document.getElementById("province").value = "";
      document.getElementById("contactStatus").value = "lead";
      renderOwnerNuevoContacto();
      document.getElementById("msg").innerText = "";
    }

    function abrirModalTrato(contactId, contactName) {
      CONTACT_ID_SELECCIONADO = contactId || "";
      CONTACT_NAME_SELECCIONADO = contactName || "";
      document.getElementById("dealContactName").innerText = CONTACT_NAME_SELECCIONADO;
      document.getElementById("dealTitle").value = "";
      document.getElementById("dealValue").value = "0";
      document.getElementById("dealDueDate").value = "";
      document.getElementById("dealStage").value = "No responde";
      document.getElementById("dealNotes").value = "";
      document.getElementById("dealModalMsg").innerText = "";
      document.getElementById("dealModalBg").style.display = "flex";
    }

    function cerrarModalTrato() {
      document.getElementById("dealModalBg").style.display = "none";
      CONTACT_ID_SELECCIONADO = "";
      CONTACT_NAME_SELECCIONADO = "";
    }

    async function guardarTratoDesdeContacto() {
      const msg = document.getElementById("dealModalMsg");
      const btn = document.querySelector('#dealModalBg button[onclick="guardarTratoDesdeContacto()"]');
      await withActionLock("crear_trato_desde_contacto", async function() {
        msg.innerText = "";
        setButtonBusy(btn, "Guardando...", true);
        const title = document.getElementById("dealTitle").value.trim();
        const value = Number(document.getElementById("dealValue").value || 0);
        const dueDate = document.getElementById("dealDueDate").value;
        const stage = document.getElementById("dealStage").value;
        const notes = document.getElementById("dealNotes").value.trim();
        const contacto = CONTACTS.find(function(item) { return item.id === CONTACT_ID_SELECCIONADO; }) || {};

        if (!CONTACT_ID_SELECCIONADO) {
          msg.innerText = "No se encontró el contacto";
          return;
        }
        if (!title) {
          msg.innerText = "El título del trato es obligatorio";
          return;
        }

        try {
          const r = await fetch("/api/deals", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              title,
              contactId: CONTACT_ID_SELECCIONADO,
              contactName: CONTACT_NAME_SELECCIONADO,
              value,
              dueDate,
              stage,
              owner: contacto.owner || "",
              notes
            })
          });
          const data = await r.json();
          if (!data.ok) {
            msg.innerText = data.error || "No se pudo guardar el trato";
            return;
          }
          cerrarModalTrato();
          await cargarContactos(true);
        } catch (err) {
          msg.innerText = "Error conectando con el servidor";
          console.error(err);
        } finally {
          setButtonBusy(btn, "Guardando...", false);
        }
      });
    }

    let contactsSearchTimer = null;
    document.getElementById("contactsSearch").addEventListener("input", function() {
      clearTimeout(contactsSearchTimer);
      contactsSearchTimer = setTimeout(aplicarBusquedaContactos, 220);
    });
    document.getElementById("filterStatus").addEventListener("change", aplicarBusquedaContactos);
    document.getElementById("filterOwner").addEventListener("change", aplicarBusquedaContactos);

    (async function init() {
      await cargarUsuarios();
      await cargarContactos(true);
    })();
  </script>
</body>
</html>
  `);
});








// =====================================================
// BLOQUE 4B0 - PÁGINA CAMPAÑAS DE VENCIMIENTOS
// =====================================================
app.get("/campanas", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Campañas</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;color:#111827}
    .topbar{background:#1a73e8;color:#fff;padding:16px 24px;display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap}
    .container{padding:24px;max-width:1500px;margin:0 auto}
    .box{background:#fff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.08);padding:18px;margin-bottom:18px}
    button{padding:10px 13px;border:none;border-radius:8px;background:#1a73e8;color:#fff;font-weight:bold;cursor:pointer}
    button:disabled{opacity:.55;cursor:not-allowed}.secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}.success{background:#188038}.danger{background:#d93025}
    input,select{padding:10px;border:1px solid #cfd7e2;border-radius:8px;box-sizing:border-box;width:100%} label{font-size:12px;color:#5f6368;font-weight:bold;display:block;margin-bottom:6px}
    table{width:100%;border-collapse:collapse;background:#fff} th,td{padding:10px;border-bottom:1px solid #edf1f5;text-align:left;font-size:13px;vertical-align:top} th{background:#f8fafc;color:#374151;font-size:12px}
    .muted,.small{color:#6b7280;font-size:12px}.pill{display:inline-block;padding:5px 9px;border-radius:999px;background:#eef3fb;color:#174ea6;border:1px solid #dbe7ff;font-weight:bold;font-size:12px}.ok{background:#e6f4ea;color:#137333}.warn{background:#fff3cd;color:#8a6d3b}.err{background:#fce8e6;color:#c5221f}
    .grid{display:grid;grid-template-columns:1.2fr 1.2fr 1fr 1fr auto;gap:12px;align-items:end}.actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.msg{white-space:pre-wrap;color:#d93025}.okmsg{color:#188038}
    .folderGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px;margin-top:12px}
    .folderCard{border:1px solid #dbe7ff;background:#f8fbff;border-radius:12px;padding:12px;cursor:pointer;min-height:74px}
    .folderCard.active{border-color:#1a73e8;background:#eaf2ff;box-shadow:0 0 0 2px rgba(26,115,232,.08)}
    .folderCard .folderName{font-weight:800;margin-bottom:6px}
    .folderCard .folderMeta{font-size:12px;color:#6b7280}
    @media(max-width:900px){.grid{grid-template-columns:1fr}.container{padding:14px}}
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>CRMSCB</strong> / Campañas de vencimientos</div>
    <div class="actions"><button class="secondary" onclick="window.location='/vencimientos'">Vencimientos</button><button class="secondary" onclick="window.location='/crm'">CRM</button></div>
  </div>
  <div class="container">
    <div class="box">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap">
        <div>
          <h2 style="margin:0 0 6px 0">Carpetas de campañas</h2>
          <div class="small">Usá una carpeta como grupo de trabajo. Ej: <b>AMBA - Seguimiento Junio</b>. Adentro podés tener Mensaje 1, Mensaje 2, Mensaje 3...</div>
        </div>
        <button class="secondary" onclick="selectCampaignFolder(&quot;&quot;)">Ver todas</button>
      </div>
      <div class="grid" style="grid-template-columns:1.4fr auto;margin-top:14px;">
        <div><label>Nueva carpeta</label><input id="newCampaignFolderName" placeholder="Ej: AMBA - Seguimiento Junio / Mendoza - Recupero ZOHO"></div>
        <button onclick="createCampaignFolder()">Crear carpeta</button>
      </div>
      <div id="campaignFolderMsg" class="small" style="margin-top:10px;color:#6b7280">Cargando carpetas...</div>
      <div id="campaignFolderCards" class="folderGrid"></div>
    </div>
    <div class="box">
      <h2 style="margin-top:0">Campañas</h2>
      <div id="campaignListMsg" class="small">Cargando campañas...</div>
      <div id="campaignListBox"></div>
    </div>
    <div id="campaignDetailBox" class="box" style="display:none"></div>
  </div>
<script>
  const userRaw = localStorage.getItem("crmscb_user");
  if(!userRaw) window.location.href='/?redirect=' + encodeURIComponent(window.location.pathname + window.location.search);
  const __originalFetch = window.fetch.bind(window);
  window.fetch = function(url, options){
    const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
    options = options || {}; options.headers = Object.assign({}, options.headers || {}, {"x-user-id":user.id||"", "x-auth-token":user.token||""});
    return __originalFetch(url, options);
  };
  let JOBS = []; let ALL_JOBS = []; let CURRENT_JOB = null; let TEMPLATES = []; let FOLDERS = []; let ACTIVE_FOLDER_ID = ''; let STOP_PROCESS = false; let PROCESS_JOB_RUNNING = false;
  function esc(s){return String(s||"").replace(/[&<>\"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[m];});}
  function fmt(v){ if(!v) return '-'; const d=new Date(v); return isNaN(d.getTime()) ? String(v) : d.toLocaleString('es-AR'); }
  function todayPlus7(){ const d=new Date(); d.setDate(d.getDate()+7); return d.toISOString().slice(0,10); }
  function qs(){ return new URLSearchParams(window.location.search); }
  async function loadTemplates(){
    try{ const r=await fetch('/api/due-templates?ts='+Date.now()); const d=await r.json(); TEMPLATES=Array.isArray(d.templates)?d.templates:[]; }catch(e){ TEMPLATES=[]; }
  }
  function folderOptions(selectedId){
    const selected = String(selectedId || '');
    return '<option value="">Sin carpeta</option>' + FOLDERS.map(function(f){
      const id = String(f.id || '');
      return '<option value="'+esc(id)+'"'+(id===selected?' selected':'')+'>'+esc(f.name || 'Carpeta')+'</option>';
    }).join('');
  }

  function getFolderNameById(folderId){
    const clean = String(folderId || '');
    if(!clean) return '';
    const f = FOLDERS.find(function(item){ return String(item.id || '') === clean; });
    return f ? String(f.name || '') : '';
  }
  function setActiveFolderFromUrl(){
    const params = qs();
    ACTIVE_FOLDER_ID = String(params.get('folderId') || '').trim();
  }
  function syncCampaignFolderUrl(){
    const url = new URL(window.location.href);
    if(ACTIVE_FOLDER_ID) url.searchParams.set('folderId', ACTIVE_FOLDER_ID);
    else url.searchParams.delete('folderId');
    history.replaceState({}, '', url.toString());
  }
  function selectCampaignFolder(folderId){
    ACTIVE_FOLDER_ID = String(folderId || '').trim();
    syncCampaignFolderUrl();
    renderCampaignFolderCards();
    renderCampaignList();
  }
  function getVisibleCampaigns(){
    const list = Array.isArray(ALL_JOBS) ? ALL_JOBS.slice() : [];
    if(ACTIVE_FOLDER_ID === '__no_folder__') return list.filter(function(j){ return !String(j.folderId || '').trim(); });
    if(ACTIVE_FOLDER_ID) return list.filter(function(j){ return String(j.folderId || '') === ACTIVE_FOLDER_ID; });
    return list;
  }
  function getFolderCampaignCount(folderId){
    const clean = String(folderId || '');
    return (Array.isArray(ALL_JOBS) ? ALL_JOBS : []).filter(function(j){ return String(j.folderId || '') === clean; }).length;
  }
  function renderCampaignFolderCards(){
    const box = document.getElementById('campaignFolderCards');
    if(!box) return;
    const total = (Array.isArray(ALL_JOBS) ? ALL_JOBS : []).length;
    const noFolder = (Array.isArray(ALL_JOBS) ? ALL_JOBS : []).filter(function(j){ return !String(j.folderId || '').trim(); }).length;
    let html = '';
    html += '<div class="folderCard '+(!ACTIVE_FOLDER_ID ? 'active' : '')+'" onclick="selectCampaignFolder(&quot;&quot;)"><div class="folderName">📁 Todas</div><div class="folderMeta">'+total+' campaña(s)</div></div>';
    html += '<div class="folderCard '+(ACTIVE_FOLDER_ID==='__no_folder__' ? 'active' : '')+'" onclick="selectCampaignFolder(&quot;__no_folder__&quot;)"><div class="folderName">📂 Sin carpeta</div><div class="folderMeta">'+noFolder+' campaña(s)</div></div>';
    html += FOLDERS.map(function(f){
      const id = String(f.id || '');
      const count = getFolderCampaignCount(id);
      return '<div class="folderCard '+(ACTIVE_FOLDER_ID===id ? 'active' : '')+'" onclick="selectCampaignFolder(&quot;'+esc(id)+'&quot;)"><div class="folderName">📁 '+esc(f.name || 'Carpeta')+'</div><div class="folderMeta">'+count+' campaña(s)</div></div>';
    }).join('');
    box.innerHTML = html;
  }
  async function loadCampaignFolders(){
    const msg = document.getElementById('campaignFolderMsg');
    try{
      const r = await fetch('/api/due-campaign-folders?ts=' + Date.now());
      const d = await r.json();
      if(!r.ok || !d.ok) throw new Error(d.error || 'Error cargando carpetas');
      FOLDERS = Array.isArray(d.folders) ? d.folders : [];
      if(msg) msg.innerText = FOLDERS.length ? ('Carpetas creadas: ' + FOLDERS.length + ' · tocá una carpeta para entrar') : 'Sin carpetas creadas.';
      renderCampaignFolderCards();
    }catch(err){ if(msg) msg.innerHTML = '<span style="color:#d93025">Error carpetas: '+esc(err.message||'error')+'</span>'; }
  }
  async function createCampaignFolder(){
    const input = document.getElementById('newCampaignFolderName');
    const name = String((input && input.value) || '').trim();
    if(!name) return alert('Ingresá un nombre de carpeta');
    const r = await fetch('/api/due-campaign-folders', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ name }) });
    const d = await r.json();
    if(!r.ok || !d.ok) return alert(d.error || 'No se pudo crear la carpeta');
    if(input) input.value = '';
    await loadCampaignFolders();
    if(d.folder && d.folder.id){ ACTIVE_FOLDER_ID = String(d.folder.id || ''); syncCampaignFolderUrl(); }
    await loadCampaigns();
  }
  async function updateCampaignFolder(jobId, folderId){
    const folder = FOLDERS.find(function(f){ return String(f.id||'') === String(folderId||''); }) || null;
    const r = await fetch('/api/due-send-jobs/' + encodeURIComponent(jobId) + '/folder', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ folderId: folder ? folder.id : '', folderName: folder ? folder.name : '' }) });
    const d = await r.json();
    if(!r.ok || !d.ok) return alert(d.error || 'No se pudo mover la campaña');
    await loadCampaigns();
    if(CURRENT_JOB && String(CURRENT_JOB.id||'') === String(jobId||'')) await openCampaign(jobId);
  }
  async function deleteCampaign(jobId){
    if(!jobId) return;
    if(!confirm('¿Eliminar esta campaña del historial? No borra las notas ni mensajes enviados.')) return;
    const r = await fetch('/api/due-send-jobs/' + encodeURIComponent(jobId), { method:'DELETE' });
    const d = await r.json();
    if(!r.ok || !d.ok) return alert(d.error || 'No se pudo eliminar la campaña');
    if(CURRENT_JOB && String(CURRENT_JOB.id||'') === String(jobId||'')){ CURRENT_JOB = null; renderCampaignDetail(); }
    await loadCampaigns();
  }
  async function loadCampaigns(){
    const msg=document.getElementById('campaignListMsg');
    if(msg) msg.innerText='Cargando campañas...';
    try{
      const url = '/api/due-send-jobs?limit=100&ts=' + Date.now();
      const r=await fetch(url); const data=await r.json(); if(!r.ok||!data.ok) throw new Error(data.error||'Error');
      ALL_JOBS=data.jobs||[];
      renderCampaignFolderCards();
      renderCampaignList();
    }catch(err){ if(msg) msg.innerHTML='<span style="color:#d93025">Error: '+esc(err.message||'error')+'</span>'; }
  }
  function renderCampaignList(){
    const msg=document.getElementById('campaignListMsg'); const box=document.getElementById('campaignListBox');
    JOBS=getVisibleCampaigns();
    const folderLabel = ACTIVE_FOLDER_ID === '__no_folder__' ? 'Sin carpeta' : (ACTIVE_FOLDER_ID ? getFolderNameById(ACTIVE_FOLDER_ID) : 'Todas las carpetas');
    if(msg) msg.innerText=JOBS.length ? ('Carpeta: '+folderLabel+' · Campañas: '+JOBS.length) : ('Carpeta: '+folderLabel+' · Sin campañas.');
    if(!box) return;
    if(!JOBS.length){ box.innerHTML='<div class="small">No hay campañas en esta carpeta.</div>'; return; }
    box.innerHTML='<table><thead><tr><th>Campaña</th><th>Carpeta</th><th>Estado</th><th>Total</th><th>Plantilla</th><th>Fecha</th><th>Acción</th></tr></thead><tbody>'+JOBS.map(function(j){ const s=j.summary||{}; return '<tr>'+ 
      '<td><b>'+esc(j.campaignName||'Sin nombre')+'</b><div class="small">Por: '+esc(j.createdBy||'-')+'</div></td>'+ 
      '<td><select onchange="updateCampaignFolder(&quot;'+esc(j.id)+'&quot;, this.value)">'+folderOptions(j.folderId||'')+'</select></td>'+ 
      '<td><span class="pill">'+esc(j.status||'-')+'</span></td>'+ 
      '<td><span class="pill">'+Number(j.total||0)+'</span> <span class="pill ok">'+Number(s.sent||0)+' enviados</span> <span class="pill warn">'+Number(s.skipped||0)+' omitidos</span> <span class="pill err">'+Number(s.errors||0)+' errores</span></td>'+ 
      '<td>'+esc(j.templateName||j.contentSid||'-')+'</td><td>'+esc(fmt(j.createdAt))+'</td>'+ 
      '<td><div class="actions"><button class="secondary" onclick="openCampaign(&quot;'+esc(j.id)+'&quot;)">Ver campaña</button><button class="danger" onclick="deleteCampaign(&quot;'+esc(j.id)+'&quot;)">Eliminar</button></div></td></tr>'; }).join('')+'</tbody></table>';
  }


  async function openCampaign(id){
    const r=await fetch('/api/due-send-jobs/'+encodeURIComponent(id)+'?ts='+Date.now()); const data=await r.json(); if(!r.ok||!data.ok) return alert(data.error||'No se pudo abrir');
    CURRENT_JOB=data.job; const url=new URL(window.location.href); url.searchParams.set('id',id); history.replaceState({},'',url.toString()); renderCampaignDetail();
  }
  function templateOptions(){ return '<option value="">Seleccionar plantilla aprobada</option>'+TEMPLATES.map(t=>'<option value="'+esc(t.sid||'')+'">'+esc((t.name||t.sid||'')+(t.language?' · '+t.language:'')+(t.category?' · '+t.category:''))+'</option>').join(''); }
  function renderCampaignDetail(){
    const box=document.getElementById('campaignDetailBox'); if(!CURRENT_JOB){box.style.display='none';return;} box.style.display='block';
    const j=CURRENT_JOB; const s=j.summary||{}; const items=Array.isArray(j.items)?j.items:[];
    box.innerHTML='<div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><h2 style="margin:0 0 6px 0">'+esc(j.campaignName||'Campaña')+'</h2><div class="small">ID: '+esc(j.id)+' · Creada: '+esc(fmt(j.createdAt))+' · Por: '+esc(j.createdBy||'-')+' · Carpeta: '+esc(j.folderName||'Sin carpeta')+'</div></div><div class="actions"><button class="secondary" onclick="openCampaign(&quot;'+esc(j.id)+'&quot;)">Refrescar</button><button class="danger" onclick="deleteCampaign(&quot;'+esc(j.id)+'&quot;)">Eliminar campaña</button></div></div>'+ 
      '<div style="height:12px"></div><div class="actions"><span class="pill">Estado: '+esc(j.status||'-')+'</span><span class="pill">Total: '+Number(j.total||0)+'</span><span class="pill ok">Enviados: '+Number(s.sent||0)+'</span><span class="pill warn">Omitidos: '+Number(s.skipped||0)+'</span><span class="pill err">Errores: '+Number(s.errors||0)+'</span><span class="pill">Plantilla: '+esc(j.templateName||j.contentSid||'-')+'</span></div>'+ 
      '<div style="height:18px"></div><div class="box" style="box-shadow:none;border:1px solid #e5e7eb;background:#f8fbff"><h3 style="margin-top:0">Enviar otro mensaje a esta campaña</h3><div class="grid"><div><label>Nuevo nombre de campaña</label><input id="resendCampaignName" value="'+esc((j.campaignName||'Campaña')+' - Reenvío '+new Date().toLocaleDateString('es-AR'))+'"></div><div><label>Plantilla aprobada</label><select id="resendTemplateSelect">'+templateOptions()+'</select></div><div><label>Próximo vencimiento</label><input id="resendNextDueDate" type="date" value="'+todayPlus7()+'"><div class="small">Si lo dejás vacío, usa hoy + 7 días.</div></div><div><label>Delay</label><select id="resendDelay"><option value="1000">1 segundo</option><option value="2000">2 segundos</option><option value="3000" selected>3 segundos</option><option value="5000">5 segundos</option></select></div><button class="success" onclick="createResendJob()">Crear y enviar</button></div><div id="resendMsg" class="msg" style="margin-top:10px"></div><div id="resendQueueBox" style="margin-top:10px"></div></div>'+ 
      '<h3>Contactos / tratos de la campaña</h3><table><thead><tr><th>#</th><th>Cliente</th><th>Teléfono</th><th>Línea</th><th>Trato</th><th>Etapa</th><th>Vencimiento</th><th>Estado</th><th>Enviado</th><th>Error</th></tr></thead><tbody>'+items.map(function(it){return '<tr><td>'+Number(it.index||0)+'</td><td>'+esc(it.contactName||'-')+'</td><td>'+esc(it.phone||'-')+'</td><td>'+esc(it.lineId||'-')+'</td><td>'+esc(it.dealTitle||it.dealId||'-')+'</td><td>'+esc(it.stage||'-')+'</td><td>'+esc(it.dueDate||'-')+'</td><td><span class="pill">'+esc(it.status||'-')+'</span></td><td>'+esc(fmt(it.sentAt))+'</td><td>'+esc(it.error||'-')+'</td></tr>';}).join('')+'</tbody></table>';
  }
  function sleep(ms){return new Promise(r=>setTimeout(r,Math.max(0,Number(ms||0))));}
  function renderMiniQueue(job){ const box=document.getElementById('resendQueueBox'); if(!box||!job) return; const s=job.summary||{}; box.innerHTML='<div class="small"><b>Cola:</b> '+esc(job.status||'-')+' · '+Number(s.processed||0)+'/'+Number(job.total||0)+' procesados · '+Number(s.sent||0)+' enviados · '+Number(s.errors||0)+' errores</div>'; }
  async function cancelDueJobClient(jobId, reason){
    try{
      await fetch('/api/due-send-jobs/'+encodeURIComponent(jobId)+'/cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reason:reason||'cancelado_desde_front'})});
    }catch(e){ console.warn('No se pudo cancelar cola', e); }
  }
  async function safeProcessFetch(url, options, timeoutMs){
    const controller = new AbortController();
    const timer = setTimeout(function(){ controller.abort(); }, Math.max(1000, Number(timeoutMs||45000)));
    try{
      return await fetch(url, Object.assign({}, options || {}, { signal: controller.signal }));
    }finally{
      clearTimeout(timer);
    }
  }
  async function processJob(jobId){
    if(PROCESS_JOB_RUNNING) return alert('Ya hay una cola procesándose. Esperá que termine o cancelala.');
    PROCESS_JOB_RUNNING = true;
    STOP_PROCESS=false;
    const msg=document.getElementById('resendMsg');
    let loops = 0;
    let lastProcessed = -1;
    let noProgress = 0;
    const startedAt = Date.now();
    try{
      while(true){
        if(STOP_PROCESS){
          await cancelDueJobClient(jobId, 'pausado_por_usuario');
          if(msg)msg.innerText='Cola cancelada/pausada. No seguirá en bucle.';
          await loadCampaigns();
          return;
        }
        loops += 1;
        if(loops > 1000 || Date.now() - startedAt > 30*60*1000){
          await cancelDueJobClient(jobId, 'seguridad_maximo_bucle_o_tiempo');
          throw new Error('Cola cancelada por seguridad: superó el máximo de ciclos o tiempo.');
        }
        const r=await safeProcessFetch('/api/due-send-jobs/'+encodeURIComponent(jobId)+'/process-next',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'},60000);
        const d=await r.json();
        if(!r.ok||!d.ok){
          await cancelDueJobClient(jobId, 'error_process_next_'+(d.error||r.status));
          throw new Error(d.error||'Error procesando');
        }
        renderMiniQueue(d.job);
        const processed = Number((d.job && d.job.summary && d.job.summary.processed) || 0);
        if(processed === lastProcessed && !d.done && d.hasMore) noProgress += 1; else noProgress = 0;
        lastProcessed = processed;
        if(noProgress >= 3){
          await cancelDueJobClient(jobId, 'sin_avance_3_intentos');
          throw new Error('Cola cancelada por seguridad: no avanzó después de 3 intentos.');
        }
        if(d.done||!d.hasMore){
          if(msg){msg.className='msg okmsg';msg.innerText='Reenvío finalizado.';}
          await openCampaign(jobId); await loadCampaigns(); return;
        }
        const delay=Number(d.nextDelayMs||3000);
        if(msg){msg.className='msg okmsg';msg.innerText='Procesando. Próximo mensaje en '+Math.round(delay/1000)+' segundos...';}
        await sleep(delay);
      }
    } finally {
      PROCESS_JOB_RUNNING = false;
    }
  }
  async function createResendJob(){
    if(!CURRENT_JOB) return; const msg=document.getElementById('resendMsg'); const contentSid=(document.getElementById('resendTemplateSelect').value||'').trim(); if(!contentSid) return alert('Seleccioná plantilla');
    const body={contentSid:contentSid, campaignName:(document.getElementById('resendCampaignName').value||'').trim(), nextDueDate:(document.getElementById('resendNextDueDate').value||'').trim(), delayMs:Number(document.getElementById('resendDelay').value||3000), contentVariables:{}};
    try{ msg.className='msg'; msg.innerText='Creando nueva cola desde esta campaña...'; const r=await fetch('/api/due-send-jobs/'+encodeURIComponent(CURRENT_JOB.id)+'/resend',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); const d=await r.json(); if(!r.ok||!d.ok) throw new Error(d.error||'No se pudo crear reenvío'); renderMiniQueue(d.job); msg.className='msg okmsg'; msg.innerText='Nueva campaña creada. Procesando...'; await processJob(d.job.id); }catch(err){ msg.className='msg'; msg.innerText=err.message||'Error'; }
  }
  (async function init(){ setActiveFolderFromUrl(); await Promise.allSettled([loadTemplates(), loadCampaignFolders()]); await loadCampaigns(); const id=qs().get('id'); if(id) await openCampaign(id); })();
</script>
</body>
</html>`);
});


// =====================================================
// BLOQUE 4B-AGENDA - PÁGINA AGENDA COMERCIAL
// =====================================================
const AGENDA_IMPORTANT_STAGES = [
  "Nuevos Prospectos",
  "Marca personal",
  "Esperando PI",
  "Para cotizar",
  "Cotizado para enviar",
  "Horno"
];

app.get("/agenda", (req, res) => {
  const stageFilterOptions = ['<option value="important">Etapas importantes</option>']
    .concat(AGENDA_IMPORTANT_STAGES.map((stage) => `<option value="${esc(stage)}">${esc(stage)}</option>`))
    .concat(['<option value="all">Todas</option>'])
    .join("");
  const createDealStageOptions = PIPELINE_STAGES.map((stage) => `<option value="${esc(stage)}">${esc(stage)}</option>`).join("");
  const dealTypeOptions = DEAL_TYPES.map((type) => `<option value="${esc(type)}">${esc(getDealTypeLabel(type))}</option>`).join("");
  const provinceOptions = [
    "", "Buenos Aires", "CABA", "Catamarca", "Chaco", "Chubut", "Córdoba", "Corrientes", "Entre Ríos", "Formosa", "Jujuy", "La Pampa", "La Rioja", "Mendoza", "Misiones", "Neuquén", "Río Negro", "Salta", "San Juan", "San Luis", "Santa Cruz", "Santa Fe", "Santiago del Estero", "Tierra del Fuego", "Tucumán"
  ].map((p) => `<option value="${esc(p)}">${esc(p || "Seleccionar provincia")}</option>`).join("");

  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Agenda Comercial</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;color:#111827}
    .topbar{background:#1a73e8;color:#fff;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
    .container{padding:24px;max-width:1500px;margin:0 auto}.box{background:#fff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.08);padding:18px;margin-bottom:18px}
    .tabs{display:flex;gap:8px;flex-wrap:wrap}.tab{background:#fff;color:#1a73e8;border:1px solid #1a73e8}.tab.active{background:#1a73e8;color:#fff}
    button{padding:10px 14px;border:none;border-radius:8px;background:#1a73e8;color:#fff;font-weight:bold;cursor:pointer}button:disabled{opacity:.55;cursor:not-allowed}.secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}.success{background:#188038}.danger{background:#d93025}.warnbtn{background:#fbbc04;color:#111827}
    input,select,textarea{width:100%;padding:10px;border:1px solid #cfd7e2;border-radius:8px;box-sizing:border-box;font-family:Arial,sans-serif}textarea{min-height:80px;resize:vertical}label{font-size:12px;color:#5f6368;font-weight:bold;display:block;margin-bottom:6px}
    .filters{display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr 1.4fr auto;gap:12px;align-items:end}.customDates{display:none;grid-template-columns:1fr 1fr;gap:10px}
    .actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.summary{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-top:14px}.metric{background:#f8fbff;border:1px solid #dbe7ff;border-radius:12px;padding:12px}.metric .label{font-size:12px;color:#5f6368}.metric .value{font-size:22px;font-weight:bold;color:#174ea6;margin-top:4px}
    .group{border:1px solid #e5e7eb;border-radius:14px;overflow:hidden;margin-bottom:14px;background:#fff}.group-head{background:#eef3fb;padding:12px 14px;display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap}.group-title{font-weight:bold;color:#174ea6}.item{padding:13px 14px;border-top:1px solid #edf1f5;display:grid;grid-template-columns:90px 1fr auto;gap:12px;align-items:start}.item.task-item{border-left:5px solid #188038;background:#fbfffb}.item.deal-has-task{border-left:5px solid #34a853;background:#f7fff8}.time{font-weight:bold;color:#374151}.item-title{font-weight:bold;margin-bottom:4px;font-size:16px}.task-note{margin-top:8px;background:#f1f8f3;border:1px solid #cde8d4;border-radius:10px;padding:9px;color:#1f2937;font-size:13px}.task-label{display:inline-block;margin-bottom:6px;color:#137333;font-weight:800;font-size:12px;letter-spacing:.02em}.muted,.small{color:#6b7280;font-size:12px}.pill{display:inline-block;padding:5px 9px;border-radius:999px;background:#eef3fb;color:#174ea6;border:1px solid #dbe7ff;font-weight:bold;font-size:12px}.pill.red{background:#fce8e6;color:#c5221f;border-color:#f6c7c2}.pill.orange{background:#fff3cd;color:#8a6d3b;border-color:#f1df9a}.pill.green{background:#e6f4ea;color:#137333;border-color:#cde8d4}.pill.gray{background:#f1f3f4;color:#5f6368;border-color:#e0e3e7}
    .modalBack{position:fixed;inset:0;background:rgba(17,24,39,.45);display:none;align-items:center;justify-content:center;padding:18px;z-index:1000}.modal{background:#fff;border-radius:16px;max-width:920px;width:100%;max-height:92vh;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,.25)}.modalHead{padding:16px 18px;border-bottom:1px solid #e5e7eb;font-weight:bold;font-size:18px}.modalBody{padding:18px}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}.result{border:1px solid #e5e7eb;border-radius:10px;padding:10px;margin-top:8px;cursor:pointer}.result:hover{background:#f8fbff}.selectedBox{background:#eaf2ff;border:1px solid #dbe7ff;border-radius:10px;padding:10px;margin-top:8px}.msg{margin-top:10px;color:#d93025;white-space:pre-wrap}.okmsg{color:#188038}.hidden{display:none!important}
    @media(max-width:1000px){.filters,.summary,.grid2,.grid3{grid-template-columns:1fr}.item{grid-template-columns:1fr}.container{padding:14px}}
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>CRMSCB</strong> / Agenda Comercial</div>
    <div class="actions"><button class="secondary" onclick="window.location='/pipeline'">Pipeline</button><button class="secondary" onclick="window.location='/vencimientos'">Vencimientos</button><button class="secondary" onclick="window.location='/crm'">Volver al panel</button></div>
  </div>
  <div class="container">
    <div class="box">
      <div style="display:flex;justify-content:space-between;gap:14px;align-items:flex-start;flex-wrap:wrap">
        <div><h2 style="margin:0 0 6px 0">Agenda Comercial</h2><div class="small">Tareas manuales + vencimientos de tratos. Carga por rango para cuidar reads.</div></div>
        <div class="actions"><button class="success" onclick="openTaskModal()">+ Nueva tarea</button><button class="secondary" onclick="loadAgenda()">Actualizar</button></div>
      </div>
      <div class="tabs" style="margin-top:16px">
        <button id="tab_vencidos" class="tab active" onclick="setAgendaMode('vencidos')">Vencidos</button>
        <button id="tab_tareas" class="tab" onclick="setAgendaMode('tareas')">Tareas</button>
        <button id="tab_hoy" class="tab" onclick="setAgendaMode('hoy')">Hoy</button>
        <button id="tab_manana" class="tab" onclick="setAgendaMode('manana')">Mañana</button>
        <button id="tab_semana" class="tab" onclick="setAgendaMode('semana')">Esta semana</button>
        <button id="tab_proximos_7" class="tab" onclick="setAgendaMode('proximos_7')">Próximos 7 días</button>
        <button id="tab_personalizado" class="tab" onclick="setAgendaMode('personalizado')">Personalizado</button>
      </div>
      <div class="filters" style="margin-top:14px">
        <div><label>Owner</label><select id="ownerFilter"><option value="">Todos los owners</option></select></div>
        <div><label>Stage</label><select id="stageFilter">${stageFilterOptions}</select></div>
        <div><label>Estado tarea</label><select id="taskStatusFilter"><option value="pending">Pendientes</option><option value="all">Todas</option><option value="done">Hechas</option><option value="cancelled">Canceladas</option></select></div>
        <div><label>Tipo</label><select id="itemTypeFilter"><option value="all">Tareas + vencimientos</option><option value="tasks">Solo tareas</option><option value="deals">Solo vencimientos</option></select></div>
        <div><label>Límite</label><select id="limitFilter"><option value="100">100</option><option value="150" selected>150</option><option value="200">200</option></select></div>
        <div><label>Buscar</label><input id="qFilter" placeholder="cliente, trato o nota..."></div>
        <button onclick="loadAgenda()">Aplicar</button>
      </div>
      <div id="customDateBox" class="customDates" style="margin-top:12px;max-width:520px">
        <div><label>Desde</label><input id="dateFrom" type="date"></div>
        <div><label>Hasta</label><input id="dateTo" type="date"></div>
      </div>
      <div id="summaryBox" class="summary"></div>
      <div id="agendaMsg" class="small" style="margin-top:10px;color:#6b7280"></div>
    </div>
    <div id="agendaBox"><div class="box"><div class="small">Cargando agenda...</div></div></div>
  </div>

  <div id="taskModal" class="modalBack">
    <div class="modal">
      <div class="modalHead">Nueva tarea</div>
      <div class="modalBody">
        <div class="box" style="box-shadow:none;border:1px solid #e5e7eb">
          <h3 style="margin-top:0">1. Contacto *</h3>
          <div class="grid2">
            <div><label>Buscar contacto</label><input id="contactSearch" placeholder="mínimo 3 letras, teléfono o email"></div>
            <div style="display:flex;align-items:end"><button class="secondary" onclick="showCreateContactBox()">+ Crear contacto</button></div>
          </div>
          <div id="contactResults"></div>
          <div id="selectedContactBox" class="selectedBox hidden"></div>
          <div id="createContactBox" class="hidden" style="margin-top:12px;border-top:1px solid #edf1f5;padding-top:12px">
            <h4>Crear contacto</h4>
            <div class="grid3">
              <div><label>Nombre *</label><input id="newContactName"></div>
              <div><label>Empresa</label><input id="newContactCompany"></div>
              <div><label>Teléfono</label><input id="newContactPhone"></div>
              <div><label>Email</label><input id="newContactEmail"></div>
              <div><label>Provincia</label><select id="newContactProvince">${provinceOptions}</select></div>
              <div><label>Owner</label><select id="newContactOwner"></select></div>
              <div><label>Estado</label><select id="newContactStatus"><option value="lead">Lead</option><option value="prospecto">Prospecto</option><option value="cliente">Cliente</option><option value="inactivo">Inactivo</option></select></div>
            </div>
            <div class="actions" style="margin-top:10px"><button class="success" onclick="createContactFromAgenda()">Guardar contacto y usar</button></div>
          </div>
        </div>

        <div class="box" style="box-shadow:none;border:1px solid #e5e7eb">
          <h3 style="margin-top:0">2. Trato *</h3>
          <div id="dealSelectBox" class="small">Primero seleccioná un contacto.</div>
          <div id="selectedDealBox" class="selectedBox hidden"></div>
          <div id="createDealBox" class="hidden" style="margin-top:12px;border-top:1px solid #edf1f5;padding-top:12px">
            <h4>Crear trato</h4>
            <div class="grid3">
              <div><label>Título *</label><input id="newDealTitle"></div>
              <div><label>Valor</label><input id="newDealValue" type="number" min="0" step="0.01" value="0"></div>
              <div><label>Vencimiento</label><input id="newDealDueDate" type="date"></div>
              <div><label>Etapa *</label><select id="newDealStage">${createDealStageOptions}</select></div>
              <div><label>Tipo</label><select id="newDealType">${dealTypeOptions}</select></div>
              <div><label>Owner</label><select id="newDealOwner"></select></div>
            </div>
            <div style="margin-top:10px"><label>Notas</label><textarea id="newDealNotes"></textarea></div>
            <div class="actions" style="margin-top:10px"><button class="success" onclick="createDealFromAgenda()">Guardar trato y usar</button></div>
          </div>
        </div>

        <div class="box" style="box-shadow:none;border:1px solid #e5e7eb">
          <h3 style="margin-top:0">3. Tarea</h3>
          <div class="grid3">
            <div><label>Título *</label><input id="taskTitle" placeholder="Ej: Pedir packing list"></div>
            <div><label>Fecha *</label><input id="taskDate" type="date"></div>
            <div><label>Hora</label><input id="taskTime" type="time"></div>
          </div>
          <div style="margin-top:10px"><label>Notas</label><textarea id="taskNotes" placeholder="Detalle del seguimiento..."></textarea></div>
        </div>
        <div id="taskModalMsg" class="msg"></div>
        <div class="actions" style="justify-content:flex-end;margin-top:14px"><button class="secondary" onclick="closeTaskModal()">Cancelar</button><button id="saveTaskBtn" class="success" onclick="saveTaskFromAgenda()">Guardar tarea</button></div>
      </div>
    </div>
  </div>

  <script>
    const userRaw = localStorage.getItem('crmscb_user');
    if(!userRaw) window.location.href='/?redirect=' + encodeURIComponent(window.location.pathname + window.location.search);
    const CURRENT_USER = JSON.parse(userRaw || '{}');
    const __originalFetch = window.fetch.bind(window);
    window.fetch = function(url, options){
      const user = JSON.parse(localStorage.getItem('crmscb_user') || '{}');
      options = options || {}; options.headers = Object.assign({}, options.headers || {}, {'x-user-id':user.id||'', 'x-auth-token':user.token||''});
      return __originalFetch(url, options);
    };
    let MODE='vencidos'; let USERS=[]; let ITEMS=[]; let SELECTED_CONTACT=null; let SELECTED_DEAL=null; let CONTACT_TIMER=null; let SEARCH_TIMER=null; let CURRENT_VIEW_TASK_ID='';
    function escHtml(s){return String(s||'').replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
    function todayIso(){return new Date().toISOString().slice(0,10);} function addDaysIso(n){const d=new Date();d.setDate(d.getDate()+n);return d.toISOString().slice(0,10);} 
    function fmtDate(iso){if(!iso)return '-'; const d=new Date(String(iso)+'T00:00:00'); return isNaN(d.getTime())?iso:d.toLocaleDateString('es-AR',{weekday:'long',day:'2-digit',month:'2-digit'});}
    function daysLabel(dateIso){const t=new Date(todayIso()+'T00:00:00').getTime(); const d=new Date(String(dateIso||'')+'T00:00:00').getTime(); if(isNaN(d))return ''; const diff=Math.round((d-t)/86400000); if(diff<0)return 'Hace '+Math.abs(diff)+' día(s)'; if(diff===0)return 'Hoy'; if(diff===1)return 'Mañana'; return 'En '+diff+' día(s)';}
    function normalizeRoleFront(role){const v=String(role||'').toLowerCase(); if(v==='admin'||v==='backoffice'||v==='team_leader')return v; return 'field_sales';}
    function setAgendaMode(mode){MODE=mode||'vencidos'; if(MODE==='tareas'){const itemType=document.getElementById('itemTypeFilter'); if(itemType)itemType.value='tasks'; const st=document.getElementById('stageFilter'); if(st && st.value==='important')st.value='all'; const taskStatus=document.getElementById('taskStatusFilter'); if(taskStatus)taskStatus.value='all';} updateTabs(); loadAgenda();}
    function updateTabs(){['vencidos','tareas','hoy','manana','semana','proximos_7','personalizado'].forEach(function(m){const el=document.getElementById('tab_'+m); if(el)el.className=MODE===m?'tab active':'tab';}); document.getElementById('customDateBox').style.display=MODE==='personalizado'?'grid':'none';}
    function ownerOptions(selected){let html='<option value="">Todos / según permisos</option>'; USERS.forEach(function(u){const email=u.email||''; const label=(u.name||u.email||'')+(u.email?' ('+u.email+')':''); html+='<option value="'+escHtml(email)+'"'+(email===(selected||'')?' selected':'')+'>'+escHtml(label)+'</option>';}); return html;}
    function singleOwnerOptions(selected){let html='<option value="">Sin owner</option>'; USERS.forEach(function(u){const email=u.email||''; const label=(u.name||u.email||'')+(u.email?' ('+u.email+')':''); html+='<option value="'+escHtml(email)+'"'+(email===(selected||'')?' selected':'')+'>'+escHtml(label)+'</option>';}); return html;}
    async function loadUsers(){try{const r=await fetch('/api/users?ts='+Date.now()); const d=await r.json(); USERS=Array.isArray(d)?d:[];}catch(e){USERS=[];} document.getElementById('ownerFilter').innerHTML=ownerOptions(''); document.getElementById('newContactOwner').innerHTML=singleOwnerOptions(CURRENT_USER.email||''); document.getElementById('newDealOwner').innerHTML=singleOwnerOptions(CURRENT_USER.email||'');}
    function buildAgendaQuery(){const p=new URLSearchParams(); p.set('mode',MODE); p.set('limit',document.getElementById('limitFilter').value||'150'); const owner=document.getElementById('ownerFilter').value||''; const stage=document.getElementById('stageFilter').value||'important'; const taskStatus=document.getElementById('taskStatusFilter').value||'pending'; const itemType=document.getElementById('itemTypeFilter').value||'all'; const q=(document.getElementById('qFilter').value||'').trim(); if(owner)p.set('owner',owner); if(stage)p.set('stage',stage); if(taskStatus)p.set('taskStatus',taskStatus); if(itemType)p.set('itemType',itemType); if(q)p.set('q',q); if(MODE==='personalizado'){p.set('start',document.getElementById('dateFrom').value||todayIso()); p.set('end',document.getElementById('dateTo').value||todayIso());} p.set('ts',Date.now()); return p;}
    async function loadAgenda(){document.getElementById('agendaBox').innerHTML='<div class="box"><div class="small">Cargando agenda...</div></div>'; try{const r=await fetch('/api/agenda/items?'+buildAgendaQuery().toString()); const d=await r.json(); if(!r.ok||!d.ok)throw new Error(d.error||'No se pudo cargar agenda'); ITEMS=d.items||[]; renderSummary(d.summary||{}); renderItems(ITEMS); document.getElementById('agendaMsg').innerText='Rango: '+(d.rangeLabel||'')+' · '+ITEMS.length+' item(s) cargados · sin auto-refresh';}catch(err){document.getElementById('agendaBox').innerHTML='<div class="box"><div class="msg">Error: '+escHtml(err.message||'Error')+'</div></div>';}}
    function renderSummary(s){document.getElementById('summaryBox').innerHTML='<div class="metric"><div class="label">Total</div><div class="value">'+Number(s.total||0)+'</div></div><div class="metric"><div class="label">Tareas</div><div class="value">'+Number(s.tasks||0)+'</div></div><div class="metric"><div class="label">Vencimientos</div><div class="value">'+Number(s.deals||0)+'</div></div><div class="metric"><div class="label">Vencidos</div><div class="value">'+Number(s.overdue||0)+'</div></div><div class="metric"><div class="label">Hoy / mañana</div><div class="value">'+Number((s.today||0)+(s.tomorrow||0))+'</div></div>';}
    function groupKey(item){if(item.urgency==='overdue')return '🔴 VENCIDOS'; if(item.date===todayIso())return '🟠 HOY'; if(item.date===addDaysIso(1))return '🟡 MAÑANA'; return '🟢 '+fmtDate(item.date).toUpperCase();}
    function itemPill(item){if(item.urgency==='overdue')return '<span class="pill red">Vencido</span>'; if(item.date===todayIso())return '<span class="pill orange">Hoy</span>'; if(item.date===addDaysIso(1))return '<span class="pill orange">Mañana</span>'; return '<span class="pill green">Próximo</span>';}
    function renderItems(items){
      const box=document.getElementById('agendaBox');
      if(!items.length){box.innerHTML='<div class="box"><div class="small">No hay tareas ni vencimientos para mostrar.</div></div>';return;}
      const groups={};
      items.forEach(function(it){const k=groupKey(it); if(!groups[k])groups[k]=[]; groups[k].push(it);});
      let html='';
      Object.keys(groups).forEach(function(k){
        html+='<div class="group"><div class="group-head"><div class="group-title">'+escHtml(k)+'</div><span class="pill">'+groups[k].length+' item(s)</span></div>';
        groups[k].forEach(function(it){
          const isTask=it.type==='task';
          const dealId=escHtml(it.dealId||'');
          const taskId=escHtml(it.taskId||'');
          const itemDate=escHtml(it.date||'');
          const relatedTaskId=escHtml(it.relatedTaskId||'');
          const hasRelatedTask=!isTask && !!(it.relatedTaskId);
          html+='<div class="item '+(isTask?'task-item':(hasRelatedTask?'deal-has-task':''))+'"><div class="time">'+escHtml(it.time||'Sin hora')+'</div>'+
            '<div><div>'+itemPill(it)+' <span class="pill gray">'+(isTask?'Tarea manual':'Vence trato')+'</span>'+(hasRelatedTask?' <span class="pill green">Con tarea</span>':'')+'</div>'+
            (isTask?'<div class="task-label">TAREA CREADA</div>':(hasRelatedTask?'<div class="task-label">TIENE TAREA CREADA</div>':''))+
            '<div class="item-title">'+escHtml(it.title||'-')+'</div>'+
            '<div class="small"><b>Cliente:</b> '+escHtml(it.contactName||'-')+' · <b>Trato:</b> '+escHtml(it.dealTitle||'-')+'</div>'+
            '<div class="small"><b>Stage:</b> '+escHtml(it.stage||'-')+' · <b>Owner:</b> '+escHtml(it.owner||'-')+'</div>'+
            (isTask?'<div class="task-note"><b>Lo escrito en la tarea:</b><br>'+escHtml(it.notes||'Sin nota cargada')+'</div>':(hasRelatedTask?'<div class="task-note"><b>Tarea creada:</b> '+escHtml(it.relatedTaskTitle||'Tarea')+'<br><b>Lo escrito en la tarea:</b><br>'+escHtml(it.relatedTaskNotes||'Sin nota cargada')+'</div>':(it.notes?'<div class="small"><b>Nota del trato:</b> '+escHtml(it.notes)+'</div>':'')))+
            '</div><div class="actions">'+
            '<button class="secondary" data-deal-id="'+dealId+'" onclick="openHubFromAgendaButton(this)">Ir al HUB</button>'+
            '<button class="secondary" data-deal-id="'+dealId+'" onclick="openDealFromAgendaButton(this)">Ir a trato</button>'+
            (isTask
              ? '<button class="success" data-task-id="'+taskId+'" onclick="completeTaskFromAgendaButton(this)">Marcar hecha</button><button class="secondary" data-task-id="'+taskId+'" onclick="editTaskFromAgendaButton(this)">Editar tarea</button><button class="warnbtn" data-task-id="'+taskId+'" data-date="'+itemDate+'" onclick="rescheduleTaskFromAgendaButton(this)">Reprogramar</button>'
              : ((hasRelatedTask?'<button class="success" data-task-id="'+relatedTaskId+'" onclick="viewTaskFromAgendaButton(this)">Ver tarea</button>':'<button class="success" data-deal-id="'+dealId+'" onclick="openTaskModalForDealFromAgendaButton(this)">+ Crear tarea</button>')+'<button class="secondary" data-deal-id="'+dealId+'" onclick="openTaskModalForDealFromAgendaButton(this)">'+(hasRelatedTask?'Crear otra tarea':'+ Crear tarea')+'</button><button class="warnbtn" data-deal-id="'+dealId+'" data-date="'+itemDate+'" onclick="changeDealDueDateFromAgendaButton(this)">Cambiar vencimiento</button>'))+
            '</div></div>';
        });
        html+='</div>';
      });
      box.innerHTML=html;
    }
    function openHubFromAgendaButton(btn){openHub(btn && btn.dataset ? btn.dataset.dealId : '');}
    function openDealFromAgendaButton(btn){openDeal(btn && btn.dataset ? btn.dataset.dealId : '');}
    function completeTaskFromAgendaButton(btn){completeTask(btn && btn.dataset ? btn.dataset.taskId : '');}
    function rescheduleTaskFromAgendaButton(btn){rescheduleTask(btn && btn.dataset ? btn.dataset.taskId : '', btn && btn.dataset ? btn.dataset.date : '');}
    function editTaskFromAgendaButton(btn){editTask(btn && btn.dataset ? btn.dataset.taskId : '');}
    function openTaskModalForDealFromAgendaButton(btn){openTaskModalForDeal(btn && btn.dataset ? btn.dataset.dealId : '');}
    function changeDealDueDateFromAgendaButton(btn){changeDealDueDate(btn && btn.dataset ? btn.dataset.dealId : '', btn && btn.dataset ? btn.dataset.date : '');}
    function viewTaskFromAgendaButton(btn){viewTask(btn && btn.dataset ? btn.dataset.taskId : '');}
    function closeTaskViewModal(){const m=document.getElementById('taskViewModal'); if(m)m.style.display='none';}
    async function viewTask(taskId){
      if(!taskId)return alert('No encontré la tarea');
      CURRENT_VIEW_TASK_ID=String(taskId||'');
      try{
        const m=document.getElementById('taskViewModal');
        const c=document.getElementById('taskViewContent');
        if(c)c.innerHTML='Cargando...';
        if(m)m.style.display='flex';
        const r=await fetch('/api/tasks/'+encodeURIComponent(CURRENT_VIEW_TASK_ID));
        const d=await r.json();
        if(!r.ok||!d.ok) throw new Error(d.error||'No se pudo cargar la tarea');
        const t=d.task||{};
        if(c)c.innerHTML='<div class="grid2"><div><label>Título</label><div><b>'+escHtml(t.title||'-')+'</b></div></div><div><label>Fecha</label><div>'+escHtml(t.taskDate||'-')+(t.taskTime?' '+escHtml(t.taskTime):'')+'</div></div><div><label>Cliente</label><div>'+escHtml(t.contactName||'-')+'</div></div><div><label>Trato</label><div>'+escHtml(t.dealTitle||'-')+'</div></div><div><label>Stage</label><div>'+escHtml(t.stage||'-')+'</div></div><div><label>Owner</label><div>'+escHtml(t.owner||'-')+'</div></div></div><div class="task-note" style="margin-top:12px"><b>Lo escrito en la tarea:</b><br>'+escHtml(t.notes||'Sin nota cargada')+'</div><div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap"><button class="secondary" onclick="closeTaskViewModal()">Cerrar</button><button class="secondary" onclick="editCurrentViewedTask()">Editar tarea</button></div>';
      }catch(e){
        const c=document.getElementById('taskViewContent');
        if(c)c.innerHTML='<div class="small" style="color:#b3261e">'+escHtml(e.message||'Error cargando tarea')+'</div>';
      }
    }
    function editCurrentViewedTask(){
      if(!CURRENT_VIEW_TASK_ID) return alert('No encontré la tarea');
      closeTaskViewModal();
      editTask(CURRENT_VIEW_TASK_ID);
    }
    function openDeal(dealId){if(!dealId)return alert('No hay trato vinculado'); window.open('/pipeline?dealId='+encodeURIComponent(dealId)+'&view=lista','_blank');}
    async function openHub(dealId){if(!dealId)return alert('No hay trato vinculado'); try{const r=await fetch('/api/deals/'+encodeURIComponent(dealId)+'/hub-link?ts='+Date.now()); const d=await r.json(); if(d.ok&&d.found&&d.url){window.open(d.url,'_blank');return;} alert(d.error||'No hay conversación vinculada en HUB');}catch(e){alert('Error buscando link HUB');}}
    async function completeTask(taskId){if(!taskId)return; const r=await fetch('/api/tasks/'+encodeURIComponent(taskId)+'/status',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:'done'})}); const d=await r.json(); if(!r.ok||!d.ok)return alert(d.error||'No se pudo completar'); await loadAgenda();}
    async function rescheduleTask(taskId,current){const next=prompt('Nueva fecha de tarea (YYYY-MM-DD)',current||todayIso()); if(!next)return; const r=await fetch('/api/tasks/'+encodeURIComponent(taskId),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({taskDate:next})}); const d=await r.json(); if(!r.ok||!d.ok)return alert(d.error||'No se pudo reprogramar'); await loadAgenda();}
    async function editTask(taskId){const it=(ITEMS||[]).find(function(x){return String(x.taskId||'')===String(taskId||'');}); if(!it)return alert('No encontré la tarea en la vista actual'); const title=prompt('Título de la tarea',it.title||''); if(title===null)return; const taskDate=prompt('Fecha de tarea (YYYY-MM-DD)',it.date||todayIso()); if(taskDate===null)return; const taskTime=prompt('Hora (HH:MM, opcional)',it.time||''); if(taskTime===null)return; const notes=prompt('Notas de la tarea',it.notes||''); if(notes===null)return; const r=await fetch('/api/tasks/'+encodeURIComponent(taskId),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:title,taskDate:taskDate,taskTime:taskTime,notes:notes})}); const d=await r.json(); if(!r.ok||!d.ok)return alert(d.error||'No se pudo editar tarea'); await loadAgenda();}
    async function changeDealDueDate(dealId,current){const next=prompt('Nuevo vencimiento del trato (YYYY-MM-DD)',current||todayIso()); if(!next)return; const r=await fetch('/api/deals/'+encodeURIComponent(dealId)+'/due-date',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({dueDate:next})}); const d=await r.json(); if(!r.ok||!d.ok)return alert(d.error||'No se pudo cambiar vencimiento'); await loadAgenda();}
    function resetModal(){SELECTED_CONTACT=null;SELECTED_DEAL=null; ['contactSearch','taskTitle','taskTime','taskNotes','newContactName','newContactCompany','newContactPhone','newContactEmail','newDealTitle','newDealNotes'].forEach(function(id){const el=document.getElementById(id);if(el)el.value='';}); document.getElementById('taskDate').value=todayIso(); document.getElementById('newDealValue').value='0'; document.getElementById('newDealDueDate').value=''; document.getElementById('newContactProvince').value=''; document.getElementById('newContactStatus').value='lead'; document.getElementById('contactResults').innerHTML=''; document.getElementById('selectedContactBox').classList.add('hidden'); document.getElementById('selectedDealBox').classList.add('hidden'); document.getElementById('createContactBox').classList.add('hidden'); document.getElementById('createDealBox').classList.add('hidden'); document.getElementById('dealSelectBox').innerHTML='Primero seleccioná un contacto.'; document.getElementById('taskModalMsg').innerText='';}
    function openTaskModal(){resetModal(); document.getElementById('taskModal').style.display='flex';}
    async function openTaskModalForDeal(dealId){openTaskModal(); try{const r=await fetch('/api/agenda/deal/'+encodeURIComponent(dealId)+'?ts='+Date.now()); const d=await r.json(); if(d.ok&&d.deal){selectContact(d.contact); selectDeal(d.deal);}}catch(e){}}
    function closeTaskModal(){document.getElementById('taskModal').style.display='none';}
    function showCreateContactBox(){document.getElementById('createContactBox').classList.remove('hidden'); const q=document.getElementById('contactSearch').value||''; if(q&&!document.getElementById('newContactName').value)document.getElementById('newContactName').value=q;}
    async function searchContacts(){const q=(document.getElementById('contactSearch').value||'').trim(); const box=document.getElementById('contactResults'); if(q.length<3){box.innerHTML='<div class="small" style="margin-top:8px">Escribí mínimo 3 caracteres.</div>';return;} box.innerHTML='<div class="small" style="margin-top:8px">Buscando...</div>'; try{const r=await fetch('/api/agenda/contact-search?q='+encodeURIComponent(q)+'&limit=10&ts='+Date.now()); const d=await r.json(); if(!r.ok||!d.ok)throw new Error(d.error||'Error'); const rows=d.contacts||[]; box.innerHTML=rows.length?rows.map(function(c){const contactId=escHtml(c.id||''); return '<div class="result" data-contact-id="'+contactId+'" onclick="selectContactFromAgendaResult(this)"><b>'+escHtml(c.name||'-')+'</b><div class="small">'+escHtml(c.company||'')+' · '+escHtml(c.phone||'')+' · '+escHtml(c.email||'')+' · '+escHtml(c.owner||'')+'</div></div>';}).join(''):'<div class="small" style="margin-top:8px">No se encontró. Podés crear contacto.</div>'; window.__CONTACT_RESULTS=rows;}catch(e){box.innerHTML='<div class="msg">'+escHtml(e.message||'Error')+'</div>';}}
    function selectContactFromAgendaResult(el){selectContactById(el && el.dataset ? el.dataset.contactId : '');}
    function selectContactById(id){const rows=window.__CONTACT_RESULTS||[]; const c=rows.find(function(x){return String(x.id)===String(id);}); if(c)selectContact(c);}
    async function selectContact(c){SELECTED_CONTACT=c; document.getElementById('selectedContactBox').classList.remove('hidden'); document.getElementById('selectedContactBox').innerHTML='<b>Contacto seleccionado:</b> '+escHtml(c.name||'-')+'<div class="small">'+escHtml(c.company||'')+' · '+escHtml(c.phone||'')+' · '+escHtml(c.owner||'')+'</div>'; document.getElementById('newDealOwner').innerHTML=singleOwnerOptions(c.owner||CURRENT_USER.email||''); await loadDealsForContact(c.id);}
    async function loadDealsForContact(contactId){const box=document.getElementById('dealSelectBox'); box.innerHTML='Cargando tratos...'; SELECTED_DEAL=null; document.getElementById('selectedDealBox').classList.add('hidden'); try{const r=await fetch('/api/agenda/contact/'+encodeURIComponent(contactId)+'/deals?ts='+Date.now()); const d=await r.json(); if(!r.ok||!d.ok)throw new Error(d.error||'Error'); const deals=d.deals||[]; let html='<div class="actions"><button class="secondary" onclick="document.getElementById(&quot;createDealBox&quot;).classList.remove(&quot;hidden&quot;)">+ Crear trato</button></div>'; html+=deals.length?deals.map(function(deal){const dealId=escHtml(deal.id||''); return '<div class="result" data-deal-id="'+dealId+'" onclick="selectDealFromAgendaResult(this)"><b>'+escHtml(deal.title||'-')+'</b><div class="small">Stage: '+escHtml(deal.stage||'-')+' · Owner: '+escHtml(deal.owner||'-')+' · Vence: '+escHtml(deal.dueDate||'-')+'</div></div>';}).join(''):'<div class="small" style="margin-top:8px">Este contacto no tiene tratos. Creá uno para poder guardar la tarea.</div>'; box.innerHTML=html; window.__DEAL_RESULTS=deals;}catch(e){box.innerHTML='<div class="msg">'+escHtml(e.message||'Error')+'</div>';}}
    function selectDealFromAgendaResult(el){selectDealById(el && el.dataset ? el.dataset.dealId : '');}
    function selectDealById(id){const rows=window.__DEAL_RESULTS||[]; const d=rows.find(function(x){return String(x.id)===String(id);}); if(d)selectDeal(d);}
    function selectDeal(d){SELECTED_DEAL=d; document.getElementById('selectedDealBox').classList.remove('hidden'); document.getElementById('selectedDealBox').innerHTML='<b>Trato seleccionado:</b> '+escHtml(d.title||'-')+'<div class="small">Stage: '+escHtml(d.stage||'-')+' · Owner: '+escHtml(d.owner||'-')+'</div>'; if(!document.getElementById('taskTitle').value)document.getElementById('taskTitle').value='Seguimiento: '+(d.title||'trato');}
    async function createContactFromAgenda(){const body={name:document.getElementById('newContactName').value.trim(),company:document.getElementById('newContactCompany').value.trim(),phone:document.getElementById('newContactPhone').value.trim(),email:document.getElementById('newContactEmail').value.trim(),province:document.getElementById('newContactProvince').value,owner:document.getElementById('newContactOwner').value||CURRENT_USER.email||'',contactStatus:document.getElementById('newContactStatus').value||'lead'}; if(!body.name)return alert('Nombre obligatorio'); const r=await fetch('/api/contacts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); const d=await r.json(); if(!r.ok||!d.ok)return alert(d.error||'No se pudo crear contacto'); selectContact(Object.assign({id:d.id},body)); document.getElementById('createContactBox').classList.add('hidden');}
    async function createDealFromAgenda(){if(!SELECTED_CONTACT)return alert('Primero seleccioná contacto'); const body={title:document.getElementById('newDealTitle').value.trim(),contactId:SELECTED_CONTACT.id,contactName:SELECTED_CONTACT.name||'',value:Number(document.getElementById('newDealValue').value||0),dueDate:document.getElementById('newDealDueDate').value||'',stage:document.getElementById('newDealStage').value||'No responde',dealType:document.getElementById('newDealType').value||'LCL_PROPIO',owner:document.getElementById('newDealOwner').value||SELECTED_CONTACT.owner||CURRENT_USER.email||'',notes:document.getElementById('newDealNotes').value.trim()}; if(!body.title)return alert('Título del trato obligatorio'); const r=await fetch('/api/deals',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); const d=await r.json(); if(!r.ok||!d.ok)return alert(d.error||'No se pudo crear trato'); const deal=Object.assign({id:d.id},body); window.__DEAL_RESULTS=[deal].concat(window.__DEAL_RESULTS||[]); selectDeal(deal); document.getElementById('createDealBox').classList.add('hidden');}
    async function saveTaskFromAgenda(){
      const msg=document.getElementById('taskModalMsg');
      const btn=document.getElementById('saveTaskBtn');
      msg.innerText='';
      if(!SELECTED_CONTACT)return msg.innerText='Seleccioná o creá un contacto.';
      if(!SELECTED_DEAL)return msg.innerText='Seleccioná o creá un trato.';
      const body={contactId:SELECTED_CONTACT.id,dealId:SELECTED_DEAL.id,title:document.getElementById('taskTitle').value.trim(),taskDate:document.getElementById('taskDate').value,taskTime:document.getElementById('taskTime').value,notes:document.getElementById('taskNotes').value.trim()};
      if(!body.title)return msg.innerText='Título obligatorio.';
      if(!body.taskDate)return msg.innerText='Fecha obligatoria.';
      try{
        if(btn){btn.disabled=true;btn.innerText='Guardando...';}
        msg.innerText='Guardando tarea...';
        const r=await fetch('/api/tasks',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
        let d={};
        try{d=await r.json();}catch(e){d={};}
        if(!r.ok||!d.ok){msg.innerText=d.error||('No se pudo guardar tarea. HTTP '+r.status);return;}
        closeTaskModal();
        // Después de guardar, vamos directo a la vista Tareas para confirmar visualmente.
        MODE='tareas';
        updateTabs();
        const itemType=document.getElementById('itemTypeFilter'); if(itemType)itemType.value='tasks';
        const taskStatus=document.getElementById('taskStatusFilter'); if(taskStatus)taskStatus.value='all';
        const stage=document.getElementById('stageFilter'); if(stage)stage.value='all';
        const q=document.getElementById('qFilter'); if(q)q.value='';
        await loadAgenda();
        const topMsg=document.getElementById('agendaMsg');
        if(topMsg)topMsg.innerText='Tarea guardada correctamente. Vista: Tareas.';
      }catch(err){
        msg.innerText='Error guardando tarea: '+(err.message||'error desconocido');
      }finally{
        if(btn){btn.disabled=false;btn.innerText='Guardar tarea';}
      }
    }
    document.getElementById('contactSearch').addEventListener('input',function(){clearTimeout(CONTACT_TIMER); CONTACT_TIMER=setTimeout(searchContacts,350);});
    document.getElementById('qFilter').addEventListener('input',function(){clearTimeout(SEARCH_TIMER); SEARCH_TIMER=setTimeout(loadAgenda,400);});
    ['ownerFilter','stageFilter','taskStatusFilter','itemTypeFilter','limitFilter','dateFrom','dateTo'].forEach(function(id){document.getElementById(id).addEventListener('change',loadAgenda);});
    document.getElementById('taskModal').addEventListener('click',function(e){if(e.target&&e.target.id==='taskModal')closeTaskModal();});
    (async function init(){document.getElementById('dateFrom').value=todayIso(); document.getElementById('dateTo').value=addDaysIso(7); updateTabs(); await loadUsers(); await loadAgenda();})();
  </script>
</body>
</html>`);
});

// =====================================================
// BLOQUE 4B - PÁGINA SEGUIMIENTOS POR VENCIMIENTO
// =====================================================
app.get("/vencimientos", (req, res) => {
  const stageFilterOptions = ['<option value="">Todas las etapas</option>'].concat(
    PIPELINE_STAGES.map((stage) => `<option value="${esc(stage)}">${esc(stage)}</option>`)
  ).join("");
  const dealTypeFilterOptions = ['<option value="">Todos los tipos</option>'].concat(
    DEAL_TYPES.map((type) => `<option value="${esc(type)}">${esc(getDealTypeLabel(type))}</option>`)
  ).join("");

  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Vencimientos</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;padding:0;color:#111827}
    .topbar{background:#1a73e8;color:white;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
    .topbar strong{font-size:16px}
    .container{padding:24px;max-width:1500px;margin:0 auto}
    .box{background:#fff;padding:18px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08);margin-bottom:18px}
    .filters{display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr 120px;gap:12px;align-items:end}
    label{font-size:12px;color:#5f6368;font-weight:bold;display:block;margin-bottom:6px}
    input,select{width:100%;padding:11px;border:1px solid #cfd7e2;border-radius:8px;box-sizing:border-box;background:#fff}
    button{padding:11px 14px;border:none;border-radius:8px;background:#1a73e8;color:#fff;cursor:pointer;font-weight:bold}
    button:disabled{opacity:.55;cursor:not-allowed}
    .secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}
    .danger{background:#d93025;color:#fff}
    .success{background:#188038;color:#fff}
    .muted{color:#666;font-size:13px}
    .tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}
    .tab{background:#fff;color:#1a73e8;border:1px solid #1a73e8}
    .tab.active{background:#1a73e8;color:#fff}
    .summary{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:14px}
    .metric{background:#f8fbff;border:1px solid #dbe7ff;border-radius:12px;padding:14px}
    .metric .label{font-size:12px;color:#5f6368;margin-bottom:6px}
    .metric .value{font-size:24px;font-weight:bold;color:#174ea6}
    .actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:14px}
    .template-row{display:grid;grid-template-columns:1.1fr 1.2fr 1.2fr 150px 160px auto auto;gap:12px;align-items:end}
    .group{border:1px solid #e5e7eb;border-radius:14px;overflow:hidden;margin-bottom:14px;background:#fff}
    .group-head{display:flex;justify-content:space-between;align-items:center;gap:12px;background:#eef3fb;padding:12px 14px;cursor:pointer;flex-wrap:wrap}
    .group-title{font-weight:bold;color:#174ea6}
    .group-stats{display:flex;gap:8px;flex-wrap:wrap;font-size:12px}
    .pill{display:inline-block;padding:5px 9px;border-radius:999px;background:#fff;color:#174ea6;border:1px solid #dbe7ff;font-weight:bold;font-size:12px}
    .pill.ok{background:#e6f4ea;color:#137333;border-color:#cde8d4}
    .pill.warn{background:#fff3cd;color:#8a6d3b;border-color:#f1df9a}
    .pill.err{background:#fce8e6;color:#c5221f;border-color:#f6c7c2}
    table{width:100%;border-collapse:collapse;background:#fff}
    th,td{padding:10px 12px;border-bottom:1px solid #edf1f5;text-align:left;font-size:13px;vertical-align:top}
    th{background:#f8fafc;color:#374151;font-size:12px}
    .check{width:18px;height:18px;cursor:pointer}
    .status{font-weight:bold;font-size:12px}
    .status-ready{color:#137333}
    .status-nophone,.status-invalid,.status-nocontact{color:#b26a00}
    .status-sent{color:#174ea6}
    .status-error{color:#c5221f}
    .small{font-size:12px;color:#6b7280}
    .msg{margin-top:12px;font-size:13px;color:#d93025;white-space:pre-wrap}
    .okmsg{color:#188038}
    .loading{padding:18px;color:#666}
    .modalBack{position:fixed;inset:0;background:rgba(17,24,39,.45);display:none;align-items:center;justify-content:center;padding:18px;z-index:1000}
    .modal{background:#fff;border-radius:16px;max-width:720px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,.25);overflow:hidden}
    .modalHead{padding:16px 18px;border-bottom:1px solid #e5e7eb;font-weight:bold;font-size:18px}
    .modalBody{padding:18px}
    .previewBox{border:1px solid #dbe7ff;background:#f8fbff;border-radius:12px;padding:14px;white-space:pre-wrap;min-height:120px;max-height:320px;overflow:auto}
    .modalActions{display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap;margin-top:16px}
    @media (max-width: 1100px){.filters,.template-row,.summary{grid-template-columns:1fr 1fr}.container{padding:14px}}
    @media (max-width: 700px){.filters,.template-row,.summary{grid-template-columns:1fr}.topbar{align-items:flex-start}}
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>CRMSCB</strong> / Seguimientos por Vencimiento</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <button class="secondary" onclick="window.location='/pipeline'">Pipeline</button>
      <button class="secondary" onclick="window.location='/contacts'">Contactos</button>
      <button class="secondary" onclick="window.location='/campanas'">Campañas</button>
      <button class="secondary" onclick="window.location='/crm'">Volver al panel</button>
    </div>
  </div>

  <div class="container">
    <div class="box">
      <h2 style="margin-top:0">Centro de vencimientos</h2>
      <div class="tabs">
        <button id="tabVencidos" class="tab active" onclick="setMode('vencidos')">Vencidos</button>
        <button id="tabHoy" class="tab" onclick="setMode('hoy')">Vencen hoy</button>
        <button id="tabProx" class="tab" onclick="setMode('proximos_7')">Próximos 7 días</button>
      </div>
      <div class="filters">
        <div><label>Etapa / Pipeline</label><select id="stageFilter">${stageFilterOptions}</select></div>
        <div><label>Owner</label><select id="ownerFilter"><option value="">Todos los owners</option></select></div>
        <div><label>Tipo de trato</label><select id="dealTypeFilter">${dealTypeFilterOptions}</select></div>
        <div><label>Estado de envío</label><select id="sendStateFilter"><option value="">Todos</option><option value="ready">Listo para enviar</option><option value="resend">Listo para reenviar</option><option value="blocked">Bloqueados / sin teléfono</option></select></div>
        <div><label>Buscar trato / cliente</label><input id="qFilter" placeholder="Nombre, cliente, notas..."></div>
        <div><label>Límite</label><select id="limitFilter"><option value="50">50</option><option value="100" selected>100</option><option value="200">200</option></select></div>
      </div>
      <div class="actions">
        <button onclick="loadDueDeals()">Aplicar filtros</button>
        <button class="secondary" onclick="clearFilters()">Limpiar</button>
        <button class="secondary" onclick="exportCurrentView()">Exportar vista actual</button>
        <span class="muted" id="loadedInfo">Sin cargar</span>
      </div>
      <div class="summary" id="summaryBox"></div>
    </div>

    <div class="box">
      <div class="template-row">
        <div>
          <label>Nombre campaña</label>
          <input id="campaignNameInput" placeholder="Ej: AMBA - Seguimiento - Lunes">
          <div class="small" style="margin-top:6px;color:#6b7280">Se guarda en historial y en la nota del trato.</div>
        </div>
        <div>
          <label>Carpeta campaña</label>
          <select id="campaignFolderSelect"><option value="">Sin carpeta</option></select>
          <div class="small" style="margin-top:6px;color:#6b7280">Opcional, para ordenar campañas.</div>
        </div>
        <div>
          <label>Plantilla aprobada</label>
          <select id="templateSelect"><option value="">Cargando plantillas...</option></select>
          <div id="templateLoadMsg" class="small" style="margin-top:6px;color:#6b7280">Cargando plantillas aprobadas desde HUB...</div>
        </div>
        <div>
          <label>Variables JSON opcionales</label>
          <input id="templateVars" placeholder='{}' value="{}">
        </div>
        <div>
          <label>Delay entre mensajes</label>
          <select id="sendDelayMs">
            <option value="1000">1 segundo</option>
            <option value="2000">2 segundos</option>
            <option value="3000" selected>3 segundos</option>
            <option value="5000">5 segundos</option>
          </select>
          <div class="small" style="margin-top:6px;color:#6b7280">Recomendado: 3 segundos para tandas grandes.</div>
        </div>
        <div>
          <label>Próximo vencimiento</label>
          <input id="nextDueDateInput" type="date">
          <div class="small" style="margin-top:6px;color:#6b7280">Opcional. Si queda vacío, usa hoy + 7 días.</div>
        </div>
        <button class="success" onclick="sendSelectedTemplates()">Enviar plantilla a seleccionados</button>
        <button class="secondary" onclick="selectAllReadyVisible()">Seleccionar válidos visibles</button>
      </div>
      <div class="actions">
        <span class="pill" id="selectedPill">0 seleccionados</span>
        <button class="secondary" onclick="clearSelection()">Limpiar selección</button>
        <span class="muted">Solo se pueden seleccionar tratos con teléfono válido.</span>
      </div>
      <div id="sendMsg" class="msg"></div>
      <div id="queueBox" class="box" style="margin-top:12px;display:none;background:#f8fbff;border-color:#dbeafe"></div>
      <div class="box" style="margin-top:12px;background:#fff;border:1px solid #e5e7eb;box-shadow:none">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
          <strong>Historial de campañas recientes</strong>
          <button class="secondary" onclick="loadDueCampaignHistory()">Refrescar historial</button>
        </div>
        <div id="campaignHistoryBox" class="small" style="margin-top:10px;color:#6b7280">Cargando historial...</div>
      </div>
    </div>

    <div id="duePreviewModal" class="modalBack">
      <div class="modal">
        <div class="modalHead">Confirmar envío de plantilla</div>
        <div class="modalBody">
          <div class="small" id="duePreviewMeta">Cargando...</div>
          <div style="height:10px"></div>
          <label>Mensaje que se va a enviar</label>
          <div id="duePreviewText" class="previewBox">Cargando preview...</div>
          <div style="height:12px"></div>
          <label>Variables JSON</label>
          <div id="duePreviewVars" class="previewBox" style="min-height:50px;max-height:120px"></div>
          <div class="modalActions">
            <button class="secondary" onclick="closeDuePreviewModal()">Cancelar</button>
            <button id="confirmDueSendBtn" class="success" onclick="confirmDueTemplateSend()">Confirmar y enviar</button>
          </div>
        </div>
      </div>
    </div>

    <div id="groupsBox"><div class="loading">Cargando vencimientos...</div></div>
  </div>

  <script>
    const userRaw = localStorage.getItem("crmscb_user");
    if (!userRaw) window.location.href = "/?redirect=" + encodeURIComponent(window.location.pathname + window.location.search);
    const CURRENT_USER = JSON.parse(userRaw || "{}");
    if (String(CURRENT_USER.role || "").trim().toLowerCase() !== "admin") {
      alert("Acceso exclusivo para administradores");
      window.location.replace("/crm");
      throw new Error("Acceso exclusivo para administradores");
    }
    const __originalFetch = window.fetch.bind(window);
    window.fetch = function(url, options) {
      const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
      options = options || {};
      options.headers = Object.assign({}, options.headers || {}, {
        "x-user-id": user.id || "",
        "x-auth-token": user.token || ""
      });
      return __originalFetch(url, options);
    };

    let MODE = "vencidos";
    let DUE_ROWS = [];
    let GROUPS = {};
    let SELECTED = new Set();
    let TEMPLATES = [];
    let USERS = [];
    let PENDING_DUE_SEND = null;
    let ACTIVE_DUE_JOB_RUNNING = false;

    window.addEventListener('error', function(event){
      try {
        const box = document.getElementById('groupsBox');
        if (box) box.innerHTML = '<div class="box"><div class="msg">Error JS en la página: ' + escHtml(event.message || 'error desconocido') + '</div></div>';
      } catch(e) {}
    });

    function escHtml(s){return String(s||"").replace(/[&<>\"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[m];});}
    function normalizePhone(p){return String(p||"").replace(/[^0-9+]/g,"").trim();}
    function daysDiff(due){
      if(!due) return "";
      const today = new Date();
      const t = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
      const d = new Date(String(due)+"T00:00:00").getTime();
      if(isNaN(d)) return "";
      return Math.floor((t-d)/86400000);
    }
    function formatDueDateTime(value){
      if(!value) return '';
      const d = new Date(value);
      if(isNaN(d.getTime())) return String(value);
      return d.toLocaleString('es-AR');
    }
    function modeLabel(){ if(MODE==='hoy') return 'Vencen hoy'; if(MODE==='proximos_7') return 'Próximos 7 días'; return 'Vencidos'; }
    function statusLabel(row){
      if(row.status === 'ready') return 'Listo para enviar';
      if(row.status === 'sent') return 'Listo para reenviar';
      if(row.status === 'no_phone') return 'Sin teléfono';
      if(row.status === 'invalid_phone') return 'Teléfono inválido';
      if(row.status === 'no_contact') return 'Sin contacto';
      if(row.status === 'no_line') return 'Sin línea';
      if(row.status === 'no_line') return 'Sin línea';
      if(row.status === 'error') return 'Error anterior';
      return row.status || '-';
    }
    function statusClass(row){
      if(row.status === 'ready') return 'status-ready';
      if(row.status === 'sent') return 'status-sent';
      if(row.status === 'error') return 'status-error';
      return 'status-nophone';
    }
    function isSelectable(row){ return !!(row && row.canSend); }
    function updateTabs(){
      document.getElementById('tabVencidos').className = MODE==='vencidos' ? 'tab active' : 'tab';
      document.getElementById('tabHoy').className = MODE==='hoy' ? 'tab active' : 'tab';
      document.getElementById('tabProx').className = MODE==='proximos_7' ? 'tab active' : 'tab';
    }
    function setMode(mode){ MODE = mode || 'vencidos'; updateTabs(); loadDueDeals(); }
    function updateSelectedPill(){ document.getElementById('selectedPill').innerText = SELECTED.size + ' seleccionados'; }
    function clearSelection(){ SELECTED = new Set(); updateSelectedPill(); renderGroups(); }
    function toggleRow(id, checked){ if(checked) SELECTED.add(String(id||'')); else SELECTED.delete(String(id||'')); updateSelectedPill(); }
    function selectAllReadyVisible(){ DUE_ROWS.forEach(function(r){ if(isSelectable(r)) SELECTED.add(String(r.id)); }); updateSelectedPill(); renderGroups(); }
    function selectGroupReady(stage){ (GROUPS[stage] || []).forEach(function(r){ if(isSelectable(r)) SELECTED.add(String(r.id)); }); updateSelectedPill(); renderGroups(); }

    async function loadUsers(){
      try{
        const r = await fetch('/api/users?ts=' + Date.now());
        const data = await r.json();
        USERS = Array.isArray(data) ? data : [];
        const sel = document.getElementById('ownerFilter');
        const current = sel.value || '';
        sel.innerHTML = '<option value="">Todos los owners</option>' + USERS.map(function(u){
          const email = u.email || '';
          const label = (u.name || u.email || '') + (u.email ? ' (' + u.email + ')' : '');
          return '<option value="' + escHtml(email) + '">' + escHtml(label) + '</option>';
        }).join('');
        sel.value = current;
      }catch(e){ USERS = []; }
    }

    async function loadTemplates(){
      const sel = document.getElementById('templateSelect');
      const templateMsg = document.getElementById('templateLoadMsg');
      if(templateMsg){ templateMsg.style.color = '#6b7280'; templateMsg.innerText = 'Cargando plantillas aprobadas desde HUB...'; }
      try{
        const r = await fetch('/api/due-templates?ts=' + Date.now());
        const data = await r.json();
        if(!r.ok || !data.ok) throw new Error(data.error || 'No se pudieron cargar plantillas');
        TEMPLATES = data.templates || [];
        sel.innerHTML = '<option value="">Seleccionar plantilla aprobada</option>' + TEMPLATES.map(function(t){
          return '<option value="' + escHtml(t.sid || '') + '">' + escHtml((t.name || t.sid || '') + (t.language ? ' · ' + t.language : '') + (t.category ? ' · ' + t.category : '')) + '</option>';
        }).join('');
        if(templateMsg){
          templateMsg.style.color = '#188038';
          templateMsg.innerText = TEMPLATES.length ? ('Plantillas cargadas: ' + TEMPLATES.length) : 'No hay plantillas aprobadas disponibles.';
        }
      }catch(err){
        sel.innerHTML = '<option value="">Error cargando plantillas</option>';
        if(templateMsg){
          templateMsg.style.color = '#d93025';
          templateMsg.innerText = 'Error cargando plantillas: ' + (err.message || 'Error desconocido') + '. Revisar CORE_BASE_URL del CRM y que el usuario tenga sesión válida en HUB.';
        }
      }
    }

    function buildQuery(){
      const params = new URLSearchParams();
      params.set('mode', MODE);
      params.set('limit', document.getElementById('limitFilter').value || '100');
      const stage = document.getElementById('stageFilter').value || '';
      const owner = document.getElementById('ownerFilter').value || '';
      const dealType = document.getElementById('dealTypeFilter').value || '';
      const sendState = (document.getElementById('sendStateFilter') || {}).value || '';
      const q = (document.getElementById('qFilter').value || '').trim();
      if(stage) params.set('stage', stage);
      if(owner) params.set('owner', owner);
      if(dealType) params.set('dealType', dealType);
      if(sendState) params.set('sendState', sendState);
      if(q) params.set('q', q);
      params.set('ts', Date.now());
      return params;
    }

    async function loadDueDeals(){
      const box = document.getElementById('groupsBox');
      box.innerHTML = '<div class="loading">Cargando vencimientos...</div>';
      document.getElementById('sendMsg').innerText = '';
      try{
        const r = await fetch('/api/due-deals?' + buildQuery().toString());
        const data = await r.json();
        if(!r.ok || !data.ok) throw new Error(data.error || 'No se pudieron cargar vencimientos');
        DUE_ROWS = data.deals || [];
        GROUPS = data.groups || {};
        SELECTED = new Set(Array.from(SELECTED).filter(function(id){ return DUE_ROWS.some(function(r){ return String(r.id) === String(id) && isSelectable(r); }); }));
        renderSummary(data.summary || {});
        renderGroups();
        updateSelectedPill();
        const activeStage = (document.getElementById('stageFilter').value || 'Todas las etapas');
        const activeSendState = (document.getElementById('sendStateFilter') || {}).value || '';
        const sendLabel = activeSendState === 'ready' ? ' · Listo para enviar' : (activeSendState === 'resend' ? ' · Listo para reenviar' : (activeSendState === 'blocked' ? ' · Bloqueados' : ''));
        const fallbackText = data.usedFallback ? (' · consulta alternativa' + (data.fallbackScope ? ' por ' + data.fallbackScope : '')) : ' · consulta filtrada';
        document.getElementById('loadedInfo').innerText = modeLabel() + ' · Etapa: ' + activeStage + sendLabel + ' · ' + DUE_ROWS.length + ' trato(s) cargados' + fallbackText + (data.hasMore ? ' · puede haber más' : '');
      }catch(err){
        box.innerHTML = '<div class="box"><div class="msg">Error cargando vencimientos: ' + escHtml(err.message || 'Error cargando datos') + '</div></div>';
        document.getElementById('loadedInfo').innerText = 'Error cargando vencimientos';
      }
    }

    function renderSummary(summary){
      const box = document.getElementById('summaryBox');
      box.innerHTML = ''
        + '<div class="metric"><div class="label">Total cargado</div><div class="value">' + Number(summary.total || 0) + '</div></div>'
        + '<div class="metric"><div class="label">Habilitados para enviar</div><div class="value">' + Number(summary.ready || 0) + '</div></div>'
        + '<div class="metric"><div class="label">Sin teléfono / inválidos</div><div class="value">' + Number((summary.noPhone || 0) + (summary.invalidPhone || 0) + (summary.noLine || 0)) + '</div></div>'
        + '<div class="metric"><div class="label">Con historial</div><div class="value">' + Number(summary.sent || 0) + '</div></div>';
    }

    function renderGroups(){
      const box = document.getElementById('groupsBox');
      const stages = Object.keys(GROUPS || {});
      if(!stages.length){ box.innerHTML = '<div class="box"><div class="muted">No hay tratos para mostrar.</div></div>'; return; }
      box.innerHTML = stages.map(function(stage){
        const rows = GROUPS[stage] || [];
        const ready = rows.filter(function(r){return !!r.canSend;}).length;
        const blocked = rows.filter(function(r){return !r.canSend;}).length;
        const sent = rows.filter(function(r){return Number(r.sentCount || 0) > 0 || r.status==='sent';}).length;
        const body = rows.map(function(r){
          const d = daysDiff(r.dueDate);
          const can = isSelectable(r);
          const checked = SELECTED.has(String(r.id)) ? ' checked' : '';
          const disabled = can ? '' : ' disabled';
          const sentCountText = Number(r.sentCount || 0)
            ? ('Envíos: ' + Number(r.sentCount || 0) + (r.lastSentAt ? ' · Último: ' + escHtml(formatDueDateTime(r.lastSentAt)) : ''))
            : 'Sin envíos previos';
          const lastTemplateText = r.lastTemplateName || r.lastTemplateSid || '';
          return '<tr>'
            + '<td><input class="check" type="checkbox"' + checked + disabled + ' onchange="toggleRow(&quot;' + escHtml(r.id) + '&quot;, this.checked)"></td>'
            + '<td><strong>' + escHtml(r.contactName || '-') + '</strong><div class="small">' + escHtml(r.company || '') + '</div></td>'
            + '<td>' + escHtml(r.phone || '-') + '</td>'
            + '<td>' + (r.lineId ? escHtml(r.lineId) : '<span style="color:#b45309">Sin línea</span>') + '<div class="small">' + escHtml(r.lineSource || '') + '</div></td>'
            + '<td><strong>' + escHtml(r.title || '-') + '</strong><div class="small">' + escHtml(r.dealTypeLabel || '') + '</div></td>'
            + '<td>' + escHtml(r.dueDate || '-') + '<div class="small">' + (d === '' ? '' : (d > 0 ? d + ' día(s) vencido' : d === 0 ? 'Vence hoy' : 'Faltan ' + Math.abs(d) + ' día(s)')) + '</div></td>'
            + '<td>' + escHtml(r.owner || '-') + '</td>'
            + '<td><span class="status ' + statusClass(r) + '">' + escHtml(statusLabel(r)) + '</span><div class="small">' + escHtml(r.blockReason || r.lastError || '') + '</div><div class="small"><b>' + escHtml(sentCountText) + '</b></div><div class="small">' + (lastTemplateText ? ('Última plantilla: ' + escHtml(lastTemplateText)) : '') + '</div><div id="hist_' + escHtml(r.id) + '" class="small"></div></td>'
            + '<td><button class="secondary" onclick="window.open(&quot;/pipeline?dealId=' + encodeURIComponent(r.id) + '&view=lista&quot;, &quot;_blank&quot;)">Abrir trato</button><div style="height:6px"></div><button class="secondary" onclick="viewDueMessageHistory(&quot;' + escHtml(r.id) + '&quot;)">Ver historial</button></td>'
            + '</tr>';
        }).join('');
        return '<div class="group">'
          + '<div class="group-head">'
          + '<div><div class="group-title">' + escHtml(stage) + '</div><div class="small">Ordenado por fecha de vencimiento</div></div>'
          + '<div class="group-stats"><span class="pill">' + rows.length + ' trato(s)</span><span class="pill ok">' + ready + ' habilitados</span><span class="pill warn">' + blocked + ' bloqueados</span><span class="pill">' + sent + ' con historial</span><button class="secondary" onclick="selectGroupReady(&quot;' + escHtml(stage) + '&quot;)">Seleccionar válidos</button></div>'
          + '</div>'
          + '<div><table><thead><tr><th></th><th>Cliente</th><th>Teléfono</th><th>Línea</th><th>Trato</th><th>Vencimiento</th><th>Owner</th><th>Estado</th><th>Acción</th></tr></thead><tbody>' + body + '</tbody></table></div>'
          + '</div>';
      }).join('');
    }

    async function viewDueMessageHistory(dealId){
      const id = String(dealId || '').trim();
      const box = document.getElementById('hist_' + id);
      if(!id || !box) return;
      box.innerHTML = '<div class="small">Cargando historial...</div>';
      try{
        const r = await fetch('/api/due-deals/' + encodeURIComponent(id) + '/message-logs?limit=10&ts=' + Date.now());
        const data = await r.json();
        if(!r.ok || !data.ok) throw new Error(data.error || 'No se pudo cargar historial');
        const logs = Array.isArray(data.items) ? data.items : [];
        if(!logs.length){ box.innerHTML = '<div class="small">Sin historial de envíos.</div>'; return; }
        box.innerHTML = '<div style="margin-top:8px;padding:8px;border:1px solid #dbe7ff;border-radius:8px;background:#f8fbff">' +
          logs.map(function(log){
            return '<div style="margin-bottom:6px"><b>' + escHtml(formatDueDateTime(log.sentAt || log.createdAt || '')) + '</b><br>Plantilla: ' + escHtml(log.templateName || log.templateSid || '-') + '<br>Estado: ' + escHtml(log.status || '-') + '</div>';
          }).join('<hr style="border:none;border-top:1px solid #e5e7eb">') +
          '</div>';
      }catch(err){
        box.innerHTML = '<div class="small" style="color:#d93025">Error cargando historial: ' + escHtml(err.message || 'error') + '</div>';
      }
    }

    function clearFilters(){
      document.getElementById('stageFilter').value = '';
      document.getElementById('ownerFilter').value = '';
      document.getElementById('dealTypeFilter').value = '';
      const sendStateFilter = document.getElementById('sendStateFilter');
      if (sendStateFilter) sendStateFilter.value = '';
      document.getElementById('qFilter').value = '';
      document.getElementById('limitFilter').value = '100';
      loadDueDeals();
    }

    function csvEscape(value){
      const s = String(value == null ? '' : value);
      if(/[";\\n\\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
      return s;
    }
    function exportCurrentView(){
      const headers = ['Etapa','Fecha vencimiento','Días vencido','Cliente','Empresa','Teléfono','Línea WhatsApp','Origen línea','Teléfono válido','Trato','Tipo de trato','Owner','Estado','Motivo','Último envío','Cantidad envíos','Deal ID','Contact ID'];
      const lines = [headers.map(csvEscape).join(';')];
      DUE_ROWS.forEach(function(r){
        const d = daysDiff(r.dueDate);
        lines.push([
          r.stage || '', r.dueDate || '', d === '' ? '' : d, r.contactName || '', r.company || '', r.phone || '', r.lineId || '', r.lineSource || '', r.canSend ? 'Sí' : 'No', r.title || '', r.dealTypeLabel || '', r.owner || '', statusLabel(r), r.blockReason || r.lastError || '', r.lastSentAt || '', r.sentCount || 0, r.id || '', r.contactId || ''
        ].map(csvEscape).join(';'));
      });
      const blob = new Blob(['\\uFEFF' + lines.join('\\n')], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'vencimientos_' + MODE + '_' + new Date().toISOString().slice(0,10) + '.csv';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    function getSelectedTemplateForDue(contentSid){
      const sid = String(contentSid || '').trim();
      return (TEMPLATES || []).find(function(t){ return String(t.sid || '').trim() === sid; }) || null;
    }
    let DUE_FOLDERS = [];
    async function loadDueCampaignFolders(){
      try{
        const r = await fetch('/api/due-campaign-folders?ts=' + Date.now());
        const d = await r.json();
        if(!r.ok || !d.ok) throw new Error(d.error || 'Error cargando carpetas');
        DUE_FOLDERS = Array.isArray(d.folders) ? d.folders : [];
        const sel = document.getElementById('campaignFolderSelect');
        if(sel){
          const current = sel.value || '';
          sel.innerHTML = '<option value="">Sin carpeta</option>' + DUE_FOLDERS.map(function(f){ return '<option value="' + escHtml(f.id || '') + '">' + escHtml(f.name || 'Carpeta') + '</option>'; }).join('');
          sel.value = current;
        }
      }catch(err){ console.warn('loadDueCampaignFolders', err); }
    }
    function getSelectedDueFolder(){
      const sel = document.getElementById('campaignFolderSelect');
      const id = String((sel && sel.value) || '').trim();
      if(!id) return { folderId:'', folderName:'' };
      const folder = DUE_FOLDERS.find(function(f){ return String(f.id || '') === id; }) || null;
      return { folderId: id, folderName: folder ? String(folder.name || '') : '' };
    }

    function collectDueSendPayload(){
      const contentSid = document.getElementById('templateSelect').value || '';
      const msg = document.getElementById('sendMsg');
      msg.className = 'msg';
      msg.innerText = '';
      if(!SELECTED.size){ msg.innerText = 'Seleccioná al menos un trato válido.'; return null; }
      if(!contentSid){ msg.innerText = 'Seleccioná una plantilla aprobada.'; return null; }
      let contentVariables = {};
      try{ contentVariables = JSON.parse((document.getElementById('templateVars').value || '{}').trim() || '{}'); }
      catch(e){ msg.innerText = 'Variables JSON inválidas.'; return null; }
      const delayMs = Math.max(0, Math.min(10000, Number((document.getElementById('sendDelayMs') || {}).value || 3000)));
      const campaignName = getCampaignNameForDue();
      const nextDueDateInput = document.getElementById('nextDueDateInput');
      const nextDueDate = nextDueDateInput ? String(nextDueDateInput.value || '').trim() : '';
      const folder = getSelectedDueFolder();
      return { dealIds: Array.from(SELECTED), contentSid: contentSid, contentVariables: contentVariables, delayMs: delayMs, campaignName: campaignName, nextDueDate: nextDueDate, folderId: folder.folderId, folderName: folder.folderName };
    }

    async function loadDueTemplatePreview(contentSid){
      const r = await fetch('/api/due-templates/' + encodeURIComponent(contentSid) + '/preview?ts=' + Date.now());
      const data = await r.json();
      if(!r.ok || !data.ok) throw new Error(data.error || 'No se pudo cargar preview de plantilla');
      return data.template || data;
    }

    function closeDuePreviewModal(){
      const modal = document.getElementById('duePreviewModal');
      if(modal) modal.style.display = 'none';
      PENDING_DUE_SEND = null;
    }

    async function sendSelectedTemplates(){
      const payload = collectDueSendPayload();
      if(!payload) return;
      PENDING_DUE_SEND = payload;

      const modal = document.getElementById('duePreviewModal');
      const meta = document.getElementById('duePreviewMeta');
      const body = document.getElementById('duePreviewText');
      const vars = document.getElementById('duePreviewVars');
      const template = getSelectedTemplateForDue(payload.contentSid) || {};

      if(meta) meta.innerText = 'Campaña: ' + (payload.campaignName || '-') + ' · Plantilla: ' + (template.name || payload.contentSid) + ' · Seleccionados: ' + payload.dealIds.length + (payload.nextDueDate ? ' · Próximo vencimiento: ' + payload.nextDueDate : ' · Próximo vencimiento: hoy + 7 días');
      if(body) body.innerText = 'Cargando preview de la plantilla...';
      if(vars) vars.innerText = JSON.stringify(payload.contentVariables || {}, null, 2);
      if(modal) modal.style.display = 'flex';

      try{
        const preview = await loadDueTemplatePreview(payload.contentSid);
        const previewText = preview.previewText || preview.body || preview.text || preview.content || 'No hay preview disponible para esta plantilla. Se enviará la plantilla aprobada seleccionada.';
        if(meta) meta.innerText = 'Campaña: ' + (payload.campaignName || '-') + ' · Plantilla: ' + (preview.name || template.name || payload.contentSid) + (preview.language ? ' · ' + preview.language : '') + (preview.category ? ' · ' + preview.category : '') + ' · Seleccionados: ' + payload.dealIds.length + (payload.nextDueDate ? ' · Próximo vencimiento: ' + payload.nextDueDate : ' · Próximo vencimiento: hoy + 7 días');
        if(body) body.innerText = previewText;
      }catch(err){
        if(body) body.innerText = 'No se pudo cargar el preview desde HUB. Error: ' + (err.message || 'Error desconocido') + '\\n\\nSe puede cancelar o confirmar el envío de la plantilla aprobada seleccionada.';
      }
    }

    function sleepClient(ms){
      return new Promise(function(resolve){ setTimeout(resolve, Math.max(0, Number(ms || 0))); });
    }

    function getCampaignNameForDue(){
      const input = document.getElementById('campaignNameInput');
      let name = input ? String(input.value || '').trim() : '';
      if(!name){
        const stage = (document.getElementById('stageFilter') || {}).value || 'Todas las etapas';
        const owner = (document.getElementById('ownerFilter') || {}).value || '';
        const d = new Date().toLocaleDateString('es-AR');
        name = modeLabel() + ' - ' + stage + (owner ? ' - ' + owner : '') + ' - ' + d;
        if(input) input.value = name;
      }
      return name;
    }

    async function loadDueCampaignHistory(){
      const box = document.getElementById('campaignHistoryBox');
      if(!box) return;
      box.innerHTML = 'Cargando historial...';
      try{
        const r = await fetch('/api/due-send-jobs?limit=15&ts=' + Date.now());
        const data = await r.json();
        if(!r.ok || !data.ok) throw new Error(data.error || 'No se pudo cargar historial');
        const jobs = Array.isArray(data.jobs) ? data.jobs : [];
        if(!jobs.length){ box.innerHTML = 'Sin campañas registradas todavía.'; return; }
        box.innerHTML = jobs.map(function(job){
          const s = job.summary || {};
          return '<div style="padding:8px 0;border-top:1px solid #eef2f7">'
            + '<b>' + escHtml(job.campaignName || 'Campaña sin nombre') + '</b>'
            + '<div>Estado: ' + escHtml(job.status || '-') + ' · Total: ' + Number(job.total || 0) + ' · Enviados: ' + Number(s.sent || 0) + ' · Omitidos: ' + Number(s.skipped || 0) + ' · Errores: ' + Number(s.errors || 0) + '</div>'
            + '<div>Plantilla: ' + escHtml(job.templateName || job.contentSid || '-') + ' · Creada: ' + escHtml(formatDueDateTime(job.createdAt || '')) + ' · Por: ' + escHtml(job.createdBy || '-') + '</div>'
            + '<div style="margin-top:6px"><button class="secondary" onclick="goCampaignFromDueHistory(&quot;' + escHtml(job.id || '') + '&quot;)">Ver campaña</button></div>'
            + '</div>';
        }).join('');
      }catch(err){
        box.innerHTML = '<span style="color:#d93025">Error cargando historial: ' + escHtml(err.message || 'error') + '</span>';
      }
    }

    function goCampaignFromDueHistory(jobId){
      const id = String(jobId || '').trim();
      if(!id){
        alert('No se encontró el ID de la campaña');
        return;
      }
      window.location.href = '/campanas?id=' + encodeURIComponent(id);
    }

    function renderDueQueueBox(job){
      const box = document.getElementById('queueBox');
      if(!box) return;
      if(!job){ box.style.display = 'none'; box.innerHTML = ''; return; }
      box.style.display = 'block';
      const summary = job.summary || {};
      const items = Array.isArray(job.items) ? job.items : [];
      const total = Number(job.total || summary.total || items.length || 0);
      const processed = Number(summary.processed || 0);
      const sent = Number(summary.sent || 0);
      const skipped = Number(summary.skipped || 0);
      const errors = Number(summary.errors || 0);
      const status = String(job.status || 'queued');
      const progress = total ? Math.round((processed / total) * 100) : 0;
      const rows = items.slice(0, 12).map(function(item){
        const state = String(item.status || 'queued');
        const label = item.contactName || item.dealTitle || item.dealId || '-';
        const info = item.error ? (' · ' + item.error) : (item.templateName ? (' · ' + item.templateName) : '');
        return '<div class="small" style="padding:4px 0;border-top:1px solid #e5e7eb"><b>' + escHtml(state) + '</b> · ' + escHtml(label) + escHtml(info) + '</div>';
      }).join('');
      box.innerHTML = ''
        + '<div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap">'
        + '<div><strong>Cola de envío</strong><div class="small">Estado: ' + escHtml(status) + ' · Delay: ' + Number(job.delayMs || 0) + ' ms</div></div>'
        + '<div><span class="pill">' + processed + '/' + total + ' procesados</span> <span class="pill ok">' + sent + ' enviados</span> <span class="pill warn">' + skipped + ' omitidos</span> <span class="pill warn">' + errors + ' errores</span></div>'
        + '</div>'
        + '<div style="height:10px"></div><div style="height:10px;background:#e5e7eb;border-radius:999px;overflow:hidden"><div style="height:10px;width:' + progress + '%;background:#188038"></div></div>'
        + '<div style="height:8px"></div>'
        + (status === 'running' || status === 'queued' ? '<button class="secondary" onclick="ACTIVE_DUE_JOB_STOP=true">Cancelar en próximo mensaje</button>' : '')
        + '<div style="height:8px"></div>' + rows;
    }

    async function cancelDueJobClient(jobId, reason){
      try{
        await fetch('/api/due-send-jobs/' + encodeURIComponent(jobId) + '/cancel', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ reason: reason || 'cancelado_desde_front' })
        });
      }catch(e){ console.warn('No se pudo cancelar cola', e); }
    }

    async function safeProcessFetch(url, options, timeoutMs){
      const controller = new AbortController();
      const timer = setTimeout(function(){ controller.abort(); }, Math.max(1000, Number(timeoutMs || 45000)));
      try{
        return await fetch(url, Object.assign({}, options || {}, { signal: controller.signal }));
      }finally{
        clearTimeout(timer);
      }
    }

    async function fetchDueJob(jobId){
      const r = await fetch('/api/due-send-jobs/' + encodeURIComponent(jobId) + '?ts=' + Date.now());
      const data = await r.json();
      if(!r.ok || !data.ok) throw new Error(data.error || 'No se pudo leer la cola');
      return data.job;
    }

    async function processDueJobLoop(jobId){
      if(ACTIVE_DUE_JOB_RUNNING){
        alert('Ya hay una cola de envío procesándose. Esperá que termine o cancelala.');
        return;
      }
      ACTIVE_DUE_JOB_RUNNING = true;
      ACTIVE_DUE_JOB_STOP = false;
      const msg = document.getElementById('sendMsg');
      let loops = 0;
      let lastProcessed = -1;
      let noProgress = 0;
      const startedAt = Date.now();
      try{
        while(true){
          if(ACTIVE_DUE_JOB_STOP){
            await cancelDueJobClient(jobId, 'cancelado_por_usuario');
            if(msg){ msg.className = 'msg'; msg.innerText = 'Cola cancelada. No seguirá enviando ni consultando en bucle.'; }
            const job = await fetchDueJob(jobId);
            ACTIVE_DUE_JOB = job;
            renderDueQueueBox(job);
            await loadDueCampaignHistory();
            return;
          }

          loops += 1;
          if(loops > 1000 || Date.now() - startedAt > 30*60*1000){
            await cancelDueJobClient(jobId, 'seguridad_maximo_bucle_o_tiempo');
            throw new Error('Cola cancelada por seguridad: superó el máximo de ciclos o tiempo.');
          }

          const r = await safeProcessFetch('/api/due-send-jobs/' + encodeURIComponent(jobId) + '/process-next', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
          }, 60000);
          const data = await r.json();
          if(!r.ok || !data.ok){
            await cancelDueJobClient(jobId, 'error_process_next_' + (data.error || r.status));
            throw new Error(data.error || 'Error procesando cola');
          }
          ACTIVE_DUE_JOB = data.job;
          renderDueQueueBox(ACTIVE_DUE_JOB);

          const processed = Number((ACTIVE_DUE_JOB && ACTIVE_DUE_JOB.summary && ACTIVE_DUE_JOB.summary.processed) || 0);
          if(processed === lastProcessed && !data.done && data.hasMore) noProgress += 1;
          else noProgress = 0;
          lastProcessed = processed;

          if(noProgress >= 3){
            await cancelDueJobClient(jobId, 'sin_avance_3_intentos');
            throw new Error('Cola cancelada por seguridad: no avanzó después de 3 intentos.');
          }

          if(data.done || !data.hasMore){
            if(msg){
              const s = (ACTIVE_DUE_JOB && ACTIVE_DUE_JOB.summary) || {};
              msg.className = 'msg okmsg';
              msg.innerText = 'Cola finalizada: enviados ' + (s.sent || 0) + ', omitidos ' + (s.skipped || 0) + ', errores ' + (s.errors || 0) + '.';
            }
            SELECTED = new Set();
            updateSelectedPill();
            await loadDueDeals();
            await loadDueCampaignHistory();
            return;
          }
          const delay = Number(data.nextDelayMs || (ACTIVE_DUE_JOB && ACTIVE_DUE_JOB.delayMs) || 3000);
          if(msg){ msg.className = 'msg okmsg'; msg.innerText = 'Cola en proceso. Próximo mensaje en ' + Math.round(delay/1000) + ' segundo(s)...'; }
          await sleepClient(delay);
        }
      }catch(err){
        if(msg){ msg.className = 'msg'; msg.innerText = (err && err.message) ? err.message : 'Cola cancelada por seguridad.'; }
        try{
          const job = await fetchDueJob(jobId);
          ACTIVE_DUE_JOB = job;
          renderDueQueueBox(job);
        }catch(e){}
      }finally{
        ACTIVE_DUE_JOB_RUNNING = false;
      }
    }

    async function confirmDueTemplateSend(){
      const payload = PENDING_DUE_SEND;
      const msg = document.getElementById('sendMsg');
      const btn = document.getElementById('confirmDueSendBtn');
      if(!payload){ closeDuePreviewModal(); return; }
      if(btn){ btn.disabled = true; btn.innerText = 'Creando cola...'; }
      try{
        msg.className = 'msg';
        msg.innerText = 'Creando cola de envío...';
        const r = await fetch('/api/due-send-jobs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await r.json();
        if(!r.ok || !data.ok) throw new Error(data.error || 'No se pudo crear la cola');
        closeDuePreviewModal();
        ACTIVE_DUE_JOB = data.job;
        renderDueQueueBox(ACTIVE_DUE_JOB);
        msg.className = 'msg okmsg';
        msg.innerText = 'Cola creada con ' + (ACTIVE_DUE_JOB.total || 0) + ' mensaje(s). Procesando con delay de ' + Math.round((ACTIVE_DUE_JOB.delayMs || 0)/1000) + ' segundo(s).';
        await processDueJobLoop(ACTIVE_DUE_JOB.id);
      }catch(err){
        msg.className = 'msg';
        msg.innerText = err.message || 'Error creando/procesando cola';
      }finally{
        if(btn){ btn.disabled = false; btn.innerText = 'Confirmar y enviar'; }
      }
    }

    document.getElementById('duePreviewModal').addEventListener('click', function(e){ if(e.target && e.target.id === 'duePreviewModal') closeDuePreviewModal(); });
    document.getElementById('stageFilter').addEventListener('change', loadDueDeals);
    document.getElementById('ownerFilter').addEventListener('change', loadDueDeals);
    document.getElementById('dealTypeFilter').addEventListener('change', loadDueDeals);
    document.getElementById('sendStateFilter').addEventListener('change', loadDueDeals);
    document.getElementById('limitFilter').addEventListener('change', loadDueDeals);
    let searchTimer = null;
    document.getElementById('qFilter').addEventListener('input', function(){ clearTimeout(searchTimer); searchTimer = setTimeout(loadDueDeals, 350); });

    (async function init(){
      try {
        updateTabs();
        await Promise.allSettled([loadUsers(), loadTemplates(), loadDueCampaignFolders()]);
        await loadDueDeals();
        await loadDueCampaignHistory();
      } catch (err) {
        const box = document.getElementById('groupsBox');
        if (box) box.innerHTML = '<div class="box"><div class="msg">Error inicializando vencimientos: ' + escHtml(err.message || 'error desconocido') + '</div></div>';
      }
    })();
  </script>
</body>
</html>
  `);
});



// =====================================================
// BLOQUE 4C - MI ESTADO COMERCIAL
// =====================================================
const MY_STATUS_SECTIONS = {
  nuevos_prospectos: { label: "Nuevos Prospectos", stage: "Nuevos Prospectos" },
  seguimiento: { label: "Seguimiento", stage: "Seguimiento" },
  marca_personal: { label: "Marca personal", stage: "Marca personal" },
  esperando_pi: { label: "Esperando PI", stage: "Esperando PI" },
  para_cotizar: { label: "Para cotizar", stage: "Para cotizar" },
  cotizado_para_enviar: { label: "Cotizado para enviar", stage: "Cotizado para enviar" },
  horno: { label: "Horno", stage: "Horno" }
};

function normalizeMyStatusPeriod(value) {
  const clean = String(value || "today").trim().toLowerCase();
  if (["today", "week", "month", "total", "custom"].includes(clean)) return clean;
  return "today";
}

function getMyStatusPeriodRange(period, startDateIso, endDateIso) {
  const normalized = normalizeMyStatusPeriod(period);
  if (normalized === "total") return { period: normalized, start: null, end: null, startIso: "", endIso: "" };

  if (normalized === "custom") {
    const startValue = String(startDateIso || "").trim();
    const endValue = String(endDateIso || startValue || "").trim();
    const startDate = isoToDateUTC(startValue);
    const endDate = isoToDateUTC(endValue);
    if (startDate && endDate) {
      const safeStart = startDate <= endDate ? startDate : endDate;
      const safeEnd = startDate <= endDate ? endDate : startDate;
      return {
        period: normalized,
        start: safeStart,
        end: addDaysUTC(safeEnd, 1),
        startIso: dateToISOUTC(safeStart),
        endIso: dateToISOUTC(safeEnd)
      };
    }
  }

  const now = new Date();
  const baParts = nowInBuenosAiresParts();
  const todayUtc = new Date(Date.UTC(baParts.year, baParts.month - 1, baParts.day));
  let start = new Date(todayUtc.getTime());

  if (normalized === "week") {
    const day = getISODayOfWeek(todayUtc);
    start = addDaysUTC(todayUtc, 1 - day);
  } else if (normalized === "month") {
    start = new Date(Date.UTC(baParts.year, baParts.month - 1, 1));
  }

  const end = addDaysUTC(todayUtc, 1);
  return {
    period: normalized === "custom" ? "today" : normalized,
    start,
    end,
    startIso: dateToISOUTC(start),
    endIso: dateToISOUTC(addDaysUTC(end, -1))
  };
}

function myStatusDateInRange(value, range) {
  if (!range || !range.start || !range.end) return true;
  const millis = timestampToMillis(value);
  return !!millis && millis >= range.start.getTime() && millis < range.end.getTime();
}

function myStatusDealCreatedInFiniteRange(deal, range) {
  if (!range || !range.start || !range.end) return false;
  if (deal && Number(deal.createdAtMillis || 0)) {
    return myStatusDateInRange(new Date(Number(deal.createdAtMillis || 0)), range);
  }
  return myStatusDateInRange(deal && deal.createdAt, range);
}

function myStatusDealMatchesSection(deal, section, range, todayIso) {
  const stage = String((deal && deal.stage) || "").trim();

  // Mi Estado > Nuevos Prospectos:
  // no significa "tratos que HOY están en la etapa Nuevos Prospectos".
  // Significa "tratos nuevos creados/asignados a ese owner en el período elegido".
  // Así, si el vendedor creó/recibió un trato hoy y luego lo movió a Seguimiento/Horno,
  // sigue contando como nuevo del período.
  if (section === "nuevos_prospectos") {
    if (!range || !range.start || !range.end) return true;
    return myStatusDealCreatedInFiniteRange(deal, range);
  }

  const cfg = MY_STATUS_SECTIONS[section] || {};
  if (cfg.stage) return stage === cfg.stage;
  return false;
}

function normalizeMyStatusOwnerEmail(value) {
  return String(value || "").trim().toLowerCase();
}

async function getMyStatusOwnerScope(req) {
  const requestedOwner = normalizeMyStatusOwnerEmail(req.query.owner || "");
  const visibleOwnerEmails = await getVisibleOwnerEmails(req.authUser);
  const visible = Array.isArray(visibleOwnerEmails)
    ? Array.from(new Set(visibleOwnerEmails.map(normalizeMyStatusOwnerEmail).filter(Boolean)))
    : null;

  if ((isAdmin(req.authUser) || isBackoffice(req.authUser)) && (!requestedOwner || requestedOwner === "all")) {
    return { mode: "all", owner: "", owners: null, visible };
  }

  if (requestedOwner && (isAdmin(req.authUser) || isBackoffice(req.authUser))) {
    return { mode: "one", owner: requestedOwner, owners: [requestedOwner], visible };
  }

  if (visible && visible.length) {
    const own = normalizeMyStatusOwnerEmail(req.authUser && req.authUser.email);
    return { mode: "one", owner: own || visible[0], owners: [own || visible[0]], visible };
  }

  const fallback = normalizeMyStatusOwnerEmail(req.authUser && req.authUser.email);
  return { mode: "one", owner: fallback, owners: fallback ? [fallback] : [], visible };
}

function normalizeMyStatusDeal(doc) {
  const data = doc && typeof doc.data === "function" ? (doc.data() || {}) : (doc || {});
  return {
    id: doc && doc.id ? doc.id : String(data.id || ""),
    title: data.title || "",
    contactName: data.contactName || "",
    company: data.company || "",
    value: Number(data.value || 0) || 0,
    dueDate: data.dueDate || "",
    stage: data.stage || "",
    owner: normalizeMyStatusOwnerEmail(data.owner || ""),
    notes: data.notes || "",
    leadQuality: normalizeLeadQuality(data.leadQuality || "NO_RESPONDE"),
    leadQualityLabel: getLeadQualityLabel(data.leadQuality || "NO_RESPONDE"),
    dealType: normalizeDealType(data.dealType || "LCL_PROPIO"),
    createdAtMillis: timestampToMillis(data.createdAt),
    updatedAtMillis: timestampToMillis(data.updatedAt)
  };
}

function sortMyStatusDeals(section, deals) {
  const arr = Array.isArray(deals) ? deals.slice() : [];
  return arr.sort((a, b) => {
    const dueCmp = String(a.dueDate || "9999-99-99").localeCompare(String(b.dueDate || "9999-99-99"));
    if (dueCmp !== 0) return dueCmp;
    const valueCmp = (Number(b.value || 0) - Number(a.value || 0));
    if (valueCmp !== 0) return valueCmp;
    return (Number(b.updatedAtMillis || 0) - Number(a.updatedAtMillis || 0));
  });
}

async function scanMyStatusDealsForOwner(ownerEmail, options) {
  const section = String(options.section || "");
  const range = options.range || getMyStatusPeriodRange("today");
  const todayIso = options.todayIso || getTodayISOInBuenosAires();
  const limit = Math.max(1, Math.min(50, Number(options.limit || 25)));
  const offset = Math.max(0, Number(options.offset || 0));
  const maxScan = Math.max(250, Math.min(2500, Number(options.maxScan || 1500)));
  const owner = normalizeMyStatusOwnerEmail(ownerEmail);
  if (!owner) return { deals: [], total: 0, hasMore: false, scanned: 0 };

  let query = db.collection("deals").where("owner", "==", owner).orderBy("createdAt", "desc").limit(maxScan);
  const snap = await query.get();
  const matched = [];
  snap.docs.forEach((doc) => {
    const deal = normalizeMyStatusDeal(doc);
    if (myStatusDealMatchesSection(deal, section, range, todayIso)) matched.push(deal);
  });

  const sorted = sortMyStatusDeals(section, matched);
  const page = sorted.slice(offset, offset + limit);
  return {
    deals: page,
    total: sorted.length,
    hasMore: sorted.length > offset + limit,
    scanned: snap.size
  };
}

function emptyMyStatusMetrics(owner, name) {
  return {
    owner: owner || "",
    name: name || owner || "Sin owner",
    nuevosProspectos: 0,
    nuevosProspectosVencidos: 0,
    seguimiento: 0,
    seguimientoVencidos: 0,
    marcaPersonal: 0,
    marcaPersonalVencidos: 0,
    esperandoPI: 0,
    esperandoPIVencidos: 0,
    paraCotizar: 0,
    paraCotizarVencidos: 0,
    cotizadoParaEnviar: 0,
    cotizadoParaEnviarVencidos: 0,
    horno: 0,
    hornoVencidos: 0,
    vencidosClave: 0,
    totalCalidad: 0,
    calidadDescartado: 0,
    calidadNoResponde: 0,
    calidadRegular: 0,
    calidadBueno: 0,
    calidadExcelente: 0,
    buenoExcelente: 0,
    buenoExcelentePct: 0
  };
}

function addDealToMyStatusMetrics(metrics, deal, range, todayIso) {
  const stage = String(deal.stage || "").trim();
  const dueDate = String(deal.dueDate || "").trim();
  const isVencido = !!dueDate && dueDate < todayIso;

  // Nuevos Prospectos en Mi Estado = tratos creados/asignados al owner en el período seleccionado,
  // independientemente de la etapa actual del trato.
  const isNewDealForSelectedPeriod = (!range || !range.start || !range.end)
    ? true
    : myStatusDealCreatedInFiniteRange(deal, range);

  if (isNewDealForSelectedPeriod) {
    metrics.nuevosProspectos += 1;
    if (isVencido) metrics.nuevosProspectosVencidos += 1;

    // Calidad de los leads que ingresaron en el período elegido.
    // Se toma la calidad actual del trato, pero solamente para tratos
    // creados/asignados dentro del rango seleccionado.
    const quality = normalizeLeadQuality(deal.leadQuality || "NO_RESPONDE");
    metrics.totalCalidad += 1;
    if (quality === "DESCARTADO") metrics.calidadDescartado += 1;
    if (quality === "NO_RESPONDE") metrics.calidadNoResponde += 1;
    if (quality === "REGULAR") metrics.calidadRegular += 1;
    if (quality === "BUENO") metrics.calidadBueno += 1;
    if (quality === "EXCELENTE") metrics.calidadExcelente += 1;
    if (quality === "BUENO" || quality === "EXCELENTE") metrics.buenoExcelente += 1;
  }
  if (stage === "Seguimiento") {
    metrics.seguimiento += 1;
    if (isVencido) metrics.seguimientoVencidos += 1;
  }
  if (stage === "Marca personal") {
    metrics.marcaPersonal += 1;
    if (isVencido) metrics.marcaPersonalVencidos += 1;
  }
  if (stage === "Esperando PI") {
    metrics.esperandoPI += 1;
    if (isVencido) metrics.esperandoPIVencidos += 1;
  }
  if (stage === "Para cotizar") {
    metrics.paraCotizar += 1;
    if (isVencido) metrics.paraCotizarVencidos += 1;
  }
  if (stage === "Cotizado para enviar") {
    metrics.cotizadoParaEnviar += 1;
    if (isVencido) metrics.cotizadoParaEnviarVencidos += 1;
  }
  if (stage === "Horno") {
    metrics.horno += 1;
    if (isVencido) metrics.hornoVencidos += 1;
  }

  if (isVencido && ["Nuevos Prospectos", "Seguimiento", "Marca personal", "Esperando PI", "Para cotizar", "Cotizado para enviar", "Horno"].includes(stage)) {
    metrics.vencidosClave += 1;
  }
}

async function buildMyStatusSummaryForOwner(ownerEmail, userName, range, todayIso) {
  const owner = normalizeMyStatusOwnerEmail(ownerEmail);
  const metrics = emptyMyStatusMetrics(owner, userName || owner);
  if (!owner) return metrics;

  const maxScan = 2500;
  const snap = await db.collection("deals").where("owner", "==", owner).orderBy("createdAt", "desc").limit(maxScan).get();
  snap.docs.forEach((doc) => addDealToMyStatusMetrics(metrics, normalizeMyStatusDeal(doc), range, todayIso));
  metrics.buenoExcelentePct = metrics.totalCalidad ? Math.round((metrics.buenoExcelente / metrics.totalCalidad) * 100) : 0;
  metrics.scanned = snap.size;
  metrics.limited = snap.size >= maxScan;
  return metrics;
}

app.get("/mi-estado", (req, res) => {
  const stageOptions = PIPELINE_STAGES.map((stage) => `<option value="${esc(stage)}">${esc(stage)}</option>`).join("");
  const leadQualityOptions = buildLeadQualityOptions("NO_RESPONDE");
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Mi Estado</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;color:#111827}
    .topbar{background:#1a73e8;color:#fff;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
    .container{padding:22px;max-width:1600px;margin:0 auto}
    .box{background:#fff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.08);padding:16px;margin-bottom:16px}
    button{padding:10px 13px;border:none;border-radius:8px;background:#1a73e8;color:#fff;font-weight:bold;cursor:pointer}button:disabled{opacity:.55;cursor:not-allowed}.secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}.success{background:#188038}.danger{background:#d93025}
    input,select,textarea{padding:9px;border:1px solid #cfd7e2;border-radius:8px;box-sizing:border-box;font-family:Arial,sans-serif}textarea{resize:vertical;min-height:42px;width:100%}
    label{font-size:12px;color:#5f6368;font-weight:bold;display:block;margin-bottom:6px}.muted,.small{color:#6b7280;font-size:12px}.msg{white-space:pre-wrap;color:#d93025}.okmsg{color:#188038}
    .filters{display:flex;gap:12px;align-items:end;flex-wrap:wrap}.filters>div{min-width:190px}.filters select,.filters input{width:100%}
    .priority{background:#fff8e1;border:1px solid #f4d06f;border-radius:12px;padding:14px;font-weight:bold;color:#6f4e00;margin-bottom:16px}
    .cards{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:12px;margin-bottom:16px}.card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:13px;box-shadow:0 2px 10px rgba(0,0,0,.04)}.card .label{font-size:12px;color:#5f6368}.card .value{font-size:24px;font-weight:bold;color:#174ea6;margin-top:5px}.card .sub{font-size:12px;color:#6b7280;margin-top:4px}
    .qualitySummary{margin-bottom:16px}.qualityHeader{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap;margin-bottom:12px}.qualityGrid{display:grid;grid-template-columns:repeat(6,minmax(130px,1fr));gap:10px}.qualityCard{border:1px solid #e5e7eb;border-radius:12px;padding:12px;background:#fafcff}.qualityCard .qLabel{font-size:12px;color:#5f6368}.qualityCard .qValue{font-size:22px;font-weight:800;margin-top:5px}.qualityCard.good{background:#e6f4ea;border-color:#cde8d4}.qualityCard.bad{background:#fce8e6;border-color:#f6c7c2}.qualityCard.neutral{background:#fff8e1;border-color:#f4d06f}
    .sections{display:grid;grid-template-columns:1fr;gap:16px}.section{background:#fff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.08);overflow:hidden}.sectionHead{display:flex;justify-content:space-between;gap:10px;align-items:center;padding:13px 15px;background:#eef3fb;flex-wrap:wrap}.sectionTitle{font-weight:bold;color:#174ea6}.sectionBody{max-height:520px;overflow:auto;scrollbar-gutter:stable}.sectionFooter{padding:12px 15px;border-top:1px solid #e5e7eb;background:#fafcff}
    table{width:100%;border-collapse:collapse;min-width:1050px}th,td{padding:9px 10px;border-bottom:1px solid #edf1f5;text-align:left;font-size:13px;vertical-align:top}th{background:#f8fafc;color:#374151;font-size:12px;position:sticky;top:0;z-index:2}.dealTitle{font-weight:bold}.pill{display:inline-block;padding:4px 8px;border-radius:999px;background:#eef3fb;color:#174ea6;border:1px solid #dbe7ff;font-weight:bold;font-size:12px}.pill.ok{background:#e6f4ea;color:#137333;border-color:#cde8d4}.pill.warn{background:#fff3cd;color:#8a6d3b;border-color:#f1df9a}.pill.err{background:#fce8e6;color:#c5221f;border-color:#f6c7c2}.mini{width:140px}.noteBox{width:260px}.dateBox{width:132px}.stageBox{width:170px}.qualityBox{width:130px}.actionsInline{display:flex;gap:7px;align-items:center;flex-wrap:wrap}.saving{opacity:.65}
    .adminTableWrap{overflow:auto;max-height:70vh}.adminTableWrap table{min-width:1180px}.historyBox{display:none;margin-top:8px;max-height:180px;overflow:auto;border:1px solid #e5e7eb;border-radius:8px;background:#fafcff;padding:8px}.historyItem{border-bottom:1px solid #e5e7eb;padding:7px 0}.historyItem:last-child{border-bottom:none}.hubBtn{background:#111827;color:#fff}
    @media(max-width:900px){.container{padding:12px}.cards{grid-template-columns:repeat(2,1fr)}.qualityGrid{grid-template-columns:repeat(2,1fr)}.filters>div{min-width:150px}.sectionBody{max-height:470px}}
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>CRMSCB</strong> / Mi Estado</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap"><button class="secondary" onclick="window.location='/pipeline'">Pipeline</button><button class="secondary" onclick="window.open('/','_blank')">Ir al HUB</button><button class="secondary" onclick="window.location='/crm'">Volver al panel</button></div>
  </div>
  <div class="container">
    <div class="box">
      <h2 style="margin-top:0">Mi Estado Comercial</h2>
      <div class="filters">
        <div><label>Período</label><select id="periodFilter"><option value="today">Hoy</option><option value="week">Semana</option><option value="month">Mes</option><option value="total">Total</option><option value="custom">Personalizado</option></select></div><div id="customDateWrap" style="display:none"><label>Desde</label><input id="customStartDate" type="date"></div><div id="customDateEndWrap" style="display:none"><label>Hasta</label><input id="customEndDate" type="date"></div>
        <div id="ownerFilterWrap" style="display:none"><label>Vendedor</label><select id="ownerFilter"><option value="all">Todos</option></select></div>
        <div><button onclick="reloadAll()">Actualizar</button></div>
      </div>
    </div>
    <div id="priorityBox" class="priority">Cargando prioridades...</div>
    <div id="cardsBox" class="cards"></div>
    <div id="qualitySummaryBox" class="box qualitySummary"></div>
    <div id="adminSummaryBox" class="box" style="display:none"></div>
    <div id="sectionsBox" class="sections"></div>
  </div>
<script>
  const userRaw = localStorage.getItem("crmscb_user");
  if(!userRaw) window.location.href = "/?redirect=" + encodeURIComponent(window.location.pathname + window.location.search);
  const CURRENT_USER = JSON.parse(userRaw || "{}");
  const PIPELINE_STAGES = ${JSON.stringify(PIPELINE_STAGES)};
  const LEAD_QUALITY_VALUES = ${JSON.stringify(LEAD_QUALITY_VALUES)};
  const LEAD_QUALITY_LABELS = ${JSON.stringify(LEAD_QUALITY_LABELS)};
  const STAGE_OPTIONS_HTML = ${JSON.stringify(stageOptions)};
  const QUALITY_OPTIONS_HTML = ${JSON.stringify(leadQualityOptions)};
  const SECTIONS = [
    {key:'nuevos_prospectos', label:'Nuevos Prospectos'},
    {key:'seguimiento', label:'Seguimiento'},
    {key:'marca_personal', label:'Marca personal'},
    {key:'esperando_pi', label:'Esperando PI'},
    {key:'para_cotizar', label:'Para cotizar'},
    {key:'cotizado_para_enviar', label:'Cotizado para enviar'},
    {key:'horno', label:'Horno'}
  ];
  let USERS = [];
  let SUMMARY = null;
  let SECTION_STATE = {};
  const __originalFetch = window.fetch.bind(window);
  window.fetch = function(url, options){
    const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
    options = options || {}; options.headers = Object.assign({}, options.headers || {}, {"x-user-id":user.id||"", "x-auth-token":user.token||""});
    return __originalFetch(url, options);
  };
  function escHtml(s){return String(s||"").replace(/[&<>\"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[m];});}
  function normalizeRole(role){const r=String(role||'').trim().toLowerCase(); if(['admin','backoffice','team_leader','field_sales'].includes(r)) return r; return 'field_sales';}
  function isAdminView(){const r=normalizeRole(CURRENT_USER.role); return r==='admin'||r==='backoffice';}
  function money(n){return 'USD ' + Number(n||0).toLocaleString('es-AR', {maximumFractionDigits:0});}
  function qualityLabel(q){return LEAD_QUALITY_LABELS[String(q||'NO_RESPONDE')] || 'No Responde';}
  function selectedPeriod(){return document.getElementById('periodFilter').value || 'today';}
  function customStartDate(){return String((document.getElementById('customStartDate')||{}).value||'').trim();}
  function customEndDate(){return String((document.getElementById('customEndDate')||{}).value||customStartDate()||'').trim();}
  function appendPeriodParams(params){params.set('period', selectedPeriod()); if(selectedPeriod()==='custom'){params.set('startDate', customStartDate()); params.set('endDate', customEndDate());}}
  function toggleCustomDates(){const show=selectedPeriod()==='custom'; const a=document.getElementById('customDateWrap'); const b=document.getElementById('customDateEndWrap'); if(a)a.style.display=show?'block':'none'; if(b)b.style.display=show?'block':'none'; if(show){const today=new Date().toISOString().slice(0,10); const s=document.getElementById('customStartDate'); const e=document.getElementById('customEndDate'); if(s&&!s.value)s.value=today; if(e&&!e.value)e.value=s&&s.value?s.value:today;}}
  function selectedOwner(){const sel=document.getElementById('ownerFilter'); return isAdminView() ? String((sel&&sel.value)||'all') : String(CURRENT_USER.email||'').toLowerCase();}
  async function loadUsers(){
    if(!isAdminView()) return;
    document.getElementById('ownerFilterWrap').style.display='block';
    try{const r=await fetch('/api/users?ts='+Date.now()); const d=await r.json(); USERS=Array.isArray(d)?d:[]; const sel=document.getElementById('ownerFilter'); sel.innerHTML='<option value="all">Todos</option>'+USERS.map(function(u){const email=String(u.email||'').toLowerCase(); return '<option value="'+escHtml(email)+'">'+escHtml((u.name||u.email||'')+(u.email?' ('+u.email+')':''))+'</option>';}).join('');}catch(e){USERS=[];}
  }
  async function loadSummary(){
    const params = new URLSearchParams(); appendPeriodParams(params); params.set('owner', selectedOwner()); params.set('ts', Date.now());
    const r = await fetch('/api/my-status/summary?' + params.toString()); const d = await r.json(); if(!r.ok || !d.ok) throw new Error(d.error || 'Error cargando resumen'); SUMMARY = d; renderSummary();
  }
  function activeMetrics(){return SUMMARY && SUMMARY.summary ? SUMMARY.summary : {};}
  function renderSummary(){
    const m = activeMetrics();
    const sellerName = selectedOwner()==='all' ? 'El equipo' : (m.name || CURRENT_USER.name || CURRENT_USER.email || 'Vendedor');
    document.getElementById('priorityBox').innerText = sellerName + ' tiene ' + Number(m.vencidosClave||0) + ' vencidos en etapas clave. ' +
      'Nuevos Prospectos ' + Number(m.nuevosProspectosVencidos||0) + ', Seguimiento ' + Number(m.seguimientoVencidos||0) + ', Marca personal ' + Number(m.marcaPersonalVencidos||0) + ', Esperando PI ' + Number(m.esperandoPIVencidos||0) + ', Para cotizar ' + Number(m.paraCotizarVencidos||0) + ', Cotizado ' + Number(m.cotizadoParaEnviarVencidos||0) + ' y Horno ' + Number(m.hornoVencidos||0) + '.';
    const cards = [
      ['Nuevos Prospectos', m.nuevosProspectos, selectedPeriod()==='total' ? 'tratos creados/asignados' : 'creados/asignados en período'],
      ['Seguimiento', m.seguimiento, Number(m.seguimientoVencidos||0) + ' vencidos'],
      ['Marca personal', m.marcaPersonal, Number(m.marcaPersonalVencidos||0) + ' vencidos'],
      ['Esperando PI', m.esperandoPI, Number(m.esperandoPIVencidos||0) + ' vencidos'],
      ['Para cotizar', m.paraCotizar, Number(m.paraCotizarVencidos||0) + ' vencidos'],
      ['Cotizado para enviar', m.cotizadoParaEnviar, Number(m.cotizadoParaEnviarVencidos||0) + ' vencidos'],
      ['Horno', m.horno, Number(m.hornoVencidos||0) + ' vencidos']
    ];
    document.getElementById('cardsBox').innerHTML = cards.map(function(c){return '<div class="card"><div class="label">'+escHtml(c[0])+'</div><div class="value">'+escHtml(c[1])+'</div><div class="sub">'+escHtml(c[2])+'</div></div>';}).join('');
    renderQualitySummary();
    renderAdminSummary();
  }
  function periodLabel(){
    const p=selectedPeriod();
    if(p==='today') return 'hoy';
    if(p==='week') return 'esta semana';
    if(p==='month') return 'este mes';
    if(p==='custom') return 'el período personalizado';
    return 'todo el historial';
  }
  function renderQualitySummary(){
    const m=activeMetrics();
    const box=document.getElementById('qualitySummaryBox');
    if(!box) return;
    const qualityCards=[
      ['Descartado', Number(m.calidadDescartado||0), 'bad'],
      ['No responde', Number(m.calidadNoResponde||0), 'bad'],
      ['Regular', Number(m.calidadRegular||0), 'neutral'],
      ['Bueno', Number(m.calidadBueno||0), 'good'],
      ['Excelente', Number(m.calidadExcelente||0), 'good'],
      ['Bueno + Excelente', Number(m.buenoExcelentePct||0)+'%', 'good']
    ];
    box.innerHTML='<div class="qualityHeader"><div><h3 style="margin:0 0 5px 0">Calidad de los leads ingresados</h3><div class="small">Tratos creados/asignados '+escHtml(periodLabel())+' · Total evaluado: <b>'+Number(m.totalCalidad||0)+'</b></div></div></div><div class="qualityGrid">'+qualityCards.map(function(q){return '<div class="qualityCard '+q[2]+'"><div class="qLabel">'+escHtml(q[0])+'</div><div class="qValue">'+escHtml(q[1])+'</div></div>';}).join('')+'</div>';
  }
  function renderAdminSummary(){
    const box=document.getElementById('adminSummaryBox');
    if(!SUMMARY || !SUMMARY.adminRows || selectedOwner() !== 'all'){box.style.display='none'; box.innerHTML=''; return;}
    box.style.display='block';
    const rows=SUMMARY.adminRows||[];
    box.innerHTML='<h3 style="margin-top:0">Resumen por vendedor</h3><div class="small" style="margin-bottom:8px">Nuevos Prospectos cuenta tratos creados/asignados en el período elegido. El resto muestra etapas comerciales principales y vencidos.</div><div class="adminTableWrap"><table><thead><tr><th>Vendedor</th><th>Nuevos Prospectos</th><th>Seguimiento</th><th>Marca personal</th><th>Esperando PI</th><th>Para cotizar</th><th>Cotizado para enviar</th><th>Horno</th><th>Vencidos clave</th><th>Calidad leads ingresados</th></tr></thead><tbody>'+
      rows.map(function(r){return '<tr><td><b>'+escHtml(r.name||r.owner||'-')+'</b><div class="small">'+escHtml(r.owner||'')+'</div></td><td>'+Number(r.nuevosProspectos||0)+'<div class="small">'+Number(r.nuevosProspectosVencidos||0)+' venc.</div></td><td>'+Number(r.seguimiento||0)+'<div class="small">'+Number(r.seguimientoVencidos||0)+' venc.</div></td><td>'+Number(r.marcaPersonal||0)+'<div class="small">'+Number(r.marcaPersonalVencidos||0)+' venc.</div></td><td>'+Number(r.esperandoPI||0)+'<div class="small">'+Number(r.esperandoPIVencidos||0)+' venc.</div></td><td>'+Number(r.paraCotizar||0)+'<div class="small">'+Number(r.paraCotizarVencidos||0)+' venc.</div></td><td>'+Number(r.cotizadoParaEnviar||0)+'<div class="small">'+Number(r.cotizadoParaEnviarVencidos||0)+' venc.</div></td><td>'+Number(r.horno||0)+'<div class="small">'+Number(r.hornoVencidos||0)+' venc.</div></td><td><b>'+Number(r.vencidosClave||0)+'</b></td><td><b>'+Number(r.buenoExcelentePct||0)+'% Bueno/Excelente</b><div class="small">E '+Number(r.calidadExcelente||0)+' · B '+Number(r.calidadBueno||0)+' · R '+Number(r.calidadRegular||0)+' · NR '+Number(r.calidadNoResponde||0)+' · D '+Number(r.calidadDescartado||0)+'</div></td></tr>';}).join('')+
      '</tbody></table></div><div class="small" style="margin-top:8px">Para ver listas, elegí un vendedor específico.</div>';
  }
  function renderSectionsSkeleton(){
    const box=document.getElementById('sectionsBox');
    if(selectedOwner()==='all'){box.innerHTML=''; return;}
    box.innerHTML=SECTIONS.map(function(s){return '<div class="section" id="section_'+escHtml(s.key)+'"><div class="sectionHead"><div><div class="sectionTitle">'+escHtml(s.label)+'</div><div class="small" id="meta_'+escHtml(s.key)+'">Cargando...</div></div><button class="secondary" data-section="'+escHtml(s.key)+'" onclick="loadSectionFromButton(this, true)">Refrescar</button></div><div class="sectionBody" id="body_'+escHtml(s.key)+'"><div style="padding:14px" class="small">Cargando...</div></div><div class="sectionFooter" id="foot_'+escHtml(s.key)+'"></div></div>';}).join('');
  }
  function makeOptions(optionsHtml, selected){ return String(optionsHtml||'').replace('value="'+String(selected||'').replace(/"/g,'&quot;')+'"', 'value="'+String(selected||'').replace(/"/g,'&quot;')+'" selected'); }
  function stageSelectHtml(value){ return '<select class="stageBox" data-field="stage">' + PIPELINE_STAGES.map(function(st){return '<option value="'+escHtml(st)+'"'+(st===String(value||'')?' selected':'')+'>'+escHtml(st)+'</option>';}).join('') + '</select>'; }
  function qualitySelectHtml(value){ return '<select class="qualityBox" data-field="leadQuality">' + LEAD_QUALITY_VALUES.map(function(q){return '<option value="'+escHtml(q)+'"'+(q===String(value||'NO_RESPONDE')?' selected':'')+'>'+escHtml(qualityLabel(q))+'</option>';}).join('') + '</select>'; }

  function loadSectionFromButton(btn, reset){ loadSection(String((btn && btn.dataset && btn.dataset.section) || ''), !!reset); }
  function saveRowFromButton(btn){ saveRow(String((btn && btn.dataset && btn.dataset.id) || ''), String((btn && btn.dataset && btn.dataset.section) || '')); }
  function openDealFromButton(btn){ const id = String((btn && btn.dataset && btn.dataset.id) || ''); if(id) window.open('/pipeline?dealId=' + encodeURIComponent(id) + '&view=lista', '_blank'); }
  async function openHubFromButton(btn){
    const id = String((btn && btn.dataset && btn.dataset.id) || '');
    if(!id) return;
    try{
      const r = await fetch('/api/deals/' + encodeURIComponent(id) + '/hub-link?ts=' + Date.now());
      const data = await r.json();
      if(!r.ok || !data.ok || !data.found || !data.url){ alert((data && data.error) || 'No se encontró conversación en HUB para este trato'); return; }
      window.open(data.url, '_blank');
    }catch(e){ alert('No se pudo abrir HUB'); }
  }
  function hubFromButton(btn){ openHubFromButton(btn); }
  function formatHistoryDate(item){
    const c = item && item.createdAt;
    let d = null;
    if(c && c._seconds) d = new Date(c._seconds * 1000);
    else if(c && c.seconds) d = new Date(c.seconds * 1000);
    else if(typeof c === 'string') d = new Date(c);
    return d && !isNaN(d.getTime()) ? d.toLocaleString('es-AR') : '';
  }
  async function toggleNoteHistoryFromButton(btn){
    const id = String((btn && btn.dataset && btn.dataset.id) || '');
    const box = document.getElementById('hist_' + id);
    if(!id || !box) return;
    const opening = box.style.display === 'none' || !box.style.display;
    if(!opening){ box.style.display='none'; btn.innerText='Ver historial'; return; }
    box.style.display='block'; btn.innerText='Ocultar historial';
    if(box.dataset.loaded === '1') return;
    box.innerHTML = '<div class="small">Cargando historial...</div>';
    try{
      const r = await fetch('/api/deals/' + encodeURIComponent(id) + '/note-history?ts=' + Date.now());
      const data = await r.json();
      const history = data && data.ok && Array.isArray(data.history) ? data.history : [];
      if(!history.length){ box.innerHTML = '<div class="small">Sin historial de notas</div>'; box.dataset.loaded='1'; return; }
      box.innerHTML = history.map(function(item){
        return '<div class="historyItem"><div style="white-space:pre-wrap">'+escHtml(item.note||'')+'</div><div class="small">'+escHtml(item.user||'')+(formatHistoryDate(item)?' · '+escHtml(formatHistoryDate(item)):'')+'</div></div>';
      }).join('');
      box.dataset.loaded='1';
    }catch(e){ box.innerHTML = '<div class="msg small">Error cargando historial</div>'; }
  }
  function historyFromButton(btn){ toggleNoteHistoryFromButton(btn); }
  function renderSection(key){
    const st=SECTION_STATE[key]||{rows:[],total:0,hasMore:false,offset:0};
    const meta=document.getElementById('meta_'+key); if(meta){ const vencidos=(st.rows||[]).filter(function(r){return r && r.dueDate && String(r.dueDate)<new Date().toISOString().slice(0,10);}).length; meta.innerText='Mostrando '+st.rows.length+' de '+st.total+' trato(s) · '+vencidos+' vencido(s) en esta etapa'; }
    const body=document.getElementById('body_'+key); const foot=document.getElementById('foot_'+key); if(!body||!foot) return;
    if(!st.rows.length){body.innerHTML='<div style="padding:14px" class="small">No hay tratos para mostrar.</div>'; foot.innerHTML=''; return;}
    body.innerHTML='<table><thead><tr><th>Cliente / Trato</th><th>Valor</th><th>Fecha</th><th>Etapa</th><th>Calidad</th><th>Nota rápida</th><th>Acción</th></tr></thead><tbody>'+st.rows.map(function(r){const vencido=!!(r.dueDate&&String(r.dueDate)<new Date().toISOString().slice(0,10)); return '<tr id="row_'+escHtml(r.id)+'"><td><div class="dealTitle">'+escHtml(r.contactName||'-')+'</div><div>'+escHtml(r.title||'-')+'</div><div class="small">'+escHtml(r.owner||'')+'</div>'+(vencido?'<div style="margin-top:6px"><span class="pill err">Vencido</span></div>':'')+'</td><td><b>'+money(r.value)+'</b></td><td><input class="dateBox" type="date" data-field="dueDate" value="'+escHtml(r.dueDate||'')+'"></td><td>'+stageSelectHtml(r.stage)+'</td><td>'+qualitySelectHtml(r.leadQuality)+'</td><td><textarea class="noteBox" data-field="notes">'+escHtml(r.notes||'')+'</textarea><div style="margin-top:6px"><button type="button" class="secondary" data-id="'+escHtml(r.id)+'" onclick="historyFromButton(this)">Ver historial</button></div><div class="historyBox" id="hist_'+escHtml(r.id)+'"></div></td><td><div class="actionsInline"><button class="success" data-id="'+escHtml(r.id)+'" data-section="'+escHtml(key)+'" onclick="saveRowFromButton(this)">Guardar</button><button class="secondary" data-id="'+escHtml(r.id)+'" onclick="openDealFromButton(this)">Abrir</button><button class="hubBtn" data-id="'+escHtml(r.id)+'" onclick="hubFromButton(this)">Ir al HUB</button></div><div class="small" id="msg_'+escHtml(r.id)+'"></div></td></tr>';}).join('')+'</tbody></table>';
    foot.innerHTML=st.hasMore ? '<button class="secondary" data-section="'+escHtml(key)+'" onclick="loadSectionFromButton(this, false)">Ver 25 más</button>' : '<span class="small">Fin de la lista</span>';
  }
  async function loadSection(key, reset){
    if(selectedOwner()==='all') return;
    const current=SECTION_STATE[key]||{rows:[],offset:0};
    const offset=reset?0:(current.rows||[]).length;
    const params=new URLSearchParams(); params.set('section',key); appendPeriodParams(params); params.set('owner',selectedOwner()); params.set('limit','25'); params.set('offset',String(offset)); params.set('ts',Date.now());
    const body=document.getElementById('body_'+key); if(reset && body) body.innerHTML='<div style="padding:14px" class="small">Cargando...</div>';
    try{const r=await fetch('/api/my-status/list?'+params.toString()); const d=await r.json(); if(!r.ok||!d.ok) throw new Error(d.error||'Error'); SECTION_STATE[key]={rows:reset?(d.deals||[]):(current.rows||[]).concat(d.deals||[]), total:Number(d.total||0), hasMore:!!d.hasMore}; renderSection(key);}catch(e){if(body) body.innerHTML='<div style="padding:14px" class="msg">Error: '+escHtml(e.message||'error')+'</div>';}
  }
  async function saveRow(id, key){
    const row=document.getElementById('row_'+id); const msg=document.getElementById('msg_'+id); if(!row) return;
    const dueDate=row.querySelector('[data-field="dueDate"]').value||'';
    const stage=row.querySelector('[data-field="stage"]').value||'';
    const leadQuality=row.querySelector('[data-field="leadQuality"]').value||'NO_RESPONDE';
    const notes=row.querySelector('[data-field="notes"]').value||'';
    if(msg){msg.className='small';msg.innerText='Guardando...';}
    try{
      const calls = [
        fetch('/api/deals/'+encodeURIComponent(id)+'/due-date',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({dueDate})}),
        fetch('/api/deals/'+encodeURIComponent(id)+'/stage',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({stage})}),
        fetch('/api/deals/'+encodeURIComponent(id)+'/lead-quality',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({leadQuality})}),
        fetch('/api/deals/'+encodeURIComponent(id)+'/notes',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({notes})})
      ];
      const responses = await Promise.all(calls);
      for(const response of responses){
        const data = await response.json();
        if(!response.ok || !data.ok) throw new Error(data.error || 'No se pudo guardar');
      }
      const current = SECTION_STATE[key];
      if(current && Array.isArray(current.rows)){
        current.rows = current.rows.map(function(item){
          return String(item.id||'') === String(id||'') ? Object.assign({}, item, { dueDate: dueDate, stage: stage, leadQuality: leadQuality, notes: notes }) : item;
        });
      }
      if(msg){msg.className='small okmsg';msg.innerText='Guardado';}
      await loadSummary();
      await loadSection(key,true);
    }catch(e){if(msg){msg.className='small msg';msg.innerText=e.message||'Error';}}
  }
  async function reloadAll(){
    try{document.getElementById('priorityBox').innerText='Cargando prioridades...'; await loadSummary(); SECTION_STATE={}; renderSectionsSkeleton(); if(selectedOwner() !== 'all'){for(const s of SECTIONS){loadSection(s.key,true);}}}catch(e){document.getElementById('priorityBox').innerText='Error cargando Mi Estado: '+(e.message||'error');}
  }
  document.getElementById('periodFilter').addEventListener('change', function(){toggleCustomDates(); reloadAll();});
  document.getElementById('customStartDate').addEventListener('change', function(){if(selectedPeriod()==='custom') reloadAll();});
  document.getElementById('customEndDate').addEventListener('change', function(){if(selectedPeriod()==='custom') reloadAll();});
  document.getElementById('ownerFilter').addEventListener('change', reloadAll);
  (async function init(){toggleCustomDates(); await loadUsers(); await reloadAll();})();
</script>
</body>
</html>`);
});

app.get("/api/my-status/summary", authRequired, async (req, res) => {
  try {
    const range = getMyStatusPeriodRange(req.query.period || "today", req.query.startDate || "", req.query.endDate || "");
    const todayIso = getTodayISOInBuenosAires();
    const scope = await getMyStatusOwnerScope(req);
    const users = await getUsersList();
    const userByEmail = new Map(users.map((u) => [normalizeMyStatusOwnerEmail(u.email), u]));

    if (scope.mode === "all") {
      const ownerEmails = Array.from(new Set(users.map((u) => normalizeMyStatusOwnerEmail(u.email)).filter(Boolean)));
      const rows = [];
      for (const email of ownerEmails) {
        const u = userByEmail.get(email) || {};
        rows.push(await buildMyStatusSummaryForOwner(email, u.name || email, range, todayIso));
      }
      const total = emptyMyStatusMetrics("all", "Equipo");
      rows.forEach((row) => {
        ["nuevosProspectos","nuevosProspectosVencidos","seguimiento","seguimientoVencidos","marcaPersonal","marcaPersonalVencidos","esperandoPI","esperandoPIVencidos","paraCotizar","paraCotizarVencidos","cotizadoParaEnviar","cotizadoParaEnviarVencidos","horno","hornoVencidos","vencidosClave","totalCalidad","calidadDescartado","calidadNoResponde","calidadRegular","calidadBueno","calidadExcelente","buenoExcelente"].forEach((key) => {
          total[key] = Number(total[key] || 0) + Number(row[key] || 0);
        });
      });
      total.buenoExcelentePct = total.totalCalidad ? Math.round((total.buenoExcelente / total.totalCalidad) * 100) : 0;

      return res.json({ ok: true, period: range.period, summary: total, adminRows: rows });
    }

    const owner = scope.owner || (scope.owners && scope.owners[0]) || "";
    const u = userByEmail.get(owner) || {};
    const summary = await buildMyStatusSummaryForOwner(owner, u.name || owner, range, todayIso);
    return res.json({ ok: true, period: range.period, summary });
  } catch (err) {
    console.error("ERROR /api/my-status/summary:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error cargando Mi Estado" });
  }
});

app.get("/api/my-status/list", authRequired, async (req, res) => {
  try {
    const section = String(req.query.section || "").trim();
    if (!MY_STATUS_SECTIONS[section]) return res.status(400).json({ ok: false, error: "Sección inválida" });
    const scope = await getMyStatusOwnerScope(req);
    if (scope.mode === "all") return res.status(400).json({ ok: false, error: "Elegí un vendedor para ver listas" });

    const range = getMyStatusPeriodRange(req.query.period || "today", req.query.startDate || "", req.query.endDate || "");
    const todayIso = getTodayISOInBuenosAires();
    const result = await scanMyStatusDealsForOwner(scope.owner, {
      section,
      range,
      todayIso,
      limit: Number(req.query.limit || 25),
      offset: Number(req.query.offset || 0)
    });

    return res.json({ ok: true, section, deals: result.deals, total: result.total, hasMore: result.hasMore, scanned: result.scanned });
  } catch (err) {
    console.error("ERROR /api/my-status/list:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error cargando lista" });
  }
});


// =====================================================
// BLOQUE 5 - PIPELINE
// =====================================================

// =====================================================
// BLOQUE 5A - PÁGINA PIPELINE
// =====================================================
app.get("/pipeline", (req, res) => {
  const stageOptions = PIPELINE_STAGES.map((stage) => `<option value="${esc(stage)}">${esc(stage)}</option>`).join("");
  const dealTypeOptions = DEAL_TYPES.map((type) => `<option value="${esc(type)}">${esc(getDealTypeLabel(type))}</option>`).join("");
  const leadQualityOptions = buildLeadQualityOptions("NO_RESPONDE");
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Pipeline</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;padding:0}
    .topbar{background:#1a73e8;color:white;padding:16px 24px;display:flex;justify-content:space-between;align-items:center}
    .container{padding:24px;max-width:100%;margin:0 auto;overflow:hidden}
    .layout{display:flex;gap:20px;align-items:flex-start}
    .sidebar{width:280px;min-width:280px;position:sticky;top:20px;align-self:flex-start}
    .main{flex:1;min-width:0}
    .box{background:#fff;padding:20px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08);margin-bottom:20px}
    .form-grid{display:grid;grid-template-columns:2fr 1.8fr 1fr 1fr 1fr 1fr 1fr;gap:12px}
    .contact-picker{display:flex;flex-direction:column;gap:8px}
    .contact-results{border:1px solid #ddd;border-radius:10px;height:220px;max-height:220px;overflow-y:scroll;overflow-x:hidden;background:#fff;scrollbar-gutter:stable}
    .contact-item{padding:10px 12px;border-bottom:1px solid #eee;cursor:pointer}
    .contact-item:last-child{border-bottom:none}
    .contact-item:hover{background:#f6f9ff}
    .contact-selected{font-size:13px;color:#1557b0;font-weight:bold}
    input,select,textarea{width:100%;padding:12px;border:1px solid #ccc;border-radius:8px;box-sizing:border-box;font-family:Arial,sans-serif}
    textarea{min-height:90px;resize:vertical}
    button{padding:12px 16px;border:none;border-radius:8px;background:#1a73e8;color:#fff;cursor:pointer}
    .secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}
    .actions{display:flex;gap:10px;margin-top:16px;flex-wrap:wrap}
    .msg{margin-top:12px;color:#d93025}
    .view-buttons{display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap}
    .bulk-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap;background:#f8fbff;border:1px solid #dbe7ff;border-radius:12px;padding:12px 14px;margin-bottom:16px}
    .selection-pill{display:inline-flex;align-items:center;padding:6px 10px;border-radius:999px;background:#eef3fb;color:#174ea6;font-size:12px;font-weight:bold}
    .deal-check{width:18px;height:18px;cursor:pointer}
    .history-toggle{padding:6px 10px;font-size:12px;border-radius:8px;background:#fff;color:#1a73e8;border:1px solid #1a73e8;cursor:pointer;margin-top:8px}
    .history-collapsed{display:none}
    .active-view{background:#1557b0;color:#fff}
    .list-view{display:none}
    .kanban-scroll{width:100%;max-width:100%;overflow-x:auto;overflow-y:hidden;padding-bottom:12px}
    .board{display:flex;flex-direction:row;flex-wrap:nowrap;gap:16px;align-items:flex-start;width:max-content;min-width:max-content}
    .column{background:#eef3fb;border-radius:12px;padding:12px;width:340px;min-width:340px;max-width:340px;height:74vh;max-height:74vh;display:flex;flex-direction:column;flex:0 0 340px;overflow:hidden;box-sizing:border-box}
    .column-header{font-weight:bold;margin-bottom:10px;position:sticky;top:0;background:#eef3fb;padding-bottom:8px;z-index:2;flex:0 0 auto}
    .column-body{flex:1 1 auto;min-height:0;overflow-y:auto;overflow-x:hidden;padding-right:6px;scrollbar-gutter:stable}
    .deal-card{background:#fff;border-radius:10px;padding:12px;box-shadow:0 2px 8px rgba(0,0,0,0.06);margin-bottom:10px}
    .deal-card.high-value{background:#D4AF37;border:1px solid #b8931f}
    .deal-title{font-weight:bold;margin-bottom:6px}
    .deal-meta{font-size:12px;color:#666;margin-bottom:8px}
    .deal-meta-strong{font-size:13px;color:#111;margin-bottom:8px;font-weight:bold}
    .deal-select{width:100%;padding:8px;border-radius:8px;border:1px solid #ccc;margin-top:6px}
    .deal-label{font-size:12px;color:#555;margin-top:8px;margin-bottom:4px}
    .inline-select{width:180px;padding:8px;border-radius:8px;border:1px solid #ccc}
    .due-input{width:100%;padding:8px;border-radius:8px;border:1px solid #ccc;margin-top:6px;box-sizing:border-box}
    .note-textarea{width:100%;padding:8px;border-radius:8px;border:1px solid #ccc;margin-top:6px;box-sizing:border-box;min-height:90px;resize:vertical;font-family:Arial,sans-serif}
    .files-box{margin-top:10px;padding:10px;border:1px solid #e2e8f0;border-radius:10px;background:#fafcff}
    .files-list{display:flex;flex-direction:column;gap:8px;margin-top:10px}
    .file-row{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px;border:1px solid #e5e7eb;border-radius:8px;background:#fff}
    .file-link{font-size:12px;color:#1557b0;text-decoration:none;word-break:break-word}
    .file-meta{font-size:11px;color:#666}
    .upload-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
    .upload-btn{padding:8px 10px;font-size:12px;border-radius:8px}
    .file-input{font-size:12px}
    .upload-msg{margin-top:8px;font-size:12px;color:#d93025}
    .value-edit-wrap{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:6px}
    .value-input{width:120px;padding:8px;border-radius:8px;border:1px solid #ccc;box-sizing:border-box}
    .value-save-btn{padding:8px 10px;font-size:12px;border-radius:8px;background:#188038;color:#fff;border:none;cursor:pointer}
    .value-save-btn:disabled{opacity:0.7;cursor:not-allowed}
    .value-msg{font-size:11px;color:#1557b0;margin-top:6px}
    .deal-type-badge{display:inline-block;padding:4px 8px;border-radius:999px;background:#e8f0fe;color:#174ea6;font-size:11px;font-weight:bold;margin-bottom:8px}
    .type-edit-wrap{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:6px}
    .type-save-btn{padding:8px 10px;font-size:12px;border-radius:8px;background:#188038;color:#fff;border:none;cursor:pointer}
    .type-save-btn:disabled{opacity:0.7;cursor:not-allowed}
    .type-msg{font-size:11px;color:#1557b0;margin-top:6px}
    table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08)}
    th,td{padding:12px;border-bottom:1px solid #eee;text-align:left;font-size:14px;vertical-align:top}
    th{background:#f0f4fb}
    tr.high-value-row{background:#fff6d8}
    .deal-open-btn{padding:8px 10px;font-size:12px;border-radius:8px;background:#fff;color:#1a73e8;border:1px solid #1a73e8;cursor:pointer;width:100%;margin-top:8px}
    .deal-detail-modal-bg{position:fixed;inset:0;background:rgba(0,0,0,0.35);display:none;align-items:center;justify-content:center;padding:20px;z-index:1000}
    .deal-detail-modal{background:#fff;width:100%;max-width:780px;max-height:90vh;overflow:auto;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,0.2);padding:20px}
    .deal-detail-header{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px}
    .deal-detail-title{font-size:20px;font-weight:bold;margin:0}
    .deal-detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
    .deal-detail-section{border:1px solid #e5e7eb;border-radius:12px;padding:14px;background:#fafcff}
    .deal-detail-close{background:#fff;color:#1a73e8;border:1px solid #1a73e8}
    .bulk-updater-modal-bg{position:fixed;inset:0;background:rgba(0,0,0,0.35);display:none;align-items:center;justify-content:center;padding:20px;z-index:1001}
    .bulk-updater-modal{background:#fff;width:100%;max-width:760px;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,0.2);padding:20px;max-height:90vh;overflow:auto}
    .bulk-updater-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
    .bulk-updater-section{border:1px solid #e5e7eb;border-radius:12px;padding:14px;background:#fafcff}
    .bulk-updater-close{background:#fff;color:#1a73e8;border:1px solid #1a73e8}
.pipeline-summary{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.pipeline-kpi{background:#f8fbff;border:1px solid #dbe7ff;border-radius:12px;padding:14px}
.pipeline-kpi-label{font-size:12px;color:#5f6368;margin-bottom:6px}
.pipeline-kpi-value{font-size:24px;font-weight:bold;color:#174ea6}
.pipeline-kpi-sub{font-size:12px;color:#666;margin-top:6px}
.owner-filter-button{width:100%;text-align:left;background:#fff;color:#1a73e8;border:1px solid #1a73e8;display:none;justify-content:space-between;align-items:center;gap:8px}
.owner-filter-modal-bg{position:fixed;inset:0;background:rgba(0,0,0,0.35);display:none;align-items:center;justify-content:center;padding:20px;z-index:1002}
.owner-filter-modal{background:#fff;width:100%;max-width:560px;max-height:86vh;overflow:auto;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,0.2);padding:20px}
.owner-filter-list{border:1px solid #e5e7eb;border-radius:12px;max-height:420px;overflow:auto;background:#fafcff;margin-top:12px}
.owner-filter-row{display:flex;align-items:center;gap:10px;padding:10px 12px;border-bottom:1px solid #e5e7eb;cursor:pointer}
.owner-filter-row:last-child{border-bottom:none}
.owner-filter-row:hover{background:#eef3fb}
.owner-filter-row input{width:auto}
.owner-filter-row-label{font-size:14px;color:#111}
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>CRMSCB</strong> / Pipeline</div>
<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
  <button id="bulkUpdaterTopBtn" class="secondary" style="display:none" onclick="abrirActualizadorMasivo()">Actualizador masivo</button>
  <button class="secondary" onclick="window.location='/contacts'">Contactos</button>
  <button class="secondary" onclick="window.location='/pipeline'">Pipeline</button>
  <button class="secondary" onclick="window.location='/reportes'">Reportes / KPI</button>
  <button class="secondary" onclick="window.location='/crm'">Volver al panel</button>
</div>




    </div>
  </div>
  <div class="container">
    <div class="layout">
      <div class="sidebar">
        <div class="box">
          <h2>Filtros</h2>
          <div id="mobileStageFilterWrap" style="display:none">
            <div class="deal-label">Etapa a trabajar</div>
            <select id="mobileStageFilter">${stageOptions}</select>
            <div class="deal-meta" style="margin-top:7px">En el celular se muestra una etapa por vez.</div>
          </div>
          <div class="deal-label">Por owner</div>
          <select id="filterOwner"><option value="">Todos los owners</option></select>
          <button id="ownerFilterButton" type="button" class="owner-filter-button" onclick="openOwnerFilterModal()">Todos los owners</button>
          <div class="deal-label">Por tipo de trato</div>
          <select id="filterDealType">
            <option value="">Todos los tipos</option>
            ${dealTypeOptions}
          </select>
          <div class="deal-label">Por nombre del trato</div>
          <input id="filterDealName" placeholder="Buscar por nombre del trato">
          <div class="deal-label">Por fecha de vencimiento</div>
          <select id="filterDueMode">
            <option value="">Todas</option>
            <option value="sin_fecha">Sin fecha</option>
            <option value="vencidos">Vencidos</option>
            <option value="hoy">Vence hoy</option>
            <option value="proximos_7">Próximos 7 días</option>
            <option value="rango">Rango personalizado</option>
          </select>
          <div id="filterDueRangeBox" style="display:none;margin-top:12px;">
            <div class="deal-label">Desde</div>
            <input id="filterDueFrom" type="date">
            <div class="deal-label">Hasta</div>
            <input id="filterDueTo" type="date">
          </div>
          <div class="actions">
            <button onclick="aplicarFiltros()">Aplicar filtros</button>
            <button class="secondary" onclick="limpiarFiltros()">Limpiar</button>
          </div>
          <div class="deal-meta" id="filtersSummary" style="margin-top:10px;">Mostrando todos los tratos</div>
        </div>
      </div>
      <div class="main">
        <div class="box">
          <h2>Nuevo trato</h2>
          <div class="form-grid">
            <input id="title" placeholder="Título del trato">
            <div class="contact-picker">
              <input id="contactSearchDeal" placeholder="Buscar contacto por nombre, empresa, teléfono o email">
              <div id="contactSelectedDeal" class="contact-selected">Sin contacto seleccionado</div>
              <div id="contactResultsDeal" class="contact-results"></div>
            </div>
            <input id="value" type="number" min="0" step="0.01" placeholder="Valor del trato">
            <input id="dueDate" type="date">
            <select id="stage">${stageOptions}</select>
            <select id="dealType">${dealTypeOptions}</select>
            <select id="leadQuality">${leadQualityOptions}</select>
          </div>
          <div class="actions" style="margin-top:12px">
            <textarea id="newDealNotes" placeholder="Notas del trato"></textarea>
          </div>
          <div class="actions">
            <button onclick="crearDeal()">Guardar trato</button>
            <button class="secondary" onclick="limpiarDeal()">Limpiar</button>
          </div>
          <div id="msg" class="msg"></div>
        </div>

<div class="box pipeline-summary" id="pipelineSummary">
  <div class="pipeline-kpi">
    <div class="pipeline-kpi-label">Valor total pipeline</div>
    <div class="pipeline-kpi-value">$0</div>
    <div class="pipeline-kpi-sub">0 tratos</div>
  </div>
  <div class="pipeline-kpi">
    <div class="pipeline-kpi-label">Ticket promedio</div>
    <div class="pipeline-kpi-value">$0</div>
    <div class="pipeline-kpi-sub">Promedio por trato</div>
  </div>
  <div class="pipeline-kpi">
    <div class="pipeline-kpi-label">Mayor trato</div>
    <div class="pipeline-kpi-value">$0</div>
    <div class="pipeline-kpi-sub">Valor máximo actual</div>
  </div>
</div>


        <div class="view-buttons">
          <button id="btnKanban" class="active-view" onclick="cambiarVista('kanban')">Vista Kanban</button>
          <button id="btnLista" class="secondary" onclick="cambiarVista('lista')">Vista Lista</button>
        </div>
        <div class="bulk-actions">
          <span class="selection-pill" id="bulkSelectionSummary">0 trato(s) seleccionados</span>
          <button class="secondary" onclick="selectAllFilteredDeals()">Seleccionar todos los visibles</button>
          <button class="secondary" onclick="clearSelectedDeals()">Limpiar selección</button>
          <button class="secondary" onclick="exportSelectedDealsToExcel()">Exportar seleccionados Excel</button>
          <select id="bulkStageTarget">${stageOptions}</select>
          <button onclick="moveSelectedDealsStage()">Mover seleccionados</button>
          <input id="bulkDueDateTarget" type="date" style="max-width:180px;">
          <button class="secondary" onclick="updateSelectedDealsDueDate()">Fecha vencimiento</button>
        </div>
        <div id="kanbanView">
          <h2>Pipeline SCB</h2>
          <div class="kanban-scroll"><div class="board" id="board"></div></div>
          <div class="actions" style="justify-content:center;margin-top:14px;">
            <button id="kanbanLoadMoreBtn" class="secondary" style="display:none;" onclick="verMasKanbanGlobal()">Ver más tratos</button>
          </div>
        </div>
        <div id="listView" class="list-view">
          <h2>Lista de tratos</h2>
          <table>
            <thead>
              <tr>
                <th><input type="checkbox" id="listSelectAll" class="deal-check" onchange="toggleSelectAllVisible(this.checked)"></th>
                <th>Título</th>
                <th>Tipo</th>
                <th>Calidad lead</th>
                <th>Valor</th>
                <th>Contacto</th>
                <th>Vencimiento</th>
                <th>Etapa</th>
                <th>Owner</th>
                <th>Notas</th>
                <th>Archivos</th>
                <th>Producción</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody id="dealsTableBody"><tr><td colspan="13">Cargando tratos...</td></tr></tbody>
          </table>
          <div class="actions" style="justify-content:center;margin-top:14px;">
            <button id="listLoadMoreBtn" class="secondary" style="display:none;" onclick="verMasDealsLista()">Ver 25 más</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="deal-detail-modal-bg" id="dealDetailModalBg">
    <div class="deal-detail-modal">
      <div class="deal-detail-header">
        <div>
          <div class="deal-detail-title" id="dealDetailTitle">Detalle del trato</div>
          <div class="deal-meta" id="dealDetailSubtitle"></div>
        </div>
        <button class="deal-detail-close" onclick="cerrarDetalleTrato()">Cerrar</button>
      </div>
      <div id="dealDetailContent"></div>
    </div>
  </div>
  <div class="bulk-updater-modal-bg" id="bulkUpdaterModalBg">
    <div class="bulk-updater-modal">
      <div class="deal-detail-header">
        <div>
          <div class="deal-detail-title">Actualizador masivo</div>
          <div class="deal-meta">Solo admin. Toma TODOS los tratos de una stage, no solo los visibles.</div>
        </div>
        <button class="bulk-updater-close" onclick="cerrarActualizadorMasivo()">Cerrar</button>
      </div>
      <div class="bulk-updater-grid">
        <div class="bulk-updater-section">
          <div class="deal-label">Stage origen</div>
          <select id="bulkStageSource">${stageOptions}</select>
          <div class="deal-label">Stage destino</div>
          <select id="bulkStageTargetAll">${stageOptions}</select>
          <div class="actions">
            <button onclick="moverTodosPorStage()">Mover TODOS</button>
          </div>
        </div>
        <div class="bulk-updater-section">
          <div class="deal-label">Stage origen</div>
          <select id="bulkDueStageSource">${stageOptions}</select>
          <div class="deal-label">Nueva fecha de vencimiento</div>
          <input id="bulkDueDateAll" type="date">
          <div class="actions">
            <button onclick="cambiarFechaTodosPorStage()">Fecha a TODOS</button>
          </div>
        </div>
      </div>
      <div id="bulkUpdaterMsg" class="msg"></div>
    </div>
  </div>
  <div class="owner-filter-modal-bg" id="ownerFilterModalBg">
    <div class="owner-filter-modal">
      <div class="deal-detail-header">
        <div>
          <div class="deal-detail-title">Filtrar por owners</div>
          <div class="deal-meta">Seleccioná uno o varios vendedores. Solo admin/backoffice.</div>
        </div>
        <button class="deal-detail-close" onclick="closeOwnerFilterModal()">Cerrar</button>
      </div>
      <div class="actions" style="margin-top:0">
        <button class="secondary" onclick="selectAllOwnerFilterModal()">Seleccionar todos</button>
        <button class="secondary" onclick="clearAllOwnerFilterModal()">Limpiar selección</button>
      </div>
      <div id="ownerFilterModalList" class="owner-filter-list"></div>
      <div class="actions" style="justify-content:flex-end;margin-top:16px">
        <button class="secondary" onclick="closeOwnerFilterModal()">Cancelar</button>
        <button onclick="applyOwnerFilterModal()">Aplicar owners</button>
      </div>
    </div>
  </div>
  <script>
    const userRaw = localStorage.getItem("crmscb_user");
    if (!userRaw) window.location.href = "/?redirect=" + encodeURIComponent(window.location.pathname + window.location.search);
    const CURRENT_USER = JSON.parse(userRaw || "{}");
    const __originalFetch = window.fetch.bind(window);
    window.fetch = function(url, options) {
      const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
      options = options || {};
      options.headers = Object.assign({}, options.headers || {}, {
        "x-user-id": user.id || "",
        "x-auth-token": user.token || ""
      });
      return __originalFetch(url, options);
    };
    function esAdmin() { return (CURRENT_USER.role || "") === "admin"; }
    function esBackoffice() { return (CURRENT_USER.role || "") === "backoffice"; }
    function esAdminOrBackoffice() { return esAdmin() || esBackoffice(); }
    function esSeller() { return (CURRENT_USER.role || "") === "seller"; }
    function abrirActualizadorMasivo() {
      if (!esAdmin()) return;
      document.getElementById("bulkUpdaterMsg").innerText = "";
      document.getElementById("bulkUpdaterModalBg").style.display = "flex";
    }
    function cerrarActualizadorMasivo() {
      document.getElementById("bulkUpdaterModalBg").style.display = "none";
      document.getElementById("bulkUpdaterMsg").innerText = "";
    }
    function setBulkUpdaterMsg(text, isError) {
      const el = document.getElementById("bulkUpdaterMsg");
      if (!el) return;
      el.style.color = isError ? "#d93025" : "#188038";
      el.innerText = text || "";
    }
    const STAGES = ${JSON.stringify(PIPELINE_STAGES)};
    const DEAL_TYPES_JS = ${JSON.stringify(DEAL_TYPES)};
    const DEAL_TYPE_LABELS_JS = ${JSON.stringify(DEAL_TYPE_LABELS)};
    const LEAD_QUALITY_VALUES_JS = ${JSON.stringify(LEAD_QUALITY_VALUES)};
    const LEAD_QUALITY_LABELS_JS = ${JSON.stringify(LEAD_QUALITY_LABELS)};
    const DEALS_PAGE_SIZE = 25;
    const KANBAN_STAGE_PAGE_SIZE = 12;
    const KANBAN_SINGLE_REQUEST_LIMIT = 100;
    const KANBAN_STAGE_INITIAL_VISIBLE = 12;
    const KANBAN_STAGE_LOAD_MORE = 25;
    const KANBAN_PRIORITY_STAGES = ["No responde", "Seguimiento", "Horno"];
    let KANBAN_GLOBAL_CURSOR = "";
    let KANBAN_GLOBAL_HAS_MORE = false;
    let KANBAN_GLOBAL_LOADING_MORE = false;
    let USERS = [];
    let PENDING_DUE_SEND = null;
    let CONTACT_SEARCH_RESULTS = [];
    let DEALS = [];
    let FILTERED_DEALS = [];
    let CURRENT_VIEW = "kanban";
    let SELECTED_DEAL_IDS = new Set();
    let SELECTED_CONTACT_ID = "";
    let SELECTED_CONTACT_NAME = "";
    let SELECTED_CONTACT_OWNER = "";
    let FILTER_DEAL_ID_FROM_URL = "";
    let CURRENT_DEAL_MODAL_ID = "";

    function isMobilePipelineView() {
      return !!(window.matchMedia && window.matchMedia("(max-width:780px)").matches);
    }

    function getMobileStageFilterValue() {
      if (!isMobilePipelineView()) return "";
      const select = document.getElementById("mobileStageFilter");
      return select ? String(select.value || "Horno").trim() : "Horno";
    }

    const __ACTION_LOCKS = window.__ACTION_LOCKS || (window.__ACTION_LOCKS = {});
    async function withActionLock(actionKey, callback) {
      const key = String(actionKey || "").trim();
      if (!key) return await callback();
      if (__ACTION_LOCKS[key]) return false;
      __ACTION_LOCKS[key] = true;
      try {
        await callback();
        return true;
      } finally {
        delete __ACTION_LOCKS[key];
      }
    }
    function setButtonBusy(button, busyText, isBusy) {
      if (!button) return;
      if (typeof button.dataset.originalText === "undefined") {
        button.dataset.originalText = button.innerText || button.textContent || "";
      }
      button.disabled = !!isBusy;
      button.innerText = isBusy ? String(busyText || "Guardando...") : String(button.dataset.originalText || "");
    }
    let LIST_META = { total: 0, cursor: "", hasMore: false };
    let KANBAN_META = {};
    let KANBAN_BG_RUN_ID = 0;
    function emptyKanbanStageMeta() {
      return { total: 0, totalKnown: false, cursor: "", hasMore: false, items: [], allItems: [], visibleCount: 0, loaded: false, loading: false };
    }
    STAGES.forEach(function(stage) { KANBAN_META[stage] = emptyKanbanStageMeta(); });

    function getOwnerFilterValues() {
      const select = document.getElementById("filterOwner");
      if (!select) return [];
      if (select.multiple) {
        return Array.from(select.selectedOptions || [])
          .map(function(option) { return String(option.value || "").trim().toLowerCase(); })
          .filter(Boolean);
      }
      const single = String(select.value || "").trim().toLowerCase();
      return single ? [single] : [];
    }

    function clearOwnerFilterSelection() {
      const select = document.getElementById("filterOwner");
      if (!select) return;
      if (select.multiple) {
        Array.from(select.options || []).forEach(function(option) { option.selected = false; });
      } else {
        select.value = "";
      }
      updateOwnerFilterButtonLabel();
    }

    function getOwnerLabelByEmail(email) {
      const clean = String(email || "").trim().toLowerCase();
      if (!clean) return "";
      for (let i = 0; i < USERS.length; i += 1) {
        const user = USERS[i] || {};
        if (String(user.email || "").trim().toLowerCase() === clean) {
          return (user.name || user.email || clean) + (user.email ? " (" + user.email + ")" : "");
        }
      }
      return clean;
    }

function syncPipelineUrl() {
  const params = new URLSearchParams(window.location.search || "");
  if (FILTER_DEAL_ID_FROM_URL) params.set("dealId", FILTER_DEAL_ID_FROM_URL);
  else params.delete("dealId");
  if (CURRENT_VIEW === "lista") params.set("view", "lista");
  else params.delete("view");
  const qs = params.toString();
  const nextUrl = window.location.pathname + (qs ? ("?" + qs) : "");
  window.history.replaceState({}, "", nextUrl);
}

function syncSelectedDeals() {
  const visibleIds = new Set(DEALS.map(function(deal) { return String(deal.id || ""); }));
  SELECTED_DEAL_IDS = new Set(Array.from(SELECTED_DEAL_IDS).filter(function(id) { return visibleIds.has(String(id || "")); }));
}

function isDealSelected(dealId) {
  return SELECTED_DEAL_IDS.has(String(dealId || ""));
}

function toggleDealSelection(dealId, checked) {
  const id = String(dealId || "");
  if (!id) return;
  if (checked) SELECTED_DEAL_IDS.add(id);
  else SELECTED_DEAL_IDS.delete(id);
  updateBulkSummary();
  refreshSelectionInputs();
}

function refreshSelectionInputs() {
  FILTERED_DEALS.forEach(function(deal) {
    const checked = isDealSelected(deal.id);
    document.querySelectorAll('[data-deal-check="' + String(deal.id || "") + '"]').forEach(function(node) {
      node.checked = checked;
    });
  });
  const listSelectAll = document.getElementById("listSelectAll");
  if (listSelectAll) {
    listSelectAll.checked = FILTERED_DEALS.length > 0 && FILTERED_DEALS.every(function(deal) { return isDealSelected(deal.id); });
  }
}

function updateBulkSummary() {
  const el = document.getElementById("bulkSelectionSummary");
  if (el) el.innerText = SELECTED_DEAL_IDS.size + " trato(s) seleccionados";
}

function clearSelectedDeals() {
  SELECTED_DEAL_IDS = new Set();
  updateBulkSummary();
  refreshSelectionInputs();
}

async function exportSelectedDealsToExcel() {
  const dealIds = Array.from(SELECTED_DEAL_IDS).filter(Boolean);
  if (!dealIds.length) {
    alert("Seleccioná al menos un trato para exportar");
    return;
  }

  try {
    const r = await fetch("/api/deals/export-selected", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dealIds: dealIds })
    });

    if (!r.ok) {
      let errorText = "No se pudo exportar";
      try {
        const data = await r.json();
        errorText = data.error || errorText;
      } catch (e) {
        errorText = await r.text();
      }
      alert(errorText || "No se pudo exportar");
      return;
    }

    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "tratos_seleccionados_" + new Date().toISOString().slice(0, 10) + ".csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (err) {
    console.error(err);
    alert("Error exportando tratos seleccionados");
  }
}

function selectAllFilteredDeals() {
  FILTERED_DEALS.forEach(function(deal) {
    if (deal && deal.id) SELECTED_DEAL_IDS.add(String(deal.id));
  });
  updateBulkSummary();
  refreshSelectionInputs();
}

function selectStageDeals(stage) {
  FILTERED_DEALS.filter(function(deal) { return (deal.stage || "No responde") === stage; }).forEach(function(deal) {
    if (deal && deal.id) SELECTED_DEAL_IDS.add(String(deal.id));
  });
  updateBulkSummary();
  refreshSelectionInputs();
}

function toggleSelectAllVisible(checked) {
  FILTERED_DEALS.forEach(function(deal) {
    const id = String(deal.id || "");
    if (!id) return;
    if (checked) SELECTED_DEAL_IDS.add(id);
    else SELECTED_DEAL_IDS.delete(id);
  });
  updateBulkSummary();
  refreshSelectionInputs();
}

async function moveSelectedDealsStage() {
  const stage = document.getElementById("bulkStageTarget").value || "";
  const dealIds = Array.from(SELECTED_DEAL_IDS);
  if (!dealIds.length) {
    alert("Seleccioná al menos un trato");
    return;
  }
  if (!stage) {
    alert("Seleccioná una etapa destino");
    return;
  }
  if (!confirm("¿Mover " + dealIds.length + " trato(s) a " + stage + "?")) return;
  try {
    const r = await fetch("/api/deals/bulk-stage", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dealIds: dealIds, stage: stage })
    });
    const data = await r.json();
    if (!data.ok) {
      alert(data.error || "No se pudieron mover los tratos");
      return;
    }
    clearSelectedDeals();
    await cargarDeals();
  } catch (err) {
    console.error(err);
    alert("Error moviendo tratos");
  }
}

async function updateSelectedDealsDueDate() {
  const dueDate = document.getElementById("bulkDueDateTarget").value || "";
  const dealIds = Array.from(SELECTED_DEAL_IDS);
  if (!dealIds.length) {
    alert("Seleccioná al menos un trato");
    return;
  }
  if (!dueDate) {
    alert("Seleccioná una fecha de vencimiento");
    return;
  }
  if (!confirm("¿Cambiar la fecha de vencimiento de " + dealIds.length + " trato(s) a " + dueDate + "?")) return;
  try {
    const r = await fetch("/api/deals/bulk-due-date", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dealIds: dealIds, dueDate: dueDate })
    });
    const data = await r.json();
    if (!data.ok) {
      alert(data.error || "No se pudo actualizar la fecha de vencimiento");
      return;
    }
    clearSelectedDeals();
    await cargarDeals();
  } catch (err) {
    console.error(err);
    alert("Error actualizando fecha de vencimiento");
  }
}

async function moverTodosPorStage() {
  const sourceStage = document.getElementById("bulkStageSource").value || "";
  const targetStage = document.getElementById("bulkStageTargetAll").value || "";
  if (!sourceStage || !targetStage) {
    setBulkUpdaterMsg("Seleccioná stage origen y destino", true);
    return;
  }
  if (sourceStage === targetStage) {
    setBulkUpdaterMsg("El stage origen y destino no pueden ser iguales", true);
    return;
  }
  if (!confirm("¿Mover TODOS los tratos de " + sourceStage + " a " + targetStage + "?")) return;
  try {
    setBulkUpdaterMsg("Actualizando...", false);
    const r = await fetch("/api/deals/bulk-stage-all", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sourceStage: sourceStage, targetStage: targetStage })
    });
    const data = await r.json();
    if (!data.ok) {
      setBulkUpdaterMsg(data.error || "No se pudo mover la stage completa", true);
      return;
    }
    setBulkUpdaterMsg("Listo. Se movieron " + Number(data.updated || 0) + " trato(s)", false);
    await cargarDeals();
  } catch (err) {
    console.error(err);
    setBulkUpdaterMsg("Error moviendo la stage completa", true);
  }
}

async function cambiarFechaTodosPorStage() {
  const sourceStage = document.getElementById("bulkDueStageSource").value || "";
  const dueDate = document.getElementById("bulkDueDateAll").value || "";
  if (!sourceStage || !dueDate) {
    setBulkUpdaterMsg("Seleccioná stage origen y fecha", true);
    return;
  }
  if (!confirm("¿Cambiar la fecha de vencimiento de TODOS los tratos en " + sourceStage + " a " + dueDate + "?")) return;
  try {
    setBulkUpdaterMsg("Actualizando...", false);
    const r = await fetch("/api/deals/bulk-due-date-all", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sourceStage: sourceStage, dueDate: dueDate })
    });
    const data = await r.json();
    if (!data.ok) {
      setBulkUpdaterMsg(data.error || "No se pudo actualizar la fecha para la stage", true);
      return;
    }
    setBulkUpdaterMsg("Listo. Se actualizaron " + Number(data.updated || 0) + " trato(s)", false);
    await cargarDeals();
  } catch (err) {
    console.error(err);
    setBulkUpdaterMsg("Error actualizando la fecha para la stage", true);
  }
}

function aplicarFiltroDesdeURL() {
  const params = new URLSearchParams(window.location.search || "");
  FILTER_DEAL_ID_FROM_URL = (params.get("dealId") || "").trim();

  const view = (params.get("view") || "").trim().toLowerCase();
  if (view === "lista") {
    CURRENT_VIEW = "lista";
  } else if (view === "kanban") {
    CURRENT_VIEW = "kanban";
  }

  syncPipelineUrl();
}





    function limpiarBoard() { document.getElementById("board").innerHTML = ""; }
    function textoContacto(c) { return [c.name, c.company, c.phone, c.email, c.owner].join(" ").toLowerCase(); }
    function normalizePhoneForWhatsApp(phone) { return String(phone || "").replace(/[^0-9]/g, ""); }
    function buildWhatsAppUrl(phone, name) {
      const clean = normalizePhoneForWhatsApp(phone);
      if (!clean) return "";
      const text = "Hola " + (name || "");
      return "https://web.whatsapp.com/send?phone=" + clean + "&text=" + encodeURIComponent(text);
    }
    function buildWhatsAppButton(phone, name) {
      const url = buildWhatsAppUrl(phone, name);
      if (!url) return null;
      const link = document.createElement("a");
      link.href = url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.style.display = "inline-flex";
      link.style.alignItems = "center";
      link.style.justifyContent = "center";
      link.style.width = "36px";
      link.style.height = "36px";
      link.style.borderRadius = "10px";
      link.style.textDecoration = "none";
      link.style.border = "1px solid #25D366";
      link.style.fontSize = "18px";
      link.title = "Abrir WhatsApp";
      link.textContent = "🟢";
      return link;
    }
    function formatFileSize(bytes) {
      const n = Number(bytes || 0);
      if (!n) return "0 KB";
      if (n < 1024) return n + " B";
      if (n < 1024 * 1024) return (n / 1024).toFixed(1) + " KB";
      return (n / (1024 * 1024)).toFixed(1) + " MB";
    }
    function formatMoney(value) {
      const n = Number(value || 0);
      return "$" + n.toLocaleString("es-AR", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    }
    function isHighValueDeal(deal) {
      return Number(deal && deal.value || 0) > 1000;
    }
 function contarPorEtapa(stage) {
  const meta = KANBAN_META[stage] || emptyKanbanStageMeta();
  if (meta.totalKnown) return Number(meta.total || 0);
  return Number((meta.items && meta.items.length) || 0);
}

function totalValorDeals(list) {
  return (Array.isArray(list) ? list : []).reduce(function(acc, deal) {
    return acc + Number((deal && deal.value) || 0);
  }, 0);
}

function totalPorEtapa(stage) {
  return totalValorDeals(
    FILTERED_DEALS.filter(function(deal) {
      return (deal.stage || "No responde") === stage;
    })
  );
}

function getDealsTotalCount() {
  if (CURRENT_VIEW === "lista") {
    return Number((LIST_META && LIST_META.total) || 0);
  }
  return STAGES.reduce(function(acc, stage) {
    const meta = KANBAN_META[stage] || emptyKanbanStageMeta();
    return acc + (meta.totalKnown ? Number(meta.total || 0) : Number((meta.items && meta.items.length) || 0));
  }, 0);
}

function kanbanHasUnknownTotals() {
  return STAGES.some(function(stage) {
    const meta = KANBAN_META[stage] || emptyKanbanStageMeta();
    return !meta.totalKnown && (meta.loading || meta.hasMore || !meta.loaded);
  });
}

function renderPipelineSummary() {
  const box = document.getElementById("pipelineSummary");
  if (!box) return;

  const total = totalValorDeals(FILTERED_DEALS);
  const cantidad = FILTERED_DEALS.length;
  const promedio = cantidad ? (total / cantidad) : 0;
  const mayor = FILTERED_DEALS.reduce(function(max, deal) {
    const value = Number((deal && deal.value) || 0);
    return value > max ? value : max;
  }, 0);

  box.innerHTML = ''
    + '<div class="pipeline-kpi">'
    +   '<div class="pipeline-kpi-label">Valor total pipeline</div>'
    +   '<div class="pipeline-kpi-value">' + formatMoney(total) + '</div>'
    +   '<div class="pipeline-kpi-sub">' + cantidad + ' trato(s)</div>'
    + '</div>'
    + '<div class="pipeline-kpi">'
    +   '<div class="pipeline-kpi-label">Ticket promedio</div>'
    +   '<div class="pipeline-kpi-value">' + formatMoney(promedio) + '</div>'
    +   '<div class="pipeline-kpi-sub">Promedio por trato</div>'
    + '</div>'
    + '<div class="pipeline-kpi">'
    +   '<div class="pipeline-kpi-label">Mayor trato</div>'
    +   '<div class="pipeline-kpi-value">' + formatMoney(mayor) + '</div>'
    +   '<div class="pipeline-kpi-sub">Valor máximo actual</div>'
    + '</div>';
}


    
    function normalizeDealTypeFront(value) {
      const clean = String(value || "").trim().toUpperCase();
      return DEAL_TYPES_JS.includes(clean) ? clean : "LCL_PROPIO";
    }
    function getDealTypeLabelFront(value) {
      const normalized = normalizeDealTypeFront(value);
      return DEAL_TYPE_LABELS_JS[normalized] || normalized;
    }
    function normalizeLeadQualityFront(value) {
      const clean = String(value || "").trim().toUpperCase();
      return LEAD_QUALITY_VALUES_JS.includes(clean) ? clean : "NO_RESPONDE";
    }
    function getLeadQualityLabelFront(value) {
      const normalized = normalizeLeadQualityFront(value);
      return LEAD_QUALITY_LABELS_JS[normalized] || normalized;
    }

    async function renderContactResultsDeal() {
      const q = (document.getElementById("contactSearchDeal").value || "").trim();
      const box = document.getElementById("contactResultsDeal");
      try {
        const params = new URLSearchParams();
        params.set("ts", Date.now());
        params.set("limit", "20");
        params.set("lite", "1");
        if (q) params.set("q", q);
        const r = await fetch("/api/contacts?" + params.toString());
        const data = await r.json();
        CONTACT_SEARCH_RESULTS = data && data.ok && Array.isArray(data.contacts) ? data.contacts : [];
      } catch (err) {
        CONTACT_SEARCH_RESULTS = [];
      }
      if (!CONTACT_SEARCH_RESULTS.length) {
        box.innerHTML = '<div class="contact-item">No se encontraron contactos</div>';
        return;
      }
      box.innerHTML = CONTACT_SEARCH_RESULTS.map(function(c) {
        return '<div class="contact-item" onclick="seleccionarContactoDeal(' + "'" + c.id + "'" + ',' + "'" + String(c.name || '').replace(/'/g, "\'") + "'" + ',' + "'" + String(c.owner || '').replace(/'/g, "\'") + "'" + ')"><strong>' + (c.name || 'Sin nombre') + '</strong><br><span style="font-size:12px;color:#666">' + [c.company, c.phone, c.email, c.owner].filter(Boolean).join(' | ') + '</span></div>';
      }).join('');
    }

    function seleccionarContactoDeal(id, name, owner) {
      SELECTED_CONTACT_ID = id || "";
      SELECTED_CONTACT_NAME = name || "";
      SELECTED_CONTACT_OWNER = owner || "";
      document.getElementById("contactSelectedDeal").innerText = SELECTED_CONTACT_NAME ? ('Seleccionado: ' + SELECTED_CONTACT_NAME) : 'Sin contacto seleccionado';
    }

function getKanbanColumnHeaderId(stage) {
  return "col-header-" + stage;
}

function getKanbanColumnBodyId(stage) {
  return "col-" + stage;
}

function ensureKanbanColumns() {
  const board = document.getElementById("board");
  if (!board) return;
  if (board.children.length === STAGES.length) return;
  crearColumnas();
}

function crearColumnas() {
  const board = document.getElementById("board");
  board.innerHTML = "";

  STAGES.forEach(function(stage) {
    const column = document.createElement("div");
    column.className = "column";

    const header = document.createElement("div");
    header.className = "column-header";
    header.id = getKanbanColumnHeaderId(stage);

    const body = document.createElement("div");
    body.className = "column-body";
    body.id = getKanbanColumnBodyId(stage);

    column.appendChild(header);
    column.appendChild(body);
    board.appendChild(column);
  });

  STAGES.forEach(function(stage) {
    renderKanbanStage(stage);
  });
}

function renderKanbanColumnHeader(stage) {
  const header = document.getElementById(getKanbanColumnHeaderId(stage));
  if (!header) return;

  const meta = KANBAN_META[stage] || emptyKanbanStageMeta();
  const allItems = Array.isArray(meta.allItems) && meta.allItems.length ? meta.allItems : (Array.isArray(meta.items) ? meta.items : []);
  const visibleCount = Math.max(0, Number(meta.visibleCount || allItems.length));
  const items = allItems.slice(0, visibleCount);
  const count = meta.totalKnown ? Number(meta.total || 0) : items.length;
  const total = items.reduce(function(acc, deal) { return acc + Number((deal && deal.value) || 0); }, 0);
  const loadedLabel = meta.loaded ? (String(count) + (meta.totalKnown ? '' : '+') + ' trato(s)') : 'Cargando...';
  const totalLabel = meta.loaded ? formatMoney(total) : 'Preparando etapa';

  header.innerHTML = ''
    + '<div style="font-weight:bold;">' + stage + '</div>'
    + '<div style="font-size:12px;color:#555;margin-top:4px;">' + loadedLabel + '</div>'
    + '<div style="font-size:13px;color:#174ea6;font-weight:bold;margin-top:4px;">' + totalLabel + '</div>';

  const selectBtn = document.createElement("button");
  selectBtn.className = "secondary";
  selectBtn.style.marginTop = "8px";
  selectBtn.style.padding = "8px 10px";
  selectBtn.style.fontSize = "12px";
  selectBtn.textContent = "Seleccionar visibles";
  selectBtn.onclick = function() { selectStageDeals(stage); };
  header.appendChild(selectBtn);
}

function buildKanbanDealCard(deal) {
  const card = document.createElement("div");
  card.className = "deal-card" + (isHighValueDeal(deal) ? " high-value" : "");

  const selectionRow = document.createElement("div");
  selectionRow.style.display = "flex";
  selectionRow.style.justifyContent = "space-between";
  selectionRow.style.alignItems = "center";
  selectionRow.style.marginBottom = "8px";

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.className = "deal-check";
  checkbox.checked = isDealSelected(deal.id);
  checkbox.setAttribute("data-deal-check", String(deal.id || ""));
  checkbox.onchange = function() { toggleDealSelection(deal.id, this.checked); };
  selectionRow.appendChild(checkbox);

  const title = document.createElement("div");
  title.className = "deal-title";
  title.innerText = deal.title || "";

  const valueMeta = document.createElement("div");
  valueMeta.className = "deal-meta-strong";
  valueMeta.innerText = formatMoney(deal.value || 0);

  const qualityMeta = document.createElement("div");
  qualityMeta.className = "deal-type-badge";
  qualityMeta.innerText = "Lead: " + getLeadQualityLabelFront(deal.leadQuality || "NO_RESPONDE");

  const dueMeta = document.createElement("div");
  dueMeta.className = "deal-meta";
  dueMeta.innerText = "Vence: " + (deal.dueDate || "Sin fecha");

  const openBtn = document.createElement("button");
  openBtn.className = "deal-open-btn";
  openBtn.textContent = "Abrir";
  openBtn.onclick = function() { abrirDetalleTrato(deal.id); };

  card.appendChild(selectionRow);
  card.appendChild(title);
  card.appendChild(valueMeta);
  card.appendChild(qualityMeta);
  card.appendChild(dueMeta);
  card.appendChild(openBtn);
  return card;
}

function getKanbanStageVisibleItems(stage) {
  const meta = KANBAN_META[stage] || emptyKanbanStageMeta();
  const source = Array.isArray(meta.allItems) && meta.allItems.length ? meta.allItems : (Array.isArray(meta.items) ? meta.items : []);
  const visibleCount = Math.max(0, Number(meta.visibleCount || 0));
  return source.slice(0, visibleCount || source.length);
}

function updateKanbanStageVisibility(stage, extraCount) {
  const meta = KANBAN_META[stage] || emptyKanbanStageMeta();
  const source = Array.isArray(meta.allItems) ? meta.allItems.slice() : [];
  const nextVisible = Math.min(source.length, Math.max(0, Number(meta.visibleCount || 0)) + Math.max(0, Number(extraCount || 0)));
  KANBAN_META[stage] = Object.assign({}, meta, {
    allItems: source,
    visibleCount: nextVisible,
    items: source.slice(0, nextVisible),
    total: source.length,
    loaded: true,
    loading: false
  });
}

function renderKanbanStage(stage) {
  ensureKanbanColumns();
  renderKanbanColumnHeader(stage);

  const col = document.getElementById(getKanbanColumnBodyId(stage));
  if (!col) return;
  col.innerHTML = "";

  const meta = KANBAN_META[stage] || emptyKanbanStageMeta();
  const allItems = Array.isArray(meta.allItems) && meta.allItems.length ? meta.allItems : (Array.isArray(meta.items) ? meta.items : []);
  const visibleCount = Math.max(0, Number(meta.visibleCount || allItems.length));
  const items = allItems.slice(0, visibleCount);

  if (!meta.loaded) {
    const loading = document.createElement("div");
    loading.className = "deal-meta";
    loading.style.padding = "8px 4px";
    loading.innerText = meta.loading ? "Cargando etapa..." : "Etapa pendiente...";
    col.appendChild(loading);
    return;
  }

  if (!items.length) {
    const empty = document.createElement("div");
    empty.className = "deal-meta";
    empty.style.padding = "8px 4px";
    empty.innerText = "Sin tratos en esta etapa";
    col.appendChild(empty);
  } else {
    const fragment = document.createDocumentFragment();
    items.forEach(function(deal) {
      fragment.appendChild(buildKanbanDealCard(deal));
    });
    col.appendChild(fragment);
  }

  if ((allItems.length > visibleCount) || meta.hasMore || KANBAN_GLOBAL_HAS_MORE) {
    const wrap = document.createElement("div");
    wrap.style.display = "flex";
    wrap.style.justifyContent = "center";
    wrap.style.padding = "8px 0 4px";

    const btn = document.createElement("button");
    btn.className = "secondary";
    btn.style.width = "100%";
    btn.textContent = "Ver más";
    btn.onclick = function() { verMasDealsKanban(stage); };

    wrap.appendChild(btn);
    col.appendChild(wrap);
  }
}

function updateKanbanGlobalLoadMoreButton() {
  const btn = document.getElementById("kanbanLoadMoreBtn");
  if (!btn) return;
  btn.style.display = "none";
}

async function fetchMoreKanbanGlobalRows() {
  if (!KANBAN_GLOBAL_HAS_MORE || KANBAN_GLOBAL_LOADING_MORE) return [];
  KANBAN_GLOBAL_LOADING_MORE = true;
  try {
    const extra = {
      view: "kanban_single",
      skipCount: "1",
      limit: KANBAN_SINGLE_REQUEST_LIMIT,
      cursor: KANBAN_GLOBAL_CURSOR
    };
    const r = await fetch("/api/deals?" + buildDealsQueryParams(extra).toString());
    const data = await r.json();
    if (!data.ok) throw new Error(data.error || "No se pudieron cargar más tratos");
    const rows = Array.isArray(data.deals) ? data.deals : [];
    KANBAN_GLOBAL_CURSOR = String(data.nextCursor || "");
    KANBAN_GLOBAL_HAS_MORE = !!data.hasMore;
    return rows;
  } finally {
    KANBAN_GLOBAL_LOADING_MORE = false;
  }
}

async function verMasKanbanGlobal() {
  return;
}

async function loadDealNoteHistory(id) {
  try {
    const r = await fetch("/api/deals/" + id + "/note-history");
    const data = await r.json();
    if (!data.ok) return [];
    return Array.isArray(data.history) ? data.history : [];
  } catch (err) {
    console.error(err);
    return [];
  }
}

    async function fetchUsersCached(forceFresh) {
      const cacheKey = "crmscb_users_cache_v1";
      const now = Date.now();
      if (!forceFresh) {
        try {
          const cached = JSON.parse(sessionStorage.getItem(cacheKey) || "null");
          if (cached && Array.isArray(cached.data) && Number(cached.expiresAt || 0) > now) {
            return cached.data;
          }
        } catch (e) {}
      }
      const r = await fetch("/api/users?ts=" + Date.now());
      const data = await r.json();
      const list = Array.isArray(data) ? data : [];
      try {
        sessionStorage.setItem(cacheKey, JSON.stringify({ expiresAt: now + 30000, data: list }));
      } catch (e) {}
      return list;
    }

    async function cargarUsuarios(forceFresh) {
      try {
        USERS = await fetchUsersCached(!!forceFresh);
        cargarOwnersEnFiltro();
      } catch (err) {
        USERS = [];
        cargarOwnersEnFiltro();
        console.error(err);
      }
    }


    function armarSelectEtapa(dealId, selectedStage, compact) {
      const select = document.createElement("select");
      select.className = compact ? "inline-select" : "deal-select";
      STAGES.forEach(function(stage) {
        const option = document.createElement("option");
        option.value = stage;
        option.text = stage;
        if (stage === selectedStage) option.selected = true;
        select.appendChild(option);
      });
      select.onchange = function() { moverDeal(dealId, this.value); };
      return select;
    }

    function armarSelectDealType(dealId, selectedType, compact) {
      const select = document.createElement("select");
      select.className = compact ? "inline-select" : "deal-select";
      DEAL_TYPES_JS.forEach(function(type) {
        const option = document.createElement("option");
        option.value = type;
        option.text = getDealTypeLabelFront(type);
        if (type === normalizeDealTypeFront(selectedType)) option.selected = true;
        select.appendChild(option);
      });
      select.onchange = function() { cambiarTipoDeal(dealId, this.value); };
      return select;
    }

    function armarSelectLeadQuality(dealId, selectedQuality, reloadAfter = true) {
      const select = document.createElement("select");
      select.className = reloadAfter ? "inline-select" : "deal-select";
      LEAD_QUALITY_VALUES_JS.forEach(function(quality) {
        const option = document.createElement("option");
        option.value = quality;
        option.text = getLeadQualityLabelFront(quality);
        if (quality === normalizeLeadQualityFront(selectedQuality)) option.selected = true;
        select.appendChild(option);
      });
      select.onchange = async function() {
        try {
          await cambiarCalidadLeadDeal(dealId, this.value, reloadAfter);
        } catch (err) {
          alert(err.message || "No se pudo actualizar la calidad del lead");
        }
      };
      return select;
    }

    function armarEditorTipoTratoKanban(dealId, currentType) {
      const wrap = document.createElement("div");
      const row = document.createElement("div");
      row.className = "type-edit-wrap";

      const select = document.createElement("select");
      select.className = "deal-select";
      select.style.marginTop = "0";

      DEAL_TYPES_JS.forEach(function(type) {
        const option = document.createElement("option");
        option.value = type;
        option.text = getDealTypeLabelFront(type);
        if (type === normalizeDealTypeFront(currentType)) option.selected = true;
        select.appendChild(option);
      });

      const btn = document.createElement("button");
      btn.className = "type-save-btn";
      btn.textContent = "Guardar tipo";

      const msg = document.createElement("div");
      msg.className = "type-msg";

      btn.onclick = async function() {
        btn.disabled = true;
        msg.innerText = "Guardando...";
        try {
          await cambiarTipoDeal(dealId, select.value, false);
          msg.innerText = "Tipo actualizado";
          await cargarDeals();
        } catch (error) {
          msg.innerText = "No se pudo guardar";
        } finally {
          btn.disabled = false;
        }
      };

      row.appendChild(select);
      row.appendChild(btn);
      wrap.appendChild(row);
      wrap.appendChild(msg);
      return wrap;
    }

    function armarSelectOwner(dealId, selectedOwner, compact) {
      const select = document.createElement("select");
      select.className = compact ? "inline-select" : "deal-select";
      const emptyOption = document.createElement("option");
      emptyOption.value = "";
      emptyOption.text = "Sin owner";
      if (!selectedOwner) emptyOption.selected = true;
      select.appendChild(emptyOption);
      USERS.forEach(function(user) {
        const option = document.createElement("option");
        option.value = user.email || "";
        option.text = (user.name || user.email || "") + (user.email ? " (" + user.email + ")" : "");
        if ((user.email || "") === (selectedOwner || "")) option.selected = true;
        select.appendChild(option);
      });
      select.onchange = function() { cambiarOwnerDeal(dealId, this.value); };
      if (esSeller()) select.disabled = true;
      return select;
    }

    function armarInputDueDate(dealId, dueDate, compact) {
      const input = document.createElement("input");
      input.type = "date";
      input.className = compact ? "inline-select" : "due-input";
      input.value = dueDate || "";
      input.onchange = function() { cambiarVencimientoDeal(dealId, this.value); };
      return input;
    }

    function armarEditorValor(dealId, currentValue) {
      const wrap = document.createElement("div");
      const row = document.createElement("div");
      row.className = "value-edit-wrap";
      const input = document.createElement("input");
      input.type = "number";
      input.step = "0.01";
      input.min = "0";
      input.className = "value-input";
      input.value = Number(currentValue || 0);
      const btn = document.createElement("button");
      btn.className = "value-save-btn";
      btn.textContent = "Guardar";
      const msg = document.createElement("div");
      msg.className = "value-msg";
      btn.onclick = async function() {
        btn.disabled = true;
        msg.innerText = "Guardando...";
        try {
          await guardarValorDeal(dealId, input.value);
          msg.innerText = "Valor actualizado";
        } catch (error) {
          msg.innerText = "No se pudo guardar";
        } finally {
          btn.disabled = false;
        }
      };
      row.appendChild(input);
      row.appendChild(btn);
      wrap.appendChild(row);
      wrap.appendChild(msg);
      return wrap;
    }

    function armarTextareaNotas(dealId, notes) {
  const wrap = document.createElement("div");

  const textarea = document.createElement("textarea");
  textarea.className = "note-textarea";
  textarea.value = notes || "";

  const btn = document.createElement("button");
  btn.textContent = "Guardar notas";
  btn.style.marginTop = "8px";
  btn.style.padding = "8px 10px";
  btn.style.fontSize = "12px";

  const toggleBtn = document.createElement("button");
  toggleBtn.type = "button";
  toggleBtn.className = "history-toggle";
  toggleBtn.textContent = "Ver historial";

  const historyBox = document.createElement("div");
  historyBox.className = "history-collapsed";
  historyBox.style.marginTop = "8px";
  historyBox.style.flexDirection = "column";
  historyBox.style.gap = "8px";
  historyBox.style.display = "none";

  let historyLoaded = false;

  async function refreshHistory() {
    historyBox.innerHTML = '<div style="font-size:12px;color:#666;">Cargando historial...</div>';

    const r = await fetch("/api/deals/" + dealId + "/note-history");
    const data = await r.json();
    const history = data && data.ok && Array.isArray(data.history) ? data.history : [];

    if (!history.length) {
      historyBox.innerHTML = '<div style="font-size:12px;color:#666;">Sin historial de notas</div>';
      historyLoaded = true;
      return;
    }

    historyBox.innerHTML = history.map(function(item) {
      const note = String(item.note || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");

      const user = String(item.user || "system")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");

      let created = "";
      if (item.createdAt && item.createdAt._seconds) {
        created = new Date(item.createdAt._seconds * 1000).toLocaleString();
      } else if (item.createdAt && item.createdAt.seconds) {
        created = new Date(item.createdAt.seconds * 1000).toLocaleString();
      }

      return ''
        + '<div style="border:1px solid #e5e7eb;border-radius:8px;padding:8px;background:#fff;">'
        +   '<div style="font-size:12px;white-space:pre-wrap;">' + note + '</div>'
        +   '<div style="font-size:11px;color:#6b7280;margin-top:4px;">' + user + (created ? ' · ' + created : '') + '</div>'
        + '</div>';
    }).join("");
    historyLoaded = true;
  }

  toggleBtn.onclick = async function() {
    const opening = historyBox.classList.contains("history-collapsed");
    if (opening) {
      historyBox.classList.remove("history-collapsed");
      historyBox.style.display = "flex";
      toggleBtn.textContent = "Ocultar historial";
      if (!historyLoaded) await refreshHistory();
    } else {
      historyBox.classList.add("history-collapsed");
      historyBox.style.display = "none";
      toggleBtn.textContent = "Ver historial";
    }
  };

  btn.onclick = async function() {
    await withActionLock("deal_note_save_" + dealId, async function() {
      setButtonBusy(btn, "Guardando...", true);
      try {
        await guardarNotasDeal(dealId, textarea.value);
        if (!historyBox.classList.contains("history-collapsed")) {
          await refreshHistory();
        } else {
          historyLoaded = false;
        }
      } finally {
        setButtonBusy(btn, "Guardando...", false);
      }
    });
  };

  wrap.appendChild(textarea);
  wrap.appendChild(btn);
  wrap.appendChild(toggleBtn);
  wrap.appendChild(historyBox);

  return wrap;
}







        // =====================================================
    // BLOQUE 5J - ADJUNTOS
    // =====================================================

    function armarFilesBox(deal) {
      const wrap = document.createElement("div");
      wrap.className = "files-box";
      const title = document.createElement("div");
      title.className = "deal-label";
      title.style.marginTop = "0";
      title.innerText = "Archivos";
      const uploadRow = document.createElement("div");
      uploadRow.className = "upload-row";
      const input = document.createElement("input");
      input.type = "file";
      input.className = "file-input";
      input.accept = ".pdf,.jpg,.jpeg,.png";
      input.id = "file-input-" + deal.id;
      const btn = document.createElement("button");
      btn.className = "upload-btn";
      btn.textContent = "Adjuntar";
      const msg = document.createElement("div");
      msg.className = "upload-msg";
      msg.id = "upload-msg-" + deal.id;
      btn.onclick = function() {
        subirArchivoDeal(deal.id, input, msg);
      };
      uploadRow.appendChild(input);
      uploadRow.appendChild(btn);
      wrap.appendChild(title);
      wrap.appendChild(uploadRow);
      wrap.appendChild(msg);

      const filesList = document.createElement("div");
      filesList.className = "files-list";
      const files = Array.isArray(deal.files) ? deal.files : [];
      if (!files.length) {
        const empty = document.createElement("div");
        empty.className = "file-meta";
        empty.innerText = "Sin archivos cargados";
        filesList.appendChild(empty);
      } else {
        files.forEach(function(file) {
          const isUploading = !!(file && file.__uploading);
          const row = document.createElement("div");
          row.className = "file-row";
          const left = document.createElement("div");
          left.style.display = "flex";
          left.style.flexDirection = "column";
          left.style.minWidth = "0";

          if (isUploading) {
            const pendingName = document.createElement("div");
            pendingName.className = "file-link";
            pendingName.style.cursor = "default";
            pendingName.style.textDecoration = "none";
            pendingName.innerText = (file.name || "Archivo") + " · Subiendo...";
            const meta = document.createElement("div");
            meta.className = "file-meta";
            meta.innerText = (file.mimeType || "") + " · " + formatFileSize(file.size || 0);
            left.appendChild(pendingName);
            left.appendChild(meta);
            row.appendChild(left);
          } else {
            const link = document.createElement("a");
            link.className = "file-link";
            link.href =
              "/api/deals/" + deal.id + "/files/" + file.id + "/view" +
              "?userId=" + encodeURIComponent(CURRENT_USER.id || "") +
              "&token=" + encodeURIComponent(CURRENT_USER.token || "");
            link.target = "_blank";
            link.rel = "noopener noreferrer";
            link.innerText = file.name || "Archivo";
            const meta = document.createElement("div");
            meta.className = "file-meta";
            meta.innerText = (file.mimeType || "") + " · " + formatFileSize(file.size || 0);
            left.appendChild(link);
            left.appendChild(meta);
            row.appendChild(left);
            if (esAdmin()) {
              const delBtn = document.createElement("button");
              delBtn.className = "upload-btn";
              delBtn.style.background = "#d93025";
              delBtn.textContent = "Borrar";
              delBtn.onclick = function() { borrarArchivoDeal(deal.id, file.id); };
              row.appendChild(delBtn);
            }
          }

          filesList.appendChild(row);
        });
      }
      wrap.appendChild(filesList);
      return wrap;
    }

        // =====================================================
        // =====================================================
    // BLOQUE 5B - VISTA KANBAN
    // =====================================================

    function buildContactLinkElement(contactId, contactName) {
      if (!contactId) {
        const span = document.createElement("span");
        span.textContent = contactName || "";
        return span;
      }

      const link = document.createElement("a");
      link.href = "/contacts?contactId=" + encodeURIComponent(contactId) + "&contactName=" + encodeURIComponent(contactName || "");
      link.textContent = contactName || "Sin contacto";
      link.style.color = "#1a73e8";
      link.style.fontWeight = "bold";
      link.style.textDecoration = "underline";
      link.style.cursor = "pointer";
      link.title = "Abrir contacto";
      return link;
    }

    function renderKanban() {
      ensureKanbanColumns();
      STAGES.forEach(function(stage) {
        renderKanbanStage(stage);
      });
    }

    async function abrirDealEnHub(dealId) {
      try {
        if (!dealId) {
          alert("No se encontró el trato");
          return;
        }

        const r = await fetch("/api/deals/" + encodeURIComponent(dealId) + "/hub-link");
        const data = await r.json();

        if (!r.ok || !data.ok) {
          alert(data.error || "No se pudo abrir HUB");
          return;
        }

        if (!data.found || !data.url) {
          alert(data.error || "No se encontró conversación en HUB para este trato");
          return;
        }

        window.open(data.url, "_blank");
      } catch (err) {
        console.error("ERROR abrirDealEnHub:", err);
        alert("Error conectando con HUB");
      }
    }

    function abrirDetalleTrato(dealId) {
      const deal = DEALS.find(function(item) { return item.id === dealId; }) || null;
      if (!deal) return;
      CURRENT_DEAL_MODAL_ID = dealId;
      document.getElementById("dealDetailTitle").innerText = deal.title || "Detalle del trato";
      document.getElementById("dealDetailSubtitle").innerText = "Contacto: " + (deal.contactName || "-") + " | Owner: " + (deal.owner || "Sin owner");
      const content = document.getElementById("dealDetailContent");
      content.innerHTML = "";

      const grid = document.createElement("div");
      grid.className = "deal-detail-grid";

      const secMain = document.createElement("div");
      secMain.className = "deal-detail-section";
      const valueLabel = document.createElement("div");
      valueLabel.className = "deal-label";
      valueLabel.innerText = "Modificar valor";
      secMain.appendChild(valueLabel);
      secMain.appendChild(armarEditorValor(deal.id, deal.value || 0));
      const dueLabel = document.createElement("div");
      dueLabel.className = "deal-label";
      dueLabel.innerText = "Fecha de vencimiento";
      secMain.appendChild(dueLabel);
      secMain.appendChild(armarInputDueDate(deal.id, deal.dueDate || "", false));
      const stageLabel = document.createElement("div");
      stageLabel.className = "deal-label";
      stageLabel.innerText = "Cambiar etapa";
      secMain.appendChild(stageLabel);
      secMain.appendChild(armarSelectEtapa(deal.id, deal.stage || "No responde", false));
      const typeLabel = document.createElement("div");
      typeLabel.className = "deal-label";
      typeLabel.innerText = "Tipo de trato";
      secMain.appendChild(typeLabel);
      secMain.appendChild(armarEditorTipoTratoKanban(deal.id, deal.dealType || "LCL_PROPIO"));
      const qualityLabel = document.createElement("div");
      qualityLabel.className = "deal-label";
      qualityLabel.innerText = "Calidad de lead";
      secMain.appendChild(qualityLabel);
      secMain.appendChild(armarSelectLeadQuality(deal.id, deal.leadQuality || "NO_RESPONDE", false));
      const ownerLabel = document.createElement("div");
      ownerLabel.className = "deal-label";
      ownerLabel.innerText = "Cambiar owner";
      secMain.appendChild(ownerLabel);
      secMain.appendChild(armarSelectOwner(deal.id, deal.owner || "", false));

      const secNotes = document.createElement("div");
      secNotes.className = "deal-detail-section";
      const notesLabel = document.createElement("div");
      notesLabel.className = "deal-label";
      notesLabel.innerText = "Notas";
      secNotes.appendChild(notesLabel);
      secNotes.appendChild(armarTextareaNotas(deal.id, deal.notes || ""));

      grid.appendChild(secMain);
      grid.appendChild(secNotes);
      content.appendChild(grid);

      const filesSection = document.createElement("div");
      filesSection.className = "deal-detail-section";
      filesSection.style.marginTop = "14px";
      filesSection.appendChild(armarFilesBox(deal));
      content.appendChild(filesSection);

      const actions = document.createElement("div");
      actions.className = "actions";
      actions.style.marginTop = "14px";

      const hubBtn = document.createElement("button");
      hubBtn.className = "upload-btn";
      hubBtn.style.background = "#111827";
      hubBtn.textContent = "Ir a HUB";
      hubBtn.onclick = function() { abrirDealEnHub(deal.id); };
      actions.appendChild(hubBtn);

      const editBtn = document.createElement("button");
      editBtn.className = "upload-btn";
      editBtn.textContent = "Editar";
      editBtn.onclick = function() { editarDealPrompt(deal.id); };
      actions.appendChild(editBtn);
      const productionDetailBtn = document.createElement("button");
      productionDetailBtn.className = "upload-btn secondary";
      productionDetailBtn.textContent = "Producción / CBM";
      productionDetailBtn.onclick = function() {
        if (typeof window.scbOpenProductionDeal === "function") window.scbOpenProductionDeal(deal);
        else alert("El módulo de producción todavía no terminó de cargar");
      };
      actions.appendChild(productionDetailBtn);
      if (esAdmin()) {
        const delBtn = document.createElement("button");
        delBtn.className = "upload-btn";
        delBtn.style.background = "#d93025";
        delBtn.textContent = "Borrar";
        delBtn.onclick = function() { borrarDeal(deal.id); };
        actions.appendChild(delBtn);
      }
      content.appendChild(actions);
      document.getElementById("dealDetailModalBg").style.display = "flex";
    }

    function cerrarDetalleTrato() {
      document.getElementById("dealDetailModalBg").style.display = "none";
      document.getElementById("dealDetailContent").innerHTML = "";
      CURRENT_DEAL_MODAL_ID = "";
    }


        // =====================================================
        // =====================================================
    // BLOQUE 5C - VISTA LISTA
    // =====================================================

    function renderLista() {
      const body = document.getElementById("dealsTableBody");
      if (!FILTERED_DEALS.length) {
        body.innerHTML = '<tr><td colspan="13">No hay tratos todavía</td></tr>';
        return;
      }
      body.innerHTML = "";
      FILTERED_DEALS.forEach(function(deal) {
        const contactoPhone = deal.contactPhone || "";
        const tr = document.createElement("tr");
        if (isHighValueDeal(deal)) tr.className = "high-value-row";

        const tdCheck = document.createElement("td");
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.className = "deal-check";
        checkbox.checked = isDealSelected(deal.id);
        checkbox.setAttribute("data-deal-check", String(deal.id || ""));
        checkbox.onchange = function() { toggleDealSelection(deal.id, this.checked); };
        tdCheck.appendChild(checkbox);

        const tdTitle = document.createElement("td");
        tdTitle.innerText = deal.title || "";

        const tdType = document.createElement("td");
        tdType.appendChild(armarSelectDealType(deal.id, deal.dealType || "LCL_PROPIO", true));

        const tdQuality = document.createElement("td");
        tdQuality.appendChild(armarSelectLeadQuality(deal.id, deal.leadQuality || "NO_RESPONDE", true));

        const tdValue = document.createElement("td");
        const currentValue = document.createElement("div");
        currentValue.style.fontWeight = "bold";
        currentValue.style.marginBottom = "8px";
        currentValue.innerText = formatMoney(deal.value || 0);
        tdValue.appendChild(currentValue);
        tdValue.appendChild(armarEditorValor(deal.id, deal.value || 0));

        const tdContact = document.createElement("td");
        const contactNameDiv = document.createElement("div");
        contactNameDiv.appendChild(buildContactLinkElement(deal.contactId, deal.contactName || ""));
        tdContact.appendChild(contactNameDiv);

        if (contactoPhone) {
          const waWrap = document.createElement("div");
          waWrap.style.marginTop = "8px";
          waWrap.style.display = "flex";
          waWrap.style.alignItems = "center";
          waWrap.style.gap = "8px";
          const waBtn = buildWhatsAppButton(contactoPhone, deal.contactName || "");
          const phoneText = document.createElement("span");
          phoneText.style.fontSize = "12px";
          phoneText.style.color = "#666";
          phoneText.innerText = contactoPhone;
          if (waBtn) waWrap.appendChild(waBtn);
          waWrap.appendChild(phoneText);
          tdContact.appendChild(waWrap);
        }

        const tdDue = document.createElement("td");
        tdDue.appendChild(armarInputDueDate(deal.id, deal.dueDate || "", true));

        const tdStage = document.createElement("td");
        tdStage.appendChild(armarSelectEtapa(deal.id, deal.stage || "No responde", true));

        const tdOwner = document.createElement("td");
        tdOwner.appendChild(armarSelectOwner(deal.id, deal.owner || "", true));

        const tdNotes = document.createElement("td");
        tdNotes.appendChild(armarTextareaNotas(deal.id, deal.notes || ""));

        const tdFiles = document.createElement("td");
        tdFiles.appendChild(armarFilesBox(deal));

        const tdProduction = document.createElement("td");
        const productionInfo = document.createElement("div");
        productionInfo.style.fontSize = "12px";
        productionInfo.style.lineHeight = "1.45";
        productionInfo.innerHTML =
          '<div><b>CBM:</b> ' + Number(deal.cbm || 0).toLocaleString("es-AR", { maximumFractionDigits: 2 }) + ' m³</div>' +
          '<div><b>Hunter:</b> ' + (deal.isHunterSale === true ? 'Sí (+2%)' : 'No') + '</div>' +
          '<div><b>Warehouse:</b> ' + (deal.warehouseEntryDate || 'Pendiente') + '</div>' +
          '<div><b>Salida:</b> ' + (deal.containerDepartureDate || 'Pendiente') + '</div>';
        tdProduction.appendChild(productionInfo);
        const productionInlineBtn = document.createElement("button");
        productionInlineBtn.className = "upload-btn secondary";
        productionInlineBtn.style.marginTop = "8px";
        productionInlineBtn.style.width = "100%";
        productionInlineBtn.textContent = "Cargar / editar CBM";
        productionInlineBtn.onclick = function() {
          if (typeof window.scbOpenProductionDeal === "function") window.scbOpenProductionDeal(deal);
          else alert("El módulo de producción todavía no terminó de cargar");
        };
        tdProduction.appendChild(productionInlineBtn);

        const tdActions = document.createElement("td");
        const editBtn = document.createElement("button");
        editBtn.className = "upload-btn";
        editBtn.textContent = "Editar";
        editBtn.onclick = function() { editarDealPrompt(deal.id); };
        tdActions.appendChild(editBtn);

        const productionBtn = document.createElement("button");
        productionBtn.className = "upload-btn secondary";
        productionBtn.style.marginTop = "8px";
        productionBtn.textContent = "Producción / CBM";
        productionBtn.onclick = function() {
          if (typeof window.scbOpenProductionDeal === "function") {
            window.scbOpenProductionDeal(deal);
          } else {
            alert("El módulo de producción todavía no terminó de cargar");
          }
        };
        tdActions.appendChild(productionBtn);
        if (esAdmin()) {
          const delBtn = document.createElement("button");
          delBtn.className = "upload-btn";
          delBtn.style.background = "#d93025";
          delBtn.style.marginTop = "8px";
          delBtn.textContent = "Borrar";
          delBtn.onclick = function() { borrarDeal(deal.id); };
          tdActions.appendChild(delBtn);
        }

        tr.appendChild(tdCheck);
        tr.appendChild(tdTitle);
        tr.appendChild(tdType);
        tr.appendChild(tdQuality);
        tr.appendChild(tdValue);
        tr.appendChild(tdContact);
        tr.appendChild(tdDue);
        tr.appendChild(tdStage);
        tr.appendChild(tdOwner);
        tr.appendChild(tdNotes);
        tr.appendChild(tdFiles);
        tr.appendChild(tdProduction);
        tr.appendChild(tdActions);
        body.appendChild(tr);
      });
    }

    
        // =====================================================
    // BLOQUE 5D - CAMBIO DE VISTA
    // =====================================================

    async function cambiarVista(view) {
      CURRENT_VIEW = view;
      const kanbanView = document.getElementById("kanbanView");
      const listView = document.getElementById("listView");
      const btnKanban = document.getElementById("btnKanban");
      const btnLista = document.getElementById("btnLista");
      if (view === "kanban") {
        kanbanView.style.display = "block";
        listView.style.display = "none";
        btnKanban.className = "active-view";
        btnLista.className = "secondary";
      } else {
        kanbanView.style.display = "none";
        listView.style.display = "block";
        btnKanban.className = "secondary";
        btnLista.className = "active-view";
      }
      await cargarDeals();
    }

    function buildDealsQueryParams(extra) {
      const params = new URLSearchParams();
      params.set("ts", Date.now());
      params.set("limit", String(DEALS_PAGE_SIZE));
      const ownerValues = getOwnerFilterValues();
      const dealType = document.getElementById("filterDealType").value || "";
      const dealName = (document.getElementById("filterDealName").value || "").trim();
      const dueMode = document.getElementById("filterDueMode").value || "";
      const dueFrom = document.getElementById("filterDueFrom").value || "";
      const dueTo = document.getElementById("filterDueTo").value || "";
      const mobileStage = getMobileStageFilterValue();
      if (mobileStage) params.set("stage", mobileStage);
      if (ownerValues.length) params.set("owner", ownerValues.join(","));
      if (dealType) params.set("dealType", dealType);
      if (dealName) params.set("q", dealName);
      if (dueMode) params.set("dueMode", dueMode);
      if (dueFrom) params.set("dueFrom", dueFrom);
      if (dueTo) params.set("dueTo", dueTo);
      if (FILTER_DEAL_ID_FROM_URL) params.set("dealId", FILTER_DEAL_ID_FROM_URL);
      const wantsContactPhone = ((extra && extra.view) === "lista") || CURRENT_VIEW === "lista";
      params.set("includeContactPhone", wantsContactPhone ? "1" : "0");
      Object.keys(extra || {}).forEach(function(key) {
        if (extra[key] !== "" && extra[key] !== null && typeof extra[key] !== "undefined") params.set(key, String(extra[key]));
      });
      return params;
    }

    async function cargarDeals() {
      const msg = document.getElementById("msg");
      msg.innerText = "";
      try {
        await cargarUsuarios();
        await renderContactResultsDeal();
        if (CURRENT_VIEW === "kanban") {
          await cargarDealsKanban(true);
        } else {
          await cargarDealsLista(true);
          renderLista();
        }
        refreshSelectionInputs();
      } catch (err) {
        msg.innerText = "Error cargando tratos";
        console.error(err);
      }
    }

    function rebuildDealsFromKanbanMeta() {
      DEALS = STAGES.reduce(function(acc, stage) { return acc.concat((KANBAN_META[stage] && KANBAN_META[stage].items) || []); }, []);
      FILTERED_DEALS = DEALS.slice();
      updateBulkSummary();
      renderPipelineSummary();
      actualizarResumenFiltros();
    }

    async function cargarDealsLista(reset) {
      const cursor = reset ? "" : (LIST_META.cursor || "");
      const extra = { view: "lista" };
      if (cursor) extra.cursor = cursor;
      const r = await fetch("/api/deals?" + buildDealsQueryParams(extra).toString());
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || "No se pudieron cargar los tratos");
      const rows = Array.isArray(data.deals) ? data.deals : [];
      LIST_META = { total: Number(data.total || 0), cursor: String(data.nextCursor || ""), hasMore: !!data.hasMore };
      DEALS = reset ? rows : DEALS.concat(rows);
      FILTERED_DEALS = DEALS.slice();
      updateBulkSummary();
      const btn = document.getElementById("listLoadMoreBtn");
      if (btn) btn.style.display = LIST_META.hasMore ? "inline-block" : "none";
      renderPipelineSummary();
      actualizarResumenFiltros();
    }

    async function cargarDealsKanbanStage(stage, reset) {
      const current = KANBAN_META[stage] || emptyKanbanStageMeta();
      const cursor = reset ? "" : (current.cursor || "");
      KANBAN_META[stage] = Object.assign({}, current, { loading: true });
      const extra = { view: "kanban", stage: stage, skipCount: "1", limit: KANBAN_STAGE_PAGE_SIZE };
      if (cursor) extra.cursor = cursor;
      const r = await fetch("/api/deals?" + buildDealsQueryParams(extra).toString());
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || "No se pudieron cargar los tratos");
      const rows = Array.isArray(data.deals) ? data.deals : [];
      KANBAN_META[stage] = {
        total: Number(data.total || 0),
        totalKnown: !!data.totalKnown,
        cursor: String(data.nextCursor || ""),
        hasMore: !!data.hasMore,
        items: reset ? rows : ((current.items || []).concat(rows)),
        loaded: true,
        loading: false
      };
    }

    function hydrateKanbanMetaFromSingleRequest(rows) {
      const grouped = {};
      STAGES.forEach(function(stage) { grouped[stage] = []; });
      (Array.isArray(rows) ? rows : []).forEach(function(deal) {
        const stage = (deal && deal.stage) || "No responde";
        if (!grouped[stage]) grouped[stage] = [];
        grouped[stage].push(deal);
      });

      STAGES.forEach(function(stage) {
        const allItems = grouped[stage] || [];
        const visibleCount = Math.min(allItems.length, KANBAN_STAGE_INITIAL_VISIBLE);
        KANBAN_META[stage] = {
          total: allItems.length,
          totalKnown: false,
          cursor: "",
          hasMore: false,
          items: allItems.slice(0, visibleCount),
          allItems: allItems,
          visibleCount: visibleCount,
          loaded: true,
          loading: false
        };
      });
    }

    async function cargarDealsKanban(reset) {
      KANBAN_BG_RUN_ID += 1;
      if (reset) {
        DEALS = [];
        FILTERED_DEALS = [];
        KANBAN_GLOBAL_CURSOR = "";
        KANBAN_GLOBAL_HAS_MORE = false;
        KANBAN_GLOBAL_LOADING_MORE = false;
        STAGES.forEach(function(stage) {
          KANBAN_META[stage] = Object.assign({}, emptyKanbanStageMeta(), { loading: true });
        });
        crearColumnas();
      } else {
        ensureKanbanColumns();
      }

      const extra = {
        view: "kanban_single",
        skipCount: "1",
        limit: KANBAN_SINGLE_REQUEST_LIMIT
      };
      const r = await fetch("/api/deals?" + buildDealsQueryParams(extra).toString());
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || "No se pudieron cargar los tratos");
      const rows = Array.isArray(data.deals) ? data.deals : [];

      KANBAN_GLOBAL_CURSOR = String(data.nextCursor || "");
      KANBAN_GLOBAL_HAS_MORE = !!data.hasMore;
      hydrateKanbanMetaFromSingleRequest(rows);
      STAGES.forEach(function(stage) {
        const meta = KANBAN_META[stage] || emptyKanbanStageMeta();
        const allItems = Array.isArray(meta.allItems) ? meta.allItems : [];
        KANBAN_META[stage] = Object.assign({}, meta, { hasMore: allItems.length > Number(meta.visibleCount || 0) || KANBAN_GLOBAL_HAS_MORE });
      });
      rebuildDealsFromKanbanMeta();
      STAGES.forEach(function(stage) { renderKanbanStage(stage); });
      updateKanbanGlobalLoadMoreButton();
    }

    async function cargarKanbanDiferido() {
      return;
    }

    async function verMasDealsLista() {
      if (!LIST_META.hasMore) return;
      await cargarDealsLista(false);
      renderLista();
      refreshSelectionInputs();
    }

    async function verMasDealsKanban(stage) {
      const meta = KANBAN_META[stage] || emptyKanbanStageMeta();
      const currentVisible = Number(meta.visibleCount || 0);
      const targetVisible = currentVisible + KANBAN_STAGE_LOAD_MORE;
      const buffered = Math.max(0, (Array.isArray(meta.allItems) ? meta.allItems.length : 0) - currentVisible);
      if (buffered > 0) {
        updateKanbanStageVisibility(stage, KANBAN_STAGE_LOAD_MORE);
        rebuildDealsFromKanbanMeta();
        renderKanbanStage(stage);
        refreshSelectionInputs();
        return;
      }

      if (!KANBAN_GLOBAL_HAS_MORE) return;
      try {
        const existingIds = new Set(DEALS.map(function(item) { return String(item && item.id || ""); }));
        let stageBufferedCount = Array.isArray(meta.allItems) ? meta.allItems.length : 0;

        while (stageBufferedCount < targetVisible && KANBAN_GLOBAL_HAS_MORE) {
          const rows = await fetchMoreKanbanGlobalRows();
          if (!rows.length) break;

          rows.forEach(function(deal) {
            const id = String(deal && deal.id || "");
            if (!id || existingIds.has(id)) return;
            existingIds.add(id);
            const dealStage = deal && deal.stage ? deal.stage : "No responde";
            const stageMeta = KANBAN_META[dealStage] || emptyKanbanStageMeta();
            const allItems = Array.isArray(stageMeta.allItems) ? stageMeta.allItems.slice() : [];
            allItems.push(deal);
            const keepVisible = Number(stageMeta.visibleCount || Math.min(allItems.length, KANBAN_STAGE_INITIAL_VISIBLE));
            KANBAN_META[dealStage] = Object.assign({}, stageMeta, {
              allItems: allItems,
              visibleCount: Math.min(allItems.length, keepVisible),
              items: allItems.slice(0, Math.min(allItems.length, keepVisible)),
              total: allItems.length,
              loaded: true,
              loading: false
            });
          });

          stageBufferedCount = Array.isArray((KANBAN_META[stage] || {}).allItems) ? KANBAN_META[stage].allItems.length : 0;
        }

        updateKanbanStageVisibility(stage, KANBAN_STAGE_LOAD_MORE);

        STAGES.forEach(function(name) {
          const stageMeta = KANBAN_META[name] || emptyKanbanStageMeta();
          const allItems = Array.isArray(stageMeta.allItems) ? stageMeta.allItems : [];
          const visibleCount = Math.min(allItems.length, Number(stageMeta.visibleCount || 0));
          const needsMoreBuffered = allItems.length > visibleCount;
          KANBAN_META[name] = Object.assign({}, stageMeta, {
            items: allItems.slice(0, visibleCount),
            hasMore: needsMoreBuffered || KANBAN_GLOBAL_HAS_MORE
          });
        });

        rebuildDealsFromKanbanMeta();
        STAGES.forEach(function(name) { renderKanbanStage(name); });
        refreshSelectionInputs();
      } catch (error) {
        console.error(error);
        alert("Error cargando más tratos en kanban");
      }
    }

    async function crearDeal() {
      const msg = document.getElementById("msg");
      const btn = document.querySelector('.box button[onclick="crearDeal()"]');
      await withActionLock("crear_deal", async function() {
        msg.innerText = "";
        setButtonBusy(btn, "Guardando...", true);
        const title = document.getElementById("title").value.trim();
        const value = Number(document.getElementById("value").value || 0);
        const dueDate = document.getElementById("dueDate").value;
        const stage = document.getElementById("stage").value;
        const dealType = document.getElementById("dealType").value;
        const leadQuality = document.getElementById("leadQuality").value || "NO_RESPONDE";
        const notes = document.getElementById("newDealNotes").value.trim();
        if (!title) {
          msg.innerText = "El título es obligatorio";
          return;
        }
        if (!SELECTED_CONTACT_ID) {
          msg.innerText = "Debés seleccionar un contacto";
          return;
        }
        try {
          const r = await fetch("/api/deals", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title, contactId: SELECTED_CONTACT_ID, contactName: SELECTED_CONTACT_NAME, value, dueDate, stage, dealType, leadQuality, owner: SELECTED_CONTACT_OWNER || "", notes })
          });
          const data = await r.json();
          if (!data.ok) {
            msg.innerText = data.error || "No se pudo guardar el trato";
            return;
          }
          limpiarDeal();
          await cargarDeals();
        } catch (err) {
          msg.innerText = "Error conectando con el servidor";
          console.error(err);
        } finally {
          setButtonBusy(btn, "Guardando...", false);
        }
      });
    }

        // =====================================================
    // BLOQUE 5F - CAMBIO ETAPA
    // =====================================================

    async function moverDeal(id, stage) {
      try {
        const r = await fetch("/api/deals/" + id + "/stage", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ stage }) });
        const data = await r.json();
        if (data.ok) await cargarDeals();
      } catch (err) { console.error(err); }
    }

        // =====================================================
    // BLOQUE 5G - TIPO DE TRATO
    // =====================================================

    async function cambiarTipoDeal(id, dealType, reloadAfter = true) {
      const r = await fetch("/api/deals/" + id + "/type", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dealType })
      });
      const data = await r.json();
      if (!data.ok) {
        throw new Error(data.error || "No se pudo actualizar el tipo");
      }
      if (reloadAfter) await cargarDeals();
      return data;
    }

    async function cambiarCalidadLeadDeal(id, leadQuality, reloadAfter = true) {
      const normalized = normalizeLeadQualityFront(leadQuality);
      const r = await fetch("/api/deals/" + id + "/lead-quality", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadQuality: normalized })
      });
      const data = await r.json();
      if (!data.ok) {
        throw new Error(data.error || "No se pudo actualizar la calidad del lead");
      }
      applyDealPatchInLocalState(id, { leadQuality: normalized });
      refreshDealUiAfterLocalPatch(id);
      if (reloadAfter) await cargarDeals();
      return data;
    }

        // =====================================================
    // BLOQUE 5H - CAMBIO OWNER DEAL
    // =====================================================

    async function cambiarOwnerDeal(id, owner) {
      try {
        const r = await fetch("/api/deals/" + id + "/owner", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ owner }) });
        const data = await r.json();
        if (data.ok) await cargarDeals();
      } catch (err) { console.error(err); }
    }

        // =====================================================
    // BLOQUE 5I - VENCIMIENTO / VALOR / NOTAS
    // =====================================================

    function applyDealPatchInLocalState(dealId, patch) {
      const cleanId = String(dealId || "");
      if (!cleanId) return null;

      let updatedDeal = null;

      DEALS = (Array.isArray(DEALS) ? DEALS : []).map(function(item) {
        if (String(item && item.id || "") !== cleanId) return item;
        updatedDeal = Object.assign({}, item || {}, patch || {});
        return updatedDeal;
      });

      FILTERED_DEALS = (Array.isArray(FILTERED_DEALS) ? FILTERED_DEALS : []).map(function(item) {
        if (String(item && item.id || "") !== cleanId) return item;
        return Object.assign({}, item || {}, patch || {});
      });

      STAGES.forEach(function(stage) {
        const meta = KANBAN_META[stage] || emptyKanbanStageMeta();
        const allItems = (Array.isArray(meta.allItems) ? meta.allItems : []).map(function(item) {
          if (String(item && item.id || "") !== cleanId) return item;
          const next = Object.assign({}, item || {}, patch || {});
          updatedDeal = next;
          return next;
        });
        const visibleCount = Math.max(0, Number(meta.visibleCount || 0));
        KANBAN_META[stage] = Object.assign({}, meta, {
          allItems: allItems,
          items: allItems.slice(0, visibleCount || allItems.length)
        });
      });

      return updatedDeal;
    }

    function refreshDealUiAfterLocalPatch(dealId) {
      if (CURRENT_VIEW === "kanban") {
        const deal = DEALS.find(function(item) { return String(item && item.id || "") === String(dealId || ""); }) || null;
        const stage = deal && deal.stage ? deal.stage : "";
        if (stage) renderKanbanStage(stage);
        renderPipelineSummary();
        updateBulkSummary();
        refreshSelectionInputs();
        if (CURRENT_DEAL_MODAL_ID && String(CURRENT_DEAL_MODAL_ID) === String(dealId || "")) {
          document.getElementById("dealDetailTitle").innerText = deal && deal.title ? deal.title : "Detalle del trato";
          document.getElementById("dealDetailSubtitle").innerText = "Contacto: " + ((deal && deal.contactName) || "-") + " | Owner: " + ((deal && deal.owner) || "Sin owner");
        }
        return;
      }

      renderLista();
      renderPipelineSummary();
      updateBulkSummary();
      refreshSelectionInputs();
    }

    async function cambiarVencimientoDeal(id, dueDate) {
      try {
        const r = await fetch("/api/deals/" + id + "/due-date", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ dueDate }) });
        const data = await r.json();
        if (!data.ok) throw new Error(data.error || "No se pudo actualizar la fecha");
        applyDealPatchInLocalState(id, { dueDate: String(dueDate || "") });
        refreshDealUiAfterLocalPatch(id);
      } catch (err) { console.error(err); }
    }

    async function guardarValorDeal(id, value) {
      const nextValue = Number(value || 0);
      const r = await fetch("/api/deals/" + id + "/value", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ value: nextValue })
      });
      const data = await r.json();
      if (!data.ok) {
        throw new Error(data.error || "No se pudo actualizar el valor");
      }
      applyDealPatchInLocalState(id, { value: nextValue });
      refreshDealUiAfterLocalPatch(id);
    }

    async function guardarNotasDeal(id, notes) {
      try {
        const r = await fetch("/api/deals/" + id + "/notes", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ notes }) });
        const data = await r.json();
        if (!data.ok) throw new Error(data.error || "No se pudo actualizar las notas");
        applyDealPatchInLocalState(id, { notes: String(notes || "") });
        refreshDealUiAfterLocalPatch(id);
      } catch (err) { console.error(err); }
    }

    async function editarDealPrompt(dealId) {
      const deal = DEALS.find(function(item) { return item.id === dealId; }) || null;
      if (!deal) return;
      const title = prompt("Título del trato", deal.title || "");
      if (title === null) return;
      const valueRaw = prompt("Valor del trato", String(Number(deal.value || 0)));
      if (valueRaw === null) return;
      const notes = prompt("Notas del trato", deal.notes || "");
      if (notes === null) return;
      const typePrompt = prompt("Tipo de trato (LCL_PROPIO / LCL_CONVENCIONAL / FCL / AEREO_COURIER / AEREO_CARGA)", deal.dealType || "LCL_PROPIO");
      if (typePrompt === null) return;
      const qualityPrompt = prompt("Calidad de lead (DESCARTADO / NO_RESPONDE / REGULAR / BUENO / EXCELENTE)", deal.leadQuality || "NO_RESPONDE");
      if (qualityPrompt === null) return;
      try {
        const r = await fetch("/api/deals/" + dealId, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title,
            notes,
            dueDate: deal.dueDate || "",
            stage: deal.stage || "No responde",
            dealType: typePrompt,
            leadQuality: qualityPrompt,
            value: Number(valueRaw || 0)
          })
        });
        const data = await r.json();
        if (!data.ok) {
          alert(data.error || "No se pudo editar el trato");
          return;
        }
        await cargarDeals();
      } catch (err) {
        console.error(err);
        alert("Error conectando con el servidor");
      }
    }

    async function borrarDeal(dealId) {
      if (!confirm("¿Seguro que querés borrar este trato?")) return;
      try {
        const r = await fetch("/api/deals/" + dealId, { method: "DELETE" });
        const data = await r.json();
        if (!data.ok) {
          alert(data.error || "No se pudo borrar el trato");
          return;
        }
        await cargarDeals();
      } catch (err) {
        console.error(err);
        alert("Error conectando con el servidor");
      }
    }

    async function borrarArchivoDeal(dealId, fileId) {
      if (!confirm("¿Seguro que querés borrar este archivo?")) return;
      try {
        const r = await fetch("/api/deals/" + dealId + "/files/" + fileId, { method: "DELETE" });
        const data = await r.json();
        if (!data.ok) {
          alert(data.error || "No se pudo borrar el archivo");
          return;
        }
        const deal = DEALS.find(function(item) { return String(item && item.id || "") === String(dealId || ""); }) || null;
        const currentFiles = Array.isArray(deal && deal.files) ? deal.files : [];
        applyDealPatchInLocalState(dealId, {
          files: currentFiles.filter(function(item) { return String(item && item.id || "") !== String(fileId || ""); })
        });
        refreshDealUiAfterLocalPatch(dealId);
      } catch (err) {
        console.error(err);
        alert("Error conectando con el servidor");
      }
    }

    async function subirArchivoDeal(dealId, input, msgNode) {
      const lockKey = "deal_upload_" + String(dealId || "");
      return await withActionLock(lockKey, async function() {
        if (!input || !input.files || !input.files[0]) {
          if (msgNode) msgNode.innerText = "Elegí un archivo primero";
          return;
        }
        const file = input.files[0];
        const allowed = ["application/pdf", "image/jpeg", "image/png"];
        if (!allowed.includes(file.type)) {
          if (msgNode) msgNode.innerText = "Solo se permiten PDF, JPG y PNG";
          return;
        }

      const tempFileId = "temp_upload_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8);
      const deal = DEALS.find(function(item) { return String(item && item.id || "") === String(dealId || ""); }) || null;
      const currentFiles = Array.isArray(deal && deal.files) ? deal.files : [];
      const tempFile = {
        id: tempFileId,
        name: file.name || "archivo",
        mimeType: file.type || "application/octet-stream",
        size: Number(file.size || 0),
        __uploading: true
      };

      applyDealPatchInLocalState(dealId, {
        files: currentFiles.concat([tempFile])
      });
      refreshDealUiAfterLocalPatch(dealId);
      if (msgNode) msgNode.innerText = "Subiendo archivo...";

      try {
        const base64Data = await new Promise(function(resolve, reject) {
          const reader = new FileReader();
          reader.onload = function() {
            const result = String(reader.result || "");
            const commaIndex = result.indexOf(",");
            resolve(commaIndex >= 0 ? result.slice(commaIndex + 1) : result);
          };
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
        const r = await fetch("/api/deals/" + dealId + "/upload", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            fileName: file.name || "archivo",
            mimeType: file.type || "application/octet-stream",
            base64Data: base64Data
          })
        });
        const data = await r.json();
        if (!data.ok) {
          const latestDealOnError = DEALS.find(function(item) { return String(item && item.id || "") === String(dealId || ""); }) || null;
          const latestFilesOnError = Array.isArray(latestDealOnError && latestDealOnError.files) ? latestDealOnError.files : [];
          applyDealPatchInLocalState(dealId, {
            files: latestFilesOnError.filter(function(item) { return String(item && item.id || "") !== tempFileId; })
          });
          refreshDealUiAfterLocalPatch(dealId);
          if (msgNode) msgNode.innerText = data.error || "No se pudo subir el archivo";
          return;
        }

        const latestDeal = DEALS.find(function(item) { return String(item && item.id || "") === String(dealId || ""); }) || null;
        const latestFiles = Array.isArray(latestDeal && latestDeal.files) ? latestDeal.files : [];
        const nextFile = data.file || null;
        applyDealPatchInLocalState(dealId, {
          files: nextFile
            ? latestFiles.map(function(item) { return String(item && item.id || "") === tempFileId ? nextFile : item; })
            : latestFiles.filter(function(item) { return String(item && item.id || "") !== tempFileId; })
        });
        input.value = "";
        if (msgNode) msgNode.innerText = "Archivo subido";
        refreshDealUiAfterLocalPatch(dealId);
      } catch (err) {
        const latestDealCatch = DEALS.find(function(item) { return String(item && item.id || "") === String(dealId || ""); }) || null;
        const latestFilesCatch = Array.isArray(latestDealCatch && latestDealCatch.files) ? latestDealCatch.files : [];
        applyDealPatchInLocalState(dealId, {
          files: latestFilesCatch.filter(function(item) { return String(item && item.id || "") !== tempFileId; })
        });
        refreshDealUiAfterLocalPatch(dealId);
        if (msgNode) msgNode.innerText = "Error conectando con el servidor";
        console.error(err);
      }
      });
    }

    function updateOwnerFilterButtonLabel() {
      const btn = document.getElementById("ownerFilterButton");
      if (!btn) return;
      const values = getOwnerFilterValues();
      if (!values.length) {
        btn.innerText = "Todos los owners";
      } else if (values.length === 1) {
        btn.innerText = getOwnerLabelByEmail(values[0]);
      } else {
        btn.innerText = values.length + " owners seleccionados";
      }
    }

    function cargarOwnersEnFiltro() {
      const select = document.getElementById("filterOwner");
      const btn = document.getElementById("ownerFilterButton");
      if (!select) return;
      const selectedValues = getOwnerFilterValues();
      const selectedSet = {};
      selectedValues.forEach(function(email) { if (email) selectedSet[email] = true; });
      const multi = esAdminOrBackoffice();
      select.multiple = !!multi;
      select.size = multi ? Math.max(2, Math.min(8, USERS.length || 2)) : 1;
      select.innerHTML = '<option value="">Todos los owners</option>';
      USERS.forEach(function(user) {
        const email = String(user.email || "").trim().toLowerCase();
        if (!email) return;
        const option = document.createElement("option");
        option.value = email;
        option.text = (user.name || user.email || "") + (user.email ? " (" + user.email + ")" : "");
        option.selected = !!selectedSet[email];
        select.appendChild(option);
      });
      if (multi) {
        select.style.display = "none";
        if (btn) btn.style.display = "flex";
      } else {
        select.style.display = "block";
        if (btn) btn.style.display = "none";
        if (selectedValues.length) select.value = selectedValues[0] || "";
      }
      updateOwnerFilterButtonLabel();
    }

    function renderOwnerFilterModal() {
      const list = document.getElementById("ownerFilterModalList");
      if (!list) return;
      const selected = {};
      getOwnerFilterValues().forEach(function(email) { selected[email] = true; });
      if (!USERS.length) {
        list.innerHTML = '<div class="deal-meta" style="padding:12px">No hay usuarios para mostrar</div>';
        return;
      }
      list.innerHTML = USERS.map(function(user) {
        const email = String(user.email || "").trim().toLowerCase();
        if (!email) return "";
        const label = (user.name || user.email || email) + (user.email ? " (" + user.email + ")" : "");
        const safeEmail = email.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;");
        const safeLabel = label.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;");
        return '<label class="owner-filter-row"><input type="checkbox" class="owner-filter-check" value="' + safeEmail + '"' + (selected[email] ? ' checked' : '') + '><span class="owner-filter-row-label">' + safeLabel + '</span></label>';
      }).join("");
    }

    function openOwnerFilterModal() {
      if (!esAdminOrBackoffice()) return;
      renderOwnerFilterModal();
      const modal = document.getElementById("ownerFilterModalBg");
      if (modal) modal.style.display = "flex";
    }

    function closeOwnerFilterModal() {
      const modal = document.getElementById("ownerFilterModalBg");
      if (modal) modal.style.display = "none";
    }

    function selectAllOwnerFilterModal() {
      document.querySelectorAll(".owner-filter-check").forEach(function(check) { check.checked = true; });
    }

    function clearAllOwnerFilterModal() {
      document.querySelectorAll(".owner-filter-check").forEach(function(check) { check.checked = false; });
    }

    async function applyOwnerFilterModal() {
      const select = document.getElementById("filterOwner");
      if (!select) return;
      const checkedValues = Array.from(document.querySelectorAll(".owner-filter-check:checked"))
        .map(function(check) { return String(check.value || "").trim().toLowerCase(); })
        .filter(Boolean);
      const checkedSet = {};
      checkedValues.forEach(function(email) { checkedSet[email] = true; });
      Array.from(select.options || []).forEach(function(option) {
        const value = String(option.value || "").trim().toLowerCase();
        option.selected = !!(value && checkedSet[value]);
      });
      updateOwnerFilterButtonLabel();
      closeOwnerFilterModal();
      await aplicarFiltros();
    }

    function hoyLocalISO() {
      const now = new Date();
      const y = now.getFullYear();
      const m = String(now.getMonth() + 1).padStart(2, "0");
      const d = String(now.getDate()).padStart(2, "0");
      return y + "-" + m + "-" + d;
    }

    function sumarDiasISO(baseIso, days) {
      const dt = new Date(baseIso + "T00:00:00");
      dt.setDate(dt.getDate() + days);
      const y = dt.getFullYear();
      const m = String(dt.getMonth() + 1).padStart(2, "0");
      const d = String(dt.getDate()).padStart(2, "0");
      return y + "-" + m + "-" + d;
    }

    function actualizarFiltroRango() {
      const mode = document.getElementById("filterDueMode").value;
      document.getElementById("filterDueRangeBox").style.display = mode === "rango" ? "block" : "none";
    }

        // =====================================================
    // BLOQUE 5E - FILTROS PIPELINE
    // =====================================================

    function dealPasaFiltros() {
      return true;
    }

    function actualizarResumenFiltros() {
  const ownerValues = getOwnerFilterValues();
  const dealType = document.getElementById("filterDealType").value;
  const dealName = (document.getElementById("filterDealName").value || "").trim();
  const dueMode = document.getElementById("filterDueMode").value;
  const dueFrom = document.getElementById("filterDueFrom").value;
  const dueTo = document.getElementById("filterDueTo").value;
  const mobileStage = getMobileStageFilterValue();
  const parts = [];

  if (mobileStage) parts.push("etapa " + mobileStage);
  if (FILTER_DEAL_ID_FROM_URL) parts.push("trato seleccionado desde contacto");
  if (ownerValues.length === 1) parts.push("owner " + getOwnerLabelByEmail(ownerValues[0]));
  if (ownerValues.length > 1) parts.push(ownerValues.length + " owners seleccionados");
  if (dealType) parts.push("tipo " + getDealTypeLabelFront(dealType));
  if (dealName) parts.push("nombre del trato");
  if (dueMode === "sin_fecha") parts.push("sin fecha");
  if (dueMode === "vencidos") parts.push("vencidos");
  if (dueMode === "hoy") parts.push("vence hoy");
  if (dueMode === "proximos_7") parts.push("próximos 7 días");
  if (dueMode === "rango") parts.push("rango " + (dueFrom || "...") + " a " + (dueTo || "..."));

  var summaryText = "Mostrando " + FILTERED_DEALS.length + " tratos";
  if (CURRENT_VIEW === "lista") {
    summaryText = "Mostrando " + FILTERED_DEALS.length + " de " + getDealsTotalCount() + " tratos";
  } else if (kanbanHasUnknownTotals()) {
    summaryText = "Mostrando " + FILTERED_DEALS.length + "+ tratos";
  } else {
    summaryText = "Mostrando " + FILTERED_DEALS.length + " de " + getDealsTotalCount() + " tratos";
  }

  document.getElementById("filtersSummary").innerText =
    summaryText +
    (parts.length ? " | " + parts.join(" + ") : "");
}




async function aplicarFiltros(reRender = true) {
  actualizarFiltroRango();
  syncSelectedDeals();
  if (CURRENT_VIEW === "kanban") {
    await cargarDealsKanban(true);
    if (reRender) renderKanban();
    setTimeout(function() { cargarKanbanDiferido(); }, 0);
  } else {
    await cargarDealsLista(true);
    if (reRender) renderLista();
  }
  refreshSelectionInputs();
}


    function limpiarFiltros() {
  clearOwnerFilterSelection();
  document.getElementById("filterDealType").value = "";
  document.getElementById("filterDealName").value = "";
  document.getElementById("filterDueMode").value = "";
  document.getElementById("filterDueFrom").value = "";
  document.getElementById("filterDueTo").value = "";
  const mobileStageSelect = document.getElementById("mobileStageFilter");
  if (mobileStageSelect && isMobilePipelineView()) mobileStageSelect.value = "Horno";
  FILTER_DEAL_ID_FROM_URL = "";
  syncPipelineUrl();
  aplicarFiltros();
}



    (function setDefaultMobilePipelineStage() {
      const mobileStageSelect = document.getElementById("mobileStageFilter");
      if (mobileStageSelect && isMobilePipelineView()) mobileStageSelect.value = "Horno";
    })();

    document.addEventListener("change", function(e) {
      if (["filterOwner", "filterDealType", "filterDueMode", "filterDueFrom", "filterDueTo", "mobileStageFilter"].includes(e.target.id)) {
        if (e.target.id === "filterDueMode") actualizarFiltroRango();
        aplicarFiltros();
      }
    });

    document.getElementById("filterDealName").addEventListener("input", function() {
      aplicarFiltros();
    });

    document.getElementById("contactSearchDeal").addEventListener("input", function() {
      renderContactResultsDeal();
    });

    function limpiarDeal() {
  document.getElementById("title").value = "";
  document.getElementById("contactSearchDeal").value = "";
  document.getElementById("contactSelectedDeal").innerText = "Sin contacto seleccionado";
  document.getElementById("value").value = "";
  document.getElementById("dueDate").value = "";
  document.getElementById("stage").value = "No responde";
  document.getElementById("dealType").value = "LCL_PROPIO";
  document.getElementById("leadQuality").value = "NO_RESPONDE";
  document.getElementById("newDealNotes").value = "";
  document.getElementById("msg").innerText = "";
  SELECTED_CONTACT_ID = "";
  SELECTED_CONTACT_NAME = "";
  SELECTED_CONTACT_OWNER = "";
  renderContactResultsDeal();
}

document.getElementById("dealDetailModalBg").addEventListener("click", function(e) {
  if (e.target && e.target.id === "dealDetailModalBg") cerrarDetalleTrato();
});

if (esAdmin()) {
  const bulkBtn = document.getElementById("bulkUpdaterTopBtn");
  if (bulkBtn) bulkBtn.style.display = "inline-block";
}
document.getElementById("bulkUpdaterModalBg").addEventListener("click", function(e) {
  if (e.target && e.target.id === "bulkUpdaterModalBg") cerrarActualizadorMasivo();
});
aplicarFiltroDesdeURL();
cambiarVista(CURRENT_VIEW);



  </script>
</body>
</html>
  `);
});





// =====================================================
// BLOQUE 6 - API / REPORTES
// =====================================================

// =====================================================
// BLOQUE 6A - PÁGINA REPORTES KPI
// =====================================================

// =====================================================
// PLAN DE PRODUCCIÓN COMERCIAL - MÓDULO INDEPENDIENTE
// =====================================================
app.get("/plan-produccion", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB / Plan de Producción Comercial</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;color:#111827}
    .topbar{background:#1a73e8;color:#fff;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
    .container{padding:24px;max-width:1500px;margin:0 auto}
    .box{background:#fff;padding:20px;border-radius:14px;box-shadow:0 4px 20px rgba(0,0,0,.08);margin-bottom:18px}
    .actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
    button{padding:10px 14px;border:0;border-radius:8px;background:#1a73e8;color:#fff;font-weight:700;cursor:pointer}
    .secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}
    .hero{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;flex-wrap:wrap}
    .hero h1{margin:0 0 7px;font-size:28px}.muted{color:#667085;font-size:13px}
    @media(max-width:780px){.container{padding:12px}.hero h1{font-size:23px}.topbar{padding:12px 14px}}
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>CRMSCB</strong> / Plan de Producción Comercial</div>
    <div class="actions">
      <button class="secondary" onclick="window.location='/mi-estado'">Mi Estado Comercial</button>
      <button class="secondary" onclick="window.location='/reportes'">Reportes KPI</button>
      <button class="secondary" onclick="window.location='/crm'">Volver al panel</button>
    </div>
  </div>
  <div class="container">
    <div class="box hero">
      <div>
        <h1>Plan de Producción Comercial</h1>
        <div class="muted">Objetivos mensuales por m³, escalas, equipos, ventas y comisiones.</div>
      </div>
    </div>
  </div>
  <script>
    const userRaw = localStorage.getItem("crmscb_user");
    if (!userRaw) window.location.href = "/?redirect=" + encodeURIComponent(window.location.pathname + window.location.search);
    const __originalFetch = window.fetch.bind(window);
    window.fetch = function(url, options) {
      const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
      options = options || {};
      options.headers = Object.assign({}, options.headers || {}, {
        "x-user-id": user.id || "",
        "x-auth-token": user.token || ""
      });
      return __originalFetch(url, options);
    };
  </script>
</body>
</html>
  `);
});

app.get("/reportes", (req, res) => {
  const dealTypeLegend = DEAL_TYPES.map((type) => {
    return `<span style="display:inline-flex;align-items:center;padding:6px 10px;border-radius:999px;background:#eef3fb;color:#174ea6;font-size:12px;font-weight:bold;">${esc(getDealTypeLabel(type))}</span>`;
  }).join(" ");

  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CRMSCB Reportes KPI</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;padding:0}
    .topbar{background:#1a73e8;color:white;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
    .container{padding:24px;max-width:1400px;margin:0 auto}
    .box{background:#fff;padding:20px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08);margin-bottom:20px}
    .toolbar{display:flex;gap:12px;align-items:end;flex-wrap:wrap}
    .toolbar .field{display:flex;flex-direction:column;gap:6px;min-width:180px}
    input,select,button{padding:12px;border-radius:8px;box-sizing:border-box;font-family:Arial,sans-serif}
    input,select{border:1px solid #ccc;background:#fff}
    button{border:none;background:#1a73e8;color:#fff;cursor:pointer}
    .secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}
    .muted{color:#666;font-size:13px}
    .legend{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
    .charts-grid{display:grid;grid-template-columns:1fr;gap:20px}
    .chart-box{border:1px solid #e5e7eb;border-radius:12px;padding:16px;background:#fff}
    .chart-title{font-weight:bold;margin-bottom:10px}
    .chart-wrap{overflow-x:auto}
    .bars-grid{display:grid;gap:14px;min-width:900px}
    .seller-card{border:1px solid #e5e7eb;border-radius:12px;padding:12px;background:#fafcff}
    .seller-name{font-weight:bold;margin-bottom:10px}
    .bar-row{display:grid;grid-template-columns:180px 1fr 160px;gap:12px;align-items:center;margin-bottom:10px}
    .bar-track{position:relative;height:18px;border-radius:999px;background:#e8edf7;overflow:hidden}
    .bar-target{position:absolute;left:0;top:0;bottom:0;background:#c7d7fe}
    .bar-real{position:absolute;left:0;top:3px;bottom:3px;background:#1a73e8;border-radius:999px}
    .bar-label{font-size:13px}
    .bar-values{font-size:12px;color:#333;text-align:right}
    table{width:100%;border-collapse:collapse;background:#fff}
    th,td{padding:12px;border-bottom:1px solid #eee;text-align:left;font-size:14px;vertical-align:top}
    th{background:#f0f4fb}
    .target-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:10px}
    .target-grid .field{display:flex;flex-direction:column;gap:6px}
    .row-actions{display:flex;gap:10px;flex-wrap:wrap}
    .msg{margin-top:12px;color:#d93025}
    .success{color:#188038}
    .summary-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
    .summary-card{background:#f8fbff;border:1px solid #d9e6fb;border-radius:12px;padding:16px}
    .summary-card h4{margin:0 0 6px 0;font-size:13px;color:#4b5563}
    .summary-card div{font-size:24px;font-weight:bold;color:#111827}
    @media (max-width: 1100px){
      .summary-cards{grid-template-columns:repeat(2,1fr)}
      .target-grid{grid-template-columns:repeat(2,1fr)}
    }
    @media (max-width: 700px){
      .summary-cards{grid-template-columns:1fr}
      .target-grid{grid-template-columns:1fr}
      .bar-row{grid-template-columns:1fr;gap:8px}
      .bars-grid{min-width:0}
    }
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>CRMSCB</strong> / Reportes KPI</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <button class="secondary" onclick="window.location='/pipeline'">Volver a Pipeline</button>
      <button class="secondary" onclick="window.location='/crm'">Volver al panel</button>
    </div>
  </div>

  <div class="container">
    <div class="box">
      <h2 style="margin-top:0">Filtros KPI</h2>
      <div class="toolbar">
        <div class="field">
          <label>Período</label>
          <select id="periodType">
            <option value="weekly">Semanal</option>
            <option value="monthly">Mensual</option>
          </select>
        </div>
        <div class="field">
          <label>Fecha de referencia</label>
          <input id="referenceDate" type="date">
        </div>
        <div class="field">
          <label>Vendedor</label>
          <select id="sellerFilter">
            <option value="">Todos</option>
          </select>
        </div>
        <div class="field">
          <button onclick="cargarResumen()">Actualizar reporte</button>
        </div>
      </div>
      <div class="legend">${dealTypeLegend}</div>
      <div class="muted" id="periodSummary" style="margin-top:12px;">Cargando período...</div>
    </div>

    <div class="box">
      <h2 style="margin-top:0">Resumen general</h2>
      <div class="summary-cards">
        <div class="summary-card">
          <h4>Total objetivo</h4>
          <div id="summaryTarget">0</div>
        </div>
        <div class="summary-card">
          <h4>Total real</h4>
          <div id="summaryReal">0</div>
        </div>
        <div class="summary-card">
          <h4>Cumplimiento</h4>
          <div id="summaryPct">0%</div>
        </div>
        <div class="summary-card">
          <h4>Vendedores con datos</h4>
          <div id="summarySellers">0</div>
        </div>
      </div>
    </div>

    <div class="box" id="adminTargetsBox" style="display:none;">
      <h2 style="margin-top:0">Objetivos KPI</h2>
      <div class="toolbar">
        <div class="field">
          <label>Vendedor</label>
          <select id="targetUserId"></select>
        </div>
        <div class="field">
          <label>Período</label>
          <select id="targetPeriodType">
            <option value="weekly">Semanal</option>
            <option value="monthly">Mensual</option>
          </select>
        </div>
        <div class="field">
          <label>Fecha de referencia</label>
          <input id="targetReferenceDate" type="date">
        </div>
      </div>

      <div class="target-grid" style="margin-top:16px;">
        <div class="field">
          <label>LCL Propio</label>
          <input id="target_LCL_PROPIO" type="number" min="0" step="1" value="0">
        </div>
        <div class="field">
          <label>LCL Convencional</label>
          <input id="target_LCL_CONVENCIONAL" type="number" min="0" step="1" value="0">
        </div>
        <div class="field">
          <label>FCL</label>
          <input id="target_FCL" type="number" min="0" step="1" value="0">
        </div>
        <div class="field">
          <label>Aéreo Courier</label>
          <input id="target_AEREO_COURIER" type="number" min="0" step="1" value="0">
        </div>
        <div class="field">
          <label>Aéreo Carga</label>
          <input id="target_AEREO_CARGA" type="number" min="0" step="1" value="0">
        </div>
      </div>

      <div class="row-actions" style="margin-top:16px;">
        <button onclick="guardarObjetivo()">Guardar objetivo</button>
        <button class="secondary" onclick="cargarObjetivoEnFormulario()">Cargar objetivo existente</button>
        <button class="secondary" onclick="limpiarFormularioObjetivo()">Limpiar formulario</button>
        <button id="deleteTargetBtn" style="background:#d93025;display:none;" onclick="borrarObjetivo()">Borrar objetivo</button>
      </div>
      <div id="targetMsg" class="msg"></div>
    </div>

    <div class="box">
      <h2 style="margin-top:0">Barras por vendedor</h2>
      <div class="charts-grid">
        <div class="chart-box">
          <div class="chart-title">Objetivo vs real por tipo de trato</div>
          <div class="chart-wrap">
            <div class="bars-grid" id="barsGrid">
              <div class="muted">Cargando gráfico...</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="box">
      <h2 style="margin-top:0">Calidad de leads por vendedor</h2>
      <div class="muted" style="margin-bottom:12px;">Cuenta los tratos creados en el período elegido, agrupados por vendedor y calidad de lead.</div>
      <table>
        <thead>
          <tr>
            <th>Vendedor</th>
            <th>Descartado</th>
            <th>No Responde</th>
            <th>Regular</th>
            <th>Bueno</th>
            <th>Excelente</th>
            <th>Total</th>
            <th>% Bueno + Excelente</th>
          </tr>
        </thead>
        <tbody id="leadQualityTableBody">
          <tr><td colspan="8">Cargando...</td></tr>
        </tbody>
      </table>
    </div>

    <div class="box">
      <h2 style="margin-top:0">Detalle numérico</h2>
      <table>
        <thead>
          <tr>
            <th>Vendedor</th>
            <th>Período</th>
            <th>LCL Propio</th>
            <th>LCL Convencional</th>
            <th>FCL</th>
            <th>Aéreo Courier</th>
            <th>Aéreo Carga</th>
            <th>Total objetivo</th>
            <th>Total real</th>
            <th>%</th>
          </tr>
        </thead>
        <tbody id="tableBody">
          <tr><td colspan="10">Cargando...</td></tr>
        </tbody>
      </table>
    </div>
  </div>

  <script>
    const userRaw = localStorage.getItem("crmscb_user");
    if (!userRaw) window.location.href = "/?redirect=" + encodeURIComponent(window.location.pathname + window.location.search);
    const CURRENT_USER = JSON.parse(userRaw || "{}");
    const __originalFetch = window.fetch.bind(window);
    window.fetch = function(url, options) {
      const user = JSON.parse(localStorage.getItem("crmscb_user") || "{}");
      options = options || {};
      options.headers = Object.assign({}, options.headers || {}, {
        "x-user-id": user.id || "",
        "x-auth-token": user.token || ""
      });
      return __originalFetch(url, options);
    };

    const DEAL_TYPES = ${JSON.stringify(DEAL_TYPES)};
    const DEAL_TYPE_LABELS = ${JSON.stringify(DEAL_TYPE_LABELS)};
    const LEAD_QUALITY_VALUES = ${JSON.stringify(LEAD_QUALITY_VALUES)};
    const LEAD_QUALITY_LABELS = ${JSON.stringify(LEAD_QUALITY_LABELS)};
    let USERS = [];
    let PENDING_DUE_SEND = null;
    let LAST_TARGET_ID = "";

    function esAdmin() { return (CURRENT_USER.role || "") === "admin"; }
    function esBackoffice() { return (CURRENT_USER.role || "") === "backoffice"; }
    function esSeller() {
  const role = String(CURRENT_USER.role || "").trim().toLowerCase();
  return role === "team_leader" || role === "field_sales";
}


    function getTodayIsoLocal() {
      const d = new Date();
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, "0");
      const day = String(d.getDate()).padStart(2, "0");
      return y + "-" + m + "-" + day;
    }

    function getDealTypeLabelFront(type) {
      return DEAL_TYPE_LABELS[type] || type || "";
    }

    function sumTargetsFront(targets) {
      return DEAL_TYPES.reduce(function(acc, type) {
        return acc + Number((targets && targets[type]) || 0);
      }, 0);
    }

    function pct(real, target) {
      const r = Number(real || 0);
      const t = Number(target || 0);
      if (!t) return r > 0 ? 100 : 0;
      return Math.round((r / t) * 100);
    }

    async function fetchUsersCached(forceFresh) {
      const cacheKey = "crmscb_users_cache_v1";
      const now = Date.now();
      if (!forceFresh) {
        try {
          const cached = JSON.parse(sessionStorage.getItem(cacheKey) || "null");
          if (cached && Array.isArray(cached.data) && Number(cached.expiresAt || 0) > now) {
            return cached.data;
          }
        } catch (e) {}
      }
      const r = await fetch("/api/users?ts=" + Date.now());
      const data = await r.json();
      const list = Array.isArray(data) ? data : [];
      try {
        sessionStorage.setItem(cacheKey, JSON.stringify({ expiresAt: now + 30000, data: list }));
      } catch (e) {}
      return list;
    }

    async function cargarUsuarios(forceFresh) {
      try {
        USERS = await fetchUsersCached(!!forceFresh);
      } catch (err) {
        USERS = [];
        console.error(err);
      }
      renderUsersFilters();
    }

    function renderUsersFilters() {
      const sellerFilter = document.getElementById("sellerFilter");
      const targetUserId = document.getElementById("targetUserId");
      sellerFilter.innerHTML = '<option value="">Todos</option>';
      targetUserId.innerHTML = '<option value="">Seleccionar vendedor</option>';

      USERS.forEach(function(user) {
        const label = (user.name || user.email || "") + (user.email ? " (" + user.email + ")" : "");
        const op1 = document.createElement("option");
        op1.value = user.id || "";
        op1.text = label;
        sellerFilter.appendChild(op1);

        const op2 = document.createElement("option");
        op2.value = user.id || "";
        op2.text = label;
        targetUserId.appendChild(op2);
      });

      if (esSeller()) {
        sellerFilter.value = CURRENT_USER.id || "";
        sellerFilter.disabled = true;
      }

      if (esAdmin()) {
        document.getElementById("adminTargetsBox").style.display = "block";
      }
    }

    function renderSummaryCards(rows) {
      const totalTarget = rows.reduce(function(acc, row) { return acc + Number(row.totalTarget || 0); }, 0);
      const totalReal = rows.reduce(function(acc, row) { return acc + Number(row.totalReal || 0); }, 0);
      document.getElementById("summaryTarget").innerText = String(totalTarget);
      document.getElementById("summaryReal").innerText = String(totalReal);
      document.getElementById("summaryPct").innerText = pct(totalReal, totalTarget) + "%";
      document.getElementById("summarySellers").innerText = String(rows.length);
    }

    function renderBars(rows) {
      const grid = document.getElementById("barsGrid");
      if (!rows.length) {
        grid.innerHTML = '<div class="muted">No hay datos para este período.</div>';
        return;
      }

      let maxValue = 1;
      rows.forEach(function(row) {
        DEAL_TYPES.forEach(function(type) {
          maxValue = Math.max(maxValue, Number((row.targets && row.targets[type]) || 0), Number((row.reals && row.reals[type]) || 0));
        });
      });

      grid.innerHTML = "";
      rows.forEach(function(row) {
        const sellerCard = document.createElement("div");
        sellerCard.className = "seller-card";

        const sellerName = document.createElement("div");
        sellerName.className = "seller-name";
        sellerName.innerText = row.userName + " — " + row.periodKey;
        sellerCard.appendChild(sellerName);

        DEAL_TYPES.forEach(function(type) {
          const target = Number((row.targets && row.targets[type]) || 0);
          const real = Number((row.reals && row.reals[type]) || 0);
          const targetWidth = Math.max(0, Math.min(100, (target / maxValue) * 100));
          const realWidth = Math.max(0, Math.min(100, (real / maxValue) * 100));

          const barRow = document.createElement("div");
          barRow.className = "bar-row";

          const label = document.createElement("div");
          label.className = "bar-label";
          label.innerText = getDealTypeLabelFront(type);

          const track = document.createElement("div");
          track.className = "bar-track";

          const targetBar = document.createElement("div");
          targetBar.className = "bar-target";
          targetBar.style.width = targetWidth + "%";

          const realBar = document.createElement("div");
          realBar.className = "bar-real";
          realBar.style.width = realWidth + "%";

          track.appendChild(targetBar);
          track.appendChild(realBar);

          const values = document.createElement("div");
          values.className = "bar-values";
          values.innerText = "Real " + real + " / Obj " + target;

          barRow.appendChild(label);
          barRow.appendChild(track);
          barRow.appendChild(values);
          sellerCard.appendChild(barRow);
        });

        grid.appendChild(sellerCard);
      });
    }

    function renderLeadQualityTable(rows) {
      const body = document.getElementById("leadQualityTableBody");
      if (!body) return;
      if (!rows.length) {
        body.innerHTML = '<tr><td colspan="8">No hay datos para este período</td></tr>';
        return;
      }
      body.innerHTML = rows.map(function(row) {
        const q = row.leadQualityCounts || {};
        const total = Number(row.totalLeadQuality || 0);
        const good = Number(q.BUENO || 0) + Number(q.EXCELENTE || 0);
        const pctGood = total ? Math.round((good / total) * 100) : 0;
        return '<tr>' +
          '<td>' + (row.userName || '') + '</td>' +
          '<td>' + Number(q.DESCARTADO || 0) + '</td>' +
          '<td>' + Number(q.NO_RESPONDE || 0) + '</td>' +
          '<td>' + Number(q.REGULAR || 0) + '</td>' +
          '<td>' + Number(q.BUENO || 0) + '</td>' +
          '<td>' + Number(q.EXCELENTE || 0) + '</td>' +
          '<td>' + total + '</td>' +
          '<td>' + pctGood + '%</td>' +
        '</tr>';
      }).join("");
    }

    function renderTable(rows) {
      const body = document.getElementById("tableBody");
      if (!rows.length) {
        body.innerHTML = '<tr><td colspan="10">No hay datos para este período</td></tr>';
        return;
      }

      body.innerHTML = rows.map(function(row) {
        return '<tr>' +
          '<td>' + (row.userName || '') + '</td>' +
          '<td>' + (row.periodKey || '') + '</td>' +
          '<td>' + Number((row.reals && row.reals.LCL_PROPIO) || 0) + ' / ' + Number((row.targets && row.targets.LCL_PROPIO) || 0) + '</td>' +
          '<td>' + Number((row.reals && row.reals.LCL_CONVENCIONAL) || 0) + ' / ' + Number((row.targets && row.targets.LCL_CONVENCIONAL) || 0) + '</td>' +
          '<td>' + Number((row.reals && row.reals.FCL) || 0) + ' / ' + Number((row.targets && row.targets.FCL) || 0) + '</td>' +
          '<td>' + Number((row.reals && row.reals.AEREO_COURIER) || 0) + ' / ' + Number((row.targets && row.targets.AEREO_COURIER) || 0) + '</td>' +
          '<td>' + Number((row.reals && row.reals.AEREO_CARGA) || 0) + ' / ' + Number((row.targets && row.targets.AEREO_CARGA) || 0) + '</td>' +
          '<td>' + Number(row.totalTarget || 0) + '</td>' +
          '<td>' + Number(row.totalReal || 0) + '</td>' +
          '<td>' + pct(row.totalReal || 0, row.totalTarget || 0) + '%</td>' +
        '</tr>';
      }).join("");
    }

    async function cargarResumen() {
      const periodType = document.getElementById("periodType").value;
      const referenceDate = document.getElementById("referenceDate").value || getTodayIsoLocal();
      const sellerId = document.getElementById("sellerFilter").value || "";
      try {
        const params = new URLSearchParams({
          periodType: periodType,
          referenceDate: referenceDate
        });
        if (sellerId) params.set("userId", sellerId);

        const r = await fetch("/api/kpi/summary?" + params.toString());
        const data = await r.json();
        if (!data.ok) {
          alert(data.error || "No se pudo cargar el reporte");
          return;
        }

        document.getElementById("periodSummary").innerText =
          "Período: " + (data.period && data.period.periodKey ? data.period.periodKey : "") +
          " | Desde " + (data.period && data.period.startDate ? data.period.startDate : "") +
          " hasta " + (data.period && data.period.endDate ? data.period.endDate : "");

        const rows = Array.isArray(data.rows) ? data.rows : [];
        renderSummaryCards(rows);
        renderBars(rows);
        renderLeadQualityTable(rows);
        renderTable(rows);
      } catch (err) {
        console.error(err);
        alert("Error cargando el reporte");
      }
    }

    function getTargetFormPayload() {
      const targets = {};
      DEAL_TYPES.forEach(function(type) {
        targets[type] = Number(document.getElementById("target_" + type).value || 0);
      });
      return {
        userId: document.getElementById("targetUserId").value || "",
        periodType: document.getElementById("targetPeriodType").value || "weekly",
        referenceDate: document.getElementById("targetReferenceDate").value || getTodayIsoLocal(),
        targets: targets
      };
    }

    function fillTargetForm(targetDoc) {
      LAST_TARGET_ID = targetDoc && targetDoc.id ? targetDoc.id : "";
      DEAL_TYPES.forEach(function(type) {
        document.getElementById("target_" + type).value = Number((targetDoc && targetDoc.targets && targetDoc.targets[type]) || 0);
      });
      document.getElementById("deleteTargetBtn").style.display = LAST_TARGET_ID ? "inline-block" : "none";
    }

    function limpiarFormularioObjetivo() {
      LAST_TARGET_ID = "";
      DEAL_TYPES.forEach(function(type) {
        document.getElementById("target_" + type).value = 0;
      });
      document.getElementById("targetMsg").innerText = "";
      document.getElementById("deleteTargetBtn").style.display = "none";
    }

    async function cargarObjetivoEnFormulario() {
      const msg = document.getElementById("targetMsg");
      msg.className = "msg";
      msg.innerText = "";
      const payload = getTargetFormPayload();
      if (!payload.userId) {
        msg.innerText = "Seleccioná un vendedor";
        return;
      }
      try {
        const params = new URLSearchParams({
          userId: payload.userId,
          periodType: payload.periodType,
          referenceDate: payload.referenceDate
        });
        const r = await fetch("/api/kpi/targets?" + params.toString());
        const data = await r.json();
        if (!data.ok) {
          msg.innerText = data.error || "No se pudo cargar el objetivo";
          return;
        }
        if (!data.target) {
          limpiarFormularioObjetivo();
          msg.className = "msg success";
          msg.innerText = "No existe objetivo guardado para ese período. Podés crear uno nuevo.";
          return;
        }
        fillTargetForm(data.target);
        msg.className = "msg success";
        msg.innerText = "Objetivo cargado correctamente.";
      } catch (err) {
        console.error(err);
        msg.innerText = "Error cargando objetivo";
      }
    }

    async function guardarObjetivo() {
      const msg = document.getElementById("targetMsg");
      msg.className = "msg";
      msg.innerText = "";
      const payload = getTargetFormPayload();
      if (!payload.userId) {
        msg.innerText = "Seleccioná un vendedor";
        return;
      }
      try {
        const r = await fetch("/api/kpi/targets", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const data = await r.json();
        if (!data.ok) {
          msg.innerText = data.error || "No se pudo guardar el objetivo";
          return;
        }
        fillTargetForm(data.target || null);
        msg.className = "msg success";
        msg.innerText = "Objetivo guardado correctamente.";
        await cargarResumen();
      } catch (err) {
        console.error(err);
        msg.innerText = "Error guardando objetivo";
      }
    }

    async function borrarObjetivo() {
      const msg = document.getElementById("targetMsg");
      msg.className = "msg";
      msg.innerText = "";
      if (!LAST_TARGET_ID) {
        msg.innerText = "No hay objetivo cargado para borrar";
        return;
      }
      if (!confirm("¿Seguro que querés borrar este objetivo?")) return;
      try {
        const r = await fetch("/api/kpi/targets/" + LAST_TARGET_ID, { method: "DELETE" });
        const data = await r.json();
        if (!data.ok) {
          msg.innerText = data.error || "No se pudo borrar el objetivo";
          return;
        }
        limpiarFormularioObjetivo();
        msg.className = "msg success";
        msg.innerText = "Objetivo borrado correctamente.";
        await cargarResumen();
      } catch (err) {
        console.error(err);
        msg.innerText = "Error borrando objetivo";
      }
    }

    (async function init() {
      const today = getTodayIsoLocal();
      document.getElementById("referenceDate").value = today;
      document.getElementById("targetReferenceDate").value = today;
      await cargarUsuarios();
      await cargarResumen();
    })();
  </script>
</body>
</html>
  `);
});

// =====================================================
// =====================================================
// BLOQUE 6B - API HEALTH / USERS / LOGIN
// =====================================================

app.get("/api/health", async (req, res) => {
  return res.status(200).json({ ok: true, app: "CRMSCB", message: "CRM SCB corriendo correctamente" });
});

app.get("/api/users", authRequired, async (req, res) => {
  try {
    const users = await getUsersList();
    let visibleUsers = [];

    if (isAdmin(req.authUser) || isBackoffice(req.authUser)) {
      visibleUsers = users;
    } else if (isTeamLeader(req.authUser)) {
      const fieldSales = await getFieldSalesByLeader(req.authUser.id);
      const fieldSalesIds = new Set(fieldSales.map((u) => u.id));
      visibleUsers = users.filter((user) => user.id === req.authUser.id || fieldSalesIds.has(user.id));
    } else {
      visibleUsers = users.filter((user) => user.id === req.authUser.id);
    }

    return res.status(200).json(
      visibleUsers.map((user) => ({
        id: user.id,
        name: user.name || "",
        email: user.email || "",
        role: normalizeRole(user.role || ""),
        teamLeaderId: user.teamLeaderId || ""
      }))
    );
  } catch (error) {
    console.error("ERROR /api/users:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error obteniendo usuarios" });
  }
});



app.post("/api/users", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) {
      return res.status(403).json({ ok: false, error: "Solo admin puede crear usuarios" });
    }

    const { name, email, password, role, teamLeaderId } = req.body || {};
    const cleanEmail = String(email || "").trim().toLowerCase();
    const cleanName = String(name || "").trim();
    const cleanPassword = String(password || "").trim();
    const cleanRole = normalizeRole(role || "");
    const cleanTeamLeaderId = String(teamLeaderId || "").trim();

    if (!cleanName || !cleanEmail || !cleanPassword) {
      return res.status(400).json({ ok: false, error: "Faltan nombre, email o password" });
    }

    if (cleanRole === "field_sales" && !cleanTeamLeaderId) {
      return res.status(400).json({ ok: false, error: "Field sales requiere teamLeaderId" });
    }

    if (cleanRole !== "field_sales" && cleanTeamLeaderId) {
      return res.status(400).json({ ok: false, error: "Solo field_sales puede tener teamLeaderId" });
    }

    if (cleanRole === "field_sales") {
      const leaderSnap = await db.collection("users").doc(cleanTeamLeaderId).get();
      if (!leaderSnap.exists) {
        return res.status(400).json({ ok: false, error: "El team leader no existe" });
      }
      const leaderData = leaderSnap.data() || {};
      if (normalizeRole(leaderData.role || "") !== "team_leader") {
        return res.status(400).json({ ok: false, error: "teamLeaderId debe pertenecer a un usuario team_leader" });
      }
    }

    const exists = await db.collection("users").where("email", "==", cleanEmail).limit(1).get();
    if (!exists.empty) {
      return res.status(400).json({ ok: false, error: "Ya existe un usuario con ese email" });
    }

    const ref = await db.collection("users").add({
      name: cleanName,
      email: cleanEmail,
      password: cleanPassword,
      role: cleanRole,
      teamLeaderId: cleanRole === "field_sales" ? cleanTeamLeaderId : "",
      createdAt: new Date(),
      updatedAt: new Date(),
      sessionToken: ""
    });

    USERS_LIST_CACHE = { expiresAt: 0, data: null };
    return res.json({ ok: true, id: ref.id });
  } catch (error) {
    console.error("ERROR /api/users POST:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error creando usuario" });
  }
});

app.put("/api/users/:id", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) {
      return res.status(403).json({ ok: false, error: "Solo admin puede editar usuarios" });
    }

    const id = req.params.id;
    const { name, email, password, role, teamLeaderId } = req.body || {};
    const payload = { updatedAt: new Date() };

    let nextRole = null;

    if (typeof role === "string") {
      nextRole = normalizeRole(role);
      payload.role = nextRole;
    }

    if (typeof name === "string") payload.name = name.trim();
    if (typeof email === "string") payload.email = email.trim().toLowerCase();
    if (typeof password === "string" && password.trim()) payload.password = password.trim();

    const currentSnap = await db.collection("users").doc(id).get();
    if (!currentSnap.exists) {
      return res.status(404).json({ ok: false, error: "Usuario no encontrado" });
    }
    const currentData = currentSnap.data() || {};
    const finalRole = nextRole || normalizeRole(currentData.role || "");

    const cleanTeamLeaderId = typeof teamLeaderId === "string"
      ? teamLeaderId.trim()
      : String(currentData.teamLeaderId || "").trim();

    if (finalRole === "field_sales") {
      if (!cleanTeamLeaderId) {
        return res.status(400).json({ ok: false, error: "Field sales requiere teamLeaderId" });
      }

      const leaderSnap = await db.collection("users").doc(cleanTeamLeaderId).get();
      if (!leaderSnap.exists) {
        return res.status(400).json({ ok: false, error: "El team leader no existe" });
      }

      const leaderData = leaderSnap.data() || {};
      if (normalizeRole(leaderData.role || "") !== "team_leader") {
        return res.status(400).json({ ok: false, error: "teamLeaderId debe pertenecer a un usuario team_leader" });
      }

      payload.teamLeaderId = cleanTeamLeaderId;
    } else {
      payload.teamLeaderId = "";
    }

    await db.collection("users").doc(id).update(payload);
    USERS_LIST_CACHE = { expiresAt: 0, data: null };
    return res.json({ ok: true });
  } catch (error) {
    console.error("ERROR /api/users/:id PUT:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error actualizando usuario" });
  }
});

app.delete("/api/users/:id", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) {
      return res.status(403).json({ ok: false, error: "Solo admin puede borrar usuarios" });
    }
    if (req.params.id === req.authUser.id) {
      return res.status(400).json({ ok: false, error: "No podés borrar tu propio usuario" });
    }

    await db.collection("users").doc(req.params.id).delete();
    USERS_LIST_CACHE = { expiresAt: 0, data: null };
    return res.json({ ok: true });
  } catch (error) {
    console.error("ERROR /api/users/:id DELETE:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error borrando usuario" });
  }
});

app.post("/api/desk/sso", authRequired, async (req, res) => {
  try {
    if (!DESK_SSO_SECRET) {
      return res.status(503).json({ ok: false, error: "DESK_SSO_SECRET no está configurado en CRM" });
    }
    const token = createDeskSsoToken(req.authUser);
    return res.json({
      ok: true,
      url: `${DESK_BASE_URL}/auth/crm?token=${encodeURIComponent(token)}`
    });
  } catch (error) {
    console.error("ERROR desk sso:", error);
    return res.status(500).json({ ok: false, error: error.message || "No se pudo generar el acceso a Desk" });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ ok: false, error: "Faltan email o password" });
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const normalizedPassword = String(password).trim();

    const snapshot = await db.collection("users").where("email", "==", normalizedEmail).limit(1).get();
    if (snapshot.empty) {
      return res.status(401).json({ ok: false, error: "Usuario o contraseña incorrectos" });
    }

    const doc = snapshot.docs[0];
    const user = doc.data() || {};

    if ((user.password || "") !== normalizedPassword) {
      return res.status(401).json({ ok: false, error: "Usuario o contraseña incorrectos" });
    }

    const sessionToken = generateSessionToken();
    await db.collection("users").doc(doc.id).
update({
  sessionToken,
  sessionAt: new Date(),
  sessions: admin.firestore.FieldValue.arrayUnion({
    token: sessionToken,
    createdAt: new Date()
  })
});


    return res.status(200).json({
      ok: true,
      message: "Login correcto",
      user: {
        id: doc.id,
        name: user.name || "",
        email: user.email || "",
        role: normalizeRole(user.role || ""),
        teamLeaderId: user.teamLeaderId || "",
        token: sessionToken
      }
    });
  } catch (error) {
    console.error("ERROR /api/login:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error en login" });
  }
});

// =====================================================
// BLOQUE 6B - API IMPORTADOR MAESTRO
// =====================================================

app.post("/api/import/master/preview", authRequired, async (req, res) => {
  try {
    if (!canUseMasterImporter(req.authUser)) {
      return res.status(403).json({ ok: false, error: "Solo admin y backoffice pueden importar CSV" });
    }

    const csvText = String((req.body && req.body.csvText) || "");
    if (!csvText.trim()) {
      return res.status(400).json({ ok: false, error: "Falta csvText" });
    }

    const analysis = await buildMasterImportAnalysis(csvText);
    if (!analysis.ok) {
      return res.status(400).json({ ok: false, error: analysis.error || "No se pudo analizar el archivo" });
    }

    return res.json({
      ok: true,
      columnMap: analysis.columnMap,
      summary: analysis.summary,
      rows: analysis.rows
    });
  } catch (error) {
    console.error("ERROR /api/import/master/preview:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error generando preview" });
  }
});

app.post("/api/import/master/commit", authRequired, async (req, res) => {
  try {
    if (!canUseMasterImporter(req.authUser)) {
      return res.status(403).json({ ok: false, error: "Solo admin y backoffice pueden importar CSV" });
    }

    const csvText = String((req.body && req.body.csvText) || "");
    if (!csvText.trim()) {
      return res.status(400).json({ ok: false, error: "Falta csvText" });
    }

    const analysis = await buildMasterImportAnalysis(csvText);
    if (!analysis.ok) {
      return res.status(400).json({ ok: false, error: analysis.error || "No se pudo analizar el archivo" });
    }

    if (!analysis.summary || !analysis.summary.okRows) {
      return res.status(400).json({ ok: false, error: "No hay filas válidas para importar" });
    }

    const result = await commitMasterImportAnalysis(analysis);
    return res.json({ ok: true, summary: analysis.summary, result });
  } catch (error) {
    console.error("ERROR /api/import/master/commit:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error importando archivo" });
  }
});


// =====================================================
// BLOQUE 6C - API CONTACTOS

// =====================================================
// BLOQUE 6C - API CONTACTOS
// =====================================================

app.get("/api/contacts", authRequired, async (req, res) => {
  try {
    const limit = Math.max(1, Math.min(100, Number(req.query.limit || 25)));
    const offset = Math.max(0, Number(req.query.offset || 0));
    const cursor = String(req.query.cursor || "").trim();
    const q = String(req.query.q || "").trim().toLowerCase();
    const ownerFilter = String(req.query.owner || "").trim().toLowerCase();
    const contactStatusFilter = String(req.query.contactStatus || "").trim().toLowerCase();
    const contactIdFilter = String(req.query.contactId || "").trim();
    const lite = String(req.query.lite || "").trim() === "1";

    const visibleOwnerEmails = await getVisibleOwnerEmails(req.authUser);

    if (contactIdFilter) {
      const contactSnap = await db.collection("contacts").doc(contactIdFilter).get();
      if (!contactSnap.exists) {
        return res.json({
          ok: true,
          contacts: [],
          total: 0,
          limit,
          offset,
          nextOffset: offset,
          nextCursor: "",
          hasMore: false
        });
      }

      const data = contactSnap.data() || {};
      const canSee = await canSeeOwner(req.authUser, data.owner || "");
      if (!canSee) {
        return res.json({
          ok: true,
          contacts: [],
          total: 0,
          limit,
          offset,
          nextOffset: offset,
          nextCursor: "",
          hasMore: false
        });
      }

      let contact = normalizeContactForList(contactSnap.id, data);
      if (ownerFilter && String(contact.owner || "").trim().toLowerCase() !== ownerFilter) {
        return res.json({ ok: true, contacts: [], total: 0, limit, offset, nextOffset: offset, nextCursor: "", hasMore: false });
      }
      if (contactStatusFilter && String(contact.contactStatus || "lead").trim().toLowerCase() !== contactStatusFilter) {
        return res.json({ ok: true, contacts: [], total: 0, limit, offset, nextOffset: offset, nextCursor: "", hasMore: false });
      }
      if (!contactMatchesSearch(contact, q)) {
        return res.json({ ok: true, contacts: [], total: 0, limit, offset, nextOffset: offset, nextCursor: "", hasMore: false });
      }

      const contactsOut = lite ? [contact] : await enrichContactsPageWithDeals([contact]);
      return res.json({ ok: true, contacts: contactsOut, total: 1, limit, offset, nextOffset: offset + contactsOut.length, nextCursor: "", hasMore: false });
    }

    const canUseFastQuery = !q && (visibleOwnerEmails === null || visibleOwnerEmails.length === 1 || !!ownerFilter);

    if (canUseFastQuery) {
      try {
        let query = db.collection("contacts");

        if (visibleOwnerEmails && visibleOwnerEmails.length === 1 && !ownerFilter) {
          query = query.where("owner", "==", String(visibleOwnerEmails[0] || "").trim().toLowerCase());
        }

        if (ownerFilter) {
          if (visibleOwnerEmails !== null && !visibleOwnerEmails.includes(ownerFilter)) {
            return res.json({ ok: true, contacts: [], total: 0, limit, offset, nextOffset: offset, nextCursor: "", hasMore: false });
          }
          query = query.where("owner", "==", ownerFilter);
        }

        if (contactStatusFilter) {
          query = query.where("contactStatus", "==", contactStatusFilter);
        }

        const orderedQuery = query
          .orderBy("createdAt", "desc")
          .orderBy(admin.firestore.FieldPath.documentId(), "desc");

        let pageQuery = orderedQuery.limit(limit);
        const decodedCursor = decodeFirestoreCursor(cursor);
        if (decodedCursor) {
          pageQuery = pageQuery.startAfter(decodedCursor.createdAt, decodedCursor.id);
        }

        const shouldUseStoredContactsTotal = !q && !ownerFilter && !contactStatusFilter && visibleOwnerEmails === null;
        const totalPromise = shouldUseStoredContactsTotal
          ? getStoredTotal("contacts_total", "contacts")
          : query.count().get().then((snap) => Number((snap && snap.data && snap.data().count) || 0));

        const [pageSnap, total] = await Promise.all([
          pageQuery.get(),
          totalPromise
        ]);

        let contacts = pageSnap.docs.map((doc) => normalizeContactForList(doc.id, doc.data() || {}));
        if (!lite) contacts = await enrichContactsPageWithDeals(contacts);

        const lastDoc = pageSnap.docs.length ? pageSnap.docs[pageSnap.docs.length - 1] : null;
        const nextCursor = pageSnap.docs.length === limit ? encodeFirestoreCursor(lastDoc) : "";

        return res.json({
          ok: true,
          contacts,
          total,
          limit,
          offset,
          nextOffset: offset + contacts.length,
          nextCursor,
          hasMore: !!nextCursor
        });
      } catch (fastErr) {
        console.warn("WARN /api/contacts GET fastQuery fallback:", fastErr && fastErr.message ? fastErr.message : fastErr);
      }
    }

    const FALLBACK_SCAN_BATCH = Math.max(100, limit * 4);
    const FALLBACK_SCAN_MAX_DOCS = Math.max(600, offset + limit + FALLBACK_SCAN_BATCH);
    const SHOULD_SCAN_ALL_CONTACTS_FOR_SEARCH = !!q;
    const matchedContacts = [];
    let scannedDocs = 0;
    let scanCursor = "";
    let exhausted = false;

    while (
      (SHOULD_SCAN_ALL_CONTACTS_FOR_SEARCH || scannedDocs < FALLBACK_SCAN_MAX_DOCS) &&
      (SHOULD_SCAN_ALL_CONTACTS_FOR_SEARCH || matchedContacts.length < (offset + limit + 1))
    ) {
      let scanQuery = db.collection("contacts")
        .orderBy("createdAt", "desc")
        .orderBy(admin.firestore.FieldPath.documentId(), "desc")
        .limit(FALLBACK_SCAN_BATCH);

      const decodedScanCursor = decodeFirestoreCursor(scanCursor);
      if (decodedScanCursor) {
        scanQuery = scanQuery.startAfter(decodedScanCursor.createdAt, decodedScanCursor.id);
      }

      const scanSnap = await scanQuery.get();
      if (!scanSnap.docs.length) {
        exhausted = true;
        break;
      }

      scannedDocs += scanSnap.docs.length;

      let batchContacts = scanSnap.docs.map((doc) => normalizeContactForList(doc.id, doc.data() || {}));
      if (visibleOwnerEmails !== null) {
        batchContacts = batchContacts.filter((contact) => visibleOwnerEmails.includes(String(contact.owner || "").trim().toLowerCase()));
      }
      if (ownerFilter) batchContacts = batchContacts.filter((contact) => String(contact.owner || "").trim().toLowerCase() === ownerFilter);
      if (contactStatusFilter) batchContacts = batchContacts.filter((contact) => String(contact.contactStatus || "lead").trim().toLowerCase() === contactStatusFilter);
      if (q) batchContacts = batchContacts.filter((contact) => contactMatchesSearch(contact, q));

      matchedContacts.push(...batchContacts);

      const lastDoc = scanSnap.docs[scanSnap.docs.length - 1];
      scanCursor = lastDoc ? encodeFirestoreCursor(lastDoc) : "";
      if (scanSnap.docs.length < FALLBACK_SCAN_BATCH) {
        exhausted = true;
        break;
      }
    }

    const pagedBase = matchedContacts.slice(offset, offset + limit);
    const contactsOut = lite ? pagedBase : await enrichContactsPageWithDeals(pagedBase);
    const hasMore = matchedContacts.length > (offset + limit) || !exhausted;
    const total = exhausted
      ? matchedContacts.length
      : Math.max(offset + contactsOut.length + (hasMore ? 1 : 0), matchedContacts.length);

    return res.json({
      ok: true,
      contacts: contactsOut,
      total,
      limit,
      offset,
      nextOffset: offset + contactsOut.length,
      nextCursor: "",
      hasMore
    });
  } catch (err) {
    console.error("ERROR /api/contacts GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error listando contactos" });
  }
});

app.post("/api/contacts", authRequired, async (req, res) => {
  try {

    const { name, company, province, phone, email, owner, contactStatus } = req.body || {};

    const cleanName = String(name || "").trim();
    const cleanCompany = String(company || "").trim();
    const cleanProvince = String(province || "").trim();
    const cleanPhone = String(phone || "").trim();
    const cleanEmail = String(email || "").trim();
    const cleanOwner = String(owner || "").trim();
    const cleanStatus = String(contactStatus || "lead").trim().toLowerCase();

    if (!cleanName) {
      return res.status(400).json({ ok:false, error:"Nombre obligatorio" });
    }

    const ref = await db.collection("contacts").add({
      name: cleanName,
      company: cleanCompany,
      province: cleanProvince,
      phone: cleanPhone,
      email: cleanEmail,
      owner: cleanOwner,
      contactStatus: cleanStatus,
      createdAt: new Date(),
      updatedAt: new Date()
    });

    await incrementStoredTotal("contacts_total", 1);

    return res.json({ ok:true, id: ref.id });

  } catch (error) {
    console.error("ERROR /api/contacts POST:", error);
    return res.status(500).json({ ok:false, error:error.message || "Error creando contacto" });
  }
});



app.put("/api/contacts/:id", authRequired, async (req, res) => {
  try {
    const id = req.params.id;
    const contactRef = db.collection("contacts").doc(id);
    const snap = await contactRef.get();

    if (!snap.exists) return res.status(404).json({ ok: false, error: "Contacto no encontrado" });

    const current = snap.data() || {};
    if (!(await canEditOwner(req.authUser, current.owner || ""))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para editar este contacto" });
    }

    const { name, company, province, phone, email, contactStatus } = req.body || {};
    const payload = { updatedAt: new Date() };

    if (typeof name === "string") payload.name = name.trim();
    if (typeof company === "string") payload.company = company.trim();
    if (typeof province === "string") payload.province = province.trim();
    if (typeof phone === "string") payload.phone = phone.trim();
    if (typeof email === "string") payload.email = email.trim();

    if (typeof contactStatus === "string") {
      const normalizedStatus = ["lead", "prospecto", "cliente", "inactivo"].includes(contactStatus.trim().toLowerCase())
        ? contactStatus.trim().toLowerCase()
        : "lead";
      payload.contactStatus = normalizedStatus;
      if (normalizedStatus === "cliente") {
        payload.convertedToClientAt = new Date();
      }
    }

    await contactRef.update(payload);
    return res.json({ ok: true });
  } catch (err) {
    console.error("ERROR /api/contacts/:id PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error editando contacto" });
  }
});



app.put("/api/contacts/:id/owner", authRequired, async (req, res) => {
  try {
    const id = req.params.id;
    const owner = req.body && typeof req.body.owner === "string" ? req.body.owner : "";

    if (!(isAdmin(req.authUser) || isBackoffice(req.authUser))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para cambiar owner" });
    }

    const contactRef = db.collection("contacts").doc(id);
    const contactSnap = await contactRef.get();
    if (!contactSnap.exists) {
      return res.status(404).json({ ok: false, error: "Contacto no encontrado" });
    }

    const contactData = contactSnap.data() || {};
    if (!(await canEditOwner(req.authUser, contactData.owner || ""))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso sobre este contacto" });
    }

    const result = await syncOwnerForContactAndDeals(id, owner);
    return res.json({ ok: true, syncedDeals: result.updatedDeals });
  } catch (err) {
    console.error("ERROR /api/contacts/:id/owner PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando owner del contacto" });
  }
});

app.put("/api/contacts/:id/status", authRequired, async (req, res) => {
  try {
    const id = req.params.id;
    const contactRef = db.collection("contacts").doc(id);
    const snap = await contactRef.get();

    if (!snap.exists) return res.status(404).json({ ok: false, error: "Contacto no encontrado" });

    const current = snap.data() || {};
    if (!(await canEditOwner(req.authUser, current.owner || ""))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para editar este contacto" });
    }

    const contactStatusRaw = String((req.body && req.body.contactStatus) || "").trim().toLowerCase();
    const contactStatus = ["lead", "prospecto", "cliente", "inactivo"].includes(contactStatusRaw)
      ? contactStatusRaw
      : "lead";

    const payload = {
      contactStatus,
      updatedAt: new Date()
    };

    if (contactStatus === "cliente") {
      payload.convertedToClientAt = new Date();
    }

    await contactRef.update(payload);
    return res.json({ ok: true, contactStatus });
  } catch (err) {
    console.error("ERROR /api/contacts/:id/status PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando estado del contacto" });
  }
});

app.delete("/api/contacts/:id", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) return res.status(403).json({ ok: false, error: "Solo admin puede borrar contactos" });

    const id = req.params.id;
    const dealsSnapshot = await db.collection("deals").where("contactId", "==", id).get();
    const batch = db.batch();

    dealsSnapshot.docs.forEach((doc) => batch.delete(doc.ref));
    batch.delete(db.collection("contacts").doc(id));

    await batch.commit();
    await Promise.all([
      incrementStoredTotal("contacts_total", -1),
      incrementStoredTotal("deals_total", -Number(dealsSnapshot.size || 0))
    ]);
    return res.json({ ok: true, deletedDeals: dealsSnapshot.size });
  } catch (err) {
    console.error("ERROR /api/contacts/:id DELETE:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error borrando contacto" });
  }
});




async function loadDealsIndexFreePage(options = {}) {
  const limit = Math.max(1, Math.min(100, Number(options.limit || 25)));
  const offset = Math.max(0, Number(options.offset || 0));
  const cursor = String(options.cursor || "").trim();
  const q = String(options.q || "").trim().toLowerCase();
  const stageFilter = String(options.stageFilter || "").trim();
  const ownerFilterList = Array.isArray(options.ownerFilters)
    ? Array.from(new Set(options.ownerFilters.map((item) => String(item || "").trim().toLowerCase()).filter(Boolean)))
    : [];
  const ownerFilter = ownerFilterList.length === 1 ? ownerFilterList[0] : String(options.ownerFilter || "").trim().toLowerCase();
  const hasDealTypeFilter = !!options.hasDealTypeFilter;
  const dealTypeFilter = normalizeDealType(options.dealTypeFilter || "LCL_PROPIO");
  const dueMode = String(options.dueMode || "").trim();
  const dueFrom = String(options.dueFrom || "").trim();
  const dueTo = String(options.dueTo || "").trim();
  const dealIdFilter = String(options.dealIdFilter || "").trim();
  const includeContactPhone = options.includeContactPhone !== false;
  const visibleOwnerEmails = Array.isArray(options.visibleOwnerEmails) ? options.visibleOwnerEmails : null;

  const today = getTodayISOInBuenosAires();
  const prox7 = dateToISOUTC(addDaysUTC(isoToDateUTC(today), 7));

  function matches(doc) {
    const data = doc.data() || {};
    const owner = String(data.owner || "").trim().toLowerCase();
    const stage = String(data.stage || "No responde").trim();
    const type = normalizeDealType(data.dealType || "LCL_PROPIO");
    const due = String(data.dueDate || "").trim();

    if (visibleOwnerEmails !== null && !visibleOwnerEmails.includes(owner)) return false;
    if (dealIdFilter && String(doc.id || "") !== dealIdFilter) return false;
    if (stageFilter && stage !== stageFilter) return false;
    if (ownerFilterList.length && !ownerFilterList.includes(owner)) return false;
    if (!ownerFilterList.length && ownerFilter && owner !== ownerFilter) return false;
    if (hasDealTypeFilter && type !== dealTypeFilter) return false;
    if (q && ![data.title, data.contactName, data.owner, data.notes].join(" ").toLowerCase().includes(q)) return false;
    if (dueMode === "sin_fecha" && due) return false;
    if (dueMode === "vencidos" && (!due || due >= today)) return false;
    if (dueMode === "hoy" && due !== today) return false;
    if (dueMode === "proximos_7" && (!due || due < today || due > prox7)) return false;
    if (dueMode === "rango") {
      if (!due) return false;
      if (dueFrom && due < dueFrom) return false;
      if (dueTo && due > dueTo) return false;
    }
    return true;
  }

  // Al abrir un trato puntual desde una URL, evitar escanear la colección.
  if (dealIdFilter) {
    const direct = await db.collection("deals").doc(dealIdFilter).get();
    const directDocs = direct.exists && matches(direct) ? [direct] : [];
    let contactsMap = new Map();
    if (includeContactPhone && directDocs.length) {
      const contactId = String((directDocs[0].data() || {}).contactId || "").trim();
      if (contactId) {
        const contactDoc = await db.collection("contacts").doc(contactId).get();
        contactsMap.set(contactId, contactDoc.exists ? (contactDoc.data() || {}) : {});
      }
    }
    const deals = directDocs.map((doc) => {
      const data = doc.data() || {};
      const contact = contactsMap.get(String(data.contactId || "").trim()) || {};
      return { id: doc.id, ...data, contactPhone: includeContactPhone ? String(contact.phone || "").trim() : "", dealType: normalizeDealType(data.dealType || "LCL_PROPIO"),
              leadQuality: normalizeLeadQuality(data.leadQuality || "NO_RESPONDE") };
    });
    return { deals, total: deals.length, totalKnown: true, nextCursor: "", hasMore: false, scannedDocs: directDocs.length };
  }

  const decodedCursor = decodeIndexFreeDealsCursor(cursor);
  const scanBatch = Math.max(100, Math.min(300, limit * 4));
  const sparseFilter = !!(q || dueMode || stageFilter || ownerFilterList.length || ownerFilter || hasDealTypeFilter || visibleOwnerEmails !== null);
  const maxScanDocs = sparseFilter ? 3000 : Math.max(300, limit * 5);
  const matched = [];
  let scannedDocs = 0;
  let lastScannedDoc = null;
  let exhausted = false;

  while (scannedDocs < maxScanDocs && matched.length < limit + 1) {
    let scanQuery = db.collection("deals")
      .orderBy(admin.firestore.FieldPath.documentId(), "desc")
      .limit(scanBatch);

    if (lastScannedDoc) {
      scanQuery = scanQuery.startAfter(lastScannedDoc);
    } else if (decodedCursor && decodedCursor.id) {
      const cursorDoc = await db.collection("deals").doc(decodedCursor.id).get();
      if (cursorDoc.exists) scanQuery = scanQuery.startAfter(cursorDoc);
    }

    const snap = await scanQuery.get();
    if (!snap.docs.length) {
      exhausted = true;
      break;
    }

    scannedDocs += snap.docs.length;
    lastScannedDoc = snap.docs[snap.docs.length - 1];
    for (const doc of snap.docs) {
      if (matches(doc)) matched.push(doc);
      if (matched.length >= limit + 1) break;
    }

    if (snap.docs.length < scanBatch) {
      exhausted = true;
      break;
    }
  }

  const selectedDocs = matched.slice(0, limit);
  selectedDocs.sort((a, b) => {
    const ad = a.data() || {};
    const bd = b.data() || {};
    const at = timestampToMillis(ad.createdAt || ad.updatedAt || 0);
    const bt = timestampToMillis(bd.createdAt || bd.updatedAt || 0);
    if (at !== bt) return bt - at;
    return String(b.id || "").localeCompare(String(a.id || ""));
  });

  let contactsMap = new Map();
  if (includeContactPhone) {
    const contactIds = Array.from(new Set(selectedDocs.map((doc) => String((doc.data() || {}).contactId || "").trim()).filter(Boolean)));
    const contactRefs = contactIds.map((id) => db.collection("contacts").doc(id));
    const contactDocs = contactRefs.length ? await db.getAll(...contactRefs) : [];
    contactDocs.forEach((doc) => contactsMap.set(doc.id, doc.exists ? (doc.data() || {}) : {}));
  }

  const deals = selectedDocs.map((doc) => {
    const data = doc.data() || {};
    const contact = includeContactPhone ? (contactsMap.get(String(data.contactId || "").trim()) || {}) : {};
    return {
      id: doc.id,
      ...data,
      contactPhone: includeContactPhone ? String(contact.phone || "").trim() : "",
      dealType: normalizeDealType(data.dealType || "LCL_PROPIO"),
              leadQuality: normalizeLeadQuality(data.leadQuality || "NO_RESPONDE")
    };
  });

  const hasMore = matched.length > limit || (!exhausted && !!lastScannedDoc);
  return {
    deals,
    total: offset + deals.length + (hasMore ? 1 : 0),
    totalKnown: false,
    nextCursor: hasMore && lastScannedDoc ? encodeIndexFreeDealsCursor(lastScannedDoc.id) : "",
    hasMore,
    scannedDocs
  };
}

// =====================================================
// BLOQUE 6D - API DEALS
// =====================================================

app.get("/api/deals", authRequired, async (req, res) => {
  try {
    const limit = Math.max(1, Math.min(100, Number(req.query.limit || 25)));
    const offset = Math.max(0, Number(req.query.offset || 0));
    const cursor = String(req.query.cursor || "").trim();
    const q = String(req.query.q || "").trim().toLowerCase();
    const stageFilter = String(req.query.stage || "").trim();
    const rawOwnerFilter = String(req.query.owner || "").trim().toLowerCase();
    const ownerFilterList = Array.from(new Set(rawOwnerFilter.split(",").map((item) => String(item || "").trim().toLowerCase()).filter(Boolean)));
    if (ownerFilterList.length > 1 && !(isAdmin(req.authUser) || isBackoffice(req.authUser))) {
      return res.status(403).json({ ok: false, error: "El filtro por múltiples owners solo está disponible para admin y backoffice" });
    }
    const ownerFilter = ownerFilterList.length === 1 ? ownerFilterList[0] : "";
    const dealTypeFilter = normalizeDealType(String(req.query.dealType || "").trim() || "LCL_PROPIO");
    const hasDealTypeFilter = !!String(req.query.dealType || "").trim();
    const dueMode = String(req.query.dueMode || "").trim();
    const dueFrom = String(req.query.dueFrom || "").trim();
    const dueTo = String(req.query.dueTo || "").trim();
    const dealIdFilter = String(req.query.dealId || "").trim();
    const skipCount = String(req.query.skipCount || "").trim() === "1";
    const includeContactPhone = String(req.query.includeContactPhone || "1").trim() !== "0";

    const visibleOwnerEmails = await getVisibleOwnerEmails(req.authUser);
    const normalizedVisibleOwners = Array.isArray(visibleOwnerEmails)
      ? Array.from(new Set(visibleOwnerEmails.map((email) => String(email || "").trim().toLowerCase()).filter(Boolean)))
      : null;
    if (ownerFilterList.length && normalizedVisibleOwners !== null) {
      const notVisibleOwner = ownerFilterList.find((owner) => !normalizedVisibleOwners.includes(owner));
      if (notVisibleOwner) {
        return res.status(403).json({ ok: false, error: "No tenés permiso para ver uno de los owners seleccionados" });
      }
    }
    const effectiveOwnerFilters = ownerFilterList.length ? ownerFilterList : normalizedVisibleOwners;
    const indexFreeCursor = decodeIndexFreeDealsCursor(cursor);
    const canUseFastQuery = !indexFreeCursor && !q && !dueMode && !dealIdFilter && (
      effectiveOwnerFilters === null ||
      ownerFilterList.length > 0 ||
      (Array.isArray(effectiveOwnerFilters) && effectiveOwnerFilters.length >= 1)
    );

    if (canUseFastQuery) {
      try {
        const useChunkedOwnerFastQuery = Array.isArray(effectiveOwnerFilters) && effectiveOwnerFilters.length > 10;

        if (!useChunkedOwnerFastQuery) {
          let query = db.collection("deals");
          if (stageFilter) query = query.where("stage", "==", stageFilter);
          if (ownerFilterList.length === 1) {
            query = query.where("owner", "==", ownerFilterList[0]);
          } else if (ownerFilterList.length > 1) {
            query = query.where("owner", "in", ownerFilterList.slice(0, 10));
          } else if (normalizedVisibleOwners && normalizedVisibleOwners.length === 1) {
            query = query.where("owner", "==", normalizedVisibleOwners[0]);
          } else if (normalizedVisibleOwners && normalizedVisibleOwners.length > 1) {
            query = query.where("owner", "in", normalizedVisibleOwners);
          }
          if (hasDealTypeFilter) query = query.where("dealType", "==", dealTypeFilter);

          const orderedQuery = query
            .orderBy("createdAt", "desc")
            .orderBy(admin.firestore.FieldPath.documentId(), "desc");

          let pageQuery = orderedQuery.limit(limit);
          const decodedCursor = decodeFirestoreCursor(cursor);
          if (decodedCursor) {
            pageQuery = pageQuery.startAfter(decodedCursor.createdAt, decodedCursor.id);
          }

          const shouldUseStoredDealsTotal = !skipCount && !q && !dueMode && !dealIdFilter && !stageFilter && !ownerFilterList.length && !hasDealTypeFilter && normalizedVisibleOwners === null;
          const pageSnapPromise = pageQuery.get();
          const totalPromise = skipCount
            ? Promise.resolve(null)
            : (shouldUseStoredDealsTotal
              ? getStoredTotal("deals_total", "deals")
              : query.count().get().then((snap) => Number((snap && snap.data && snap.data().count) || 0)));
          const [pageSnap, totalResult] = await Promise.all([pageSnapPromise, totalPromise]);

          let contactsMap = new Map();
          if (includeContactPhone) {
            const contactIds = Array.from(new Set(pageSnap.docs.map((doc) => String((doc.data() || {}).contactId || "").trim()).filter(Boolean)));
            const contactRefs = contactIds.map((id) => db.collection("contacts").doc(id));
            const contactDocs = contactRefs.length ? await db.getAll(...contactRefs) : [];
            contactDocs.forEach((doc) => contactsMap.set(doc.id, doc.exists ? (doc.data() || {}) : {}));
          }

          const deals = pageSnap.docs.map((doc) => {
            const data = doc.data() || {};
            const contact = includeContactPhone ? (contactsMap.get(String(data.contactId || "").trim()) || {}) : {};
            return {
              id: doc.id,
              ...data,
              contactPhone: includeContactPhone ? String(contact.phone || "").trim() : "",
              dealType: normalizeDealType(data.dealType || "LCL_PROPIO"),
              leadQuality: normalizeLeadQuality(data.leadQuality || "NO_RESPONDE")
            };
          });

          const lastDoc = pageSnap.docs.length ? pageSnap.docs[pageSnap.docs.length - 1] : null;
          const nextCursor = pageSnap.docs.length === limit ? encodeFirestoreCursor(lastDoc) : "";
          const total = skipCount
            ? (decodedCursor ? (offset + deals.length + (nextCursor ? 1 : 0)) : deals.length)
            : Number(totalResult || 0);

          return res.json({
            ok: true,
            deals,
            total,
            totalKnown: !skipCount,
            limit,
            offset,
            nextOffset: offset + deals.length,
            nextCursor,
            hasMore: skipCount ? pageSnap.docs.length === limit : !!nextCursor,
            stages: PIPELINE_STAGES,
            dealTypes: DEAL_TYPES
          });
        }

        const ownerChunks = chunkArray(Array.isArray(effectiveOwnerFilters) ? effectiveOwnerFilters : [], 10);
        const compositeCursorMap = decodeCompositeFirestoreCursor(cursor) || {};

        const chunkResults = await Promise.all(ownerChunks.map(async (ownerChunk, chunkIndex) => {
          let query = db.collection("deals");
          if (stageFilter) query = query.where("stage", "==", stageFilter);
          query = query.where("owner", "in", ownerChunk);
          if (hasDealTypeFilter) query = query.where("dealType", "==", dealTypeFilter);

          const orderedQuery = query
            .orderBy("createdAt", "desc")
            .orderBy(admin.firestore.FieldPath.documentId(), "desc");

          let pageQuery = orderedQuery.limit(limit + 1);
          const chunkCursor = decodeFirestoreCursor(String(compositeCursorMap[String(chunkIndex)] || ""));
          if (chunkCursor) pageQuery = pageQuery.startAfter(chunkCursor.createdAt, chunkCursor.id);

          const pageSnapPromise = pageQuery.get();
          const countSnapPromise = skipCount ? Promise.resolve(null) : query.count().get();
          const [pageSnap, countSnap] = await Promise.all([pageSnapPromise, countSnapPromise]);

          return {
            chunkIndex,
            ownerChunk,
            docs: pageSnap.docs,
            totalCount: Number((countSnap && countSnap.data && countSnap.data().count) || 0),
            previousCursor: String(compositeCursorMap[String(chunkIndex)] || "")
          };
        }));

        const mergedDocs = [];
        chunkResults.forEach((result) => {
          result.docs.forEach((doc, docIndex) => {
            mergedDocs.push({ chunkIndex: result.chunkIndex, docIndex, doc });
          });
        });
        mergedDocs.sort((a, b) => compareFirestoreDocsDesc(a.doc, b.doc));

        const selected = mergedDocs.slice(0, limit);
        const selectedDocs = selected.map((item) => item.doc);

        const nextCursorMap = {};
        let hasMore = false;
        chunkResults.forEach((result) => {
          const consumed = selected.filter((item) => item.chunkIndex === result.chunkIndex).map((item) => item.doc);
          if (consumed.length) {
            nextCursorMap[String(result.chunkIndex)] = encodeFirestoreCursor(consumed[consumed.length - 1]);
          } else if (result.previousCursor) {
            nextCursorMap[String(result.chunkIndex)] = result.previousCursor;
          }
          if (result.docs.length > consumed.length) hasMore = true;
        });

        let contactsMap = new Map();
        if (includeContactPhone) {
          const contactIds = Array.from(new Set(selectedDocs.map((doc) => String((doc.data() || {}).contactId || "").trim()).filter(Boolean)));
          const contactRefs = contactIds.map((id) => db.collection("contacts").doc(id));
          const contactDocs = contactRefs.length ? await db.getAll(...contactRefs) : [];
          contactDocs.forEach((doc) => contactsMap.set(doc.id, doc.exists ? (doc.data() || {}) : {}));
        }

        const deals = selectedDocs.map((doc) => {
          const data = doc.data() || {};
          const contact = includeContactPhone ? (contactsMap.get(String(data.contactId || "").trim()) || {}) : {};
          return {
            id: doc.id,
            ...data,
            contactPhone: includeContactPhone ? String(contact.phone || "").trim() : "",
            dealType: normalizeDealType(data.dealType || "LCL_PROPIO"),
              leadQuality: normalizeLeadQuality(data.leadQuality || "NO_RESPONDE")
          };
        });

        const total = skipCount
          ? (offset + deals.length + (hasMore ? 1 : 0))
          : chunkResults.reduce((acc, result) => acc + Number(result.totalCount || 0), 0);

        return res.json({
          ok: true,
          deals,
          total,
          totalKnown: !skipCount,
          limit,
          offset,
          nextOffset: offset + deals.length,
          nextCursor: hasMore ? encodeCompositeFirestoreCursor(nextCursorMap) : "",
          hasMore,
          stages: PIPELINE_STAGES,
          dealTypes: DEAL_TYPES
        });
      } catch (fastErr) {
        console.warn("WARN /api/deals GET fastQuery fallback:", fastErr && fastErr.message ? fastErr.message : fastErr);

        const fastErrCode = Number(fastErr && fastErr.code);
        const fastErrMessage = String((fastErr && fastErr.message) || "");
        const isMissingIndexError = fastErrCode === 9 || /FAILED_PRECONDITION/i.test(fastErrMessage) || /requires an index/i.test(fastErrMessage);

        if (isMissingIndexError) {
          const canUseSafeOwnerScan = !!(ownerFilterList.length || ownerFilter) && !q && !dueMode && !dealIdFilter;

          if (canUseSafeOwnerScan) {
            const SAFE_OWNER_SCAN_BATCH = Math.max(100, limit * 4);
            const SAFE_OWNER_SCAN_MAX_DOCS = Math.max(1200, offset + limit + 200);
            const matchedDeals = [];
            let scannedDocs = 0;
            let scanCursor = cursor;
            let exhausted = false;

            while (scannedDocs < SAFE_OWNER_SCAN_MAX_DOCS && matchedDeals.length < (offset + limit + 1)) {
              let scanQuery = db.collection("deals")
                .orderBy("createdAt", "desc")
                .orderBy(admin.firestore.FieldPath.documentId(), "desc")
                .limit(SAFE_OWNER_SCAN_BATCH);

              const decodedScanCursor = decodeFirestoreCursor(scanCursor);
              if (decodedScanCursor) {
                scanQuery = scanQuery.startAfter(decodedScanCursor.createdAt, decodedScanCursor.id);
              }

              const scanSnap = await scanQuery.get();
              if (!scanSnap.docs.length) {
                exhausted = true;
                break;
              }

              scannedDocs += scanSnap.docs.length;

              scanSnap.docs.forEach((doc) => {
                const data = doc.data() || {};
                const dealOwner = String(data.owner || "").trim().toLowerCase();
                const dealStage = String(data.stage || "No responde").trim();
                const dealType = normalizeDealType(data.dealType || "LCL_PROPIO");

                if (visibleOwnerEmails !== null && !visibleOwnerEmails.includes(dealOwner)) return;
                if (ownerFilterList.length && !ownerFilterList.includes(dealOwner)) return;
                if (!ownerFilterList.length && ownerFilter && dealOwner !== ownerFilter) return;
                if (stageFilter && dealStage !== stageFilter) return;
                if (hasDealTypeFilter && dealType !== dealTypeFilter) return;

                matchedDeals.push({ id: doc.id, ...data, dealType });
              });

              const lastScanDoc = scanSnap.docs[scanSnap.docs.length - 1];
              scanCursor = lastScanDoc ? encodeFirestoreCursor(lastScanDoc) : "";

              if (scanSnap.docs.length < SAFE_OWNER_SCAN_BATCH) {
                exhausted = true;
                break;
              }
            }

            const pagedDeals = matchedDeals.slice(offset, offset + limit);
            let contactsMap = new Map();
            if (includeContactPhone) {
              const contactIds = Array.from(new Set(pagedDeals.map((deal) => String(deal.contactId || "").trim()).filter(Boolean)));
              const contactRefs = contactIds.map((id) => db.collection("contacts").doc(id));
              const contactDocs = contactRefs.length ? await db.getAll(...contactRefs) : [];
              contactDocs.forEach((doc) => contactsMap.set(doc.id, doc.exists ? (doc.data() || {}) : {}));
            }

            const dealsOut = pagedDeals.map((deal) => {
              const contact = includeContactPhone ? (contactsMap.get(String(deal.contactId || "").trim()) || {}) : {};
              return {
                ...deal,
                contactPhone: includeContactPhone ? String(contact.phone || "").trim() : "",
                dealType: normalizeDealType(deal.dealType || "LCL_PROPIO")
              };
            });

            const hasMore = matchedDeals.length > (offset + limit) || (!exhausted && scannedDocs >= SAFE_OWNER_SCAN_MAX_DOCS);
            return res.json({
              ok: true,
              deals: dealsOut,
              total: offset + dealsOut.length + (hasMore ? 1 : 0),
              totalKnown: false,
              limit,
              offset,
              nextOffset: offset + dealsOut.length,
              nextCursor: hasMore ? String(scanCursor || "") : "",
              hasMore,
              stages: PIPELINE_STAGES,
              dealTypes: DEAL_TYPES
            });
          }

          const safePage = await loadDealsIndexFreePage({
            limit, offset, cursor, q, stageFilter, ownerFilter, ownerFilters: ownerFilterList, dealTypeFilter, hasDealTypeFilter,
            dueMode, dueFrom, dueTo, dealIdFilter, includeContactPhone, visibleOwnerEmails
          });
          return res.json({
            ok: true,
            deals: safePage.deals,
            total: safePage.total,
            totalKnown: safePage.totalKnown,
            limit,
            offset,
            nextOffset: offset + safePage.deals.length,
            nextCursor: safePage.nextCursor,
            hasMore: safePage.hasMore,
            usedIndexFreeFallback: true,
            scannedDocs: safePage.scannedDocs,
            stages: PIPELINE_STAGES,
            dealTypes: DEAL_TYPES
          });
        }
      }
    }

    const safePage = await loadDealsIndexFreePage({
      limit, offset, cursor, q, stageFilter, ownerFilter, ownerFilters: ownerFilterList, dealTypeFilter, hasDealTypeFilter,
      dueMode, dueFrom, dueTo, dealIdFilter, includeContactPhone, visibleOwnerEmails
    });
    return res.json({
      ok: true,
      deals: safePage.deals,
      total: safePage.total,
      totalKnown: safePage.totalKnown,
      limit,
      offset,
      nextOffset: offset + safePage.deals.length,
      nextCursor: safePage.nextCursor,
      hasMore: safePage.hasMore,
      usedIndexFreeFallback: true,
      scannedDocs: safePage.scannedDocs,
      stages: PIPELINE_STAGES,
      dealTypes: DEAL_TYPES
    });
  } catch (err) {
    console.error("ERROR /api/deals GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error listando tratos" });
  }
});


app.post("/api/deals/export-selected", authRequired, async (req, res) => {
  try {
    const rawDealIds = Array.isArray(req.body && req.body.dealIds) ? req.body.dealIds : [];
    const dealIds = Array.from(new Set(
      rawDealIds.map((id) => String(id || "").trim()).filter(Boolean)
    )).slice(0, 1000);

    if (!dealIds.length) {
      return res.status(400).json({ ok: false, error: "No hay tratos seleccionados para exportar" });
    }

    const dealRefs = dealIds.map((id) => db.collection("deals").doc(id));
    const dealDocs = dealRefs.length ? await db.getAll(...dealRefs) : [];

    const deals = [];
    for (const doc of dealDocs) {
      if (!doc.exists) continue;
      const data = doc.data() || {};
      if (!(await canSeeOwner(req.authUser, data.owner || ""))) continue;
      deals.push({ id: doc.id, ...data });
    }

    if (!deals.length) {
      return res.status(404).json({ ok: false, error: "No se encontraron tratos exportables para tu usuario" });
    }

    const contactIds = Array.from(new Set(
      deals.map((deal) => String(deal.contactId || "").trim()).filter(Boolean)
    ));
    const contactRefs = contactIds.map((id) => db.collection("contacts").doc(id));
    const contactDocs = contactRefs.length ? await db.getAll(...contactRefs) : [];
    const contactsMap = new Map();
    contactDocs.forEach((doc) => contactsMap.set(doc.id, doc.exists ? (doc.data() || {}) : {}));

    function exportCsvEscape(value) {
      const s = String(value == null ? "" : value);
      if (/[";\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
      return s;
    }

    function exportDateTime(value) {
      if (!value) return "";
      if (typeof value === "string") return value;
      if (value instanceof Date) return value.toISOString();
      if (typeof value.toDate === "function") {
        const d = value.toDate();
        return d instanceof Date && !Number.isNaN(d.getTime()) ? d.toISOString() : "";
      }
      if (typeof value._seconds === "number") return new Date(value._seconds * 1000).toISOString();
      if (typeof value.seconds === "number") return new Date(value.seconds * 1000).toISOString();
      return "";
    }

    const headers = [
      "Trato ID",
      "Trato",
      "Etapa",
      "Tipo",
      "Calidad lead",
      "Valor",
      "Fecha vencimiento",
      "Cliente",
      "Empresa",
      "Teléfono",
      "Email",
      "Provincia",
      "Owner",
      "Notas",
      "Archivos",
      "Creado",
      "Actualizado"
    ];

    const rows = deals.map((deal) => {
      const contact = contactsMap.get(String(deal.contactId || "").trim()) || {};
      return [
        deal.id || "",
        deal.title || "",
        deal.stage || "",
        getDealTypeLabel(deal.dealType || "LCL_PROPIO"),
        getLeadQualityLabel(deal.leadQuality || "NO_RESPONDE"),
        Number(deal.value || 0),
        deal.dueDate || "",
        deal.contactName || contact.name || "",
        contact.company || deal.company || "",
        contact.phone || deal.contactPhone || "",
        contact.email || "",
        contact.province || "",
        deal.owner || "",
        deal.notes || "",
        Array.isArray(deal.files) ? deal.files.length : 0,
        exportDateTime(deal.createdAt),
        exportDateTime(deal.updatedAt)
      ];
    });

    const csv = "\uFEFF" + [
      headers.map(exportCsvEscape).join(";"),
      ...rows.map((row) => row.map(exportCsvEscape).join(";"))
    ].join("\n");

    const filename = `tratos_seleccionados_${getTodayISOInBuenosAires()}.csv`;
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    return res.status(200).send(csv);
  } catch (err) {
    console.error("ERROR /api/deals/export-selected POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error exportando tratos seleccionados" });
  }
});

app.post("/api/deals", authRequired, async (req, res) => {
  try {
    const { title, contactId, contactName, value, dueDate, stage, dealType, leadQuality, owner, notes } = req.body || {};

    if (!title) return res.status(400).json({ ok: false, error: "El título es obligatorio" });
    if (!contactId) return res.status(400).json({ ok: false, error: "El contacto es obligatorio" });

    const contactSnap = await db.collection("contacts").doc(contactId).get();
    if (!contactSnap.exists) return res.status(404).json({ ok: false, error: "Contacto no encontrado" });

    const contactData = contactSnap.data() || {};
    if (isSeller(req.authUser) && !(await canSeeOwner(req.authUser, contactData.owner || req.authUser.email || ""))) {
      return res.status(403).json({ ok: false, error: "Solo podés crear tratos para contactos visibles para tu usuario" });
    }

    const finalOwner = isSeller(req.authUser)
      ? (req.authUser.email || "")
      : (typeof contactData.owner === "string" && contactData.owner ? contactData.owner : (owner || ""));

    const dealStage = PIPELINE_STAGES.includes(stage) ? stage : "No responde";
    const normalizedDealType = normalizeDealType(dealType || "LCL_PROPIO");
    const normalizedLeadQuality = normalizeLeadQuality(leadQuality || "NO_RESPONDE");

    const now = new Date();
    const newDeal = {
      title: title || "",
      contactId: contactId || "",
      contactName: contactName || contactData.name || "",
      value: Number(value || 0),
      dueDate: dueDate || "",
      stage: dealStage,
      dealType: normalizedDealType,
      leadQuality: normalizedLeadQuality,
      owner: finalOwner,
      notes: notes || "",
      files: [],
      createdAt: now,
      updatedAt: now
    };

    const ref = await db.collection("deals").add(newDeal);

    await incrementStoredTotal("deals_total", 1);

    // Si el trato nace directamente en una etapa con alerta, también envía el aviso.
    // Se reintenta una sola vez únicamente si MRAPI WhatsApp respondió con error.
    // No agrega lecturas de Firestore.
    let whatsappAlert = { ok: true, skipped: true, reason: "created_without_whatsapp_alert" };
    const createdStage = String(newDeal.stage || dealStage || "").trim();
    let alertSender = null;
    if (createdStage === "Horno") alertSender = sendCrmHornoWhatsAppAlert;
    if (createdStage === "Cotizado para enviar") alertSender = sendCrmCotizadoParaEnviarWhatsAppAlert;

    if (alertSender) {
      whatsappAlert = await alertSender(ref.id, newDeal, req.authUser);
      if (!whatsappAlert.ok) {
        await new Promise((resolve) => setTimeout(resolve, 1200));
        whatsappAlert = await alertSender(ref.id, newDeal, req.authUser);
        whatsappAlert.retried = true;
      }
      console.log("MRAPI WhatsApp creación directa en etapa con alerta:", {
        dealId: ref.id,
        stage: newDeal.stage,
        ok: !!whatsappAlert.ok,
        statusCode: whatsappAlert.statusCode || null,
        error: whatsappAlert.error || null
      });
    }

    // La creación siempre queda guardada aunque WhatsApp tenga una falla temporal.
    return res.json({ ok: true, id: ref.id, whatsappAlert });
  } catch (err) {
    console.error("ERROR /api/deals POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error creando trato" });
  }
});

app.put("/api/deals/:id/stage", authRequired, async (req, res) => {
  try {
    const id = req.params.id;
    const stage = req.body && req.body.stage ? req.body.stage : "";

    if (!PIPELINE_STAGES.includes(stage)) {
      return res.status(400).json({ ok: false, error: "Etapa inválida" });
    }

    const dealRef = db.collection("deals").doc(id);
    const dealSnap = await dealRef.get();
    if (!dealSnap.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });

    const deal = dealSnap.data() || {};
    if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para editar este trato" });
    }

    const previousStage = String(deal.stage || "").trim();
    const stagePayload = { stage, updatedAt: new Date() };
    Object.assign(stagePayload, buildProductionEligibilityFields({ ...deal, stage }));
    await dealRef.update(stagePayload);

    // Solo dispara cuando realmente entra a una etapa con alerta.
    // Volver a guardar la misma etapa no duplica el aviso.
    let whatsappAlert = { ok: true, skipped: true, reason: "not_entering_whatsapp_alert_stage" };
    if (stage === "Horno" && previousStage !== "Horno") {
      whatsappAlert = await sendCrmHornoWhatsAppAlert(id, deal, req.authUser);
    } else if (stage === "Cotizado para enviar" && previousStage !== "Cotizado para enviar") {
      whatsappAlert = await sendCrmCotizadoParaEnviarWhatsAppAlert(id, deal, req.authUser);
    }

    // El cambio de etapa siempre queda guardado aunque WhatsApp tenga una falla temporal.
    return res.json({ ok: true, whatsappAlert });
  } catch (err) {
    console.error("ERROR /api/deals/:id/stage PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando etapa" });
  }
});

app.put("/api/deals/bulk-stage-all", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) {
      return res.status(403).json({ ok: false, error: "Solo admin puede usar el actualizador masivo" });
    }

    const sourceStage = String((req.body && req.body.sourceStage) || "").trim();
    const targetStage = String((req.body && req.body.targetStage) || "").trim();

    if (!PIPELINE_STAGES.includes(sourceStage) || !PIPELINE_STAGES.includes(targetStage)) {
      return res.status(400).json({ ok: false, error: "Etapa inválida" });
    }
    if (sourceStage === targetStage) {
      return res.status(400).json({ ok: false, error: "La etapa origen y destino no pueden ser iguales" });
    }

    const snap = await db.collection("deals").where("stage", "==", sourceStage).get();
    const items = snap.docs.map((doc) => ({ ref: doc.ref, deal: doc.data() || {} }));

    for (const chunk of splitRowsForBatch(items, 400)) {
      const batch = db.batch();
      chunk.forEach((item) => {
        const updatePayload = { stage: targetStage, updatedAt: new Date() };
        Object.assign(updatePayload, buildProductionEligibilityFields({ ...item.deal, stage: targetStage }));
        batch.update(item.ref, updatePayload);
      });
      if (chunk.length) await batch.commit();
    }

    return res.json({ ok: true, updated: items.length, sourceStage, targetStage });
  } catch (err) {
    console.error("ERROR /api/deals/bulk-stage-all PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando la stage completa" });
  }
});

app.put("/api/deals/bulk-due-date-all", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) {
      return res.status(403).json({ ok: false, error: "Solo admin puede usar el actualizador masivo" });
    }

    const sourceStage = String((req.body && req.body.sourceStage) || "").trim();
    const dueDate = String((req.body && req.body.dueDate) || "").trim();

    if (!PIPELINE_STAGES.includes(sourceStage)) {
      return res.status(400).json({ ok: false, error: "Etapa inválida" });
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) {
      return res.status(400).json({ ok: false, error: "Fecha inválida" });
    }

    const snap = await db.collection("deals").where("stage", "==", sourceStage).get();
    const refs = snap.docs.map((doc) => doc.ref);

    for (const chunk of splitRowsForBatch(refs, 400)) {
      const batch = db.batch();
      chunk.forEach((ref) => batch.update(ref, { dueDate, updatedAt: new Date() }));
      if (chunk.length) await batch.commit();
    }

    return res.json({ ok: true, updated: refs.length, sourceStage, dueDate });
  } catch (err) {
    console.error("ERROR /api/deals/bulk-due-date-all PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando la fecha por stage" });
  }
});

app.put("/api/deals/bulk-stage", authRequired, async (req, res) => {
  try {
    const stage = String((req.body && req.body.stage) || "").trim();
    const dealIds = Array.isArray(req.body && req.body.dealIds) ? req.body.dealIds.map((id) => String(id || "").trim()).filter(Boolean) : [];

    if (!PIPELINE_STAGES.includes(stage)) {
      return res.status(400).json({ ok: false, error: "Etapa inválida" });
    }
    if (!dealIds.length) {
      return res.status(400).json({ ok: false, error: "No se enviaron tratos" });
    }

    const refs = await Promise.all(dealIds.map((id) => db.collection("deals").doc(id).get()));
    const allowedItems = [];

    for (const snap of refs) {
      if (!snap.exists) continue;
      const deal = snap.data() || {};
      if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
        return res.status(403).json({ ok: false, error: "No tenés permiso para editar uno o más tratos seleccionados" });
      }
      allowedItems.push({ ref: snap.ref, deal });
    }

    for (const chunk of splitRowsForBatch(allowedItems, 400)) {
      const batch = db.batch();
      chunk.forEach((item) => {
        const updatePayload = { stage, updatedAt: new Date() };
        Object.assign(updatePayload, buildProductionEligibilityFields({ ...item.deal, stage }));
        batch.update(item.ref, updatePayload);
      });
      if (chunk.length) await batch.commit();
    }

    return res.json({ ok: true, updated: allowedItems.length, stage });
  } catch (err) {
    console.error("ERROR /api/deals/bulk-stage PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando etapas en lote" });
  }
});

app.put("/api/deals/bulk-due-date", authRequired, async (req, res) => {
  try {
    const dueDate = String((req.body && req.body.dueDate) || "").trim();
    const dealIds = Array.isArray(req.body && req.body.dealIds) ? req.body.dealIds.map((id) => String(id || "").trim()).filter(Boolean) : [];

    if (!/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) {
      return res.status(400).json({ ok: false, error: "Fecha inválida" });
    }
    if (!dealIds.length) {
      return res.status(400).json({ ok: false, error: "No se enviaron tratos" });
    }

    const refs = await Promise.all(dealIds.map((id) => db.collection("deals").doc(id).get()));
    const allowedRefs = [];

    for (const snap of refs) {
      if (!snap.exists) continue;
      const deal = snap.data() || {};
      if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
        return res.status(403).json({ ok: false, error: "No tenés permiso para editar uno o más tratos seleccionados" });
      }
      allowedRefs.push(snap.ref);
    }

    for (const chunk of splitRowsForBatch(allowedRefs, 400)) {
      const batch = db.batch();
      chunk.forEach((ref) => batch.update(ref, { dueDate, updatedAt: new Date() }));
      if (chunk.length) await batch.commit();
    }

    return res.json({ ok: true, updated: allowedRefs.length, dueDate });
  } catch (err) {
    console.error("ERROR /api/deals/bulk-due-date PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando fecha en lote" });
  }
});

app.put("/api/deals/:id/type", authRequired, async (req, res) => {
  try {
    const id = req.params.id;
    const dealType = normalizeDealType(req.body && req.body.dealType ? req.body.dealType : "");

    const dealRef = db.collection("deals").doc(id);
    const dealSnap = await dealRef.get();
    if (!dealSnap.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });

    const deal = dealSnap.data() || {};
    if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para editar este trato" });
    }

    await dealRef.update({ dealType, updatedAt: new Date() });
    return res.json({ ok: true, dealType });
  } catch (err) {
    console.error("ERROR /api/deals/:id/type PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando tipo de trato" });
  }
});

app.put("/api/deals/:id/lead-quality", authRequired, async (req, res) => {
  try {
    const id = req.params.id;
    const leadQuality = normalizeLeadQuality(req.body && req.body.leadQuality ? req.body.leadQuality : "");

    const dealRef = db.collection("deals").doc(id);
    const dealSnap = await dealRef.get();
    if (!dealSnap.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });

    const deal = dealSnap.data() || {};
    if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para editar este trato" });
    }

    const previousLeadQuality = normalizeLeadQuality(deal.leadQuality || "NO_RESPONDE");
    await dealRef.update({ leadQuality, updatedAt: new Date() });

    let metaLeadEvent = { ok: true, skipped: true, reason: "quality_unchanged_or_not_reportable" };
    if (previousLeadQuality !== leadQuality && isMetaLeadQualityReportable(leadQuality)) {
      try {
        metaLeadEvent = await sendMetaLeadQualityEventForDeal(id, leadQuality, req.authUser);
      } catch (metaErr) {
        console.error("ERROR Meta lead quality event:", metaErr);
        metaLeadEvent = { ok: false, skipped: false, error: metaErr.message || "Error enviando evento a Meta" };
      }
    }

    return res.json({ ok: true, leadQuality, label: getLeadQualityLabel(leadQuality), metaLeadEvent });
  } catch (err) {
    console.error("ERROR /api/deals/:id/lead-quality PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando calidad de lead" });
  }
});

app.put("/api/deals/:id/owner", authRequired, async (req, res) => {
  try {
    if (!(isAdmin(req.authUser) || isBackoffice(req.authUser))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para cambiar owner" });
    }

    const id = req.params.id;
    const owner = req.body && typeof req.body.owner === "string" ? req.body.owner : "";
    const dealRef = db.collection("deals").doc(id);
    const dealSnap = await dealRef.get();

    if (!dealSnap.exists) {
      return res.status(404).json({ ok: false, error: "Trato no encontrado" });
    }

    const deal = dealSnap.data() || {};
    const contactId = deal.contactId || "";

    if (!contactId) {
      await dealRef.update({ owner, updatedAt: new Date() });
      return res.json({ ok: true, syncedDeals: 1, contactUpdated: false });
    }

    const result = await syncOwnerForContactAndDeals(contactId, owner);
    return res.json({ ok: true, syncedDeals: result.updatedDeals, contactUpdated: true });
  } catch (err) {
    console.error("ERROR /api/deals/:id/owner PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando owner" });
  }
});

app.put("/api/deals/:id/due-date", authRequired, async (req, res) => {
  try {
    const id = req.params.id;
    const dueDate = req.body && typeof req.body.dueDate === "string" ? req.body.dueDate : "";
    const dealRef = db.collection("deals").doc(id);
    const dealSnap = await dealRef.get();

    if (!dealSnap.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });

    const deal = dealSnap.data() || {};
    if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para editar este trato" });
    }

    await dealRef.update({ dueDate, updatedAt: new Date() });
    return res.json({ ok: true });
  } catch (err) {
    console.error("ERROR /api/deals/:id/due-date PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando vencimiento" });
  }
});

app.put("/api/deals/:id/value", authRequired, async (req, res) => {
  try {
    const id = req.params.id;
    const value = Number((req.body && req.body.value) || 0);
    const dealRef = db.collection("deals").doc(id);
    const dealSnap = await dealRef.get();

    if (!dealSnap.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });

    const deal = dealSnap.data() || {};
    if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para editar este trato" });
    }

    await dealRef.update({ value, updatedAt: new Date() });
    return res.json({ ok: true, value });
  } catch (err) {
    console.error("ERROR /api/deals/:id/value PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando valor" });
  }
});

app.put("/api/deals/:id/notes", authRequired, async (req, res) => {
  try {
    const id = req.params.id;
    const notes = req.body && typeof req.body.notes === "string" ? req.body.notes.trim() : "";
    const dealRef = db.collection("deals").doc(id);
    const dealSnap = await dealRef.get();

    if (!dealSnap.exists) {
      return res.status(404).json({ ok: false, error: "Trato no encontrado" });
    }

    const deal = dealSnap.data() || {};
    if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para editar este trato" });
    }

    const noteUser = (req.authUser && (req.authUser.email || req.authUser.name)) || "crm";
    const dedupKey = `${String(noteUser || "").trim().toLowerCase()}::${notes}`;
    const now = Date.now();
    let shouldWriteHistory = !!notes;
    let deduped = false;

    await db.runTransaction(async (tx) => {
      const snap = await tx.get(dealRef);
      if (!snap.exists) {
        throw new Error("Trato no encontrado");
      }

      const current = snap.data() || {};
      const lastKey = String(current.lastNoteSaveKey || "");
      const lastAtMillis = timestampToMillis(current.lastNoteSaveAt);
      const sameWindow = !!notes && lastKey === dedupKey && lastAtMillis && (now - lastAtMillis) <= NOTE_SAVE_DEDUP_WINDOW_MS;
      const sameNotes = String(current.notes || "").trim() === notes;

      if (sameWindow || sameNotes) {
        deduped = true;
        shouldWriteHistory = false;
        tx.update(dealRef, {
          notes,
          updatedAt: new Date(),
          lastNoteSaveKey: dedupKey,
          lastNoteSaveAt: new Date()
        });
        return;
      }

      tx.update(dealRef, {
        notes,
        updatedAt: new Date(),
        lastNoteSaveKey: dedupKey,
        lastNoteSaveAt: new Date()
      });
    });

    if (shouldWriteHistory) {
      await dealRef.collection("notes").add({
        note: notes,
        user: noteUser,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
    }

    return res.json({ ok: true, deduped });
  } catch (err) {
    console.error("ERROR /api/deals/:id/notes PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando notas" });
  }
});

app.get("/api/deals/:id/note-history", authRequired, async (req, res) => {
  try {
    const id = String(req.params.id || "").trim();
    const dealRef = db.collection("deals").doc(id);

    const snap = await dealRef
      .collection("notes")
      .orderBy("createdAt", "desc")
      .limit(50)
      .get();

    const history = snap.docs.map((d) => {
      const v = d.data() || {};
      return {
        note: v.note || "",
        user: v.user || "",
        createdAt: v.createdAt || null
      };
    });

    return res.json({ ok: true, history });

  } catch (err) {
    console.error("ERROR note-history:", err);
    return res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

// =====================================================
// API - HISTORIAL DE NOTAS DEL TRATO
// =====================================================

app.get("/api/deals/:id/notes/history", authRequired, async (req, res) => {
  try {

    const dealId = req.params.id;

    const snap = await db
      .collection("deals")
      .doc(dealId)
      .collection("notes")
      .orderBy("createdAt", "desc")
      .get();

    const notes = snap.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));

    return res.json({
      ok: true,
      notes
    });

  } catch (err) {

    console.error("ERROR history notes:", err);

    return res.status(500).json({
      ok: false,
      error: err.message
    });

  }
});






app.put("/api/deals/:id", authRequired, async (req, res) => {
  try {
    const id = req.params.id;
    const dealRef = db.collection("deals").doc(id);
    const snap = await dealRef.get();

    if (!snap.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });

    const current = snap.data() || {};
    if (!(await canEditOwner(req.authUser, current.owner || ""))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para editar este trato" });
    }

    const { title, value, dueDate, notes, stage, dealType, leadQuality } = req.body || {};
    const payload = { updatedAt: new Date() };

    if (typeof title === "string") payload.title = title.trim();
    if (typeof value !== "undefined") payload.value = Number(value || 0);
    if (typeof dueDate === "string") payload.dueDate = dueDate;
    if (typeof notes === "string") payload.notes = notes;
    if (typeof stage === "string" && PIPELINE_STAGES.includes(stage)) payload.stage = stage;
    if (typeof dealType === "string") payload.dealType = normalizeDealType(dealType);
    if (typeof leadQuality === "string") payload.leadQuality = normalizeLeadQuality(leadQuality);

    if (Object.prototype.hasOwnProperty.call(payload, "stage")) {
      Object.assign(payload, buildProductionEligibilityFields({ ...current, ...payload }));
    }
    await dealRef.update(payload);
    return res.json({ ok: true });
  } catch (err) {
    console.error("ERROR /api/deals/:id PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error editando trato" });
  }
});

app.delete("/api/deals/:id", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) return res.status(403).json({ ok: false, error: "Solo admin puede borrar tratos" });

    await db.collection("deals").doc(req.params.id).delete();
    await incrementStoredTotal("deals_total", -1);
    return res.json({ ok: true });
  } catch (err) {
    console.error("ERROR /api/deals/:id DELETE:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error borrando trato" });
  }
});



// =====================================================
// BLOQUE 6E - API ARCHIVOS
// =====================================================

app.delete("/api/deals/:id/files/:fileId", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) return res.status(403).json({ ok: false, error: "Solo admin puede borrar adjuntos" });

    const dealId = req.params.id;
    const fileId = req.params.fileId;
    const dealRef = db.collection("deals").doc(dealId);
    const dealSnap = await dealRef.get();

    if (!dealSnap.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });

    const deal = dealSnap.data() || {};
    const files = Array.isArray(deal.files) ? deal.files : [];
    const target = files.find((item) => item.id === fileId);

    if (!target) return res.status(404).json({ ok: false, error: "Archivo no encontrado" });

    if (target.objectPath) {
      const bucket = gcs.bucket(target.bucket || ATTACHMENTS_BUCKET);
      await bucket.file(target.objectPath).delete({ ignoreNotFound: true });
    }

    await dealRef.update({ files: files.filter((item) => item.id !== fileId), updatedAt: new Date() });
    return res.json({ ok: true });
  } catch (err) {
    console.error("ERROR /api/deals/:id/files/:fileId DELETE:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error borrando archivo" });
  }
});

app.post("/api/deals/:id/upload", authRequired, async (req, res) => {
  try {
    const dealId = req.params.id;
    const { fileName, mimeType, base64Data } = req.body || {};

    if (!fileName || !mimeType || !base64Data) {
      return res.status(400).json({ ok: false, error: "Faltan datos del archivo" });
    }

    if (!ALLOWED_UPLOAD_TYPES.includes(mimeType)) {
      return res.status(400).json({ ok: false, error: "Solo se permiten PDF, JPG y PNG" });
    }

    const buffer = Buffer.from(String(base64Data), "base64");
    if (!buffer || !buffer.length) {
      return res.status(400).json({ ok: false, error: "Archivo inválido" });
    }

    if (buffer.length > 10 * 1024 * 1024) {
      return res.status(400).json({ ok: false, error: "El archivo supera el límite de 10 MB" });
    }

    const dealRef = db.collection("deals").doc(dealId);
    const dealSnap = await dealRef.get();
    if (!dealSnap.exists) {
      return res.status(404).json({ ok: false, error: "Trato no encontrado" });
    }

    const dealData = dealSnap.data() || {};
    if (!canEditOwner(req.authUser, dealData.owner || "")) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para adjuntar archivos en este trato" });
    }

    const fileId = makeId("file");
    const safeName = sanitizeFilename(fileName || "archivo");
    const objectPath = `deals/${dealId}/${fileId}-${safeName}`;
    const bucket = getBucket();
    const gcsFile = bucket.file(objectPath);

    await gcsFile.save(buffer, {
      resumable: false,
      metadata: {
        contentType: mimeType,
        metadata: {
          dealId,
          fileId,
          originalName: safeName
        }
      }
    });

    const fileMeta = {
      id: fileId,
      name: safeName,
      mimeType: mimeType,
      size: buffer.length,
      bucket: ATTACHMENTS_BUCKET,
      objectPath,
      createdAt: new Date().toISOString()
    };

    const files = Array.isArray(dealData.files) ? dealData.files : [];
    files.push(fileMeta);
    await dealRef.update({ files, updatedAt: new Date() });

    return res.json({ ok: true, file: fileMeta });
  } catch (err) {
    console.error("ERROR /api/deals/:id/upload POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error subiendo archivo" });
  }
});

app.get("/api/deals/:id/files/:fileId/view", authRequired, async (req, res) => {
  try {
    const dealId = req.params.id;
    const fileId = req.params.fileId;
    const dealSnap = await db.collection("deals").doc(dealId).get();

    if (!dealSnap.exists) {
      return res.status(404).send("Trato no encontrado");
    }

    const deal = dealSnap.data() || {};
    if (!canSeeOwner(req.authUser, deal.owner || "")) {
      return res.status(403).send("No tenés permiso para ver este archivo");
    }

    const files = Array.isArray(deal.files) ? deal.files : [];
    const fileMeta = files.find((item) => item.id === fileId);

    if (!fileMeta || !fileMeta.objectPath) {
      return res.status(404).send("Archivo no encontrado");
    }

    const bucket = gcs.bucket(fileMeta.bucket || ATTACHMENTS_BUCKET);
    const gcsFile = bucket.file(fileMeta.objectPath);
    const [exists] = await gcsFile.exists();

    if (!exists) {
      return res.status(404).send("Archivo no encontrado en storage");
    }

    res.setHeader("Content-Type", fileMeta.mimeType || "application/octet-stream");
    res.setHeader("Content-Disposition", `inline; filename="${sanitizeFilename(fileMeta.name || "archivo")}"`);

    gcsFile.createReadStream().on("error", (err) => {
      console.error("STREAM ERROR /api/deals/:id/files/:fileId/view:", err);
      if (!res.headersSent) {
        res.status(500).send("Error leyendo archivo");
      }
    }).pipe(res);
  } catch (err) {
    console.error("ERROR /api/deals/:id/files/:fileId/view GET:", err);
    return res.status(500).send(err.message || "Error viendo archivo");
  }
});

// =====================================================
// BLOQUE 6F - API KPI / REPORTES
// =====================================================

app.get("/api/kpi/targets", authRequired, async (req, res) => {
  try {
    if (!canViewKpiReports(req.authUser)) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para ver objetivos KPI" });
    }

    const requestedUserId = String(req.query.userId || "").trim();
    const effectiveUserId = isSeller(req.authUser) ? req.authUser.id : requestedUserId;

    if (!effectiveUserId) {
      return res.status(400).json({ ok: false, error: "Falta userId" });
    }

    if (isSeller(req.authUser) && effectiveUserId !== req.authUser.id) {
      return res.status(403).json({ ok: false, error: "Solo podés ver tus propios objetivos" });
    }

    const period = getPeriodInfo(req.query.periodType || "weekly", req.query.referenceDate || "");
    const docId = buildKpiTargetDocId(effectiveUserId, period.periodType, period.periodKey);
    const snap = await db.collection("kpi_targets").doc(docId).get();

    if (!snap.exists) {
      return res.json({ ok: true, target: null, period });
    }

    const data = snap.data() || {};
    return res.json({
      ok: true,
      period,
      target: {
        id: snap.id,
        userId: data.userId || "",
        periodType: normalizePeriodType(data.periodType || "weekly"),
        periodKey: data.periodKey || "",
        targets: sanitizeTargets(data.targets || {}),
        createdAt: data.createdAt || null,
        updatedAt: data.updatedAt || null
      }
    });
  } catch (err) {
    console.error("ERROR /api/kpi/targets GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error obteniendo objetivo KPI" });
  }
});

app.post("/api/kpi/targets", authRequired, async (req, res) => {
  try {
    if (!canManageKpiTargets(req.authUser)) {
      return res.status(403).json({ ok: false, error: "Solo admin puede gestionar objetivos KPI" });
    }

    const userId = String((req.body && req.body.userId) || "").trim();
    if (!userId) {
      return res.status(400).json({ ok: false, error: "Falta userId" });
    }

    const userSnap = await db.collection("users").doc(userId).get();
    if (!userSnap.exists) {
      return res.status(404).json({ ok: false, error: "Usuario no encontrado" });
    }

    const period = getPeriodInfo((req.body && req.body.periodType) || "weekly", (req.body && req.body.referenceDate) || "");
    const targets = sanitizeTargets(req.body && req.body.targets ? req.body.targets : {});
    const docId = buildKpiTargetDocId(userId, period.periodType, period.periodKey);
    const ref = db.collection("kpi_targets").doc(docId);
    const prev = await ref.get();

    const payload = {
      userId,
      periodType: period.periodType,
      periodKey: period.periodKey,
      startDate: period.startDate,
      endDate: period.endDate,
      targets,
      updatedAt: new Date()
    };

    if (!prev.exists) {
      payload.createdAt = new Date();
    }

    await ref.set(payload, { merge: true });

    return res.json({
      ok: true,
      target: {
        id: docId,
        userId,
        periodType: period.periodType,
        periodKey: period.periodKey,
        startDate: period.startDate,
        endDate: period.endDate,
        targets
      }
    });
  } catch (err) {
    console.error("ERROR /api/kpi/targets POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error guardando objetivo KPI" });
  }
});

app.delete("/api/kpi/targets/:id", authRequired, async (req, res) => {
  try {
    if (!canManageKpiTargets(req.authUser)) {
      return res.status(403).json({ ok: false, error: "Solo admin puede borrar objetivos KPI" });
    }

    await db.collection("kpi_targets").doc(req.params.id).delete();
    return res.json({ ok: true });
  } catch (err) {
    console.error("ERROR /api/kpi/targets/:id DELETE:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error borrando objetivo KPI" });
  }
});

app.get("/api/kpi/summary", authRequired, async (req, res) => {
  try {
    if (!canViewKpiReports(req.authUser)) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para ver reportes KPI" });
    }

    const period = getPeriodInfo(req.query.periodType || "weekly", req.query.referenceDate || "");
    const requestedUserId = String(req.query.userId || "").trim();

    const users = await getUsersList();
    let visibleUsers = users;

    if (isSeller(req.authUser)) {
      visibleUsers = users.filter((u) => u.id === req.authUser.id);
    } else if (requestedUserId) {
      visibleUsers = users.filter((u) => u.id === requestedUserId);
    }

    const targetIds = visibleUsers.map((u) => buildKpiTargetDocId(u.id, period.periodType, period.periodKey));
    const targetDocs = await Promise.all(
      targetIds.map((id) => db.collection("kpi_targets").doc(id).get())
    );

    const targetsMap = {};
    targetDocs.forEach((snap) => {
      if (snap.exists) {
        const data = snap.data() || {};
        targetsMap[data.userId || ""] = sanitizeTargets(data.targets || {});
      }
    });

    const rowsMap = {};
    visibleUsers.forEach((user) => {
      rowsMap[user.id] = {
        userId: user.id,
        userName: user.name || user.email || "Sin nombre",
        userEmail: user.email || "",
        periodType: period.periodType,
        periodKey: period.periodKey,
        startDate: period.startDate,
        endDate: period.endDate,
        targets: targetsMap[user.id] || emptyDealTypeTargets(),
        reals: emptyDealTypeTargets(),
        leadQualityCounts: emptyLeadQualityCounts(),
        totalLeadQuality: 0,
        totalTarget: 0,
        totalReal: 0
      };
    });

    const dealsSnap = await db.collection("deals").get();
    dealsSnap.docs.forEach((doc) => {
      const deal = doc.data() || {};
      const owner = String(deal.owner || "").trim().toLowerCase();
      const createdIso = docDateToISO(deal.createdAt || "");
      if (!createdIso) return;
      if (!isDateWithinISO(createdIso, period.startDate, period.endDate)) return;

      const targetUser = visibleUsers.find((u) => String(u.email || "").trim().toLowerCase() === owner);
      if (!targetUser) return;

      const row = rowsMap[targetUser.id];
      if (!row) return;

      const type = normalizeDealType(deal.dealType || "LCL_PROPIO");
      row.reals[type] = Number(row.reals[type] || 0) + 1;

      const quality = normalizeLeadQuality(deal.leadQuality || "NO_RESPONDE");
      row.leadQualityCounts[quality] = Number(row.leadQualityCounts[quality] || 0) + 1;
      row.totalLeadQuality = Number(row.totalLeadQuality || 0) + 1;
    });

    const rows = Object.keys(rowsMap).map((userId) => {
      const row = rowsMap[userId];
      row.totalTarget = sumTargets(row.targets);
      row.totalReal = sumTargets(row.reals);
      return row;
    });

    return res.json({
      ok: true,
      period,
      rows
    });
  } catch (err) {
    console.error("ERROR /api/kpi/summary GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error generando resumen KPI" });
  }
});

// =====================================================
// BLOQUE 6G - API HUB LINK POR TRATO
// =====================================================

app.get("/api/deals/:id/hub-link", authRequired, async (req, res) => {
  try {
    const dealId = String(req.params.id || "").trim();
    if (!dealId) {
      return res.status(400).json({
        ok: false,
        error: "Falta dealId"
      });
    }

    const dealRef = db.collection("deals").doc(dealId);
    const dealSnap = await dealRef.get();

    if (!dealSnap.exists) {
      return res.status(404).json({
        ok: false,
        found: false,
        error: "Trato no encontrado"
      });
    }

    const deal = dealSnap.data() || {};

    if (!(await canSeeOwner(req.authUser, deal.owner || ""))) {
      return res.status(403).json({
        ok: false,
        found: false,
        error: "No tenés permiso para ver este trato"
      });
    }

    const conversationsSnap = await dbInbox
      .collection("conversations")
      .where("dealId", "==", dealId)
      .get();

    if (!conversationsSnap.empty) {
      const conversations = conversationsSnap.docs.map((doc) => ({
        id: doc.id,
        ...(doc.data() || {})
      }));

      conversations.sort((a, b) => {
        const aMillis = getDocCreatedAtMillis(a) || 0;
        const bMillis = getDocCreatedAtMillis(b) || 0;
        return bMillis - aMillis;
      });

      const selected = conversations[0];
      const conversationId = String(selected.id || "").trim();

      if (conversationId) {
        return res.json({
          ok: true,
          found: true,
          conversationId,
          url: `${HUB_BASE_URL}/?conversationId=${encodeURIComponent(conversationId)}`
        });
      }
    }

    return res.json({
      ok: true,
      found: false,
      error: "No se encontró conversación en HUB para este trato"
    });
  } catch (err) {
    console.error("ERROR /api/deals/:id/hub-link GET:", err);
    return res.status(500).json({
      ok: false,
      found: false,
      error: err.message || "Error buscando conversación en HUB"
    });
  }
});


// =====================================================
// BLOQUE 6H - API SEGUIMIENTOS POR VENCIMIENTO
// =====================================================

function normalizeWhatsappPhoneForDue(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  const keepPlus = raw.startsWith("+") ? "+" : "";
  const digits = raw.replace(/[^0-9]/g, "");
  return digits ? `${keepPlus}${digits}` : "";
}

function isValidWhatsappPhoneForDue(value) {
  const clean = normalizeWhatsappPhoneForDue(value);
  const digits = clean.replace(/[^0-9]/g, "");
  return digits.length >= 8 && digits.length <= 16;
}

function normalizeOutboundLineForDue(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  const noWa = raw.replace(/^whatsapp:/i, "").trim();
  const keepPlus = noWa.startsWith("+") ? "+" : "";
  const digits = noWa.replace(/[^0-9]/g, "");
  return digits ? `${keepPlus}${digits}` : "";
}

function extractLineInfoFromDueObject(obj, sourceLabel) {
  if (!obj || typeof obj !== "object") return null;
  const candidates = [
    "preferredLineId", "lineId", "inboundTo", "lastLineId", "outboundLineId",
    "whatsappLineId", "waLineId", "twilioLineId", "assignedLineId", "sourceLineId",
    "fromLineId", "linePhone", "waFrom", "from", "twilioFrom", "toLineId"
  ];
  for (const key of candidates) {
    const val = normalizeOutboundLineForDue(obj[key]);
    if (val) return { lineId: val, inboundTo: val, source: sourceLabel + "." + key };
  }
  const automation = obj.messageAutomation && typeof obj.messageAutomation === "object" ? obj.messageAutomation : null;
  if (automation) {
    for (const key of candidates) {
      const val = normalizeOutboundLineForDue(automation[key]);
      if (val) return { lineId: val, inboundTo: val, source: sourceLabel + ".messageAutomation." + key };
    }
  }
  return null;
}

function getConversationLineInfoForDue(conversation, sourceLabel = "conversation") {
  if (!conversation || typeof conversation !== "object") return null;
  const candidates = ["lineId", "inboundTo", "twilioFrom", "outboundLineId", "linePhone", "toLineId"];
  for (const key of candidates) {
    const val = normalizeOutboundLineForDue(conversation[key]);
    if (val) return { lineId: val, inboundTo: val, source: sourceLabel + "." + key };
  }
  return null;
}

function getCreatedMillisForDueLine(docLike) {
  const data = docLike || {};
  return getDocCreatedAtMillis(data) || getDocCreatedAtMillis({ createdAt: data.lastMessageAt }) || 0;
}

async function getLineInfoMapForDueDeals(deals, contactsMap) {
  const lineMap = new Map();
  const safeDeals = Array.isArray(deals) ? deals : [];

  safeDeals.forEach((deal) => {
    const contact = contactsMap && contactsMap.get(String(deal && deal.contactId || "").trim());
    const line = extractLineInfoFromDueObject(deal, "deal") || extractLineInfoFromDueObject(contact, "contact");
    if (line && deal && deal.id) lineMap.set(String(deal.id), line);
  });

  const missingDealIds = safeDeals.map((deal) => String(deal && deal.id || "").trim()).filter((id) => id && !lineMap.has(id));
  for (const chunk of chunkArray(missingDealIds, 30)) {
    if (!chunk.length) continue;
    try {
      const snap = await dbInbox.collection("conversations").where("dealId", "in", chunk).get();
      const byDeal = new Map();
      snap.docs.forEach((doc) => {
        const conv = { id: doc.id, ...(doc.data() || {}) };
        const dealId = String(conv.dealId || "").trim();
        const line = getConversationLineInfoForDue(conv, "conversationByDeal");
        if (!dealId || !line) return;
        const prev = byDeal.get(dealId);
        if (!prev || getCreatedMillisForDueLine(conv) > getCreatedMillisForDueLine(prev.conv)) byDeal.set(dealId, { conv, line });
      });
      byDeal.forEach((val, dealId) => { if (!lineMap.has(dealId)) lineMap.set(dealId, val.line); });
    } catch (err) {
      console.warn("No se pudo resolver línea por dealId:", err.message || err);
    }
  }

  const missingContacts = safeDeals
    .filter((deal) => !lineMap.has(String(deal && deal.id || "")))
    .map((deal) => String(deal && deal.contactId || "").trim())
    .filter(Boolean);
  const uniqueContactIds = Array.from(new Set(missingContacts));
  const contactLineMap = new Map();
  for (const chunk of chunkArray(uniqueContactIds, 30)) {
    if (!chunk.length) continue;
    try {
      const snap = await dbInbox.collection("conversations").where("contactId", "in", chunk).get();
      snap.docs.forEach((doc) => {
        const conv = { id: doc.id, ...(doc.data() || {}) };
        const contactId = String(conv.contactId || "").trim();
        const line = getConversationLineInfoForDue(conv, "conversationByContact");
        if (!contactId || !line) return;
        const prev = contactLineMap.get(contactId);
        if (!prev || getCreatedMillisForDueLine(conv) > getCreatedMillisForDueLine(prev.conv)) contactLineMap.set(contactId, { conv, line });
      });
    } catch (err) {
      console.warn("No se pudo resolver línea por contactId:", err.message || err);
    }
  }

  safeDeals.forEach((deal) => {
    const dealId = String(deal && deal.id || "").trim();
    if (!dealId || lineMap.has(dealId)) return;
    const contactId = String(deal && deal.contactId || "").trim();
    const found = contactLineMap.get(contactId);
    if (found && found.line) lineMap.set(dealId, found.line);
  });

  return lineMap;
}

async function resolveLineInfoForDueDeal(deal, contact) {
  const direct = extractLineInfoFromDueObject(deal, "deal") || extractLineInfoFromDueObject(contact, "contact");
  if (direct && direct.lineId) return direct;
  const map = await getLineInfoMapForDueDeals([deal], new Map([[String(deal && deal.contactId || "").trim(), contact || null]]));
  return map.get(String(deal && deal.id || "")) || null;
}

function getDueDealStatus({ deal, contact, phone, lineInfo }) {
  if (!String(deal && deal.contactId || "").trim()) {
    return { status: "no_contact", canSend: false, blockReason: "El trato no tiene contacto asociado" };
  }
  if (!contact) {
    return { status: "no_contact", canSend: false, blockReason: "No se encontró el contacto asociado" };
  }
  if (!phone) {
    return { status: "no_phone", canSend: false, blockReason: "Falta teléfono en el contacto" };
  }
  if (!isValidWhatsappPhoneForDue(phone)) {
    return { status: "invalid_phone", canSend: false, blockReason: "Teléfono inválido para WhatsApp" };
  }
  if (!lineInfo || !normalizeOutboundLineForDue(lineInfo.lineId || lineInfo.inboundTo)) {
    return { status: "no_line", canSend: false, blockReason: "Sin línea WhatsApp asignada" };
  }
  const lastStatus = String(deal && deal.messageAutomation && deal.messageAutomation.lastStatus || "").trim();
  if (lastStatus === "sent") {
    return { status: "sent", canSend: true, blockReason: "Tiene envíos previos. Se puede reenviar" };
  }
  if (lastStatus === "error") {
    return { status: "error", canSend: true, blockReason: String(deal.messageAutomation.lastError || "Error anterior") };
  }
  return { status: "ready", canSend: true, blockReason: "" };
}

function serializeDueTimestamp(value) {
  if (!value) return "";
  if (value instanceof Date) return value.toISOString();
  if (typeof value.toDate === "function") return value.toDate().toISOString();
  if (typeof value.toMillis === "function") return new Date(value.toMillis()).toISOString();
  if (typeof value._seconds === "number") return new Date(value._seconds * 1000).toISOString();
  if (typeof value.seconds === "number") return new Date(value.seconds * 1000).toISOString();
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString();
}

async function getContactsMapForDeals(deals) {
  const ids = Array.from(new Set(
    (Array.isArray(deals) ? deals : [])
      .map((deal) => String(deal && deal.contactId || "").trim())
      .filter(Boolean)
  ));
  const contactsMap = new Map();
  for (const chunk of chunkArray(ids, 100)) {
    const refs = chunk.map((id) => db.collection("contacts").doc(id));
    const docs = refs.length ? await db.getAll(...refs) : [];
    docs.forEach((doc) => {
      contactsMap.set(doc.id, doc.exists ? { id: doc.id, ...(doc.data() || {}) } : null);
    });
  }
  return contactsMap;
}

function buildDueDealRow(deal, contact, lineInfo) {
  const phone = normalizeWhatsappPhoneForDue(contact && contact.phone);
  const safeLine = lineInfo || extractLineInfoFromDueObject(deal, "deal") || extractLineInfoFromDueObject(contact, "contact") || null;
  const statusInfo = getDueDealStatus({ deal, contact, phone, lineInfo: safeLine });
  const automation = deal && deal.messageAutomation && typeof deal.messageAutomation === "object" ? deal.messageAutomation : {};
  return {
    id: String(deal && deal.id || ""),
    title: String(deal && deal.title || ""),
    contactId: String(deal && deal.contactId || ""),
    contactName: String((contact && contact.name) || (deal && deal.contactName) || ""),
    company: String(contact && contact.company || ""),
    phone,
    lineId: String(safeLine && safeLine.lineId || ""),
    inboundTo: String(safeLine && safeLine.inboundTo || safeLine && safeLine.lineId || ""),
    lineSource: String(safeLine && safeLine.source || ""),
    email: String(contact && contact.email || ""),
    stage: String(deal && deal.stage || "No responde"),
    owner: String(deal && deal.owner || ""),
    dueDate: String(deal && deal.dueDate || ""),
    dealType: normalizeDealType(deal && deal.dealType || "LCL_PROPIO"),
    dealTypeLabel: getDealTypeLabel(deal && deal.dealType || "LCL_PROPIO"),
    value: Number(deal && deal.value || 0),
    notes: String(deal && deal.notes || ""),
    status: statusInfo.status,
    canSend: !!statusInfo.canSend,
    blockReason: statusInfo.blockReason || "",
    lastTemplateSid: String(automation.lastTemplateSid || ""),
    lastTemplateName: String(automation.lastTemplateName || ""),
    lastConversationId: String(automation.lastConversationId || ""),
    lastMessageSid: String(automation.lastMessageSid || ""),
    lastLogId: String(automation.lastLogId || ""),
    lastStatus: String(automation.lastStatus || ""),
    lastError: String(automation.lastError || ""),
    lastSentAt: serializeDueTimestamp(automation.lastSentAt || automation.lastAttemptAt || ""),
    sentCount: Number(automation.sentCount || 0)
  };
}

function summarizeDueRows(rows) {
  const safeRows = Array.isArray(rows) ? rows : [];
  return {
    total: safeRows.length,
    ready: safeRows.filter((row) => !!row.canSend).length,
    sent: safeRows.filter((row) => Number(row.sentCount || 0) > 0 || row.status === "sent").length,
    noPhone: safeRows.filter((row) => row.status === "no_phone" || row.status === "no_contact").length,
    invalidPhone: safeRows.filter((row) => row.status === "invalid_phone").length,
    noLine: safeRows.filter((row) => row.status === "no_line").length
  };
}

function groupDueRowsByStage(rows) {
  const groups = {};
  (Array.isArray(rows) ? rows : []).forEach((row) => {
    const stage = String(row.stage || "No responde");
    if (!groups[stage]) groups[stage] = [];
    groups[stage].push(row);
  });
  Object.keys(groups).forEach((stage) => {
    groups[stage].sort((a, b) => {
      const ad = String(a.dueDate || "9999-12-31");
      const bd = String(b.dueDate || "9999-12-31");
      if (ad !== bd) return ad < bd ? -1 : 1;
      return String(a.title || "").localeCompare(String(b.title || ""), "es", { sensitivity: "base" });
    });
  });
  const ordered = {};
  PIPELINE_STAGES.forEach((stage) => {
    if (groups[stage]) ordered[stage] = groups[stage];
  });
  Object.keys(groups).sort().forEach((stage) => {
    if (!ordered[stage]) ordered[stage] = groups[stage];
  });
  return ordered;
}

async function fetchDueDealDocs({ mode, limit, stageFilter, ownerFilter, dealTypeFilter }) {
  const today = getTodayISOInBuenosAires();
  const todayDate = isoToDateUTC(today);
  const prox7 = dateToISOUTC(addDaysUTC(todayDate, 7));
  const hardLimit = Math.max(1, Math.min(250, Number(limit || 100)));

  function applyEqualityFilters(query, includeStage = true, includeOwner = true, includeDealType = true) {
    if (includeStage && stageFilter) query = query.where("stage", "==", stageFilter);
    if (includeOwner && ownerFilter) query = query.where("owner", "==", ownerFilter);
    if (includeDealType && dealTypeFilter) query = query.where("dealType", "==", dealTypeFilter);
    return query;
  }

  async function runQuery(includeFilters = true) {
    let query = db.collection("deals");
    if (mode === "hoy") {
      query = query.where("dueDate", "==", today);
      query = applyEqualityFilters(query, includeFilters, includeFilters, includeFilters).limit(hardLimit);
    } else if (mode === "proximos_7") {
      query = query.where("dueDate", ">=", today).where("dueDate", "<=", prox7).orderBy("dueDate", "asc");
      query = applyEqualityFilters(query, includeFilters, includeFilters, includeFilters).limit(hardLimit);
    } else {
      query = query.where("dueDate", ">=", "1900-01-01").where("dueDate", "<", today).orderBy("dueDate", "asc");
      query = applyEqualityFilters(query, includeFilters, includeFilters, includeFilters).limit(hardLimit);
    }
    return await query.get();
  }

  try {
    const snap = await runQuery(true);
    return { docs: snap.docs, hasMore: snap.docs.length === hardLimit, usedFallback: false };
  } catch (err) {
    const code = Number(err && err.code);
    const msg = String(err && err.message || "");
    const missingIndex = code === 9 || /FAILED_PRECONDITION/i.test(msg) || /requires an index/i.test(msg);
    if (!missingIndex) throw err;

    // IMPORTANTE:
    // Si falta un índice compuesto, NO podemos caer a una consulta general de vencidos
    // y después filtrar stage en memoria, porque con limit=200 termina trayendo 200
    // vencidos generales y solo algunos de la etapa elegida.
    // En fallback usamos primero el filtro más selectivo disponible (stage/owner/tipo),
    // y recién después filtramos vencimiento en memoria.
    const fallbackScanLimit = Math.max(hardLimit, Math.min(2500, hardLimit * 15));
    let fallbackQuery = db.collection("deals");
    let fallbackScope = "general";

    if (stageFilter) {
      fallbackQuery = fallbackQuery.where("stage", "==", stageFilter);
      fallbackScope = "stage";
    } else if (ownerFilter) {
      fallbackQuery = fallbackQuery.where("owner", "==", ownerFilter);
      fallbackScope = "owner";
    } else if (dealTypeFilter) {
      fallbackQuery = fallbackQuery.where("dealType", "==", dealTypeFilter);
      fallbackScope = "dealType";
    } else if (mode === "hoy") {
      fallbackQuery = fallbackQuery.where("dueDate", "==", today);
      fallbackScope = "dueDate";
    } else if (mode === "proximos_7") {
      fallbackQuery = fallbackQuery.where("dueDate", ">=", today).where("dueDate", "<=", prox7).orderBy("dueDate", "asc");
      fallbackScope = "dueDate";
    } else {
      fallbackQuery = fallbackQuery.where("dueDate", ">=", "1900-01-01").where("dueDate", "<", today).orderBy("dueDate", "asc");
      fallbackScope = "dueDate";
    }

    const snap = await fallbackQuery.limit(fallbackScanLimit).get();
    let docs = snap.docs.filter((doc) => {
      const data = doc.data() || {};
      if (stageFilter && String(data.stage || "No responde") !== stageFilter) return false;
      if (ownerFilter && String(data.owner || "").trim().toLowerCase() !== ownerFilter) return false;
      if (dealTypeFilter && normalizeDealType(data.dealType || "LCL_PROPIO") !== dealTypeFilter) return false;
      const due = String(data.dueDate || "").trim();
      if (mode === "vencidos" && (!/^\d{4}-\d{2}-\d{2}$/.test(due) || due >= today)) return false;
      if (mode === "proximos_7" && (!/^\d{4}-\d{2}-\d{2}$/.test(due) || due < today || due > prox7)) return false;
      if (mode === "hoy" && due !== today) return false;
      return true;
    });

    docs = docs.sort((a, b) => {
      const ad = String((a.data() || {}).dueDate || "9999-12-31");
      const bd = String((b.data() || {}).dueDate || "9999-12-31");
      if (ad !== bd) return ad < bd ? -1 : 1;
      return String(a.id || "").localeCompare(String(b.id || ""));
    });

    return {
      docs: docs.slice(0, hardLimit),
      hasMore: docs.length > hardLimit || snap.docs.length === fallbackScanLimit,
      usedFallback: true,
      fallbackScope
    };
  }
}

function buildCoreHeaders(req, extra = {}) {
  const token = String(
    (req && req.headers && req.headers["x-auth-token"]) ||
    (req && req.query && req.query.token) ||
    ""
  ).trim();

  return {
    "Content-Type": "application/json",
    "x-user-id": String(req && req.authUser && req.authUser.id || ""),
    "x-auth-token": token,
    ...extra
  };
}

async function callCoreJson(req, path, options = {}) {
  if (typeof fetch !== "function") {
    throw new Error("Este runtime de Node no tiene fetch global. Usá Node 18+ o agregá un cliente HTTP.");
  }
  const base = String(CORE_BASE_URL || "").replace(/\/$/, "");
  if (!base) throw new Error("Falta configurar CORE_BASE_URL en el servicio CRM");

  const response = await fetch(base + path, {
    ...options,
    headers: {
      ...buildCoreHeaders(req),
      ...(options.headers || {})
    }
  });
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : {}; } catch (e) { data = { raw: text }; }
  if (!response.ok || (data && data.ok === false)) {
    const detail = data && (data.error || data.details || data.raw) ? (data.error || data.details || data.raw) : `HTTP ${response.status}`;
    throw new Error(String(detail || "Error llamando a CORE/HUB"));
  }
  return data;
}

function formatDueNoteDateForCRM(dateValue) {
  const date = dateValue instanceof Date ? dateValue : new Date();
  try {
    return new Intl.DateTimeFormat("es-AR", {
      timeZone: "America/Argentina/Buenos_Aires",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    }).format(date);
  } catch (e) {
    return date.toISOString();
  }
}

function getDatePlusDaysISOInBuenosAires(baseDate = new Date(), days = 7) {
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Argentina/Buenos_Aires",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  });
  const parts = formatter.formatToParts(baseDate);
  const y = parts.find((p) => p.type === "year")?.value;
  const m = parts.find((p) => p.type === "month")?.value;
  const d = parts.find((p) => p.type === "day")?.value;
  const utc = new Date(Date.UTC(Number(y), Number(m) - 1, Number(d) + Number(days || 0)));
  return utc.toISOString().slice(0, 10);
}

function normalizeNextDueDateForDue(value, baseDate = new Date()) {
  const clean = String(value || "").trim();
  if (!clean) return getDatePlusDaysISOInBuenosAires(baseDate, 7);
  if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) return clean;
  const parsed = new Date(clean);
  if (!Number.isNaN(parsed.getTime())) return parsed.toISOString().slice(0, 10);
  return getDatePlusDaysISOInBuenosAires(baseDate, 7);
}

function buildAutomaticMessageNoteForDue({ templateName, contentSid, dueDate, sentAt, sentCount, campaignName, nextDueDate, outboundLineId, outboundLineSource }) {
  const parts = [
    `MSJ AUTOMATICO ENVIADO EL ${formatDueNoteDateForCRM(sentAt)}`,
    campaignName ? `Campaña: ${campaignName}` : "",
    templateName ? `Plantilla: ${templateName}` : `Plantilla SID: ${contentSid || ""}`,
    dueDate ? `Vencimiento anterior del trato: ${dueDate}` : "",
    nextDueDate ? `Nuevo vencimiento del trato: ${nextDueDate}` : "",
    outboundLineId ? `Línea usada: ${outboundLineId}` : "",
    outboundLineSource ? `Origen línea: ${outboundLineSource}` : "",
    Number(sentCount || 0) ? `Cantidad de envíos registrados en este trato: ${Number(sentCount || 0)}` : "",
    "Enviado desde: Centro de Vencimientos"
  ].filter(Boolean);
  return parts.join("\n");
}


app.get("/api/due-templates", authRequired, async (req, res) => {
  try {
    const data = await callCoreJson(req, "/api/templates", { method: "GET" });
    const templates = Array.isArray(data.templates) ? data.templates : [];
    return res.json({ ok: true, templates });
  } catch (err) {
    console.error("ERROR /api/due-templates GET:", err);
    const raw = String(err.message || "No se pudieron cargar plantillas aprobadas");
    const hint = raw.toLowerCase().includes("unauthorized")
      ? "CORE/HUB respondió unauthorized. Verificar CORE_BASE_URL y que la sesión del usuario sea válida en el HUB."
      : raw;
    return res.status(500).json({ ok: false, error: hint });
  }
});

app.get("/api/due-templates/:sid/preview", authRequired, async (req, res) => {
  try {
    const sid = String(req.params.sid || "").trim();
    if (!sid) return res.status(400).json({ ok: false, error: "Falta plantilla" });
    const data = await callCoreJson(req, `/api/templates/${encodeURIComponent(sid)}/preview`, { method: "GET" });
    return res.json({ ok: true, template: data.template || data });
  } catch (err) {
    console.error("ERROR /api/due-templates/:sid/preview GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "No se pudo cargar preview de plantilla" });
  }
});

app.get("/api/due-deals", authRequired, adminOnly, async (req, res) => {
  try {
    const modeRaw = String(req.query.mode || "vencidos").trim();
    const mode = ["vencidos", "hoy", "proximos_7"].includes(modeRaw) ? modeRaw : "vencidos";
    const limit = Math.max(1, Math.min(200, Number(req.query.limit || 100)));
    const stageFilter = String(req.query.stage || "").trim();
    const ownerFilter = String(req.query.owner || "").trim().toLowerCase();
    const dealTypeRaw = String(req.query.dealType || "").trim();
    const dealTypeFilter = dealTypeRaw ? normalizeDealType(dealTypeRaw) : "";
    const q = String(req.query.q || "").trim().toLowerCase();
    const sendState = String(req.query.sendState || "").trim().toLowerCase();

    const visibleOwnerEmails = await getVisibleOwnerEmails(req.authUser);
    if (ownerFilter && !(await canSeeOwner(req.authUser, ownerFilter))) {
      return res.status(403).json({ ok: false, error: "No tenés permiso para ver ese owner" });
    }

    const result = await fetchDueDealDocs({ mode, limit, stageFilter, ownerFilter, dealTypeFilter });
    let deals = result.docs.map((doc) => ({ id: doc.id, ...(doc.data() || {}) }));

    if (visibleOwnerEmails !== null) {
      const allowed = new Set(visibleOwnerEmails.map((email) => String(email || "").trim().toLowerCase()).filter(Boolean));
      deals = deals.filter((deal) => allowed.has(String(deal.owner || "").trim().toLowerCase()));
    }

    if (q) {
      deals = deals.filter((deal) => [deal.title, deal.contactName, deal.owner, deal.notes, deal.stage].join(" ").toLowerCase().includes(q));
    }

    const contactsMap = await getContactsMapForDeals(deals);
    const lineMap = await getLineInfoMapForDueDeals(deals, contactsMap);
    let rows = deals.map((deal) => buildDueDealRow(deal, contactsMap.get(String(deal.contactId || "").trim()) || null, lineMap.get(String(deal.id || "")) || null));

    if (sendState) {
      rows = rows.filter((row) => {
        const sentCount = Number(row.sentCount || 0) || 0;
        if (sendState === "ready") return !!row.canSend && sentCount <= 0 && row.status !== "sent";
        if (sendState === "resend") return !!row.canSend && (sentCount > 0 || row.status === "sent");
        if (sendState === "blocked") return !row.canSend;
        return true;
      });
    }

    rows.sort((a, b) => {
      const ad = String(a.dueDate || "9999-12-31");
      const bd = String(b.dueDate || "9999-12-31");
      if (ad !== bd) return ad < bd ? -1 : 1;
      return String(a.stage || "").localeCompare(String(b.stage || ""), "es", { sensitivity: "base" });
    });

    return res.json({
      ok: true,
      mode,
      deals: rows,
      groups: groupDueRowsByStage(rows),
      summary: summarizeDueRows(rows),
      limit,
      sendState,
      hasMore: !!result.hasMore,
      usedFallback: !!result.usedFallback,
      fallbackScope: result.fallbackScope || "",
      today: getTodayISOInBuenosAires(),
      stages: PIPELINE_STAGES,
      dealTypes: DEAL_TYPES
    });
  } catch (err) {
    console.error("ERROR /api/due-deals GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error listando vencimientos" });
  }
});

app.get("/api/due-deals/:dealId/message-logs", authRequired, adminOnly, async (req, res) => {
  try {
    const dealId = String(req.params.dealId || "").trim();
    const limit = Math.max(1, Math.min(50, Number(req.query.limit || 10)));
    if (!dealId) return res.status(400).json({ ok: false, error: "Falta dealId" });

    const dealDoc = await db.collection("deals").doc(dealId).get();
    if (!dealDoc.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });

    const deal = { id: dealDoc.id, ...(dealDoc.data() || {}) };
    if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
      return res.status(403).json({ ok: false, error: "Sin permiso sobre el trato" });
    }

    const snap = await db.collection("deals")
      .doc(dealId)
      .collection("message_logs")
      .orderBy("createdAt", "desc")
      .limit(limit)
      .get();

    const items = snap.docs.map((doc) => {
      const data = doc.data() || {};
      return {
        id: doc.id,
        type: String(data.type || ""),
        source: String(data.source || ""),
        status: String(data.status || ""),
        sentAt: serializeDueTimestamp(data.sentAt || ""),
        createdAt: serializeDueTimestamp(data.createdAt || ""),
        sentBy: String(data.sentBy || ""),
        templateSid: String(data.templateSid || ""),
        templateName: String(data.templateName || ""),
        dueDate: String(data.dueDate || ""),
        phone: String(data.phone || ""),
        lineId: String(data.lineId || ""),
        inboundTo: String(data.inboundTo || data.lineId || ""),
        lineSource: String(data.lineSource || ""),
        conversationId: String(data.conversationId || ""),
        messageSid: String(data.messageSid || ""),
        sendNumber: Number(data.sendNumber || 0) || 0
      };
    });

    return res.json({ ok: true, dealId, items });
  } catch (err) {
    console.error("ERROR /api/due-deals/:dealId/message-logs GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error leyendo historial de mensajes" });
  }
});


async function processOneDueTemplateSend({ req, dealId, contentSid, contentVariables, selectedTemplateName, campaignName, campaignId, nextDueDateOverride }) {
  const cleanDealId = String(dealId || "").trim();
  if (!cleanDealId) return { dealId: cleanDealId, ok: false, status: "not_found", error: "Falta dealId" };

  const dealRef = db.collection("deals").doc(cleanDealId);
  const dealDoc = await dealRef.get();
  if (!dealDoc.exists) return { dealId: cleanDealId, ok: false, status: "not_found", error: "Trato no encontrado" };

  const deal = { id: dealDoc.id, ...(dealDoc.data() || {}) };
  const contactsMap = await getContactsMapForDeals([deal]);
  const contact = contactsMap.get(String(deal.contactId || "").trim()) || null;
  const phone = normalizeWhatsappPhoneForDue(contact && contact.phone);
  const lineInfo = await resolveLineInfoForDueDeal(deal, contact);
  const outboundLineId = normalizeOutboundLineForDue(lineInfo && (lineInfo.lineId || lineInfo.inboundTo));
  const statusInfo = getDueDealStatus({ deal, contact, phone, lineInfo: outboundLineId ? { lineId: outboundLineId, inboundTo: outboundLineId, source: lineInfo && lineInfo.source || "" } : null });
  const now = new Date();

  if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
    return { dealId: deal.id, ok: false, status: "skipped_no_permission", error: "Sin permiso sobre el trato" };
  }

  if (!statusInfo.canSend || !phone || !isValidWhatsappPhoneForDue(phone)) {
    const error = statusInfo.blockReason || "Sin teléfono válido";
    await dealRef.update({
      "messageAutomation.lastAttemptAt": now,
      "messageAutomation.lastDueDateSent": String(deal.dueDate || ""),
      "messageAutomation.lastTemplateSid": contentSid,
      "messageAutomation.lastStatus": "skipped",
      "messageAutomation.lastError": error,
      updatedAt: now
    });
    return { dealId: deal.id, ok: false, status: "skipped", error };
  }

  try {
    const hubData = await callCoreJson(req, "/api/start-template", {
      method: "POST",
      body: JSON.stringify({
        to: phone,
        contactName: String((contact && contact.name) || deal.contactName || ""),
        contentSid,
        contentVariables: contentVariables || {},
        lineId: outboundLineId,
        inboundTo: outboundLineId
      })
    });

    const latestDealDoc = await dealRef.get();
    const latestDeal = latestDealDoc.exists ? { id: latestDealDoc.id, ...(latestDealDoc.data() || {}) } : deal;
    const previousSentCount = Number(latestDeal && latestDeal.messageAutomation && latestDeal.messageAutomation.sentCount || 0) || 0;
    const nextSentCount = previousSentCount + 1;
    const previousDueDateForNote = String(latestDeal.dueDate || deal.dueDate || "");
    const nextDueDate = normalizeNextDueDateForDue(nextDueDateOverride, now);
    const noteText = buildAutomaticMessageNoteForDue({
      templateName: selectedTemplateName,
      contentSid,
      dueDate: previousDueDateForNote,
      sentAt: now,
      sentCount: nextSentCount,
      campaignName: campaignName || "",
      nextDueDate,
      outboundLineId,
      outboundLineSource: lineInfo && lineInfo.source || ""
    });

    const noteRef = dealRef.collection("notes").doc();
    const activityRef = dealRef.collection("activities").doc();
    const logRef = dealRef.collection("message_logs").doc();
    const previousNotes = String(latestDeal.notes || "").trim();
    const nextNotes = previousNotes ? `${previousNotes}\n\n---\n${noteText}` : noteText;

    const batch = db.batch();
    batch.update(dealRef, {
      notes: nextNotes,
      "messageAutomation.lastAttemptAt": now,
      "messageAutomation.lastSentAt": now,
      "messageAutomation.lastDueDateSent": String(latestDeal.dueDate || deal.dueDate || ""),
      "messageAutomation.lastTemplateSid": contentSid,
      "messageAutomation.lastTemplateName": selectedTemplateName,
      "messageAutomation.lastStatus": "sent",
      "messageAutomation.lastError": "",
      "messageAutomation.lastConversationId": String(hubData.conversationId || ""),
      "messageAutomation.lastMessageSid": String(hubData.sid || ""),
      "messageAutomation.lastNoteId": noteRef.id,
      "messageAutomation.lastActivityId": activityRef.id,
      "messageAutomation.lastLogId": logRef.id,
      "messageAutomation.lastCampaignId": String(campaignId || ""),
      "messageAutomation.lastCampaignName": String(campaignName || ""),
      "messageAutomation.lastLineId": outboundLineId,
      "messageAutomation.lastInboundTo": outboundLineId,
      "messageAutomation.lastLineSource": String(lineInfo && lineInfo.source || ""),
      "messageAutomation.sentCount": admin.firestore.FieldValue.increment(1),
      dueDate: nextDueDate,
      updatedAt: now
    });
    batch.set(noteRef, {
      note: noteText,
      user: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm",
      type: "automatic_message",
      templateSid: contentSid,
      templateName: selectedTemplateName,
      campaignId: String(campaignId || ""),
      campaignName: String(campaignName || ""),
      conversationId: String(hubData.conversationId || ""),
      messageSid: String(hubData.sid || ""),
      lineId: outboundLineId,
      inboundTo: outboundLineId,
      lineSource: String(lineInfo && lineInfo.source || ""),
      createdAt: now
    });
    batch.set(activityRef, {
      type: "whatsapp_template_sent",
      stage: String(latestDeal.stage || deal.stage || ""),
      user: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm",
      note: noteText,
      templateSid: contentSid,
      templateName: selectedTemplateName,
      campaignId: String(campaignId || ""),
      campaignName: String(campaignName || ""),
      conversationId: String(hubData.conversationId || ""),
      messageSid: String(hubData.sid || ""),
      lineId: outboundLineId,
      inboundTo: outboundLineId,
      lineSource: String(lineInfo && lineInfo.source || ""),
      createdAt: now
    });
    batch.set(logRef, {
      type: "whatsapp_template",
      source: "centro_vencimientos",
      status: "sent",
      sentAt: now,
      sentBy: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm",
      templateSid: contentSid,
      templateName: selectedTemplateName,
      campaignId: String(campaignId || ""),
      campaignName: String(campaignName || ""),
      dueDate: previousDueDateForNote,
      nextDueDate: nextDueDate,
      stage: String(latestDeal.stage || deal.stage || ""),
      contactId: String(latestDeal.contactId || deal.contactId || ""),
      contactName: String((contact && contact.name) || latestDeal.contactName || deal.contactName || ""),
      phone,
      lineId: outboundLineId,
      inboundTo: outboundLineId,
      lineSource: String(lineInfo && lineInfo.source || ""),
      conversationId: String(hubData.conversationId || ""),
      messageSid: String(hubData.sid || ""),
      noteId: noteRef.id,
      activityId: activityRef.id,
      sendNumber: nextSentCount,
      createdAt: now
    });
    await batch.commit();

    return {
      dealId: deal.id,
      ok: true,
      status: "sent",
      conversationId: hubData.conversationId || "",
      sid: hubData.sid || "",
      noteCreated: true,
      noteId: noteRef.id,
      activityCreated: true,
      activityId: activityRef.id,
      logCreated: true,
      logId: logRef.id,
      sentCount: nextSentCount,
      campaignId: String(campaignId || ""),
      campaignName: String(campaignName || ""),
      nextDueDate,
      lineId: outboundLineId,
      inboundTo: outboundLineId,
      lineSource: String(lineInfo && lineInfo.source || "")
    };
  } catch (sendErr) {
    const error = sendErr.message || "Error enviando plantilla";
    await dealRef.update({
      "messageAutomation.lastAttemptAt": now,
      "messageAutomation.lastDueDateSent": String(deal.dueDate || ""),
      "messageAutomation.lastTemplateSid": contentSid,
      "messageAutomation.lastStatus": "error",
      "messageAutomation.lastError": error,
      updatedAt: now
    });
    return { dealId: deal.id, ok: false, status: "error", error };
  }
}

function summarizeDueJobItems(items = []) {
  const list = Array.isArray(items) ? items : [];
  return {
    total: list.length,
    processed: list.filter((item) => ["sent", "skipped", "error", "not_found", "skipped_no_permission"].includes(String(item.status || ""))).length,
    sent: list.filter((item) => item.status === "sent").length,
    skipped: list.filter((item) => String(item.status || "").startsWith("skipped") || item.status === "not_found").length,
    errors: list.filter((item) => item.status === "error").length
  };
}

async function readDueSendJob(jobId, itemLimit = 300) {
  const cleanJobId = String(jobId || "").trim();
  if (!cleanJobId) return null;
  const jobDoc = await db.collection("due_send_jobs").doc(cleanJobId).get();
  if (!jobDoc.exists) return null;
  const itemSnap = await db.collection("due_send_jobs").doc(cleanJobId).collection("items").orderBy("index", "asc").limit(itemLimit).get();
  const items = itemSnap.docs.map((doc) => {
    const data = doc.data() || {};
    return {
      id: doc.id,
      dealId: String(data.dealId || ""),
      dealTitle: String(data.dealTitle || ""),
      contactName: String(data.contactName || ""),
      phone: String(data.phone || ""),
      stage: String(data.stage || ""),
      owner: String(data.owner || ""),
      dueDate: String(data.dueDate || ""),
      nextDueDate: String(data.nextDueDate || ""),
      status: String(data.status || "queued"),
      error: String(data.error || ""),
      templateName: String(data.templateName || ""),
      sentAt: serializeDueTimestamp(data.sentAt || ""),
      processedAt: serializeDueTimestamp(data.processedAt || ""),
      index: Number(data.index || 0)
    };
  });
  const data = jobDoc.data() || {};
  return {
    id: jobDoc.id,
    status: String(data.status || "queued"),
    total: Number(data.total || 0) || items.length,
    delayMs: Number(data.delayMs || 0) || 0,
    contentSid: String(data.contentSid || ""),
    templateName: String(data.templateName || ""),
    campaignName: String(data.campaignName || ""),
    folderId: String(data.folderId || ""),
    folderName: String(data.folderName || ""),
    nextDueDate: String(data.nextDueDate || ""),
    createdBy: String(data.createdBy || ""),
    createdAt: serializeDueTimestamp(data.createdAt || ""),
    startedAt: serializeDueTimestamp(data.startedAt || ""),
    completedAt: serializeDueTimestamp(data.completedAt || ""),
    canceledAt: serializeDueTimestamp(data.canceledAt || ""),
    cancelReason: String(data.cancelReason || ""),
    summary: data.summary || summarizeDueJobItems(items),
    items
  };
}


app.get("/api/due-campaign-folders", authRequired, async (req, res) => {
  try {
    const snap = await db.collection("due_campaign_folders").orderBy("nameLower", "asc").limit(200).get();
    const folders = snap.docs.map((doc) => {
      const data = doc.data() || {};
      return {
        id: doc.id,
        name: String(data.name || ""),
        createdBy: String(data.createdBy || ""),
        createdAt: serializeDueTimestamp(data.createdAt || "")
      };
    }).filter((folder) => folder.name);
    return res.json({ ok: true, folders });
  } catch (err) {
    console.error("ERROR /api/due-campaign-folders GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error leyendo carpetas" });
  }
});

app.post("/api/due-campaign-folders", authRequired, async (req, res) => {
  try {
    const name = String(req.body && req.body.name || "").trim();
    if (!name) return res.status(400).json({ ok: false, error: "Falta nombre de carpeta" });
    const now = new Date();
    const ref = db.collection("due_campaign_folders").doc();
    await ref.set({
      name,
      nameLower: name.toLowerCase(),
      createdBy: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm",
      createdById: String(req.authUser && req.authUser.id || ""),
      createdAt: now
    });
    return res.json({ ok: true, folder: { id: ref.id, name, createdAt: now.toISOString() } });
  } catch (err) {
    console.error("ERROR /api/due-campaign-folders POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error creando carpeta" });
  }
});

app.get("/api/due-send-jobs", authRequired, async (req, res) => {
  try {
    const limit = Math.max(1, Math.min(100, Number(req.query.limit || 15)));
    const folderId = String(req.query.folderId || "").trim();
    const snap = await db.collection("due_send_jobs")
      .orderBy("createdAt", "desc")
      .limit(limit * 3)
      .get();
    const jobs = snap.docs.map((doc) => {
      const data = doc.data() || {};
      return {
        id: doc.id,
        campaignName: String(data.campaignName || ""),
        folderId: String(data.folderId || ""),
        folderName: String(data.folderName || ""),
        deletedAt: data.deletedAt || null,
        nextDueDate: String(data.nextDueDate || ""),
        status: String(data.status || "queued"),
        total: Number(data.total || 0) || 0,
        delayMs: Number(data.delayMs || 0) || 0,
        contentSid: String(data.contentSid || ""),
        templateName: String(data.templateName || ""),
        createdBy: String(data.createdBy || ""),
        createdAt: serializeDueTimestamp(data.createdAt || ""),
        startedAt: serializeDueTimestamp(data.startedAt || ""),
        completedAt: serializeDueTimestamp(data.completedAt || ""),
        summary: data.summary || { total: Number(data.total || 0) || 0, processed: 0, sent: 0, skipped: 0, errors: 0 }
      };
    }).filter((job) => !job.deletedAt && (!folderId || String(job.folderId || "") === folderId)).slice(0, limit);
    return res.json({ ok: true, jobs });
  } catch (err) {
    console.error("ERROR /api/due-send-jobs GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error leyendo historial de campañas" });
  }
});

app.post("/api/due-send-jobs", authRequired, async (req, res) => {
  try {
    const dealIds = Array.from(new Set(
      (Array.isArray(req.body && req.body.dealIds) ? req.body.dealIds : [])
        .map((id) => String(id || "").trim())
        .filter(Boolean)
    )).slice(0, 100);
    const contentSid = String(req.body && req.body.contentSid || "").trim();
    const contentVariables = req.body && req.body.contentVariables && typeof req.body.contentVariables === "object" && !Array.isArray(req.body.contentVariables)
      ? req.body.contentVariables
      : {};
    const delayMs = Math.max(0, Math.min(10000, Number(req.body && req.body.delayMs || 3000)));
    const campaignName = String(req.body && req.body.campaignName || "").trim() || `Campaña vencimientos ${formatDueNoteDateForCRM(new Date())}`;
    const folderId = String(req.body && req.body.folderId || "").trim();
    const folderName = String(req.body && req.body.folderName || "").trim();
    const nextDueDate = normalizeNextDueDateForDue(req.body && req.body.nextDueDate, new Date());
    if (!dealIds.length) return res.status(400).json({ ok: false, error: "Faltan tratos seleccionados" });
    if (!contentSid) return res.status(400).json({ ok: false, error: "Falta plantilla aprobada" });

    let selectedTemplateName = "";
    try {
      const previewData = await callCoreJson(req, `/api/templates/${encodeURIComponent(contentSid)}/preview`, { method: "GET" });
      selectedTemplateName = String((previewData.template && previewData.template.name) || previewData.name || "").trim();
    } catch (previewErr) {
      selectedTemplateName = "";
    }

    const dealRefs = dealIds.map((id) => db.collection("deals").doc(id));
    const dealDocs = await db.getAll(...dealRefs);
    const deals = dealDocs.filter((doc) => doc.exists).map((doc) => ({ id: doc.id, ...(doc.data() || {}) }));
    const contactsMap = await getContactsMapForDeals(deals);
    const lineMap = await getLineInfoMapForDueDeals(deals, contactsMap);
    const jobRef = db.collection("due_send_jobs").doc();
    const now = new Date();
    const batch = db.batch();
    batch.set(jobRef, {
      status: "queued",
      total: deals.length,
      delayMs,
      campaignName,
      folderId,
      folderName,
      nextDueDate,
      contentSid,
      templateName: selectedTemplateName,
      contentVariables,
      createdBy: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm",
      createdById: String(req.authUser && req.authUser.id || ""),
      createdAt: now,
      summary: { total: deals.length, processed: 0, sent: 0, skipped: 0, errors: 0 }
    });
    deals.forEach((deal, index) => {
      const contact = contactsMap.get(String(deal.contactId || "").trim()) || null;
      const phone = normalizeWhatsappPhoneForDue(contact && contact.phone);
      const itemLine = lineMap.get(String(deal.id || "")) || null;
      const itemLineId = normalizeOutboundLineForDue(itemLine && (itemLine.lineId || itemLine.inboundTo));
      batch.set(jobRef.collection("items").doc(), {
        index,
        dealId: deal.id,
        dealTitle: String(deal.title || ""),
        contactId: String(deal.contactId || ""),
        contactName: String((contact && contact.name) || deal.contactName || ""),
        phone,
        lineId: itemLineId,
        inboundTo: itemLineId,
        lineSource: String(itemLine && itemLine.source || ""),
        stage: String(deal.stage || ""),
        owner: String(deal.owner || ""),
        dueDate: String(deal.dueDate || ""),
        nextDueDate,
        status: "queued",
        error: "",
        templateSid: contentSid,
        templateName: selectedTemplateName,
        campaignName,
        folderId,
        folderName,
        createdAt: now
      });
    });
    await batch.commit();
    const job = await readDueSendJob(jobRef.id);
    return res.json({ ok: true, job });
  } catch (err) {
    console.error("ERROR /api/due-send-jobs POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error creando cola" });
  }
});

app.get("/api/due-send-jobs/:jobId", authRequired, async (req, res) => {
  try {
    const job = await readDueSendJob(req.params.jobId);
    if (!job) return res.status(404).json({ ok: false, error: "Cola no encontrada" });
    return res.json({ ok: true, job });
  } catch (err) {
    console.error("ERROR /api/due-send-jobs/:jobId GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error leyendo cola" });
  }
});


app.post("/api/due-send-jobs/:jobId/folder", authRequired, async (req, res) => {
  try {
    const jobId = String(req.params.jobId || "").trim();
    const folderId = String(req.body && req.body.folderId || "").trim();
    const folderName = String(req.body && req.body.folderName || "").trim();
    if (!jobId) return res.status(400).json({ ok: false, error: "Falta campaña" });
    await db.collection("due_send_jobs").doc(jobId).update({
      folderId,
      folderName,
      updatedAt: new Date(),
      updatedBy: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm"
    });
    const job = await readDueSendJob(jobId);
    return res.json({ ok: true, job });
  } catch (err) {
    console.error("ERROR /api/due-send-jobs/:jobId/folder POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error moviendo campaña" });
  }
});

app.delete("/api/due-send-jobs/:jobId", authRequired, async (req, res) => {
  try {
    const jobId = String(req.params.jobId || "").trim();
    if (!jobId) return res.status(400).json({ ok: false, error: "Falta campaña" });
    const ref = db.collection("due_send_jobs").doc(jobId);
    const doc = await ref.get();
    if (!doc.exists) return res.status(404).json({ ok: false, error: "Campaña no encontrada" });
    await ref.update({
      status: "deleted",
      deletedAt: new Date(),
      deletedBy: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm",
      deletedById: String(req.authUser && req.authUser.id || "")
    });
    return res.json({ ok: true });
  } catch (err) {
    console.error("ERROR /api/due-send-jobs/:jobId DELETE:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error eliminando campaña" });
  }
});

app.post("/api/due-send-jobs/:jobId/resend", authRequired, async (req, res) => {
  try {
    const sourceJobId = String(req.params.jobId || "").trim();
    const sourceJobRef = db.collection("due_send_jobs").doc(sourceJobId);
    const sourceJobDoc = await sourceJobRef.get();
    if (!sourceJobDoc.exists) return res.status(404).json({ ok: false, error: "Campaña origen no encontrada" });
    const sourceJob = sourceJobDoc.data() || {};
    const contentSid = String(req.body && req.body.contentSid || "").trim();
    const contentVariables = req.body && req.body.contentVariables && typeof req.body.contentVariables === "object" && !Array.isArray(req.body.contentVariables)
      ? req.body.contentVariables
      : {};
    const delayMs = Math.max(0, Math.min(10000, Number(req.body && req.body.delayMs || sourceJob.delayMs || 3000)));
    const nextDueDate = normalizeNextDueDateForDue(req.body && req.body.nextDueDate, new Date());
    const campaignName = String(req.body && req.body.campaignName || "").trim()
      || `${String(sourceJob.campaignName || "Campaña")} - Reenvío ${formatDueNoteDateForCRM(new Date())}`;
    const folderId = String(req.body && req.body.folderId || sourceJob.folderId || "").trim();
    const folderName = String(req.body && req.body.folderName || sourceJob.folderName || "").trim();

    if (!contentSid) return res.status(400).json({ ok: false, error: "Falta plantilla aprobada" });

    let selectedTemplateName = "";
    try {
      const previewData = await callCoreJson(req, `/api/templates/${encodeURIComponent(contentSid)}/preview`, { method: "GET" });
      selectedTemplateName = String((previewData.template && previewData.template.name) || previewData.name || "").trim();
    } catch (previewErr) {
      selectedTemplateName = "";
    }

    const itemSnap = await sourceJobRef.collection("items").orderBy("index", "asc").limit(500).get();
    const sourceItems = itemSnap.docs.map((doc) => ({ id: doc.id, ...(doc.data() || {}) }));
    const dealIds = Array.from(new Set(
      sourceItems
        .filter((item) => String(item.status || "") === "sent")
        .map((item) => String(item.dealId || "").trim())
        .filter(Boolean)
    )).slice(0, 200);

    if (!dealIds.length) return res.status(400).json({ ok: false, error: "La campaña no tiene contactos enviados para reenviar" });

    const dealRefs = dealIds.map((id) => db.collection("deals").doc(id));
    const dealDocs = await db.getAll(...dealRefs);
    const deals = dealDocs.filter((doc) => doc.exists).map((doc) => ({ id: doc.id, ...(doc.data() || {}) }));
    const contactsMap = await getContactsMapForDeals(deals);
    const lineMap = await getLineInfoMapForDueDeals(deals, contactsMap);
    const jobRef = db.collection("due_send_jobs").doc();
    const now = new Date();
    const batch = db.batch();
    batch.set(jobRef, {
      status: "queued",
      sourceJobId,
      sourceCampaignName: String(sourceJob.campaignName || ""),
      total: deals.length,
      delayMs,
      campaignName,
      folderId,
      folderName,
      nextDueDate,
      contentSid,
      templateName: selectedTemplateName,
      contentVariables,
      createdBy: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm",
      createdById: String(req.authUser && req.authUser.id || ""),
      createdAt: now,
      summary: { total: deals.length, processed: 0, sent: 0, skipped: 0, errors: 0 }
    });
    deals.forEach((deal, index) => {
      const contact = contactsMap.get(String(deal.contactId || "").trim()) || null;
      const phone = normalizeWhatsappPhoneForDue(contact && contact.phone);
      const itemLine = lineMap.get(String(deal.id || "")) || null;
      const itemLineId = normalizeOutboundLineForDue(itemLine && (itemLine.lineId || itemLine.inboundTo));
      batch.set(jobRef.collection("items").doc(), {
        index,
        dealId: deal.id,
        dealTitle: String(deal.title || ""),
        contactId: String(deal.contactId || ""),
        contactName: String((contact && contact.name) || deal.contactName || ""),
        phone,
        lineId: itemLineId,
        inboundTo: itemLineId,
        lineSource: String(itemLine && itemLine.source || ""),
        stage: String(deal.stage || ""),
        owner: String(deal.owner || ""),
        dueDate: String(deal.dueDate || ""),
        nextDueDate,
        status: "queued",
        error: "",
        templateSid: contentSid,
        templateName: selectedTemplateName,
        campaignName,
        folderId,
        folderName,
        sourceJobId,
        createdAt: now
      });
    });
    await batch.commit();
    const job = await readDueSendJob(jobRef.id);
    return res.json({ ok: true, job });
  } catch (err) {
    console.error("ERROR /api/due-send-jobs/:jobId/resend POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error creando reenvío de campaña" });
  }
});

app.post("/api/due-send-jobs/:jobId/cancel", authRequired, async (req, res) => {
  try {
    const jobId = String(req.params.jobId || "").trim();
    const reason = String(req.body && req.body.reason || "cancelado").trim().slice(0, 300);
    if (!jobId) return res.status(400).json({ ok: false, error: "Falta jobId" });

    const jobRef = db.collection("due_send_jobs").doc(jobId);
    const jobDoc = await jobRef.get();
    if (!jobDoc.exists) return res.status(404).json({ ok: false, error: "Cola no encontrada" });

    const now = new Date();
    const pendingSnap = await jobRef.collection("items").where("status", "in", ["queued", "processing"]).limit(400).get();
    const batch = db.batch();
    pendingSnap.docs.forEach((doc) => {
      batch.update(doc.ref, {
        status: "canceled",
        error: reason || "cancelado",
        processedAt: now,
        canceledAt: now
      });
    });
    batch.update(jobRef, {
      status: "canceled",
      cancelReason: reason || "cancelado",
      canceledAt: now,
      updatedAt: now,
      "summary.skipped": admin.firestore.FieldValue.increment(pendingSnap.size),
      "summary.processed": admin.firestore.FieldValue.increment(pendingSnap.size)
    });
    await batch.commit();

    const job = await readDueSendJob(jobId);
    return res.json({ ok: true, job });
  } catch (err) {
    console.error("ERROR /api/due-send-jobs/:jobId/cancel POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error cancelando cola" });
  }
});

app.post("/api/due-send-jobs/:jobId/process-next", authRequired, async (req, res) => {
  let jobId = "";
  let jobRef = null;
  let claimedItemRef = null;
  try {
    jobId = String(req.params.jobId || "").trim();
    jobRef = db.collection("due_send_jobs").doc(jobId);
    const jobDoc = await jobRef.get();
    if (!jobDoc.exists) return res.status(404).json({ ok: false, error: "Cola no encontrada" });
    const jobData = jobDoc.data() || {};

    if (["completed", "canceled", "cancelled"].includes(String(jobData.status || "").toLowerCase())) {
      const job = await readDueSendJob(jobId);
      return res.json({ ok: true, done: true, hasMore: false, job });
    }

    const nextSnap = await jobRef.collection("items").where("status", "==", "queued").orderBy("index", "asc").limit(1).get();
    if (nextSnap.empty) {
      await jobRef.update({ status: "completed", completedAt: new Date(), updatedAt: new Date() });
      const job = await readDueSendJob(jobId);
      return res.json({ ok: true, done: true, hasMore: false, job });
    }

    const itemDoc = nextSnap.docs[0];
    claimedItemRef = itemDoc.ref;

    const claimed = await db.runTransaction(async (tx) => {
      const freshJob = await tx.get(jobRef);
      const freshJobData = freshJob.exists ? (freshJob.data() || {}) : {};
      if (["completed", "canceled", "cancelled"].includes(String(freshJobData.status || "").toLowerCase())) {
        return { ok: false, reason: "job_closed" };
      }
      const freshItem = await tx.get(claimedItemRef);
      if (!freshItem.exists) return { ok: false, reason: "item_missing" };
      const freshItemData = freshItem.data() || {};
      if (String(freshItemData.status || "queued") !== "queued") {
        return { ok: false, reason: "item_already_claimed" };
      }
      const now = new Date();
      tx.update(claimedItemRef, { status: "processing", startedAt: now, processingLockAt: now });
      tx.update(jobRef, { status: "running", startedAt: freshJobData.startedAt || now, updatedAt: now });
      return { ok: true, item: { id: freshItem.id, ...freshItemData }, jobData: freshJobData };
    });

    if (!claimed.ok) {
      const job = await readDueSendJob(jobId);
      return res.json({ ok: true, done: false, hasMore: true, nextDelayMs: 1000, item: { ok: false, status: "skipped", error: claimed.reason }, job });
    }

    const item = claimed.item;
    const jobDataFresh = claimed.jobData || jobData;
    let result = null;

    try {
      result = await processOneDueTemplateSend({
        req,
        dealId: item.dealId,
        contentSid: String(jobDataFresh.contentSid || ""),
        contentVariables: jobDataFresh.contentVariables || {},
        selectedTemplateName: String(jobDataFresh.templateName || ""),
        campaignName: String(jobDataFresh.campaignName || ""),
        campaignId: jobId,
        nextDueDateOverride: String(jobDataFresh.nextDueDate || "")
      });
    } catch (sendErr) {
      result = {
        dealId: String(item.dealId || ""),
        ok: false,
        status: "error",
        error: sendErr.message || "Error procesando envío"
      };
    }

    const finalStatus = result.ok && result.status === "sent"
      ? "sent"
      : (String(result.status || "").startsWith("skipped") || result.status === "not_found" ? "skipped" : "error");
    const now = new Date();
    await claimedItemRef.update({
      status: finalStatus,
      error: String(result.error || ""),
      result,
      conversationId: String(result.conversationId || ""),
      messageSid: String(result.sid || ""),
      lineId: String(result.lineId || item.lineId || ""),
      inboundTo: String(result.inboundTo || result.lineId || item.inboundTo || item.lineId || ""),
      lineSource: String(result.lineSource || item.lineSource || ""),
      nextDueDate: String(result.nextDueDate || jobDataFresh.nextDueDate || ""),
      sentAt: finalStatus === "sent" ? now : null,
      processedAt: now
    });

    const inc = {
      "summary.processed": admin.firestore.FieldValue.increment(1),
      updatedAt: now
    };
    if (finalStatus === "sent") inc["summary.sent"] = admin.firestore.FieldValue.increment(1);
    else if (finalStatus === "skipped") inc["summary.skipped"] = admin.firestore.FieldValue.increment(1);
    else inc["summary.errors"] = admin.firestore.FieldValue.increment(1);
    await jobRef.update(inc);

    const remainingSnap = await jobRef.collection("items").where("status", "==", "queued").limit(1).get();
    if (remainingSnap.empty) await jobRef.update({ status: "completed", completedAt: new Date(), updatedAt: new Date() });
    const job = await readDueSendJob(jobId);
    return res.json({ ok: true, done: remainingSnap.empty, hasMore: !remainingSnap.empty, nextDelayMs: Number(job.delayMs || 0), item: result, job });
  } catch (err) {
    console.error("ERROR /api/due-send-jobs/:jobId/process-next POST:", err);
    if (claimedItemRef && jobRef) {
      try {
        const now = new Date();
        await claimedItemRef.update({ status: "error", error: err.message || "Error procesando cola", processedAt: now });
        await jobRef.update({
          "summary.processed": admin.firestore.FieldValue.increment(1),
          "summary.errors": admin.firestore.FieldValue.increment(1),
          status: "canceled",
          cancelReason: "error_process_next_" + (err.message || "error"),
          canceledAt: now,
          updatedAt: now
        });
      } catch (innerErr) {
        console.error("ERROR marking queue item failed:", innerErr);
      }
    }
    const job = jobId ? await readDueSendJob(jobId).catch(() => null) : null;
    return res.status(500).json({ ok: false, error: err.message || "Error procesando cola", job });
  }
});

app.post("/api/due-deals/send-template", authRequired, adminOnly, async (req, res) => {
  try {
    const dealIds = Array.from(new Set(
      (Array.isArray(req.body && req.body.dealIds) ? req.body.dealIds : [])
        .map((id) => String(id || "").trim())
        .filter(Boolean)
    )).slice(0, 100);
    const contentSid = String(req.body && req.body.contentSid || "").trim();
    const contentVariables = req.body && req.body.contentVariables && typeof req.body.contentVariables === "object" && !Array.isArray(req.body.contentVariables)
      ? req.body.contentVariables
      : {};
    const campaignName = String(req.body && req.body.campaignName || "").trim();
    const nextDueDate = normalizeNextDueDateForDue(req.body && req.body.nextDueDate, new Date());

    if (!dealIds.length) return res.status(400).json({ ok: false, error: "Faltan tratos seleccionados" });
    if (!contentSid) return res.status(400).json({ ok: false, error: "Falta plantilla aprobada" });

    let selectedTemplateName = "";
    try {
      const previewData = await callCoreJson(req, `/api/templates/${encodeURIComponent(contentSid)}/preview`, { method: "GET" });
      selectedTemplateName = String((previewData.template && previewData.template.name) || previewData.name || "").trim();
    } catch (previewErr) {
      selectedTemplateName = "";
    }

    const dealRefs = dealIds.map((id) => db.collection("deals").doc(id));
    const dealDocs = await db.getAll(...dealRefs);
    const deals = dealDocs
      .filter((doc) => doc.exists)
      .map((doc) => ({ id: doc.id, ...(doc.data() || {}) }));

    const contactsMap = await getContactsMapForDeals(deals);
    const results = [];
    const batch = db.batch();
    const now = new Date();

    for (const deal of deals) {
      const contact = contactsMap.get(String(deal.contactId || "").trim()) || null;
      const phone = normalizeWhatsappPhoneForDue(contact && contact.phone);
      const lineInfo = await resolveLineInfoForDueDeal(deal, contact);
      const outboundLineId = normalizeOutboundLineForDue(lineInfo && (lineInfo.lineId || lineInfo.inboundTo));
      const statusInfo = getDueDealStatus({ deal, contact, phone, lineInfo: outboundLineId ? { lineId: outboundLineId, inboundTo: outboundLineId, source: lineInfo && lineInfo.source || "" } : null });

      if (!(await canEditOwner(req.authUser, deal.owner || ""))) {
        results.push({ dealId: deal.id, ok: false, status: "skipped_no_permission", error: "Sin permiso sobre el trato" });
        continue;
      }

      if (!statusInfo.canSend || !phone || !isValidWhatsappPhoneForDue(phone)) {
        const error = statusInfo.blockReason || "Sin teléfono válido";
        batch.update(db.collection("deals").doc(deal.id), {
          "messageAutomation.lastAttemptAt": now,
          "messageAutomation.lastDueDateSent": String(deal.dueDate || ""),
          "messageAutomation.lastTemplateSid": contentSid,
          "messageAutomation.lastStatus": "skipped",
          "messageAutomation.lastError": error,
          updatedAt: now
        });
        results.push({ dealId: deal.id, ok: false, status: "skipped", error });
        continue;
      }

      try {
        const hubData = await callCoreJson(req, "/api/start-template", {
          method: "POST",
          body: JSON.stringify({
            to: phone,
            contactName: String((contact && contact.name) || deal.contactName || ""),
            contentSid,
            contentVariables,
            lineId: outboundLineId,
            inboundTo: outboundLineId
          })
        });

        const dealRef = db.collection("deals").doc(deal.id);
        const previousSentCount = Number(deal && deal.messageAutomation && deal.messageAutomation.sentCount || 0) || 0;
        const nextSentCount = previousSentCount + 1;
        const previousDueDateForNote = String(deal.dueDate || "");
        const noteText = buildAutomaticMessageNoteForDue({
          templateName: selectedTemplateName,
          contentSid,
          dueDate: previousDueDateForNote,
          sentAt: now,
          sentCount: nextSentCount,
          campaignName: campaignName || "",
          nextDueDate,
          outboundLineId,
          outboundLineSource: lineInfo && lineInfo.source || ""
        });
        const noteRef = dealRef.collection("notes").doc();
        const activityRef = dealRef.collection("activities").doc();
        const logRef = dealRef.collection("message_logs").doc();
        const previousNotes = String(deal.notes || "").trim();
        const nextNotes = previousNotes
          ? `${previousNotes}\n\n---\n${noteText}`
          : noteText;

        batch.update(dealRef, {
          notes: nextNotes,
          "messageAutomation.lastAttemptAt": now,
          "messageAutomation.lastSentAt": now,
          "messageAutomation.lastDueDateSent": String(deal.dueDate || ""),
          "messageAutomation.lastTemplateSid": contentSid,
          "messageAutomation.lastTemplateName": selectedTemplateName,
          "messageAutomation.lastStatus": "sent",
          "messageAutomation.lastError": "",
          "messageAutomation.lastConversationId": String(hubData.conversationId || ""),
          "messageAutomation.lastMessageSid": String(hubData.sid || ""),
          "messageAutomation.lastNoteId": noteRef.id,
          "messageAutomation.lastActivityId": activityRef.id,
          "messageAutomation.lastLogId": logRef.id,
          "messageAutomation.lastCampaignName": String(campaignName || ""),
          "messageAutomation.lastLineId": outboundLineId,
          "messageAutomation.lastInboundTo": outboundLineId,
          "messageAutomation.lastLineSource": String(lineInfo && lineInfo.source || ""),
          "messageAutomation.sentCount": admin.firestore.FieldValue.increment(1),
          dueDate: nextDueDate,
          updatedAt: now
        });
        batch.set(noteRef, {
          note: noteText,
          user: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm",
          type: "automatic_message",
          templateSid: contentSid,
          templateName: selectedTemplateName,
          campaignName: String(campaignName || ""),
          conversationId: String(hubData.conversationId || ""),
          messageSid: String(hubData.sid || ""),
          lineId: outboundLineId,
          inboundTo: outboundLineId,
          lineSource: String(lineInfo && lineInfo.source || ""),
          createdAt: now
        });
        batch.set(activityRef, {
          type: "whatsapp_template_sent",
          stage: String(deal.stage || ""),
          user: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm",
          note: noteText,
          templateSid: contentSid,
          templateName: selectedTemplateName,
          campaignName: String(campaignName || ""),
          conversationId: String(hubData.conversationId || ""),
          messageSid: String(hubData.sid || ""),
          lineId: outboundLineId,
          inboundTo: outboundLineId,
          lineSource: String(lineInfo && lineInfo.source || ""),
          createdAt: now
        });
        batch.set(logRef, {
          type: "whatsapp_template",
          source: "centro_vencimientos",
          status: "sent",
          sentAt: now,
          sentBy: (req.authUser && (req.authUser.email || req.authUser.name)) || "crm",
          templateSid: contentSid,
          templateName: selectedTemplateName,
          campaignName: String(campaignName || ""),
          dueDate: previousDueDateForNote,
          nextDueDate: nextDueDate,
          stage: String(deal.stage || ""),
          contactId: String(deal.contactId || ""),
          contactName: String((contact && contact.name) || deal.contactName || ""),
          phone,
          lineId: outboundLineId,
          inboundTo: outboundLineId,
          lineSource: String(lineInfo && lineInfo.source || ""),
          conversationId: String(hubData.conversationId || ""),
          messageSid: String(hubData.sid || ""),
          noteId: noteRef.id,
          activityId: activityRef.id,
          sendNumber: nextSentCount,
          createdAt: now
        });
        results.push({
          dealId: deal.id,
          ok: true,
          status: "sent",
          conversationId: hubData.conversationId || "",
          sid: hubData.sid || "",
          noteCreated: true,
          noteId: noteRef.id,
          activityCreated: true,
          activityId: activityRef.id,
          logCreated: true,
          logId: logRef.id,
          sentCount: nextSentCount,
          campaignName: String(campaignName || ""),
          nextDueDate,
          lineId: outboundLineId,
          inboundTo: outboundLineId,
          lineSource: String(lineInfo && lineInfo.source || "")
        });
      } catch (sendErr) {
        const error = sendErr.message || "Error enviando plantilla";
        batch.update(db.collection("deals").doc(deal.id), {
          "messageAutomation.lastAttemptAt": now,
          "messageAutomation.lastDueDateSent": String(deal.dueDate || ""),
          "messageAutomation.lastTemplateSid": contentSid,
          "messageAutomation.lastStatus": "error",
          "messageAutomation.lastError": error,
          updatedAt: now
        });
        results.push({ dealId: deal.id, ok: false, status: "error", error });
      }
    }

    await batch.commit();

    const missingIds = dealIds.filter((id) => !deals.some((deal) => String(deal.id) === String(id)));
    missingIds.forEach((id) => results.push({ dealId: id, ok: false, status: "not_found", error: "Trato no encontrado" }));

    const summary = {
      requested: dealIds.length,
      sent: results.filter((item) => item.ok && item.status === "sent").length,
      skipped: results.filter((item) => String(item.status || "").startsWith("skipped") || item.status === "not_found").length,
      errors: results.filter((item) => item.status === "error").length
    };

    return res.json({ ok: true, summary, results });
  } catch (err) {
    console.error("ERROR /api/due-deals/send-template POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error enviando plantillas" });
  }
});


// =====================================================
// BLOQUE 6F-AGENDA - API AGENDA COMERCIAL / TAREAS
// =====================================================
function normalizeAgendaTaskStatus(value) {
  const clean = String(value || "pending").trim().toLowerCase();
  if (["pending", "done", "cancelled"].includes(clean)) return clean;
  return "pending";
}

function agendaDateIsValid(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value || "").trim());
}

function getAgendaRange(mode, startRaw, endRaw) {
  const today = getTodayISOInBuenosAires();
  const todayDate = isoToDateUTC(today);
  const cleanMode = String(mode || "vencidos").trim().toLowerCase();

  if (cleanMode === "tareas") {
    return { mode: "tareas", start: "", end: "", rangeLabel: "Todas las tareas creadas" };
  }

  if (cleanMode === "hoy") {
    return { mode: "hoy", start: today, end: today, rangeLabel: `Hoy ${today}` };
  }
  if (cleanMode === "manana" || cleanMode === "mañana") {
    const tomorrow = dateToISOUTC(addDaysUTC(todayDate, 1));
    return { mode: "manana", start: tomorrow, end: tomorrow, rangeLabel: `Mañana ${tomorrow}` };
  }
  if (cleanMode === "semana") {
    const p = getWeeklyPeriodFromISO(today);
    return { mode: "semana", start: p.startDate, end: p.endDate, rangeLabel: `Semana ${p.startDate} al ${p.endDate}` };
  }
  if (cleanMode === "proximos_7") {
    const end = dateToISOUTC(addDaysUTC(todayDate, 7));
    return { mode: "proximos_7", start: today, end, rangeLabel: `Próximos 7 días ${today} al ${end}` };
  }
  if (cleanMode === "personalizado") {
    let start = agendaDateIsValid(startRaw) ? String(startRaw).trim() : today;
    let end = agendaDateIsValid(endRaw) ? String(endRaw).trim() : start;
    if (start > end) [start, end] = [end, start];
    const startDate = isoToDateUTC(start);
    const endDate = isoToDateUTC(end);
    const maxEnd = dateToISOUTC(addDaysUTC(startDate, 31));
    if (endDate && startDate && end > maxEnd) end = maxEnd;
    return { mode: "personalizado", start, end, rangeLabel: `Personalizado ${start} al ${end}` };
  }

  return { mode: "vencidos", start: "", end: today, rangeLabel: `Vencidos antes de ${today}` };
}

function normalizeAgendaStageFilter(value) {
  const clean = String(value || "important").trim();
  if (!clean || clean === "important") return { mode: "important", stage: "" };
  if (clean === "all") return { mode: "all", stage: "" };
  const stage = normalizePipelineStage(clean);
  return stage ? { mode: "one", stage } : { mode: "important", stage: "" };
}

function agendaStageAllowed(stage, stageFilter) {
  const cleanStage = String(stage || "").trim();
  const filter = stageFilter || { mode: "important", stage: "" };
  if (filter.mode === "all") return true;
  if (filter.mode === "one") return cleanStage === filter.stage;
  return AGENDA_IMPORTANT_STAGES.includes(cleanStage);
}

function agendaItemMatchesSearch(item, q) {
  const needle = String(q || "").trim().toLowerCase();
  if (!needle) return true;
  return [
    item.title,
    item.contactName,
    item.dealTitle,
    item.stage,
    item.owner,
    item.notes
  ].join(" ").toLowerCase().includes(needle);
}

function agendaUrgencyForDate(dateIso) {
  const today = getTodayISOInBuenosAires();
  if (!dateIso) return "future";
  if (dateIso < today) return "overdue";
  if (dateIso === today) return "today";
  const tomorrow = dateToISOUTC(addDaysUTC(isoToDateUTC(today), 1));
  if (dateIso === tomorrow) return "tomorrow";
  return "future";
}

function agendaSortItems(a, b) {
  const ad = String(a.date || "");
  const bd = String(b.date || "");
  if (ad !== bd) return ad.localeCompare(bd);

  // Las tareas manuales tienen prioridad visual sobre los vencimientos automáticos.
  // Si una tarea queda sin hora, antes se iba debajo de decenas de vencimientos "Sin hora".
  const typeA = a.type === "task" ? 0 : 1;
  const typeB = b.type === "task" ? 0 : 1;
  if (typeA !== typeB) return typeA - typeB;

  const at = String(a.time || "99:99");
  const bt = String(b.time || "99:99");
  if (at !== bt) return at.localeCompare(bt);

  return String(a.title || "").localeCompare(String(b.title || ""));
}

async function getAgendaOwnerScope(user, requestedOwner) {
  const cleanRequested = String(requestedOwner || "").trim().toLowerCase();
  const visibleOwnerEmails = await getVisibleOwnerEmails(user);
  if (visibleOwnerEmails === null) {
    return cleanRequested ? { owners: [cleanRequested], ownerFilter: cleanRequested } : { owners: null, ownerFilter: "" };
  }
  const visible = Array.from(new Set(visibleOwnerEmails.map((email) => String(email || "").trim().toLowerCase()).filter(Boolean)));
  if (cleanRequested) {
    if (!visible.includes(cleanRequested)) return { owners: [], ownerFilter: cleanRequested };
    return { owners: [cleanRequested], ownerFilter: cleanRequested };
  }
  return { owners: visible, ownerFilter: "" };
}

function agendaOwnerCanSee(ownerScope, owner) {
  const cleanOwner = String(owner || "").trim().toLowerCase();
  if (ownerScope.owners === null) return true;
  return ownerScope.owners.includes(cleanOwner);
}

async function loadAgendaTasks(req, range, ownerScope, taskStatus, stageFilter, q, limit) {
  const scanLimit = Math.max(50, Math.min(500, limit * 3));
  let query = db.collection("tasks");
  if (range.mode === "tareas") {
    // Vista especial de tareas: no depende del rango Vencidos/Hoy/Semana.
    // Lee una página acotada y filtra permisos/stage/search en memoria para cuidar reads.
    query = query.orderBy("taskDate", "asc");
  } else if (range.mode === "vencidos") {
    query = query.where("taskDate", "<", getTodayISOInBuenosAires()).orderBy("taskDate", "desc");
  } else {
    query = query.where("taskDate", ">=", range.start).where("taskDate", "<=", range.end).orderBy("taskDate", "asc");
  }
  query = query.limit(scanLimit);
  const snap = await query.get();
  const statusFilter = String(taskStatus || "pending").trim().toLowerCase();
  const out = [];
  snap.docs.forEach((doc) => {
    const data = doc.data() || {};
    const status = normalizeAgendaTaskStatus(data.status || "pending");
    const owner = String(data.owner || "").trim().toLowerCase();
    if (!agendaOwnerCanSee(ownerScope, owner)) return;
    if (statusFilter !== "all" && status !== statusFilter) return;
    // En la vista Tareas, el objetivo es encontrar tareas creadas.
    // No las ocultamos por el filtro default "Etapas importantes", porque una tarea
    // puede estar ligada a un trato en otra etapa y parecería que no se guardó.
    const shouldApplyTaskStageFilter = !(range && range.mode === "tareas" && (!stageFilter || stageFilter.mode === "important"));
    if (shouldApplyTaskStageFilter && !agendaStageAllowed(String(data.stage || ""), stageFilter)) return;
    const item = {
      type: "task",
      id: `task_${doc.id}`,
      taskId: doc.id,
      title: String(data.title || "Tarea").trim(),
      date: String(data.taskDate || "").trim(),
      time: String(data.taskTime || "").trim(),
      owner,
      contactId: String(data.contactId || "").trim(),
      contactName: String(data.contactName || "").trim(),
      dealId: String(data.dealId || "").trim(),
      dealTitle: String(data.dealTitle || "").trim(),
      stage: String(data.stage || "").trim(),
      status,
      notes: String(data.notes || "").trim(),
      urgency: agendaUrgencyForDate(String(data.taskDate || "").trim())
    };
    if (!agendaItemMatchesSearch(item, q)) return;
    out.push(item);
  });
  return out;
}

async function loadAgendaDealDues(req, range, ownerScope, stageFilter, q, limit) {
  const scanLimit = Math.max(50, Math.min(500, limit * 3));
  let query = db.collection("deals");
  if (range.mode === "vencidos") {
    query = query.where("dueDate", "<", getTodayISOInBuenosAires()).orderBy("dueDate", "desc");
  } else {
    query = query.where("dueDate", ">=", range.start).where("dueDate", "<=", range.end).orderBy("dueDate", "asc");
  }
  query = query.limit(scanLimit);
  const snap = await query.get();
  const out = [];
  snap.docs.forEach((doc) => {
    const data = doc.data() || {};
    const dueDate = String(data.dueDate || "").trim();
    if (!dueDate) return;
    const owner = String(data.owner || "").trim().toLowerCase();
    const stage = String(data.stage || "").trim();
    if (!agendaOwnerCanSee(ownerScope, owner)) return;
    if (!agendaStageAllowed(stage, stageFilter)) return;
    const item = {
      type: "deal_due",
      id: `deal_${doc.id}`,
      title: `Vence trato: ${String(data.title || "Trato").trim()}`,
      date: dueDate,
      time: "",
      owner,
      contactId: String(data.contactId || "").trim(),
      contactName: String(data.contactName || "").trim(),
      dealId: doc.id,
      dealTitle: String(data.title || "").trim(),
      stage,
      status: "pending",
      notes: String(data.notes || "").trim(),
      urgency: agendaUrgencyForDate(dueDate)
    };
    if (!agendaItemMatchesSearch(item, q)) return;
    out.push(item);
  });
  return out;
}

async function enrichAgendaDealDuesWithTasks(dealDues) {
  if (!Array.isArray(dealDues) || !dealDues.length) return dealDues || [];
  const uniqueDealIds = Array.from(new Set(dealDues.map((item) => String(item.dealId || "").trim()).filter(Boolean)));
  if (!uniqueDealIds.length) return dealDues;
  const chunks = [];
  for (let i = 0; i < uniqueDealIds.length; i += 10) chunks.push(uniqueDealIds.slice(i, i + 10));
  const taskMap = new Map();
  for (const chunk of chunks) {
    const snap = await db.collection("tasks").where("dealId", "in", chunk).get();
    snap.docs.forEach((doc) => {
      const data = doc.data() || {};
      const dealId = String(data.dealId || "").trim();
      if (!dealId) return;
      const status = normalizeAgendaTaskStatus(data.status || "pending");
      if (status === "cancelled") return;
      const current = taskMap.get(dealId);
      const candidate = {
        taskId: doc.id,
        title: String(data.title || "Tarea").trim(),
        notes: String(data.notes || "").trim(),
        status,
        taskDate: String(data.taskDate || "").trim(),
        taskTime: String(data.taskTime || "").trim(),
        updatedAt: data.updatedAt || null,
        createdAt: data.createdAt || null
      };
      if (!current) { taskMap.set(dealId, candidate); return; }
      const currentPending = current.status === "pending";
      const candidatePending = candidate.status === "pending";
      if (candidatePending && !currentPending) { taskMap.set(dealId, candidate); return; }
      if (candidatePending === currentPending) {
        const currentDate = String(current.taskDate || "") + ' ' + String(current.taskTime || '');
        const candidateDate = String(candidate.taskDate || "") + ' ' + String(candidate.taskTime || '');
        if (candidateDate > currentDate) taskMap.set(dealId, candidate);
      }
    });
  }
  return dealDues.map((item) => {
    const related = taskMap.get(String(item.dealId || "").trim());
    if (!related) return item;
    return Object.assign({}, item, {
      relatedTaskId: related.taskId,
      relatedTaskTitle: related.title,
      relatedTaskNotes: related.notes,
      relatedTaskStatus: related.status,
      hasTask: true
    });
  });
}

app.get("/api/agenda/items", authRequired, async (req, res) => {
  try {
    const limit = Math.max(25, Math.min(200, Number(req.query.limit || 150)));
    const range = getAgendaRange(req.query.mode || "vencidos", req.query.start || "", req.query.end || "");
    const ownerScope = await getAgendaOwnerScope(req.authUser, req.query.owner || "");
    const stageFilter = normalizeAgendaStageFilter(req.query.stage || "important");
    const taskStatus = String(req.query.taskStatus || "pending").trim().toLowerCase();
    const q = String(req.query.q || "").trim();
    const itemType = String(req.query.itemType || "all").trim().toLowerCase();
    const includeTasks = itemType !== "deals";
    const includeDeals = itemType !== "tasks" && range.mode !== "tareas";

    if (Array.isArray(ownerScope.owners) && !ownerScope.owners.length) {
      return res.json({ ok: true, items: [], summary: { total: 0, tasks: 0, deals: 0, overdue: 0, today: 0, tomorrow: 0 }, rangeLabel: range.rangeLabel });
    }

    const [tasks, rawDealDues] = await Promise.all([
      includeTasks ? loadAgendaTasks(req, range, ownerScope, taskStatus, stageFilter, q, limit) : Promise.resolve([]),
      includeDeals ? loadAgendaDealDues(req, range, ownerScope, stageFilter, q, limit) : Promise.resolve([])
    ]);
    const dealDues = includeDeals ? await enrichAgendaDealDuesWithTasks(rawDealDues) : [];

    let items = tasks.concat(dealDues).sort(agendaSortItems).slice(0, limit);
    const today = getTodayISOInBuenosAires();
    const tomorrow = dateToISOUTC(addDaysUTC(isoToDateUTC(today), 1));
    const summary = {
      total: items.length,
      tasks: items.filter((item) => item.type === "task").length,
      deals: items.filter((item) => item.type === "deal_due").length,
      overdue: items.filter((item) => String(item.date || "") < today).length,
      today: items.filter((item) => String(item.date || "") === today).length,
      tomorrow: items.filter((item) => String(item.date || "") === tomorrow).length
    };

    return res.json({ ok: true, items, summary, rangeLabel: range.rangeLabel, limit });
  } catch (err) {
    console.error("ERROR /api/agenda/items GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error cargando agenda" });
  }
});

app.get("/api/agenda/contact-search", authRequired, async (req, res) => {
  try {
    const q = String(req.query.q || "").trim();
    const limit = Math.max(1, Math.min(10, Number(req.query.limit || 10)));
    if (q.length < 3) return res.json({ ok: true, contacts: [] });
    const visibleOwnerEmails = await getVisibleOwnerEmails(req.authUser);
    const visible = Array.isArray(visibleOwnerEmails)
      ? visibleOwnerEmails.map((email) => String(email || "").trim().toLowerCase()).filter(Boolean)
      : null;

    const scanLimit = 250;
    const snap = await db.collection("contacts")
      .orderBy("createdAt", "desc")
      .orderBy(admin.firestore.FieldPath.documentId(), "desc")
      .limit(scanLimit)
      .get();

    const contacts = [];
    for (const doc of snap.docs) {
      const contact = normalizeContactForList(doc.id, doc.data() || {});
      const owner = String(contact.owner || "").trim().toLowerCase();
      if (visible !== null && !visible.includes(owner)) continue;
      if (!contactMatchesSearch(contact, q)) continue;
      contacts.push({
        id: contact.id,
        name: contact.name || "",
        company: contact.company || "",
        phone: contact.phone || "",
        email: contact.email || "",
        province: contact.province || "",
        owner: contact.owner || "",
        contactStatus: contact.contactStatus || "lead"
      });
      if (contacts.length >= limit) break;
    }
    return res.json({ ok: true, contacts, scanned: snap.size });
  } catch (err) {
    console.error("ERROR /api/agenda/contact-search GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error buscando contacto" });
  }
});

app.get("/api/agenda/contact/:contactId/deals", authRequired, async (req, res) => {
  try {
    const contactId = String(req.params.contactId || "").trim();
    if (!contactId) return res.status(400).json({ ok: false, error: "Falta contacto" });
    const contactSnap = await db.collection("contacts").doc(contactId).get();
    if (!contactSnap.exists) return res.status(404).json({ ok: false, error: "Contacto no encontrado" });
    const contact = contactSnap.data() || {};
    if (!(await canSeeOwner(req.authUser, contact.owner || ""))) return res.status(403).json({ ok: false, error: "No tenés permiso para ver este contacto" });

    const snap = await db.collection("deals").where("contactId", "==", contactId).limit(30).get();
    let deals = [];
    snap.docs.forEach((doc) => {
      const data = doc.data() || {};
      if (!agendaStageAllowed(String(data.stage || ""), { mode: "all", stage: "" })) return;
      deals.push({
        id: doc.id,
        title: data.title || "",
        contactId: data.contactId || "",
        contactName: data.contactName || contact.name || "",
        stage: data.stage || "",
        owner: data.owner || "",
        dueDate: data.dueDate || "",
        dealType: normalizeDealType(data.dealType || "LCL_PROPIO")
      });
    });
    const visibleDeals = [];
    for (const deal of deals) {
      if (await canSeeOwner(req.authUser, deal.owner || "")) visibleDeals.push(deal);
    }
    deals = visibleDeals
      .sort((a, b) => String(b.dueDate || "").localeCompare(String(a.dueDate || "")))
      .slice(0, 20);
    return res.json({ ok: true, deals });
  } catch (err) {
    console.error("ERROR /api/agenda/contact/:contactId/deals GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error cargando tratos del contacto" });
  }
});

app.get("/api/agenda/deal/:dealId", authRequired, async (req, res) => {
  try {
    const dealId = String(req.params.dealId || "").trim();
    const dealSnap = await db.collection("deals").doc(dealId).get();
    if (!dealSnap.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });
    const dealData = dealSnap.data() || {};
    if (!(await canSeeOwner(req.authUser, dealData.owner || ""))) return res.status(403).json({ ok: false, error: "No tenés permiso para ver este trato" });
    let contact = {};
    if (dealData.contactId) {
      const contactSnap = await db.collection("contacts").doc(String(dealData.contactId)).get();
      contact = contactSnap.exists ? { id: contactSnap.id, ...(contactSnap.data() || {}) } : {};
    }
    return res.json({
      ok: true,
      contact,
      deal: {
        id: dealSnap.id,
        title: dealData.title || "",
        contactId: dealData.contactId || "",
        contactName: dealData.contactName || contact.name || "",
        stage: dealData.stage || "",
        owner: dealData.owner || "",
        dueDate: dealData.dueDate || "",
        dealType: normalizeDealType(dealData.dealType || "LCL_PROPIO")
      }
    });
  } catch (err) {
    console.error("ERROR /api/agenda/deal/:dealId GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error leyendo trato" });
  }
});

app.post("/api/tasks", authRequired, async (req, res) => {
  try {
    const body = req.body || {};
    const contactId = String(body.contactId || "").trim();
    const dealId = String(body.dealId || "").trim();
    const title = String(body.title || "").trim();
    const taskDate = String(body.taskDate || "").trim();
    const taskTime = String(body.taskTime || "").trim();
    const notes = String(body.notes || "").trim();

    if (!contactId) return res.status(400).json({ ok: false, error: "Contacto obligatorio" });
    if (!dealId) return res.status(400).json({ ok: false, error: "Trato obligatorio" });
    if (!title) return res.status(400).json({ ok: false, error: "Título obligatorio" });
    if (!agendaDateIsValid(taskDate)) return res.status(400).json({ ok: false, error: "Fecha inválida" });
    if (taskTime && !/^\d{2}:\d{2}$/.test(taskTime)) return res.status(400).json({ ok: false, error: "Hora inválida" });

    const [contactSnap, dealSnap] = await Promise.all([
      db.collection("contacts").doc(contactId).get(),
      db.collection("deals").doc(dealId).get()
    ]);
    if (!contactSnap.exists) return res.status(404).json({ ok: false, error: "Contacto no encontrado" });
    if (!dealSnap.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });
    const contact = contactSnap.data() || {};
    const deal = dealSnap.data() || {};
    if (String(deal.contactId || "") !== contactId) return res.status(400).json({ ok: false, error: "El trato no pertenece al contacto seleccionado" });
    if (!(await canSeeOwner(req.authUser, deal.owner || contact.owner || ""))) return res.status(403).json({ ok: false, error: "No tenés permiso para crear tarea sobre este trato" });

    const owner = String(deal.owner || contact.owner || req.authUser.email || "").trim().toLowerCase();
    const taskPayload = {
      title,
      taskDate,
      taskTime,
      status: "pending",
      owner,
      contactId,
      contactName: String(contact.name || deal.contactName || "").trim(),
      dealId,
      dealTitle: String(deal.title || "").trim(),
      stage: String(deal.stage || "").trim(),
      notes,
      createdBy: String(req.authUser.email || req.authUser.id || ""),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    const ref = await db.collection("tasks").add(taskPayload);
    return res.json({ ok: true, id: ref.id, task: { id: ref.id, ...taskPayload, createdAt: undefined, updatedAt: undefined } });
  } catch (err) {
    console.error("ERROR /api/tasks POST:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error creando tarea" });
  }
});

app.get("/api/tasks/:id", authRequired, async (req, res) => {
  try {
    const id = String(req.params.id || "").trim();
    if (!id) return res.status(400).json({ ok: false, error: "Falta id" });
    const ref = db.collection("tasks").doc(id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ ok: false, error: "Tarea no encontrada" });
    const data = snap.data() || {};
    const owner = String(data.owner || "").trim().toLowerCase();
    const ownerScope = await getAgendaOwnerScope(req.authUser, "");
    if (!agendaOwnerCanSee(ownerScope, owner)) return res.status(403).json({ ok: false, error: "Sin permiso" });
    return res.json({ ok: true, task: {
      id,
      title: String(data.title || "").trim(),
      taskDate: String(data.taskDate || "").trim(),
      taskTime: String(data.taskTime || "").trim(),
      notes: String(data.notes || "").trim(),
      owner: String(data.owner || "").trim(),
      contactId: String(data.contactId || "").trim(),
      contactName: String(data.contactName || "").trim(),
      dealId: String(data.dealId || "").trim(),
      dealTitle: String(data.dealTitle || "").trim(),
      stage: String(data.stage || "").trim(),
      status: normalizeAgendaTaskStatus(data.status || "pending")
    }});
  } catch (err) {
    console.error("ERROR /api/tasks/:id GET:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error cargando tarea" });
  }
});

app.put("/api/tasks/:id", authRequired, async (req, res) => {
  try {
    const id = String(req.params.id || "").trim();
    const ref = db.collection("tasks").doc(id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ ok: false, error: "Tarea no encontrada" });
    const current = snap.data() || {};
    if (!(await canSeeOwner(req.authUser, current.owner || ""))) return res.status(403).json({ ok: false, error: "No tenés permiso para editar esta tarea" });
    const payload = { updatedAt: new Date() };
    if (typeof req.body.title === "string") {
      const title = String(req.body.title || "").trim();
      if (!title) return res.status(400).json({ ok: false, error: "Título obligatorio" });
      payload.title = title;
    }
    if (typeof req.body.taskDate === "string") {
      const taskDate = String(req.body.taskDate || "").trim();
      if (!agendaDateIsValid(taskDate)) return res.status(400).json({ ok: false, error: "Fecha inválida" });
      payload.taskDate = taskDate;
    }
    if (typeof req.body.taskTime === "string") {
      const taskTime = String(req.body.taskTime || "").trim();
      if (taskTime && !/^\d{2}:\d{2}$/.test(taskTime)) return res.status(400).json({ ok: false, error: "Hora inválida" });
      payload.taskTime = taskTime;
    }
    if (typeof req.body.notes === "string") payload.notes = String(req.body.notes || "").trim();
    await ref.update(payload);
    return res.json({ ok: true });
  } catch (err) {
    console.error("ERROR /api/tasks/:id PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error editando tarea" });
  }
});

app.put("/api/tasks/:id/status", authRequired, async (req, res) => {
  try {
    const id = String(req.params.id || "").trim();
    const status = normalizeAgendaTaskStatus(req.body && req.body.status);
    const ref = db.collection("tasks").doc(id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ ok: false, error: "Tarea no encontrada" });
    const current = snap.data() || {};
    if (!(await canSeeOwner(req.authUser, current.owner || ""))) return res.status(403).json({ ok: false, error: "No tenés permiso para modificar esta tarea" });
    await ref.update({ status, completedAt: status === "done" ? new Date() : null, updatedAt: new Date() });
    return res.json({ ok: true, status });
  } catch (err) {
    console.error("ERROR /api/tasks/:id/status PUT:", err);
    return res.status(500).json({ ok: false, error: err.message || "Error actualizando tarea" });
  }
});


// =====================================================
// BLOQUE 6H - PLAN DE PRODUCCIÓN COMERCIAL POR M3
// Capa aislada: no reemplaza KPI ni funciones existentes.
// =====================================================

const PRODUCTION_PLANS_COLLECTION = "production_plans";
const DEFAULT_PRODUCTION_LEVELS = [
  { level: 1, name: "Despegue", minCbm: 0, maxCbm: 12.9999, rate: 2 },
  { level: 2, name: "Velocidad de Crucero", minCbm: 13, maxCbm: 18.9999, rate: 4 },
  { level: 3, name: "Capitán", minCbm: 19, maxCbm: 23.9999, rate: 6 },
  { level: 4, name: "Comandante SCB", minCbm: 24, maxCbm: null, rate: 8 }
];

function sanitizeProductionNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}

function sanitizeProductionLevels(levels) {
  const source = Array.isArray(levels) && levels.length ? levels : DEFAULT_PRODUCTION_LEVELS;
  return source.slice(0, 8).map((item, idx) => ({
    level: idx + 1,
    name: String((item && item.name) || `Nivel ${idx + 1}`).trim().slice(0, 80),
    minCbm: sanitizeProductionNumber(item && item.minCbm, 0),
    maxCbm: item && (item.maxCbm === null || item.maxCbm === "") ? null : sanitizeProductionNumber(item && item.maxCbm, 0),
    rate: Math.min(100, sanitizeProductionNumber(item && item.rate, 0))
  })).sort((a, b) => a.minCbm - b.minCbm);
}

function getProductionLevel(cbm, plan) {
  const value = sanitizeProductionNumber(cbm, 0);
  const levels = sanitizeProductionLevels(plan && plan.levels);
  let current = levels[0] || { level: 1, name: "Nivel 1", minCbm: 0, maxCbm: null, rate: 0 };
  levels.forEach((level) => {
    const withinMax = level.maxCbm === null || value <= Number(level.maxCbm);
    if (value >= Number(level.minCbm || 0) && withinMax) current = level;
    if (value >= Number(level.minCbm || 0) && level.maxCbm === null) current = level;
  });
  const next = levels.find((level) => Number(level.minCbm || 0) > value) || null;
  return { current, next, levels };
}

function monthRangeFromReference(referenceDate) {
  const raw = /^\d{4}-\d{2}-\d{2}$/.test(String(referenceDate || "")) ? String(referenceDate) : getTodayISOInBuenosAires();
  const monthly = getMonthlyPeriodFromISO(raw);
  return monthly || getMonthlyPeriodFromISO(getTodayISOInBuenosAires());
}

function getProductionMonthFromWarehouseDate(value) {
  const date = String(value || "").trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(date) ? date.slice(0, 7) : "";
}

function buildProductionEligibilityFields(dealLike) {
  const deal = dealLike && typeof dealLike === "object" ? dealLike : {};
  const stage = String(deal.stage || "").trim();
  const cbm = sanitizeProductionNumber(deal.cbm, 0);
  const warehouseEntryDate = String(deal.warehouseEntryDate || "").trim();
  const productionMonth = getProductionMonthFromWarehouseDate(warehouseEntryDate);
  const productionEligible =
    stage === "Ganado maritimo" &&
    cbm > 0 &&
    !!productionMonth;

  return {
    productionEligible,
    productionMonth: productionEligible ? productionMonth : ""
  };
}

async function ensureProductionEligibilityBackfillForMonth(monthKey) {
  const cleanMonth = String(monthKey || "").trim();
  if (!/^\d{4}-\d{2}$/.test(cleanMonth)) return;

  const markerRef = db.collection("production_meta").doc(`eligibility_backfill_${cleanMonth}`);
  const markerSnap = await markerRef.get();
  if (markerSnap.exists) return;

  const wonSnap = await db.collection("deals")
    .where("stage", "==", "Ganado maritimo")
    .get();

  const updates = [];
  wonSnap.docs.forEach((doc) => {
    const deal = doc.data() || {};
    const fields = buildProductionEligibilityFields(deal);
    if (fields.productionEligible && fields.productionMonth === cleanMonth) {
      updates.push({ ref: doc.ref, fields });
    }
  });

  for (const chunk of splitRowsForBatch(updates, 400)) {
    const batch = db.batch();
    chunk.forEach((item) => {
      batch.update(item.ref, {
        ...item.fields,
        productionEligibilityUpdatedAt: new Date()
      });
    });
    if (chunk.length) await batch.commit();
  }

  await markerRef.set({
    month: cleanMonth,
    scannedWonMaritimeDeals: wonSnap.size,
    updatedEligibleDeals: updates.length,
    completedAt: new Date()
  });
}

async function getEligibleProductionDealsForPeriod(period) {
  const monthKey = String((period && period.periodKey) || "").trim();
  if (!/^\d{4}-\d{2}$/.test(monthKey)) return [];

  await ensureProductionEligibilityBackfillForMonth(monthKey);

  const snap = await db.collection("deals")
    .where("productionMonth", "==", monthKey)
    .get();

  return snap.docs.map((doc) => ({ id: doc.id, ...(doc.data() || {}) }))
    .filter((deal) =>
      deal.productionEligible === true &&
      String(deal.stage || "").trim() === "Ganado maritimo" &&
      sanitizeProductionNumber(deal.cbm, 0) > 0 &&
      String(deal.warehouseEntryDate || "").slice(0, 7) === monthKey
    );
}

function dealProductionStatus(deal) {
  const warehouseEntryDate = String((deal && deal.warehouseEntryDate) || "").trim();
  const containerDepartureDate = String((deal && deal.containerDepartureDate) || "").trim();
  const commissionPaid = !!(deal && deal.commissionPaid);
  if (commissionPaid) return "paid";
  if (containerDepartureDate) return "ready_to_pay";
  if (warehouseEntryDate) return "counted_pending_departure";
  return "pending_warehouse";
}

async function getProductionPlanForUser(userId) {
  const cleanId = String(userId || "").trim();
  if (!cleanId) return null;
  const snap = await db.collection(PRODUCTION_PLANS_COLLECTION).doc(cleanId).get();
  if (!snap.exists) return null;
  const data = snap.data() || {};
  return {
    id: snap.id,
    userId: cleanId,
    active: data.active === true,
    monthlyTargetCbm: sanitizeProductionNumber(data.monthlyTargetCbm, 0),
    hunterBonusRate: Math.min(100, sanitizeProductionNumber(data.hunterBonusRate, 2)),
    levels: sanitizeProductionLevels(data.levels),
    createdAt: data.createdAt || null,
    updatedAt: data.updatedAt || null
  };
}

async function buildProductionSummaryForUser(user, plan, period, eligibleDeals) {
  const ownerEmail = String((user && user.email) || "").trim().toLowerCase();
  const sourceDeals = Array.isArray(eligibleDeals) ? eligibleDeals : await getEligibleProductionDealsForPeriod(period);
  const deals = sourceDeals.filter((deal) =>
    String(deal.owner || "").trim().toLowerCase() === ownerEmail
  );

  const productionCbm = deals.reduce((sum, deal) => sum + sanitizeProductionNumber(deal.cbm, 0), 0);
  const levelData = getProductionLevel(productionCbm, plan);
  const baseRate = sanitizeProductionNumber(levelData.current.rate, 0);
  const hunterBonusRate = sanitizeProductionNumber(plan.hunterBonusRate, 2);
  const salesValue = deals.reduce((sum, deal) => sum + sanitizeProductionNumber(deal.value, 0), 0);
  const hunterSalesValue = deals.filter((deal) => deal.isHunterSale === true).reduce((sum, deal) => sum + sanitizeProductionNumber(deal.value, 0), 0);
  const baseCommission = salesValue * baseRate / 100;
  const hunterCommission = hunterSalesValue * hunterBonusRate / 100;
  const totalCommission = baseCommission + hunterCommission;
  const payableDeals = deals.filter((deal) => String(deal.containerDepartureDate || "").trim());
  const payableBaseValue = payableDeals.reduce((sum, deal) => sum + sanitizeProductionNumber(deal.value, 0), 0);
  const payableHunterValue = payableDeals.filter((deal) => deal.isHunterSale === true).reduce((sum, deal) => sum + sanitizeProductionNumber(deal.value, 0), 0);
  const payableCommission = payableBaseValue * baseRate / 100 + payableHunterValue * hunterBonusRate / 100;
  const paidDeals = payableDeals.filter((deal) => deal.commissionPaid === true);
  const paidBaseValue = paidDeals.reduce((sum, deal) => sum + sanitizeProductionNumber(deal.value, 0), 0);
  const paidHunterValue = paidDeals.filter((deal) => deal.isHunterSale === true).reduce((sum, deal) => sum + sanitizeProductionNumber(deal.value, 0), 0);
  const paidCommission = paidBaseValue * baseRate / 100 + paidHunterValue * hunterBonusRate / 100;
  const target = sanitizeProductionNumber(plan.monthlyTargetCbm, 0);
  const progressPct = target > 0 ? Math.min(999, productionCbm / target * 100) : 0;
  const nextMin = levelData.next ? sanitizeProductionNumber(levelData.next.minCbm, 0) : null;

  return {
    userId: String(user.id || ""),
    userName: String(user.name || user.email || "Sin nombre"),
    userEmail: ownerEmail,
    active: plan.active === true,
    targetCbm: target,
    productionCbm,
    progressPct,
    currentLevel: levelData.current,
    nextLevel: levelData.next,
    cbmToNextLevel: nextMin === null ? 0 : Math.max(0, nextMin - productionCbm),
    baseRate,
    hunterBonusRate,
    finalRateForHunterSales: baseRate + hunterBonusRate,
    salesValue,
    hunterSalesValue,
    baseCommission,
    hunterCommission,
    totalCommission,
    payableCommission,
    paidCommission,
    pendingPaymentCommission: Math.max(0, payableCommission - paidCommission),
    deals: deals.map((deal) => ({
      id: deal.id,
      title: String(deal.title || ""),
      contactName: String(deal.contactName || ""),
      dealType: normalizeDealType(deal.dealType || "LCL_PROPIO"),
      value: sanitizeProductionNumber(deal.value, 0),
      cbm: sanitizeProductionNumber(deal.cbm, 0),
      isHunterSale: deal.isHunterSale === true,
      warehouseEntryDate: String(deal.warehouseEntryDate || ""),
      containerDepartureDate: String(deal.containerDepartureDate || ""),
      commissionPaid: deal.commissionPaid === true,
      status: dealProductionStatus(deal),
      estimatedCommission: sanitizeProductionNumber(deal.value, 0) * baseRate / 100 + (deal.isHunterSale === true ? sanitizeProductionNumber(deal.value, 0) * hunterBonusRate / 100 : 0)
    })).sort((a, b) => String(b.warehouseEntryDate).localeCompare(String(a.warehouseEntryDate)))
  };
}

app.get("/api/production/plans", authRequired, async (req, res) => {
  try {
    const users = await getUsersList();
    const snaps = await db.collection(PRODUCTION_PLANS_COLLECTION).get();
    const map = new Map();
    snaps.docs.forEach((doc) => map.set(doc.id, doc.data() || {}));
    let rows = users.map((user) => {
      const data = map.get(user.id) || {};
      return {
        userId: user.id,
        userName: user.name || user.email || "Sin nombre",
        userEmail: user.email || "",
        role: normalizeRole(user.role),
        active: data.active === true,
        monthlyTargetCbm: sanitizeProductionNumber(data.monthlyTargetCbm, 0),
        hunterBonusRate: Math.min(100, sanitizeProductionNumber(data.hunterBonusRate, 2)),
        levels: sanitizeProductionLevels(data.levels)
      };
    });
    if (isSeller(req.authUser)) rows = rows.filter((row) => row.userId === req.authUser.id && row.active);
    else if (!isAdmin(req.authUser)) rows = rows.filter((row) => row.active);
    return res.json({ ok: true, plans: rows });
  } catch (error) {
    console.error("ERROR /api/production/plans GET:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error cargando planes" });
  }
});

app.put("/api/production/plans/:userId", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) return res.status(403).json({ ok: false, error: "Solo admin puede configurar planes" });
    const userId = String(req.params.userId || "").trim();
    const userSnap = await db.collection("users").doc(userId).get();
    if (!userSnap.exists) return res.status(404).json({ ok: false, error: "Usuario no encontrado" });
    const ref = db.collection(PRODUCTION_PLANS_COLLECTION).doc(userId);
    const prev = await ref.get();
    const payload = {
      userId,
      active: req.body && req.body.active === true,
      monthlyTargetCbm: sanitizeProductionNumber(req.body && req.body.monthlyTargetCbm, 0),
      hunterBonusRate: Math.min(100, sanitizeProductionNumber(req.body && req.body.hunterBonusRate, 2)),
      levels: sanitizeProductionLevels(req.body && req.body.levels),
      updatedAt: new Date()
    };
    if (!prev.exists) payload.createdAt = new Date();
    await ref.set(payload, { merge: true });
    return res.json({ ok: true, plan: payload });
  } catch (error) {
    console.error("ERROR /api/production/plans/:userId PUT:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error guardando plan" });
  }
});

app.get("/api/production/summary", authRequired, async (req, res) => {
  try {
    const period = monthRangeFromReference(req.query.referenceDate || "");
    const requestedUserId = String(req.query.userId || "").trim();
    const users = await getUsersList();
    let targetUsers = users;
    if (isSeller(req.authUser)) targetUsers = users.filter((user) => user.id === req.authUser.id);
    else if (requestedUserId) targetUsers = users.filter((user) => user.id === requestedUserId);

    const eligibleDeals = await getEligibleProductionDealsForPeriod(period);
    const rows = [];
    for (const user of targetUsers) {
      const plan = await getProductionPlanForUser(user.id);
      if (!plan || !plan.active) continue;
      rows.push(await buildProductionSummaryForUser(user, plan, period, eligibleDeals));
    }
    return res.json({ ok: true, period, rows });
  } catch (error) {
    console.error("ERROR /api/production/summary GET:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error calculando producción" });
  }
});

app.put("/api/deals/:id/production", authRequired, async (req, res) => {
  try {
    const id = String(req.params.id || "").trim();
    const ref = db.collection("deals").doc(id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ ok: false, error: "Trato no encontrado" });
    const current = snap.data() || {};
    if (!(await canEditOwner(req.authUser, current.owner || ""))) return res.status(403).json({ ok: false, error: "Sin permiso para editar este trato" });
    const payload = { updatedAt: new Date() };
    if (Object.prototype.hasOwnProperty.call(req.body || {}, "cbm")) payload.cbm = sanitizeProductionNumber(req.body.cbm, 0);
    if (Object.prototype.hasOwnProperty.call(req.body || {}, "isHunterSale")) payload.isHunterSale = req.body.isHunterSale === true;
    if (Object.prototype.hasOwnProperty.call(req.body || {}, "warehouseEntryDate")) payload.warehouseEntryDate = String(req.body.warehouseEntryDate || "").trim();
    if (Object.prototype.hasOwnProperty.call(req.body || {}, "containerDepartureDate")) payload.containerDepartureDate = String(req.body.containerDepartureDate || "").trim();
    if (Object.prototype.hasOwnProperty.call(req.body || {}, "commissionPaid")) {
      if (!(isAdmin(req.authUser) || isBackoffice(req.authUser))) return res.status(403).json({ ok: false, error: "Solo administración puede marcar comisión pagada" });
      payload.commissionPaid = req.body.commissionPaid === true;
      payload.commissionPaidAt = payload.commissionPaid ? new Date() : null;
    }
    const mergedProductionDeal = { ...current, ...payload };
    Object.assign(payload, buildProductionEligibilityFields(mergedProductionDeal));
    await ref.update(payload);
    return res.json({ ok: true, production: payload });
  } catch (error) {
    console.error("ERROR /api/deals/:id/production PUT:", error);
    return res.status(500).json({ ok: false, error: error.message || "Error guardando producción" });
  }
});


// =====================================================
// BLOQUE 6H2 - EQUIPOS / OFICINAS DE PRODUCCIÓN POR M3
// La escala se alcanza por el total del equipo y se aplica
// sobre las ventas propias de cada integrante.
// =====================================================
const PRODUCTION_TEAMS_COLLECTION = "production_teams";

function sanitizeProductionTeamPayload(input) {
  const source = input && typeof input === "object" ? input : {};
  const mode = String(source.mode || "manual").trim().toLowerCase() === "team_leader" ? "team_leader" : "manual";
  const memberUserIds = Array.from(new Set((Array.isArray(source.memberUserIds) ? source.memberUserIds : [])
    .map((id) => String(id || "").trim()).filter(Boolean)));
  return {
    name: String(source.name || "Equipo comercial").trim().slice(0, 120),
    active: source.active === true,
    mode,
    teamLeaderId: String(source.teamLeaderId || "").trim(),
    memberUserIds,
    monthlyTargetCbm: sanitizeProductionNumber(source.monthlyTargetCbm, 0),
    hunterBonusRate: Math.min(100, sanitizeProductionNumber(source.hunterBonusRate, 2)),
    levels: sanitizeProductionLevels(source.levels)
  };
}

async function resolveProductionTeamMembers(team, users) {
  const list = Array.isArray(users) ? users : await getUsersList();
  const ids = new Set();
  if (String(team.mode || "manual") === "team_leader" && team.teamLeaderId) {
    ids.add(String(team.teamLeaderId));
    list.forEach((u) => {
      if (String(u.teamLeaderId || "") === String(team.teamLeaderId || "") && normalizeRole(u.role) === "field_sales") ids.add(String(u.id));
    });
  }
  (Array.isArray(team.memberUserIds) ? team.memberUserIds : []).forEach((id) => ids.add(String(id)));
  return list.filter((u) => ids.has(String(u.id)));
}

async function buildProductionTeamSummary(teamDoc, period, users, eligibleDeals) {
  const team = { id: teamDoc.id, ...(teamDoc.data ? teamDoc.data() : teamDoc) };
  const members = await resolveProductionTeamMembers(team, users);
  const sourceDeals = Array.isArray(eligibleDeals) ? eligibleDeals : await getEligibleProductionDealsForPeriod(period);
  const memberRows = [];
  let teamCbm = 0;
  let teamSales = 0;
  let teamHunterSales = 0;

  for (const member of members) {
    const ownerEmail = String(member.email || "").trim().toLowerCase();
    const deals = sourceDeals.filter((deal) =>
      String(deal.owner || "").trim().toLowerCase() === ownerEmail
    );
    const cbm = deals.reduce((s, d) => s + sanitizeProductionNumber(d.cbm, 0), 0);
    const salesValue = deals.reduce((s, d) => s + sanitizeProductionNumber(d.value, 0), 0);
    const hunterSalesValue = deals.filter((d) => d.isHunterSale === true).reduce((s, d) => s + sanitizeProductionNumber(d.value, 0), 0);
    teamCbm += cbm;
    teamSales += salesValue;
    teamHunterSales += hunterSalesValue;
    memberRows.push({ member, ownerEmail, deals, cbm, salesValue, hunterSalesValue });
  }

  const levelData = getProductionLevel(teamCbm, team);
  const baseRate = sanitizeProductionNumber(levelData.current.rate, 0);
  const hunterBonusRate = sanitizeProductionNumber(team.hunterBonusRate, 2);
  const target = sanitizeProductionNumber(team.monthlyTargetCbm, 0);

  const membersSummary = memberRows.map((row) => {
    const baseCommission = row.salesValue * baseRate / 100;
    const hunterCommission = row.hunterSalesValue * hunterBonusRate / 100;
    const payableDeals = row.deals.filter((d) => String(d.containerDepartureDate || "").trim());
    const payableSales = payableDeals.reduce((s, d) => s + sanitizeProductionNumber(d.value, 0), 0);
    const payableHunterSales = payableDeals.filter((d) => d.isHunterSale === true).reduce((s, d) => s + sanitizeProductionNumber(d.value, 0), 0);
    const paidDeals = payableDeals.filter((d) => d.commissionPaid === true);
    const paidSales = paidDeals.reduce((s, d) => s + sanitizeProductionNumber(d.value, 0), 0);
    const paidHunterSales = paidDeals.filter((d) => d.isHunterSale === true).reduce((s, d) => s + sanitizeProductionNumber(d.value, 0), 0);
    const payableCommission = payableSales * baseRate / 100 + payableHunterSales * hunterBonusRate / 100;
    const paidCommission = paidSales * baseRate / 100 + paidHunterSales * hunterBonusRate / 100;
    return {
      userId: String(row.member.id || ""),
      userName: String(row.member.name || row.member.email || "Sin nombre"),
      userEmail: row.ownerEmail,
      role: normalizeRole(row.member.role),
      productionCbm: row.cbm,
      salesValue: row.salesValue,
      hunterSalesValue: row.hunterSalesValue,
      operationsCount: row.deals.length,
      baseRate,
      hunterBonusRate,
      baseCommission,
      hunterCommission,
      totalCommission: baseCommission + hunterCommission,
      payableCommission,
      paidCommission,
      pendingPaymentCommission: Math.max(0, payableCommission - paidCommission),
      deals: row.deals.map((d) => ({
        id: d.id, title: String(d.title || ""), contactName: String(d.contactName || ""),
        cbm: sanitizeProductionNumber(d.cbm, 0), value: sanitizeProductionNumber(d.value, 0),
        isHunterSale: d.isHunterSale === true, warehouseEntryDate: String(d.warehouseEntryDate || ""),
        containerDepartureDate: String(d.containerDepartureDate || ""), commissionPaid: d.commissionPaid === true,
        status: dealProductionStatus(d),
        estimatedCommission: sanitizeProductionNumber(d.value, 0) * baseRate / 100 + (d.isHunterSale === true ? sanitizeProductionNumber(d.value, 0) * hunterBonusRate / 100 : 0)
      })).sort((a,b) => String(b.warehouseEntryDate).localeCompare(String(a.warehouseEntryDate)))
    };
  }).sort((a,b) => b.productionCbm - a.productionCbm);

  const nextMin = levelData.next ? sanitizeProductionNumber(levelData.next.minCbm, 0) : null;
  return {
    teamId: String(team.id || ""), name: String(team.name || "Equipo comercial"), active: team.active === true,
    mode: String(team.mode || "manual"), teamLeaderId: String(team.teamLeaderId || ""),
    monthlyTargetCbm: target, productionCbm: teamCbm,
    progressPct: target > 0 ? Math.min(999, teamCbm / target * 100) : 0,
    currentLevel: levelData.current, nextLevel: levelData.next,
    cbmToNextLevel: nextMin === null ? 0 : Math.max(0, nextMin - teamCbm),
    baseRate, hunterBonusRate, salesValue: teamSales, hunterSalesValue: teamHunterSales,
    totalCommission: teamSales * baseRate / 100 + teamHunterSales * hunterBonusRate / 100,
    members: membersSummary,
    memberUserIds: members.map((u) => String(u.id || ""))
  };
}

app.get("/api/production/teams", authRequired, async (req, res) => {
  try {
    const users = await getUsersList();
    const snap = await db.collection(PRODUCTION_TEAMS_COLLECTION).get();
    const teams = [];
    for (const doc of snap.docs) {
      const data = sanitizeProductionTeamPayload(doc.data() || {});
      const members = await resolveProductionTeamMembers(data, users);
      teams.push({ id: doc.id, ...data, resolvedMemberUserIds: members.map((u) => u.id) });
    }
    let visible = teams;
    if (isSeller(req.authUser)) visible = teams.filter((t) => t.active && t.resolvedMemberUserIds.includes(req.authUser.id));
    else if (!isAdmin(req.authUser)) visible = teams.filter((t) => t.active);
    return res.json({ ok: true, teams: visible, users: isAdmin(req.authUser) ? users.map((u) => ({ id:u.id,name:u.name,email:u.email,role:normalizeRole(u.role),teamLeaderId:u.teamLeaderId||"" })) : undefined });
  } catch (error) {
    console.error("ERROR /api/production/teams GET:", error);
    return res.status(500).json({ ok:false, error:error.message || "Error cargando equipos" });
  }
});

app.post("/api/production/teams", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) return res.status(403).json({ok:false,error:"Solo admin puede crear equipos"});
    const payload = sanitizeProductionTeamPayload(req.body || {});
    if (!payload.name) return res.status(400).json({ok:false,error:"El nombre del equipo es obligatorio"});
    const ref = db.collection(PRODUCTION_TEAMS_COLLECTION).doc();
    await ref.set({ ...payload, createdAt:new Date(), updatedAt:new Date() });
    return res.json({ok:true,id:ref.id});
  } catch(error) { return res.status(500).json({ok:false,error:error.message || "Error creando equipo"}); }
});

app.put("/api/production/teams/:id", authRequired, async (req, res) => {
  try {
    if (!isAdmin(req.authUser)) return res.status(403).json({ok:false,error:"Solo admin puede editar equipos"});
    const id=String(req.params.id||"").trim(); const ref=db.collection(PRODUCTION_TEAMS_COLLECTION).doc(id);
    const snap=await ref.get(); if(!snap.exists)return res.status(404).json({ok:false,error:"Equipo no encontrado"});
    const payload=sanitizeProductionTeamPayload(req.body||{}); await ref.set({...payload,updatedAt:new Date()},{merge:true});
    return res.json({ok:true});
  } catch(error) { return res.status(500).json({ok:false,error:error.message || "Error guardando equipo"}); }
});

app.delete("/api/production/teams/:id", authRequired, async (req,res)=>{
  try { if(!isAdmin(req.authUser))return res.status(403).json({ok:false,error:"Solo admin puede borrar equipos"}); await db.collection(PRODUCTION_TEAMS_COLLECTION).doc(String(req.params.id||"")).delete(); return res.json({ok:true}); }
  catch(error){return res.status(500).json({ok:false,error:error.message||"Error borrando equipo"});}
});

app.get("/api/production/team-summary", authRequired, async (req,res)=>{
  try {
    const period=monthRangeFromReference(req.query.referenceDate||""); const users=await getUsersList();
    const eligibleDeals=await getEligibleProductionDealsForPeriod(period);
    const snap=await db.collection(PRODUCTION_TEAMS_COLLECTION).get(); const rows=[];
    for(const doc of snap.docs){ const data=doc.data()||{}; if(data.active!==true)continue; const members=await resolveProductionTeamMembers(data,users);
      if(isSeller(req.authUser)&&!members.some((u)=>u.id===req.authUser.id))continue;
      const summary=await buildProductionTeamSummary(doc,period,users,eligibleDeals);
      if(isSeller(req.authUser)){
        summary.viewerUserId=req.authUser.id;
        summary.viewerMember=summary.members.find((m)=>m.userId===req.authUser.id)||null;
        if(!isTeamLeader(req.authUser)) summary.members=summary.members.filter((m)=>m.userId===req.authUser.id);
      }
      rows.push(summary);
    }
    return res.json({ok:true,period,rows});
  }catch(error){console.error("ERROR team-summary",error);return res.status(500).json({ok:false,error:error.message||"Error calculando equipos"});}
});

const PRODUCTION_UI_JS = String.raw`
(function(){
  if(window.__SCB_PRODUCTION_UI__) return;
  window.__SCB_PRODUCTION_UI__=true;
  var path=window.location.pathname||'';
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function money(v){return 'USD '+Number(v||0).toLocaleString('es-AR',{minimumFractionDigits:0,maximumFractionDigits:2});}
  function num(v,d){return Number(v||0).toLocaleString('es-AR',{minimumFractionDigits:d||0,maximumFractionDigits:d==null?2:d});}
  function currentUser(){try{return JSON.parse(localStorage.getItem('crmscb_user')||'{}');}catch(e){return {};}}
  function isAdmin(){return String(currentUser().role||'').toLowerCase()==='admin';}
  function authFetch(url,options){return window.fetch(url,options||{});}
  function modal(){
    var el=document.getElementById('scbProductionModal'); if(el)return el;
    el=document.createElement('div');el.id='scbProductionModal';el.style.cssText='position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:2000;display:none;align-items:center;justify-content:center;padding:16px';
    el.innerHTML='<div style="background:#fff;border-radius:16px;width:min(720px,100%);max-height:92vh;overflow:auto;padding:18px;box-sizing:border-box"><div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><h2 style="margin:0">Producción del trato</h2><button id="scbProdClose" class="secondary">Cerrar</button></div><div id="scbProdBody" style="margin-top:15px"></div></div>';
    document.body.appendChild(el);el.querySelector('#scbProdClose').onclick=function(){el.style.display='none';};el.onclick=function(e){if(e.target===el)el.style.display='none';};return el;
  }
  window.scbOpenProductionDeal=function(deal){
    var el=modal(),body=el.querySelector('#scbProdBody');
    body.innerHTML='<div style="font-weight:800;margin-bottom:12px">'+esc(deal.title||'Trato')+'</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:12px"><label>CBM vendido<input id="scbProdCbm" type="number" min="0" step="0.01" value="'+esc(deal.cbm||0)+'" style="width:100%;padding:11px;box-sizing:border-box;margin-top:5px"></label><label style="display:flex;align-items:end;gap:8px;padding-bottom:10px"><input id="scbProdHunter" type="checkbox" '+(deal.isHunterSale===true?'checked':'')+'> Venta Hunter (+2%)</label><label>Ingreso al warehouse<input id="scbProdWarehouse" type="date" value="'+esc(deal.warehouseEntryDate||'')+'" style="width:100%;padding:11px;box-sizing:border-box;margin-top:5px"></label><label>Salida del contenedor<input id="scbProdDeparture" type="date" value="'+esc(deal.containerDepartureDate||'')+'" style="width:100%;padding:11px;box-sizing:border-box;margin-top:5px"></label>'+(isAdmin()?'<label style="display:flex;align-items:end;gap:8px;padding-bottom:10px"><input id="scbProdPaid" type="checkbox" '+(deal.commissionPaid===true?'checked':'')+'> Comisión pagada</label>':'')+'</div><div style="margin-top:14px;color:#667085;font-size:13px">El CBM computa en el mes de ingreso al warehouse. La comisión queda lista para liquidar cuando se carga la salida del contenedor.</div><button id="scbProdSave" style="margin-top:16px;width:100%;padding:12px;background:#188038;color:#fff;border:0;border-radius:9px;font-weight:800">Guardar producción</button><div id="scbProdMsg" style="margin-top:10px"></div>';
    el.style.display='flex';
    body.querySelector('#scbProdSave').onclick=async function(){var btn=this,msg=body.querySelector('#scbProdMsg');btn.disabled=true;btn.textContent='Guardando...';try{var payload={cbm:Number(body.querySelector('#scbProdCbm').value||0),isHunterSale:body.querySelector('#scbProdHunter').checked,warehouseEntryDate:body.querySelector('#scbProdWarehouse').value||'',containerDepartureDate:body.querySelector('#scbProdDeparture').value||''};var paid=body.querySelector('#scbProdPaid');if(paid)payload.commissionPaid=paid.checked;var r=await authFetch('/api/deals/'+encodeURIComponent(deal.id)+'/production',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});var d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'No se pudo guardar');msg.style.color='#188038';msg.textContent='Producción guardada correctamente.';Object.assign(deal,payload);setTimeout(function(){el.style.display='none';if(typeof window.cargarDeals==='function')window.cargarDeals();},500);}catch(e){msg.style.color='#d93025';msg.textContent=e.message||'Error';}finally{btn.disabled=false;btn.textContent='Guardar producción';}};
  };
  function levelsText(row){var levels=(row.currentLevel&&row.currentLevel.level)?row.currentLevel.level:'-';return 'Nivel '+levels+' · '+esc((row.currentLevel&&row.currentLevel.name)||'')+' · '+num(row.baseRate,0)+'%';}
  function summaryCard(row){var pct=Math.max(0,Math.min(100,Number(row.progressPct||0)));return '<div style="background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:18px;box-shadow:0 3px 14px rgba(0,0,0,.06);margin-bottom:14px"><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><div style="font-size:20px;font-weight:900">'+esc(row.userName)+'</div><div style="color:#667085">'+levelsText(row)+'</div></div><div style="font-size:28px;font-weight:900;color:#174ea6">'+num(row.productionCbm,2)+' / '+num(row.targetCbm,2)+' m³</div></div><div style="height:14px;background:#e9eef7;border-radius:999px;overflow:hidden;margin:14px 0"><div style="height:100%;width:'+pct+'%;background:#1a73e8"></div></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:10px"><div><small>Venta computada</small><b style="display:block">'+money(row.salesValue)+'</b></div><div><small>Comisión base</small><b style="display:block">'+num(row.baseRate,0)+'% · '+money(row.baseCommission)+'</b></div><div><small>Hunter</small><b style="display:block">+'+num(row.hunterBonusRate,0)+'% · '+money(row.hunterCommission)+'</b></div><div><small>Total estimado</small><b style="display:block;color:#188038">'+money(row.totalCommission)+'</b></div><div><small>Listo para liquidar</small><b style="display:block">'+money(row.payableCommission)+'</b></div><div><small>Pendiente de pago</small><b style="display:block">'+money(row.pendingPaymentCommission)+'</b></div></div>'+(row.nextLevel?'<div style="margin-top:12px;padding:10px;background:#fff7e6;border-radius:10px">Te faltan <b>'+num(row.cbmToNextLevel,2)+' m³</b> para '+esc(row.nextLevel.name)+' ('+num(row.nextLevel.rate,0)+'%).</div>':'<div style="margin-top:12px;padding:10px;background:#e8f5e9;border-radius:10px"><b>Nivel máximo alcanzado.</b></div>')+'</div>';}
  function dealTable(row){if(!row.deals||!row.deals.length)return '<div style="color:#667085">Todavía no hay operaciones computadas en este mes.</div>';return '<div style="overflow:auto"><table style="width:100%;border-collapse:collapse"><thead><tr><th>Cliente / trato</th><th>CBM</th><th>Venta</th><th>Hunter</th><th>Warehouse</th><th>Salida</th><th>Comisión</th><th>Estado</th></tr></thead><tbody>'+row.deals.map(function(d){var labels={pending_warehouse:'Pendiente warehouse',counted_pending_departure:'Computado / espera salida',ready_to_pay:'Listo para liquidar',paid:'Pagado'};return '<tr><td><b>'+esc(d.contactName||'-')+'</b><br><small>'+esc(d.title||'')+'</small></td><td>'+num(d.cbm,2)+'</td><td>'+money(d.value)+'</td><td>'+(d.isHunterSale?'Sí (+2%)':'No')+'</td><td>'+esc(d.warehouseEntryDate||'-')+'</td><td>'+esc(d.containerDepartureDate||'-')+'</td><td>'+money(d.estimatedCommission)+'</td><td>'+esc(labels[d.status]||d.status)+'</td></tr>';}).join('')+'</tbody></table></div>';}
  async function loadSummary(container,referenceDate,userId){container.innerHTML='<div>Cargando producción...</div>';try{var q=new URLSearchParams();if(referenceDate)q.set('referenceDate',referenceDate);if(userId)q.set('userId',userId);q.set('ts',Date.now());var r=await authFetch('/api/production/summary?'+q.toString());var d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'Error');if(!d.rows.length){container.innerHTML='<div style="padding:14px;background:#fff3cd;border-radius:12px">No hay un plan de producción activo para este usuario.</div>';return;}container.innerHTML=d.rows.map(function(row){return summaryCard(row)+'<div style="background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:14px;margin-bottom:18px"><h3>Operaciones que computan este mes</h3>'+dealTable(row)+'</div>';}).join('');}catch(e){container.innerHTML='<div style="color:#d93025">'+esc(e.message||'Error cargando producción')+'</div>';}}
  async function initMiEstado(){var container=document.querySelector('.container');if(!container)return;var box=document.createElement('div');box.className='box';box.innerHTML='<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><h2 style="margin:0">Mi Producción Comercial</h2><div style="color:#667085">Objetivo mensual en m³ y comisión estimada.</div></div><input id="scbProdMonth" type="month" style="max-width:220px;padding:10px"></div><div id="scbProdSummary" style="margin-top:15px"></div>';container.insertBefore(box,container.firstChild);var month=box.querySelector('#scbProdMonth'),out=box.querySelector('#scbProdSummary');var now=new Date();month.value=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0');function go(){loadSummary(out,month.value+'-01','');}month.onchange=go;go();}
  async function initReportes(){var container=document.querySelector('.container');if(!container)return;var box=document.createElement('div');box.className='box';box.innerHTML='<h2 style="margin-top:0">Planes individuales</h2><div style="display:flex;gap:10px;flex-wrap:wrap;align-items:end"><label>Mes<input id="scbReportMonth" type="month" style="display:block;padding:10px;margin-top:5px"></label><button id="scbRefreshProd">Actualizar</button></div><div id="scbReportProd" style="margin-top:15px"></div>'+(isAdmin()?'<div style="margin-top:18px;border-top:1px solid #e5e7eb;padding-top:14px"><button id="scbPlanAdminToggle" type="button" class="secondary" style="width:100%;display:flex;justify-content:space-between;align-items:center;padding:12px 14px;font-weight:800"><span>Configurar vendedores con plan activo</span><span id="scbPlanAdminArrow">＋</span></button><div id="scbPlanAdminPanel" style="display:none;margin-top:14px"><div id="scbPlanAdmin"></div></div></div>':'');container.insertBefore(box,container.firstChild);var month=box.querySelector('#scbReportMonth'),out=box.querySelector('#scbReportProd');var now=new Date();month.value=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0');function go(){loadSummary(out,month.value+'-01','');}box.querySelector('#scbRefreshProd').onclick=go;month.onchange=go;go();if(isAdmin()){var toggle=box.querySelector('#scbPlanAdminToggle'),panel=box.querySelector('#scbPlanAdminPanel'),arrow=box.querySelector('#scbPlanAdminArrow'),loaded=false;toggle.onclick=function(){var open=panel.style.display!=='none';panel.style.display=open?'none':'block';arrow.textContent=open?'＋':'−';if(!open&&!loaded){loaded=true;panel.querySelector('#scbPlanAdmin').innerHTML='Cargando usuarios...';loadPlanAdmin(panel.querySelector('#scbPlanAdmin'));}};}}
  function levelEditorHtml(level,idx){
    var maxValue=(level.maxCbm===null||level.maxCbm==='')?'':level.maxCbm;
    return '<div data-level-row style="display:grid;grid-template-columns:70px minmax(130px,1fr) 110px 110px 100px auto;gap:8px;align-items:end;border-top:1px solid #edf1f5;padding:10px 0">'+
      '<div><b>Nivel '+(idx+1)+'</b></div>'+
      '<label>Nombre<input data-level-name value="'+esc(level.name||('Nivel '+(idx+1)))+'" style="width:100%;padding:8px"></label>'+
      '<label>Desde m³<input data-level-min type="number" min="0" step="0.01" value="'+esc(level.minCbm||0)+'" style="width:100%;padding:8px"></label>'+
      '<label>Hasta m³<input data-level-max type="number" min="0" step="0.01" value="'+esc(maxValue)+'" placeholder="Sin límite" style="width:100%;padding:8px"></label>'+
      '<label>Comisión %<input data-level-rate type="number" min="0" max="100" step="0.1" value="'+esc(level.rate||0)+'" style="width:100%;padding:8px"></label>'+
      '<button type="button" data-remove-level class="secondary">Quitar</button></div>';
  }
  function readLevels(row){
    return Array.from(row.querySelectorAll('[data-level-row]')).map(function(el,idx){
      var rawMax=String(el.querySelector('[data-level-max]').value||'').trim();
      return {level:idx+1,name:String(el.querySelector('[data-level-name]').value||('Nivel '+(idx+1))).trim(),minCbm:Number(el.querySelector('[data-level-min]').value||0),maxCbm:rawMax===''?null:Number(rawMax),rate:Number(el.querySelector('[data-level-rate]').value||0)};
    });
  }
  function bindLevelButtons(row){
    row.querySelectorAll('[data-remove-level]').forEach(function(btn){btn.onclick=function(){var rows=row.querySelectorAll('[data-level-row]');if(rows.length<=1)return alert('Debe quedar al menos una escala');btn.closest('[data-level-row]').remove();};});
  }
  async function loadPlanAdmin(host){
    try{
      var r=await authFetch('/api/production/plans?ts='+Date.now());var d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'Error');
      host.innerHTML=d.plans.map(function(p){
        var levels=Array.isArray(p.levels)&&p.levels.length?p.levels:[];
        return '<div data-plan-row style="border:1px solid #dbe3ef;border-radius:14px;padding:14px;margin-bottom:14px;background:#fff">'+
          '<div style="display:grid;grid-template-columns:minmax(180px,1.4fr) 120px 140px 110px auto;gap:10px;align-items:end">'+
          '<div><b style="font-size:17px">'+esc(p.userName)+'</b><br><small>'+esc(p.userEmail)+'</small></div>'+ 
          '<label><input type="checkbox" data-active '+(p.active?'checked':'')+'> Plan activo</label>'+ 
          '<label>Objetivo mensual m³<input type="number" min="0" step="0.01" data-target value="'+esc(p.monthlyTargetCbm||0)+'" style="width:100%;padding:8px"></label>'+ 
          '<label>Hunter adicional %<input type="number" min="0" step="0.1" data-hunter value="'+esc(p.hunterBonusRate||2)+'" style="width:100%;padding:8px"></label>'+ 
          '<button data-save data-user="'+esc(p.userId)+'">Guardar plan</button></div>'+ 
          '<div style="margin-top:14px"><div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><b>Escalas de este vendedor</b><button type="button" data-add-level class="secondary">+ Agregar escala</button></div><div data-levels>'+levels.map(levelEditorHtml).join('')+'</div></div></div>';
      }).join('');
      host.querySelectorAll('[data-plan-row]').forEach(function(row){
        bindLevelButtons(row);
        row.querySelector('[data-add-level]').onclick=function(){
          var levelsBox=row.querySelector('[data-levels]');var idx=levelsBox.querySelectorAll('[data-level-row]').length;
          levelsBox.insertAdjacentHTML('beforeend',levelEditorHtml({name:'Nivel '+(idx+1),minCbm:0,maxCbm:null,rate:0},idx));bindLevelButtons(row);
        };
        var btn=row.querySelector('[data-save]');
        btn.onclick=async function(){btn.disabled=true;var old=btn.textContent;btn.textContent='Guardando...';try{
          var levels=readLevels(row);
          if(!levels.length)throw new Error('Cargá al menos una escala');
          levels.sort(function(a,b){return a.minCbm-b.minCbm;});
          for(var i=0;i<levels.length;i++){
            if(!levels[i].name)throw new Error('Todas las escalas necesitan nombre');
            if(i>0&&levels[i].minCbm<=levels[i-1].minCbm)throw new Error('El inicio de cada escala debe ser mayor al anterior');
            if(levels[i].maxCbm!==null&&levels[i].maxCbm<levels[i].minCbm)throw new Error('El máximo no puede ser menor que el mínimo');
          }
          var payload={active:row.querySelector('[data-active]').checked,monthlyTargetCbm:Number(row.querySelector('[data-target]').value||0),hunterBonusRate:Number(row.querySelector('[data-hunter]').value||2),levels:levels};
          var rr=await authFetch('/api/production/plans/'+encodeURIComponent(btn.dataset.user),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});var dd=await rr.json();if(!rr.ok||!dd.ok)throw new Error(dd.error||'Error');btn.textContent='Guardado';setTimeout(function(){btn.textContent=old;},1000);
        }catch(e){alert(e.message||'Error guardando');btn.textContent=old;}finally{btn.disabled=false;}};
      });
    }catch(e){host.innerHTML='<div style="color:#d93025">'+esc(e.message||'Error')+'</div>';}
  }

  if(path==='/plan-produccion')initReportes();
})();
`;


const PRODUCTION_TEAMS_UI_JS = String.raw`
(function(){
  if(window.__SCB_PRODUCTION_TEAMS_UI__)return;window.__SCB_PRODUCTION_TEAMS_UI__=true;
  var path=location.pathname||'';
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function money(v){return 'USD '+Number(v||0).toLocaleString('es-AR',{maximumFractionDigits:2});}
  function num(v,d){return Number(v||0).toLocaleString('es-AR',{minimumFractionDigits:d||0,maximumFractionDigits:d==null?2:d});}
  function user(){try{return JSON.parse(localStorage.getItem('crmscb_user')||'{}')}catch(e){return {}}}
  function role(){return String(user().role||'').toLowerCase()}
  function isAdmin(){return role()==='admin'}
  function isLeader(){return role()==='team_leader'}
  function levelRows(levels){return (levels||[]).map(function(l,i){return '<div data-tlevel style="display:grid;grid-template-columns:70px minmax(120px,1fr) 105px 105px 95px auto;gap:7px;align-items:end;border-top:1px solid #edf1f5;padding:9px 0"><b>Nivel '+(i+1)+'</b><label>Nombre<input data-n value="'+esc(l.name||'Nivel '+(i+1))+'"></label><label>Desde<input data-min type="number" step="0.01" min="0" value="'+esc(l.minCbm||0)+'"></label><label>Hasta<input data-max type="number" step="0.01" min="0" value="'+esc(l.maxCbm==null?'':l.maxCbm)+'" placeholder="Sin límite"></label><label>%<input data-rate type="number" step="0.1" min="0" value="'+esc(l.rate||0)+'"></label><button type="button" data-rm class="secondary">Quitar</button></div>'}).join('')}
  function readLevels(card){return Array.from(card.querySelectorAll('[data-tlevel]')).map(function(r,i){var mx=String(r.querySelector('[data-max]').value||'').trim();return {level:i+1,name:r.querySelector('[data-n]').value.trim()||('Nivel '+(i+1)),minCbm:Number(r.querySelector('[data-min]').value||0),maxCbm:mx===''?null:Number(mx),rate:Number(r.querySelector('[data-rate]').value||0)}})}
  function bindRm(card){card.querySelectorAll('[data-rm]').forEach(function(b){b.onclick=function(){if(card.querySelectorAll('[data-tlevel]').length<=1)return alert('Debe quedar al menos una escala');b.closest('[data-tlevel]').remove()}})}
  function memberChecks(users,selected){var set=new Set(selected||[]);return '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:7px">'+users.map(function(u){return '<label style="border:1px solid #e5e7eb;border-radius:9px;padding:8px"><input data-member type="checkbox" value="'+esc(u.id)+'" '+(set.has(u.id)?'checked':'')+'> '+esc(u.name||u.email)+'<small style="display:block;color:#667085">'+esc(u.email||'')+'</small></label>'}).join('')+'</div>'}
  function leaderOptions(users,selected){return '<option value="">Seleccionar Team Leader</option>'+users.filter(function(u){return u.role==='team_leader'}).map(function(u){return '<option value="'+esc(u.id)+'" '+(u.id===selected?'selected':'')+'>'+esc(u.name||u.email)+'</option>'}).join('')}
  function teamEditor(t,users){var levels=t.levels||[{name:'Nivel 1',minCbm:0,maxCbm:null,rate:2}];return '<div data-team-card data-id="'+esc(t.id||'')+'" style="border:1px solid #dbe3ef;border-radius:15px;padding:15px;margin:14px 0;background:#fff"><div style="display:grid;grid-template-columns:minmax(180px,1fr) 130px 160px 130px 110px;gap:9px;align-items:end"><label>Nombre<input data-name value="'+esc(t.name||'')+'"></label><label><input data-active type="checkbox" '+(t.active?'checked':'')+'> Equipo activo</label><label>Modo<select data-mode><option value="manual" '+(t.mode==='manual'?'selected':'')+'>Miembros manuales</option><option value="team_leader" '+(t.mode==='team_leader'?'selected':'')+'>Team Leader + Fields</option></select></label><label>Objetivo m³<input data-target type="number" step="0.01" value="'+esc(t.monthlyTargetCbm||0)+'"></label><label>Hunter %<input data-hunter type="number" step="0.1" value="'+esc(t.hunterBonusRate||2)+'"></label></div><div data-leader-box style="margin-top:10px"><label>Team Leader<select data-leader>'+leaderOptions(users,t.teamLeaderId||'')+'</select></label><small>En modo Team Leader se suma automáticamente el líder y todos sus Field Sales. También podés marcar miembros extra.</small></div><div style="margin-top:12px"><b>Miembros manuales / adicionales</b>'+memberChecks(users,t.memberUserIds||[])+'</div><div style="margin-top:14px"><div style="display:flex;justify-content:space-between;align-items:center"><b>Escalas del equipo</b><button type="button" data-add class="secondary">+ Agregar escala</button></div><div data-levelbox>'+levelRows(levels)+'</div></div><div style="display:flex;gap:9px;margin-top:13px"><button data-save>Guardar equipo</button>'+(t.id?'<button data-delete type="button" style="background:#d93025">Eliminar</button>':'')+'</div></div>'}
  async function loadTeamAdmin(host){try{var r=await fetch('/api/production/teams?ts='+Date.now()),d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'Error');var users=d.users||[],teams=d.teams||[];host.innerHTML='<div style="padding:12px;background:#eef4ff;border-radius:12px">Creá oficinas o equipos. La escala se alcanza con el CBM total y cada integrante cobra ese porcentaje sobre sus propias ventas.</div><div id="scbNewTeam"></div><div id="scbTeamsList"></div>';host.querySelector('#scbNewTeam').innerHTML=teamEditor({name:'',active:true,mode:'manual',monthlyTargetCbm:0,hunterBonusRate:2,levels:[{name:'Nivel 1',minCbm:0,maxCbm:null,rate:2}]},users);host.querySelector('#scbTeamsList').innerHTML=teams.map(function(t){return teamEditor(t,users)}).join('')||'<div style="margin-top:12px;color:#667085">Todavía no hay equipos.</div>';host.querySelectorAll('[data-team-card]').forEach(function(card){bindRm(card);card.querySelector('[data-add]').onclick=function(){var box=card.querySelector('[data-levelbox]'),i=box.querySelectorAll('[data-tlevel]').length;box.insertAdjacentHTML('beforeend',levelRows([{name:'Nivel '+(i+1),minCbm:0,maxCbm:null,rate:0}]));bindRm(card)};card.querySelector('[data-save]').onclick=async function(){var btn=this;btn.disabled=true;try{var id=card.dataset.id||'',payload={name:card.querySelector('[data-name]').value.trim(),active:card.querySelector('[data-active]').checked,mode:card.querySelector('[data-mode]').value,teamLeaderId:card.querySelector('[data-leader]').value||'',memberUserIds:Array.from(card.querySelectorAll('[data-member]:checked')).map(function(x){return x.value}),monthlyTargetCbm:Number(card.querySelector('[data-target]').value||0),hunterBonusRate:Number(card.querySelector('[data-hunter]').value||2),levels:readLevels(card)};if(!payload.name)throw new Error('Ingresá nombre del equipo');var rr=await fetch(id?'/api/production/teams/'+encodeURIComponent(id):'/api/production/teams',{method:id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),dd=await rr.json();if(!rr.ok||!dd.ok)throw new Error(dd.error||'Error');await loadTeamAdmin(host)}catch(e){alert(e.message||'Error')}finally{btn.disabled=false}};var del=card.querySelector('[data-delete]');if(del)del.onclick=async function(){if(!confirm('¿Eliminar este equipo?'))return;var rr=await fetch('/api/production/teams/'+encodeURIComponent(card.dataset.id),{method:'DELETE'}),dd=await rr.json();if(!rr.ok||!dd.ok)return alert(dd.error||'Error');loadTeamAdmin(host)}})}catch(e){host.innerHTML='<div style="color:#d93025">'+esc(e.message||'Error')+'</div>'}}
  function memberTable(t,showAll){var rows=t.members||[];if(!rows.length)return '<div style="color:#667085">Sin producción en el mes.</div>';return '<div style="overflow:auto"><table style="width:100%;border-collapse:collapse"><thead><tr><th>Vendedor</th><th>CBM</th><th>Venta</th><th>Operaciones</th><th>Hunter</th><th>% equipo</th><th>Comisión</th><th>Liquidable</th></tr></thead><tbody>'+rows.map(function(m){return '<tr><td><b>'+esc(m.userName)+'</b></td><td>'+num(m.productionCbm,2)+' m³</td><td>'+money(m.salesValue)+'</td><td>'+num(m.operationsCount,0)+'</td><td>'+money(m.hunterSalesValue)+' (+'+num(m.hunterBonusRate,1)+'%)</td><td>'+num(m.baseRate,1)+'%</td><td><b>'+money(m.totalCommission)+'</b></td><td>'+money(m.payableCommission)+'</td></tr>'}).join('')+'</tbody></table></div>'}
  function teamCard(t){var pct=Math.min(100,Math.max(0,Number(t.progressPct||0)));return '<div style="border:1px solid #dbe3ef;border-radius:16px;padding:18px;background:#fff;margin-bottom:15px"><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><h2 style="margin:0">'+esc(t.name)+'</h2><div style="color:#667085">Escala grupal: <b>'+esc((t.currentLevel&&t.currentLevel.name)||'-')+'</b> · '+num(t.baseRate,1)+'%</div></div><div style="font-size:27px;font-weight:900;color:#174ea6">'+num(t.productionCbm,2)+' / '+num(t.monthlyTargetCbm,2)+' m³</div></div><div style="height:14px;background:#e8edf5;border-radius:999px;overflow:hidden;margin:13px 0"><div style="height:100%;width:'+pct+'%;background:#1a73e8"></div></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:10px"><div><small>Venta equipo</small><b style="display:block">'+money(t.salesValue)+'</b></div><div><small>Hunter equipo</small><b style="display:block">'+money(t.hunterSalesValue)+'</b></div><div><small>Comisión equipo</small><b style="display:block;color:#188038">'+money(t.totalCommission)+'</b></div><div><small>Próxima escala</small><b style="display:block">'+(t.nextLevel?num(t.cbmToNextLevel,2)+' m³':'Máxima')+'</b></div></div><h3>Producción por vendedor</h3>'+memberTable(t,true)+'</div>'}
  async function loadTeamSummary(host,month){host.innerHTML='Cargando equipos...';try{var q=new URLSearchParams({referenceDate:month+'-01',ts:Date.now()}),r=await fetch('/api/production/team-summary?'+q),d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'Error');if(!d.rows.length){host.innerHTML='<div style="color:#667085">No pertenecés a un equipo activo o todavía no hay equipos configurados.</div>';return false}host.innerHTML=d.rows.map(teamCard).join('');return true}catch(e){host.innerHTML='<div style="color:#d93025">'+esc(e.message||'Error')+'</div>';return false}}
  function initReportes(){var c=document.querySelector('.container');if(!c)return;var box=document.createElement('div');box.className='box';box.innerHTML='<h2 style="margin-top:0">Producción de oficinas y equipos</h2><div style="display:flex;gap:10px;align-items:end;flex-wrap:wrap"><label>Mes<input id="scbTeamMonth" type="month" style="display:block;padding:10px;margin-top:5px"></label><button id="scbTeamRefresh">Actualizar</button></div><div id="scbTeamSummary" style="margin-top:14px"></div>'+(isAdmin()?'<div style="margin-top:18px;border-top:1px solid #e5e7eb;padding-top:14px"><button id="scbTeamAdminToggle" type="button" class="secondary" style="width:100%;display:flex;justify-content:space-between;align-items:center;padding:12px 14px;font-weight:800"><span>Configurar equipos / oficinas</span><span id="scbTeamAdminArrow">＋</span></button><div id="scbTeamAdminPanel" style="display:none;margin-top:14px"><div id="scbTeamAdmin"></div></div></div>':'');c.insertBefore(box,c.firstChild);var m=box.querySelector('#scbTeamMonth'),now=new Date();m.value=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0');function go(){loadTeamSummary(box.querySelector('#scbTeamSummary'),m.value)}m.onchange=go;box.querySelector('#scbTeamRefresh').onclick=go;go();if(isAdmin()){var toggle=box.querySelector('#scbTeamAdminToggle'),panel=box.querySelector('#scbTeamAdminPanel'),arrow=box.querySelector('#scbTeamAdminArrow'),loaded=false;toggle.onclick=function(){var open=panel.style.display!=='none';panel.style.display=open?'none':'block';arrow.textContent=open?'＋':'−';if(!open&&!loaded){loaded=true;loadTeamAdmin(box.querySelector('#scbTeamAdmin'))}}}}
  function initMiEstado(){return;}
  if(path==='/plan-produccion')setTimeout(initReportes,250);
  if(path==='/mi-estado')setTimeout(initMiEstado,250);
})();
`;

app.get('/production-teams.js', (req,res)=>{
  res.type('application/javascript').set('Cache-Control','public, max-age=120').send(PRODUCTION_TEAMS_UI_JS);
});

app.get('/production.js', (req, res) => {
  res.type('application/javascript').set('Cache-Control', 'public, max-age=120').send(PRODUCTION_UI_JS);
});


// =====================================================
// BLOQUE 6F - BÚSQUEDA DE PRODUCTOS / SOURCING CHINA
// =====================================================
const PRODUCT_SEARCH_COLLECTION = "product_searches";
const PRODUCT_SEARCH_STATUSES = [
  "BORRADOR", "VALIDACION_COMERCIAL", "PENDIENTE_GARANTIA", "PENDIENTE_APROBACION",
  "REQUIERE_CORRECCIONES", "APROBADA", "EN_BUSQUEDA", "PROPUESTA_ENVIADA",
  "CLIENTE_EVALUANDO", "COMPRA_CONFIRMADA", "PAGADA", "CERRADA_EXITOSA",
  "CERRADA_SIN_COMPRA", "RECHAZADA"
];
const PRODUCT_SEARCH_STATUS_LABELS = {
  BORRADOR:"Borrador", VALIDACION_COMERCIAL:"Validación comercial", PENDIENTE_GARANTIA:"Pendiente de garantía",
  PENDIENTE_APROBACION:"Pendiente de aprobación", REQUIERE_CORRECCIONES:"Requiere correcciones",
  APROBADA:"Aprobada", EN_BUSQUEDA:"En búsqueda", PROPUESTA_ENVIADA:"Propuesta enviada",
  CLIENTE_EVALUANDO:"Cliente evaluando", COMPRA_CONFIRMADA:"Compra confirmada", PAGADA:"Pagada",
  CERRADA_EXITOSA:"Cerrada exitosa", CERRADA_SIN_COMPRA:"Cerrada sin compra", RECHAZADA:"Rechazada"
};
const DEFAULT_PRODUCT_SEARCH_CHECKLIST = [
  { id:"phone_contact", section:"Validación comercial", label:"Se habló con el cliente por teléfono", required:true },
  { id:"real_intent", section:"Validación comercial", label:"El cliente tiene intención real de compra", required:true },
  { id:"capital_available", section:"Validación comercial", label:"Se confirmó que dispone de capital para comprar", required:true },
  { id:"sales_channel", section:"Validación comercial", label:"Tiene local, industria, ecommerce, distribuidores o canal comprobable de venta", required:true },
  { id:"client_cuit", section:"Validación comercial", label:"Se cargó y verificó el CUIT del cliente", required:true },
  { id:"import_experience", section:"Validación comercial", label:"Se confirmó si ya importa o compra directamente en China", required:true },
  { id:"service_optional", section:"Validación comercial", label:"Se explicó que el servicio es opcional y no afecta la logística actual con SCB", required:true },
  { id:"risk_checked", section:"Validación comercial", label:"Se evaluó el riesgo de afectar una relación logística existente", required:true },
  { id:"terms_explained", section:"Condiciones económicas", label:"Se explicó el plazo estimado de 5 a 7 días hábiles", required:true },
  { id:"fee_explained", section:"Condiciones económicas", label:"Se explicó la comisión del 4% sobre el valor FOB", required:true },
  { id:"seller_fee", section:"Condiciones económicas", label:"Se informó internamente que el vendedor cobra 1% del FOB una vez pagada la compra", required:true },
  { id:"payment_china", section:"Condiciones económicas", label:"El cliente aceptó comprar mediante Shenzhen Sentire Trading Co., Ltd.", required:true },
  { id:"guarantee_paid", section:"Condiciones económicas", label:"Se recibió la garantía inicial de USD 100", required:true },
  { id:"guarantee_receipt", section:"Condiciones económicas", label:"Se adjuntó el comprobante de la garantía", required:true },
  { id:"product_name", section:"Información del producto", label:"Nombre y descripción clara del producto", required:true },
  { id:"product_use", section:"Información del producto", label:"Uso previsto del producto", required:true },
  { id:"product_refs", section:"Información del producto", label:"Se adjuntaron fotos, referencias o productos similares", required:true },
  { id:"specifications", section:"Información del producto", label:"Material, medidas y especificaciones técnicas", required:true },
  { id:"quantity", section:"Información del producto", label:"Cantidad inicial requerida", required:true },
  { id:"annual_quantity", section:"Información del producto", label:"Cantidad anual estimada", required:false },
  { id:"target_price", section:"Información del producto", label:"Precio FOB objetivo o presupuesto disponible", required:true },
  { id:"quality", section:"Información del producto", label:"Calidad esperada y restricciones no negociables", required:true },
  { id:"branding", section:"Información del producto", label:"Marca propia, genérico y packaging requerido", required:false },
  { id:"certifications", section:"Información del producto", label:"Certificaciones o requisitos regulatorios conocidos", required:false }
];

function normalizeProductSearchStatus(value){
  const v=String(value||"").trim().toUpperCase();
  return PRODUCT_SEARCH_STATUSES.includes(v)?v:"BORRADOR";
}
function productSearchStatusLabel(value){return PRODUCT_SEARCH_STATUS_LABELS[normalizeProductSearchStatus(value)]||String(value||"");}
function sanitizeProductSearchChecklist(input){
  const source=Array.isArray(input)?input:[];
  const map=new Map(source.map(x=>[String(x&&x.id||""),x||{}]));
  return DEFAULT_PRODUCT_SEARCH_CHECKLIST.map(base=>{
    const x=map.get(base.id)||{};
    const state=["pending","done","na"].includes(String(x.state||""))?String(x.state):"pending";
    return {...base,state,comment:String(x.comment||"").slice(0,1000)};
  });
}
function requiredProductSearchChecklistComplete(checklist){
  return sanitizeProductSearchChecklist(checklist).filter(x=>x.required).every(x=>x.state==="done"||x.state==="na");
}
function canCreateProductSearch(user){return !!user;}
function canApproveProductSearch(user){return isAdmin(user)||isBackoffice(user);}
async function canViewProductSearch(user,data){
  if(!user||!data)return false;
  if(isAdmin(user)||isBackoffice(user))return true;
  const email=String(user.email||"").trim().toLowerCase();
  if(String(data.owner||"").trim().toLowerCase()===email||String(data.createdBy||"").trim().toLowerCase()===email)return true;
  if(isTeamLeader(user)){
    const visible=await getVisibleOwnerEmails(user);
    return Array.isArray(visible)&&visible.includes(String(data.owner||"").trim().toLowerCase());
  }
  return false;
}
function productSearchPublicData(doc){
  const d=doc&&typeof doc.data==="function"?(doc.data()||{}):(doc||{});
  const id=doc&&doc.id?doc.id:String(d.id||"");
  return {id,...d,status:normalizeProductSearchStatus(d.status),statusLabel:productSearchStatusLabel(d.status),checklist:sanitizeProductSearchChecklist(d.checklist)};
}
function calculateSourcingCommercials(data){
  const fob=Math.max(0,Number(data&&data.finalFobValue||data&&data.estimatedFobValue||0));
  const totalCommission=Math.max(100,fob*0.04);
  const guarantee=Math.max(0,Number(data&&data.guaranteePaidAmount||0));
  const sellerCommission=fob*0.01;
  return {fob,totalCommission,guaranteeApplied:Math.min(totalCommission,guarantee),balanceDue:Math.max(0,totalCommission-guarantee),sellerCommission,companyCommission:Math.max(0,totalCommission-sellerCommission)};
}

app.get("/busqueda-productos",(req,res)=>{
  res.send(`<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SCB · Búsqueda de Productos</title>
  <style>
  body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;color:#111827}.topbar{background:#1a73e8;color:#fff;padding:15px 22px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}.container{max-width:1500px;margin:auto;padding:22px}.box{background:#fff;border-radius:14px;padding:18px;margin-bottom:16px;box-shadow:0 4px 18px rgba(0,0,0,.07)}button{border:0;border-radius:9px;padding:10px 14px;background:#1a73e8;color:#fff;font-weight:700;cursor:pointer}.secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}.success{background:#188038}.danger{background:#d93025}.warning{background:#f9ab00;color:#111}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:11px}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}label{font-size:12px;font-weight:700;color:#475467}input,select,textarea{width:100%;box-sizing:border-box;padding:10px;border:1px solid #cfd7e2;border-radius:8px;margin-top:5px;font:inherit}textarea{min-height:90px}.toolbar,.actions{display:flex;gap:9px;align-items:center;flex-wrap:wrap}.pill{display:inline-block;padding:5px 9px;border-radius:999px;background:#eef4ff;color:#174ea6;font-size:12px;font-weight:800}.card{border:1px solid #e3e8ef;border-radius:13px;padding:14px;margin-top:10px;cursor:pointer}.card:hover{border-color:#1a73e8;background:#fbfdff}.muted,.small{color:#667085;font-size:12px}.modalBack{position:fixed;inset:0;background:rgba(15,23,42,.5);display:none;align-items:center;justify-content:center;padding:15px;z-index:999}.modal{background:#fff;width:min(1180px,100%);max-height:94vh;overflow:auto;border-radius:16px}.modalHead{position:sticky;top:0;background:#fff;border-bottom:1px solid #e5e7eb;padding:15px 18px;display:flex;justify-content:space-between;z-index:3}.modalBody{padding:18px}.tabs{display:flex;gap:7px;flex-wrap:wrap;margin:12px 0}.tab{background:#fff;color:#1a73e8;border:1px solid #1a73e8}.tab.active{background:#1a73e8;color:#fff}.checkSection{border:1px solid #e5e7eb;border-radius:12px;margin-bottom:12px;overflow:hidden}.checkTitle{background:#f8fafc;padding:10px 12px;font-weight:800}.checkRow{display:grid;grid-template-columns:minmax(250px,1fr) 145px minmax(180px,1fr);gap:8px;padding:10px 12px;border-top:1px solid #edf1f5;align-items:center}.message{padding:10px 12px;border:1px solid #e5e7eb;border-radius:11px;margin:8px 0}.message.mine{background:#eef7ff}.fileChip{display:inline-flex;gap:7px;align-items:center;padding:7px 9px;border-radius:9px;background:#f2f4f7;margin:4px;text-decoration:none;color:#174ea6}.metricGrid{display:grid;grid-template-columns:repeat(5,1fr);gap:9px}.metric{background:#f8fbff;border:1px solid #dbe7ff;border-radius:11px;padding:11px}.metric b{display:block;font-size:18px;margin-top:4px}.hidden{display:none!important}@media(max-width:900px){.container{padding:12px}.grid,.grid2,.metricGrid{grid-template-columns:1fr}.checkRow{grid-template-columns:1fr}.modalBack{padding:0;align-items:flex-end}.modal{border-radius:18px 18px 0 0;max-height:96vh}}
  </style></head><body><div class="topbar"><div><b>CRMSCB</b> / Búsqueda de Productos</div><div class="actions"><button class="secondary" onclick="location='/crm'">Volver al CRM</button></div></div>
  <div class="container"><div class="box"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><h2 style="margin:0">Búsquedas de productos en China</h2><div class="muted">Solicitudes detalladas, aprobación y seguimiento con Shenzhen Sentire Trading Co., Ltd.</div></div><button onclick="openNew()">+ Nueva búsqueda</button></div><div class="toolbar" style="margin-top:14px"><select id="statusFilter" style="max-width:260px"><option value="">Todos los estados</option>${PRODUCT_SEARCH_STATUSES.map(x=>`<option value="${x}">${esc(productSearchStatusLabel(x))}</option>`).join("")}</select><input id="qFilter" placeholder="Buscar tema, cliente, trato o producto" style="max-width:420px"><button class="secondary" onclick="loadList()">Buscar</button></div></div><div id="listBox" class="box">Cargando...</div></div>
  <div id="modal" class="modalBack"><div class="modal"><div class="modalHead"><b id="modalTitle">Búsqueda</b><button class="secondary" onclick="closeModal()">Cerrar</button></div><div id="modalBody" class="modalBody"></div></div></div>
<script>
const USER=JSON.parse(localStorage.getItem('crmscb_user')||'null');if(!USER)location='/?redirect='+encodeURIComponent(location.pathname);const OF=window.fetch.bind(window);window.fetch=function(u,o){o=o||{};o.headers=Object.assign({},o.headers||{}, {'x-user-id':USER.id||'','x-auth-token':USER.token||''});return OF(u,o)};
let CURRENT=null, DEAL_TIMER=null;function E(v){return String(v==null?'':v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}function M(v){return 'USD '+Number(v||0).toLocaleString('es-AR',{maximumFractionDigits:2})}function role(){return String(USER.role||'').toLowerCase()}function approver(){return role()==='admin'||role()==='backoffice'}
async function loadList(){const p=new URLSearchParams({ts:Date.now()}),s=document.getElementById('statusFilter').value,q=document.getElementById('qFilter').value.trim();if(s)p.set('status',s);if(q)p.set('q',q);const r=await fetch('/api/product-searches?'+p),d=await r.json();if(!r.ok||!d.ok){document.getElementById('listBox').innerHTML='<span style="color:#d93025">'+E(d.error||'Error')+'</span>';return}document.getElementById('listBox').innerHTML=d.rows.length?d.rows.map(x=>'<div class="card" onclick="openItem(\\''+E(x.id)+'\\')"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><b>'+E(x.code||x.title)+'</b> · '+E(x.title)+'</div><span class="pill">'+E(x.statusLabel)+'</span></div><div class="small">Cliente: '+E(x.clientName||'-')+' · Trato: '+E(x.dealTitle||'-')+' · Owner: '+E(x.owner||'-')+'</div><div class="small">Producto: '+E(x.productName||'-')+' · Creada: '+E(x.createdDate||'-')+'</div></div>').join(''):'<div class="muted">No hay búsquedas para mostrar.</div>'}
function openNew(){CURRENT={id:'',status:'BORRADOR',checklist:[],guaranteePaidAmount:0,sourcingRate:4,sellerRate:1,riskLevel:'BAJO'};renderModal()}async function openItem(id){const r=await fetch('/api/product-searches/'+encodeURIComponent(id)+'?ts='+Date.now()),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'Error');CURRENT=d.item;renderModal()}
function closeModal(){document.getElementById('modal').style.display='none';CURRENT=null}function field(id,label,type='text',value='',extra=''){return '<label>'+label+'<input id="'+id+'" type="'+type+'" value="'+E(value)+'" '+extra+'></label>'}
function renderModal(){document.getElementById('modal').style.display='flex';document.getElementById('modalTitle').textContent=CURRENT.id?(CURRENT.code+' · '+CURRENT.title):'Nueva búsqueda de producto';const c=CURRENT.commercials||{};document.getElementById('modalBody').innerHTML='<div class="tabs"><button class="tab active" data-tab="data">Solicitud</button><button class="tab" data-tab="check">Checklist</button><button class="tab" data-tab="chat">Conversación</button><button class="tab" data-tab="files">Archivos</button><button class="tab" data-tab="approval">Aprobación / Ticket</button></div><div id="tab-data"></div><div id="tab-check" class="hidden"></div><div id="tab-chat" class="hidden"></div><div id="tab-files" class="hidden"></div><div id="tab-approval" class="hidden"></div>';renderData();renderChecklist();renderChat();renderFiles();renderApproval();document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-tab]').forEach(x=>x.classList.remove('active'));b.classList.add('active');['data','check','chat','files','approval'].forEach(x=>document.getElementById('tab-'+x).classList.toggle('hidden',x!==b.dataset.tab))})}
function renderData(){const x=CURRENT;const c=x.commercials||{};document.getElementById('tab-data').innerHTML='<div class="box" style="box-shadow:none;border:1px solid #e5e7eb"><h3>Vinculación CRM</h3><div class="grid">'+field('title','Título / tema','text',x.title||'')+field('clientName','Cliente','text',x.clientName||'')+field('clientCuit','CUIT','text',x.clientCuit||'')+field('owner','Vendedor / owner','email',x.owner||USER.email||'')+'</div><div style="margin-top:10px"><label>Buscar y vincular trato<input id="dealSearch" value="'+E(x.dealTitle||'')+'" placeholder="Escribí cliente o título del trato"><input id="dealId" type="hidden" value="'+E(x.dealId||'')+'"><div id="dealResults"></div></label></div></div><div class="box" style="box-shadow:none;border:1px solid #e5e7eb"><h3>Perfil y oportunidad del cliente</h3><div class="grid"><label>Experiencia importadora<select id="importExperience"><option value="NEVER">Nunca importó</option><option value="LOW">Importó pocas veces</option><option value="NEEDS_HELP">Importa, pero necesita ayuda con este producto</option><option value="EXPERIENCED">Importador experimentado con proveedores propios</option></select></label><label>Riesgo comercial<select id="riskLevel"><option>BAJO</option><option>MEDIO</option><option>ALTO</option></select></label>'+field('salesChannel','Canal de venta / actividad','text',x.salesChannel||'')+field('capitalAvailable','Capital disponible estimado (USD)','number',x.capitalAvailable||0,'min="0" step="0.01"')+'</div><label style="display:block;margin-top:10px">Necesidad concreta y por qué conviene ofrecer el servicio<textarea id="commercialReason">'+E(x.commercialReason||'')+'</textarea></label></div><div class="box" style="box-shadow:none;border:1px solid #e5e7eb"><h3>Producto</h3><div class="grid">'+field('productName','Producto','text',x.productName||'')+field('category','Categoría','text',x.category||'')+field('initialQuantity','Cantidad inicial','number',x.initialQuantity||0,'min="0" step="0.01"')+field('annualQuantity','Cantidad anual estimada','number',x.annualQuantity||0,'min="0" step="0.01"')+field('estimatedFobValue','FOB estimado (USD)','number',x.estimatedFobValue||0,'min="0" step="0.01"')+field('finalFobValue','FOB final (USD)','number',x.finalFobValue||0,'min="0" step="0.01"')+field('targetPrice','Precio objetivo unitario','number',x.targetPrice||0,'min="0" step="0.01"')+field('deadline','Fecha objetivo','date',x.deadline||'')+'</div><label style="display:block;margin-top:10px">Descripción, uso, materiales, medidas y especificaciones<textarea id="specifications">'+E(x.specifications||'')+'</textarea></label><label style="display:block;margin-top:10px">Calidad, packaging, marca y restricciones<textarea id="qualityRequirements">'+E(x.qualityRequirements||'')+'</textarea></label></div><div class="box" style="box-shadow:none;border:1px solid #e5e7eb"><h3>Condiciones económicas</h3><div class="grid">'+field('guaranteePaidAmount','Garantía pagada (USD)','number',x.guaranteePaidAmount||0,'min="0" step="0.01"')+field('guaranteePaidDate','Fecha garantía','date',x.guaranteePaidDate||'')+field('sourcingRate','Comisión total % FOB','number',4,'readonly')+field('sellerRate','Comisión vendedor % FOB','number',1,'readonly')+'</div><div class="metricGrid" style="margin-top:12px"><div class="metric"><small>FOB usado</small><b>'+M(c.fob)+'</b></div><div class="metric"><small>Comisión total 4%</small><b>'+M(c.totalCommission)+'</b></div><div class="metric"><small>Garantía descontada</small><b>'+M(c.guaranteeApplied)+'</b></div><div class="metric"><small>Saldo cliente</small><b>'+M(c.balanceDue)+'</b></div><div class="metric"><small>Vendedor 1%</small><b>'+M(c.sellerCommission)+'</b></div></div></div><div class="actions"><button onclick="saveItem()">Guardar solicitud</button>'+(x.id?'<button class="success" onclick="submitApproval()">Enviar a aprobación</button>':'')+'</div><div id="saveMsg" class="small"></div>';document.getElementById('importExperience').value=x.importExperience||'NEVER';document.getElementById('riskLevel').value=x.riskLevel||'BAJO';const ds=document.getElementById('dealSearch');ds.oninput=()=>{clearTimeout(DEAL_TIMER);DEAL_TIMER=setTimeout(searchDeals,300)}}
async function searchDeals(){const q=document.getElementById('dealSearch').value.trim(),box=document.getElementById('dealResults');if(q.length<3){box.innerHTML='';return}const r=await fetch('/api/product-searches/deal-options?q='+encodeURIComponent(q));const d=await r.json();box.innerHTML=(d.rows||[]).map(x=>'<div class="card" onclick="selectDeal(\\''+E(x.id)+'\\',\\''+E(x.title).replace(/'/g,'&#39;')+'\\',\\''+E(x.contactName).replace(/'/g,'&#39;')+'\\',\\''+E(x.owner).replace(/'/g,'&#39;')+'\\')"><b>'+E(x.title)+'</b><div class="small">'+E(x.contactName)+' · '+E(x.stage)+' · '+E(x.owner)+'</div></div>').join('')||'<div class="small">Sin resultados</div>'}function selectDeal(id,title,client,owner){document.getElementById('dealId').value=id;document.getElementById('dealSearch').value=title;document.getElementById('clientName').value=client;document.getElementById('owner').value=owner;document.getElementById('dealResults').innerHTML=''}
function payload(){const ids=['title','clientName','clientCuit','owner','dealId','importExperience','riskLevel','salesChannel','capitalAvailable','commercialReason','productName','category','initialQuantity','annualQuantity','estimatedFobValue','finalFobValue','targetPrice','deadline','specifications','qualityRequirements','guaranteePaidAmount','guaranteePaidDate'];const o={};ids.forEach(id=>{const e=document.getElementById(id);if(e)o[id]=e.type==='number'?Number(e.value||0):e.value.trim()});o.dealTitle=document.getElementById('dealSearch').value.trim();o.checklist=CURRENT.checklist||[];return o}
async function saveItem(){const p=payload(),url=CURRENT.id?'/api/product-searches/'+CURRENT.id:'/api/product-searches',r=await fetch(url,{method:CURRENT.id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)}),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'No se pudo guardar');CURRENT=d.item;renderModal();loadList()}
function renderChecklist(){const groups={};(CURRENT.checklist||[]).forEach(x=>(groups[x.section]||(groups[x.section]=[])).push(x));document.getElementById('tab-check').innerHTML='<div class="small" style="margin-bottom:10px">Todos los requisitos obligatorios deben estar Cumplidos o No aplica antes de solicitar aprobación.</div>'+Object.keys(groups).map(sec=>'<div class="checkSection"><div class="checkTitle">'+E(sec)+'</div>'+groups[sec].map(x=>'<div class="checkRow" data-check="'+E(x.id)+'"><div><b>'+E(x.label)+'</b> '+(x.required?'<span class="pill">Obligatorio</span>':'<span class="small">Opcional</span>')+'</div><select data-state><option value="pending">Pendiente</option><option value="done">Cumplido</option><option value="na">No aplica</option></select><input data-comment placeholder="Observación" value="'+E(x.comment||'')+'"></div>').join('')+'</div>').join('')+'<button onclick="saveChecklist()">Guardar checklist</button>';document.querySelectorAll('[data-check]').forEach(r=>{const x=(CURRENT.checklist||[]).find(y=>y.id===r.dataset.check);r.querySelector('[data-state]').value=x&&x.state||'pending'})}
async function saveChecklist(){CURRENT.checklist=Array.from(document.querySelectorAll('[data-check]')).map(r=>({id:r.dataset.check,state:r.querySelector('[data-state]').value,comment:r.querySelector('[data-comment]').value.trim()}));await saveItem()}
function renderChat(){const rows=CURRENT.messages||[];document.getElementById('tab-chat').innerHTML='<div id="messages">'+(rows.map(m=>'<div class="message '+(String(m.authorEmail||'').toLowerCase()===String(USER.email||'').toLowerCase()?'mine':'')+'"><b>'+E(m.authorName||m.authorEmail)+'</b> <span class="small">'+E(m.createdDate||'')+'</span><div style="white-space:pre-wrap;margin-top:5px">'+E(m.text||'')+'</div></div>').join('')||'<div class="muted">Todavía no hay mensajes.</div>')+'</div><label>Nuevo mensaje<textarea id="newMessage" placeholder="Escribí una consulta o respuesta detallada..."></textarea></label><button onclick="sendMessage()">Enviar mensaje</button>'}async function sendMessage(){const text=document.getElementById('newMessage').value.trim();if(!text)return;const r=await fetch('/api/product-searches/'+CURRENT.id+'/messages',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text})}),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'Error');CURRENT=d.item;renderChat()}
let PRODUCT_FILES_QUEUE=[];
function renderFiles(){
  document.getElementById('tab-files').innerHTML=
    '<div>'+(CURRENT.files||[]).map(f=>'<a class="fileChip" target="_blank" href="/api/product-searches/'+CURRENT.id+'/files/'+f.id+'/view?userId='+encodeURIComponent(USER.id)+'&token='+encodeURIComponent(USER.token)+'">📎 '+E(f.name)+'</a>').join('')+'</div>'+ 
    '<div class="grid2" style="margin-top:12px">'+
      '<label>Categoría<select id="fileCategory"><option>Referencia del cliente</option><option>Especificación técnica</option><option>Comprobante de garantía</option><option>Cotización de proveedor</option><option>Foto de muestra</option><option>Packaging</option><option>Certificación</option><option>Otro</option></select></label>'+
      '<label>Archivos<input id="fileInput" type="file" multiple onchange="addSelectedProductFiles(this.files)"></label>'+
    '</div>'+
    '<div class="actions" style="margin-top:10px">'+
      '<button class="secondary" type="button" onclick="document.getElementById(&quot;fileInput&quot;).click()">+ Agregar más archivos</button>'+
      '<button id="uploadFilesBtn" type="button" onclick="uploadFiles()">Adjuntar archivos</button>'+
      '<button class="secondary" type="button" onclick="clearSelectedProductFiles()">Limpiar selección</button>'+
    '</div>'+
    '<div id="selectedFilesLabel" class="small" style="margin-top:6px"></div>';
  renderSelectedProductFiles();
}
function productFileKey(file){return [file.name,file.size,file.lastModified].join('::')}
function addSelectedProductFiles(fileList){
  const incoming=Array.from(fileList||[]);
  const existing=new Set(PRODUCT_FILES_QUEUE.map(productFileKey));
  incoming.forEach(file=>{const key=productFileKey(file);if(!existing.has(key)){PRODUCT_FILES_QUEUE.push(file);existing.add(key)}});
  const input=document.getElementById('fileInput');if(input)input.value='';
  renderSelectedProductFiles();
}
function removeSelectedProductFile(index){PRODUCT_FILES_QUEUE.splice(Number(index||0),1);renderSelectedProductFiles()}
function clearSelectedProductFiles(){PRODUCT_FILES_QUEUE=[];renderSelectedProductFiles()}
function renderSelectedProductFiles(){
  const label=document.getElementById('selectedFilesLabel');if(!label)return;
  if(!PRODUCT_FILES_QUEUE.length){label.innerHTML='Podés agregar archivos en varias selecciones. Máximo 12 MB por archivo.';return}
  label.innerHTML='<b>'+PRODUCT_FILES_QUEUE.length+' archivo(s) listo(s) para adjuntar:</b><div style="margin-top:6px">'+PRODUCT_FILES_QUEUE.map((f,i)=>'<span class="fileChip">'+E(f.name)+' <button type="button" class="danger" style="padding:2px 6px;min-height:0" onclick="removeSelectedProductFile('+i+')">×</button></span>').join('')+'</div>';
}
async function uploadFiles(){
  const files=PRODUCT_FILES_QUEUE.slice(),btn=document.getElementById('uploadFilesBtn');
  if(!files.length)return alert('Seleccioná uno o más archivos');
  const oversized=files.find(f=>f.size>12*1024*1024);if(oversized)return alert('El archivo '+oversized.name+' supera 12 MB');
  const category=document.getElementById('fileCategory').value;let uploaded=0;
  try{
    if(btn){btn.disabled=true;btn.innerText='Adjuntando 0 de '+files.length+'...'}
    for(const f of files){
      const data=await new Promise((ok,no)=>{const rd=new FileReader();rd.onload=()=>ok(String(rd.result).split(',')[1]);rd.onerror=no;rd.readAsDataURL(f)});
      const r=await fetch('/api/product-searches/'+CURRENT.id+'/upload',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:f.name,type:f.type||'application/octet-stream',category,data})}),d=await r.json();
      if(!r.ok||!d.ok)throw new Error((d&&d.error)||('Error adjuntando '+f.name));
      CURRENT=d.item;uploaded+=1;if(btn)btn.innerText='Adjuntando '+uploaded+' de '+files.length+'...';
    }
    PRODUCT_FILES_QUEUE=[];renderFiles();
  }catch(error){
    alert((error&&error.message)||'Error adjuntando archivos');
    renderSelectedProductFiles();
  }finally{
    const activeBtn=document.getElementById('uploadFilesBtn');if(activeBtn){activeBtn.disabled=false;activeBtn.innerText='Adjuntar archivos'}
  }
}
function renderApproval(){const x=CURRENT;document.getElementById('tab-approval').innerHTML='<div class="box" style="box-shadow:none;border:1px solid #e5e7eb"><div><b>Estado:</b> <span class="pill">'+E(x.statusLabel||x.status)+'</span></div><div style="margin-top:8px"><b>Motivo / observación:</b><div style="white-space:pre-wrap">'+E(x.decisionReason||'-')+'</div></div><div class="grid2" style="margin-top:12px"><label>ID de ticket SCB Desk<input id="ticketId" value="'+E(x.ticketId||'')+'"></label><label>URL del ticket<input id="ticketUrl" value="'+E(x.ticketUrl||'')+'"></label></div><button class="secondary" onclick="saveTicket()">Guardar vínculo de ticket</button>'+(x.ticketUrl?'<button onclick="window.open(\\''+E(x.ticketUrl)+'\\',\\'_blank\\')">Abrir ticket</button>':'')+'</div>'+(approver()?'<div class="box" style="box-shadow:none;border:1px solid #e5e7eb"><h3>Decisión</h3><label>Observación<textarea id="decisionReason"></textarea></label><div class="actions"><button class="success" onclick="decision(\\'APPROVE\\')">Aprobar búsqueda</button><button class="warning" onclick="decision(\\'CORRECTIONS\\')">Solicitar correcciones</button><button class="danger" onclick="decision(\\'REJECT\\')">Rechazar</button></div><h3>Cambiar estado operativo</h3><select id="operationalStatus">'+${JSON.stringify(PRODUCT_SEARCH_STATUSES)}.map(s=>'<option value="'+s+'">'+E(s.replaceAll('_',' '))+'</option>').join('')+'</select><button class="secondary" onclick="setStatus()">Actualizar estado</button></div>':'')}
async function saveTicket(){const r=await fetch('/api/product-searches/'+CURRENT.id+'/ticket',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({ticketId:document.getElementById('ticketId').value.trim(),ticketUrl:document.getElementById('ticketUrl').value.trim()})}),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'Error');CURRENT=d.item;renderApproval()}async function submitApproval(){const r=await fetch('/api/product-searches/'+CURRENT.id+'/submit',{method:'POST'}),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'No se puede enviar');CURRENT=d.item;renderModal();loadList()}async function decision(action){const reason=document.getElementById('decisionReason').value.trim(),r=await fetch('/api/product-searches/'+CURRENT.id+'/decision',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,reason})}),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'Error');CURRENT=d.item;renderModal();loadList()}async function setStatus(){const status=document.getElementById('operationalStatus').value,r=await fetch('/api/product-searches/'+CURRENT.id+'/status',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})}),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'Error');CURRENT=d.item;renderModal();loadList()}
loadList();
</script></body></html>`);
});

app.get("/api/product-searches/deal-options",authRequired,async(req,res)=>{
  try{
    const q=String(req.query.q||"").trim().toLowerCase(); if(q.length<3)return res.json({ok:true,rows:[]});
    const visible=await getVisibleOwnerEmails(req.authUser); const snap=await db.collection("deals").limit(250).get();
    const rows=snap.docs.map(doc=>({id:doc.id,...doc.data()})).filter(d=>{
      if(Array.isArray(visible)&&!visible.includes(String(d.owner||"").toLowerCase()))return false;
      return [d.title,d.contactName,d.owner,d.stage].join(" ").toLowerCase().includes(q);
    }).slice(0,20).map(d=>({id:d.id,title:d.title||"",contactName:d.contactName||"",owner:d.owner||"",stage:d.stage||""}));
    res.json({ok:true,rows});
  }catch(e){console.error(e);res.status(500).json({ok:false,error:"Error buscando tratos"});}
});
app.get("/api/product-searches",authRequired,async(req,res)=>{
  try{
    let query=db.collection(PRODUCT_SEARCH_COLLECTION).orderBy("createdAt","desc").limit(200);
    const snap=await query.get(); const visible=await getVisibleOwnerEmails(req.authUser); const status=String(req.query.status||"").trim(); const q=String(req.query.q||"").trim().toLowerCase();
    const rows=[]; for(const doc of snap.docs){const x=productSearchPublicData(doc);if(Array.isArray(visible)&&!visible.includes(String(x.owner||"").toLowerCase())&&String(x.createdBy||"").toLowerCase()!==String(req.authUser.email||"").toLowerCase())continue;if(status&&x.status!==status)continue;if(q&&![x.title,x.clientName,x.dealTitle,x.productName,x.owner,x.code].join(" ").toLowerCase().includes(q))continue;rows.push({...x,createdDate:docDateToISO(x.createdAt),commercials:calculateSourcingCommercials(x)});}res.json({ok:true,rows});
  }catch(e){console.error(e);res.status(500).json({ok:false,error:"Error cargando búsquedas"});}
});
app.post("/api/product-searches",authRequired,async(req,res)=>{
  try{
    if(!canCreateProductSearch(req.authUser))return res.status(403).json({ok:false,error:"Sin permiso"});
    const b=req.body||{}; if(!String(b.title||"").trim())return res.status(400).json({ok:false,error:"Ingresá un título para la búsqueda"}); if(!String(b.dealId||"").trim())return res.status(400).json({ok:false,error:"La búsqueda debe estar vinculada a un trato"});
    const ref=db.collection(PRODUCT_SEARCH_COLLECTION).doc(); const now=new Date(); const code=`BP-${now.getFullYear()}-${String(Date.now()).slice(-6)}`;
    const data={...b,code,status:"BORRADOR",checklist:sanitizeProductSearchChecklist(b.checklist),sourcingRate:4,sellerRate:1,createdBy:String(req.authUser.email||""),createdByName:String(req.authUser.name||""),createdAt:now,updatedAt:now,files:[],ticketId:"",ticketUrl:""};
    await ref.set(data); const snap=await ref.get();res.json({ok:true,item:{...productSearchPublicData(snap),messages:[],commercials:calculateSourcingCommercials(data)}});
  }catch(e){console.error(e);res.status(500).json({ok:false,error:"Error creando búsqueda"});}
});
app.get("/api/product-searches/:id",authRequired,async(req,res)=>{
  try{const ref=db.collection(PRODUCT_SEARCH_COLLECTION).doc(req.params.id),snap=await ref.get();if(!snap.exists)return res.status(404).json({ok:false,error:"Búsqueda inexistente"});const data=snap.data()||{};if(!(await canViewProductSearch(req.authUser,data)))return res.status(403).json({ok:false,error:"Sin permiso"});const ms=await ref.collection("messages").orderBy("createdAt","asc").limit(300).get();const messages=ms.docs.map(d=>({id:d.id,...d.data(),createdDate:(d.data().createdAt&&d.data().createdAt.toDate?d.data().createdAt.toDate():new Date()).toLocaleString("es-AR")}));res.json({ok:true,item:{...productSearchPublicData(snap),messages,commercials:calculateSourcingCommercials(data)}});}catch(e){console.error(e);res.status(500).json({ok:false,error:"Error cargando búsqueda"});}
});
app.put("/api/product-searches/:id",authRequired,async(req,res)=>{
  try{const ref=db.collection(PRODUCT_SEARCH_COLLECTION).doc(req.params.id),snap=await ref.get();if(!snap.exists)return res.status(404).json({ok:false,error:"Búsqueda inexistente"});const old=snap.data()||{};if(!(await canViewProductSearch(req.authUser,old)))return res.status(403).json({ok:false,error:"Sin permiso"});if(["APROBADA","EN_BUSQUEDA","PROPUESTA_ENVIADA","COMPRA_CONFIRMADA","PAGADA","CERRADA_EXITOSA"].includes(normalizeProductSearchStatus(old.status))&&!canApproveProductSearch(req.authUser))return res.status(403).json({ok:false,error:"La búsqueda ya fue aprobada; pedí correcciones a Admin/Backoffice"});const b=req.body||{};const allowed=["title","clientName","clientCuit","owner","dealId","dealTitle","importExperience","riskLevel","salesChannel","capitalAvailable","commercialReason","productName","category","initialQuantity","annualQuantity","estimatedFobValue","finalFobValue","targetPrice","deadline","specifications","qualityRequirements","guaranteePaidAmount","guaranteePaidDate"];
    const update={updatedAt:new Date(),updatedBy:String(req.authUser.email||"")};allowed.forEach(k=>{if(Object.prototype.hasOwnProperty.call(b,k))update[k]=b[k]});if(Array.isArray(b.checklist))update.checklist=sanitizeProductSearchChecklist(b.checklist);await ref.update(update);const fresh=await ref.get();res.json({ok:true,item:{...productSearchPublicData(fresh),commercials:calculateSourcingCommercials(fresh.data())}});}catch(e){console.error(e);res.status(500).json({ok:false,error:"Error guardando búsqueda"});}
});
app.post("/api/product-searches/:id/submit",authRequired,async(req,res)=>{
  try{const ref=db.collection(PRODUCT_SEARCH_COLLECTION).doc(req.params.id),snap=await ref.get();if(!snap.exists)return res.status(404).json({ok:false,error:"Búsqueda inexistente"});const x=snap.data()||{};if(!(await canViewProductSearch(req.authUser,x)))return res.status(403).json({ok:false,error:"Sin permiso"});if(!requiredProductSearchChecklistComplete(x.checklist))return res.status(400).json({ok:false,error:"Faltan requisitos obligatorios del checklist"});if(Number(x.guaranteePaidAmount||0)<100)return res.status(400).json({ok:false,error:"Debe registrarse la garantía mínima de USD 100"});if(!String(x.dealId||"").trim())return res.status(400).json({ok:false,error:"Falta vincular el trato"});if(String(x.riskLevel||"").toUpperCase()==="ALTO"&&!String(x.commercialReason||"").trim())return res.status(400).json({ok:false,error:"Explicá por qué conviene avanzar pese al riesgo comercial alto"});await ref.update({status:"PENDIENTE_APROBACION",submittedAt:new Date(),submittedBy:String(req.authUser.email||""),updatedAt:new Date()});const fresh=await ref.get();res.json({ok:true,item:{...productSearchPublicData(fresh),commercials:calculateSourcingCommercials(fresh.data())}});}catch(e){console.error(e);res.status(500).json({ok:false,error:"Error enviando a aprobación"});}
});
app.post("/api/product-searches/:id/decision",authRequired,async(req,res)=>{
  try{if(!canApproveProductSearch(req.authUser))return res.status(403).json({ok:false,error:"Solo Admin o Backoffice pueden decidir"});const ref=db.collection(PRODUCT_SEARCH_COLLECTION).doc(req.params.id),snap=await ref.get();if(!snap.exists)return res.status(404).json({ok:false,error:"Búsqueda inexistente"});const action=String(req.body&&req.body.action||"").toUpperCase(),reason=String(req.body&&req.body.reason||"").trim();let status;if(action==="APPROVE")status="APROBADA";else if(action==="CORRECTIONS")status="REQUIERE_CORRECCIONES";else if(action==="REJECT")status="RECHAZADA";else return res.status(400).json({ok:false,error:"Decisión inválida"});if((status==="REQUIERE_CORRECCIONES"||status==="RECHAZADA")&&!reason)return res.status(400).json({ok:false,error:"Ingresá el motivo"});await ref.update({status,decisionReason:reason,decidedAt:new Date(),decidedBy:String(req.authUser.email||""),updatedAt:new Date()});const fresh=await ref.get();res.json({ok:true,item:{...productSearchPublicData(fresh),commercials:calculateSourcingCommercials(fresh.data())}});}catch(e){console.error(e);res.status(500).json({ok:false,error:"Error registrando decisión"});}
});
app.put("/api/product-searches/:id/status",authRequired,async(req,res)=>{try{if(!canApproveProductSearch(req.authUser))return res.status(403).json({ok:false,error:"Sin permiso"});const status=normalizeProductSearchStatus(req.body&&req.body.status);const ref=db.collection(PRODUCT_SEARCH_COLLECTION).doc(req.params.id);await ref.update({status,updatedAt:new Date(),updatedBy:String(req.authUser.email||"")});const fresh=await ref.get();res.json({ok:true,item:{...productSearchPublicData(fresh),commercials:calculateSourcingCommercials(fresh.data())}});}catch(e){console.error(e);res.status(500).json({ok:false,error:"Error actualizando estado"});}});
app.put("/api/product-searches/:id/ticket",authRequired,async(req,res)=>{try{const ref=db.collection(PRODUCT_SEARCH_COLLECTION).doc(req.params.id),snap=await ref.get();if(!snap.exists)return res.status(404).json({ok:false,error:"Búsqueda inexistente"});if(!(await canViewProductSearch(req.authUser,snap.data()||{})))return res.status(403).json({ok:false,error:"Sin permiso"});await ref.update({ticketId:String(req.body&&req.body.ticketId||"").trim(),ticketUrl:String(req.body&&req.body.ticketUrl||"").trim(),updatedAt:new Date()});const fresh=await ref.get();res.json({ok:true,item:{...productSearchPublicData(fresh),commercials:calculateSourcingCommercials(fresh.data())}});}catch(e){console.error(e);res.status(500).json({ok:false,error:"Error vinculando ticket"});}});
app.post("/api/product-searches/:id/messages",authRequired,async(req,res)=>{try{const ref=db.collection(PRODUCT_SEARCH_COLLECTION).doc(req.params.id),snap=await ref.get();if(!snap.exists)return res.status(404).json({ok:false,error:"Búsqueda inexistente"});if(!(await canViewProductSearch(req.authUser,snap.data()||{})))return res.status(403).json({ok:false,error:"Sin permiso"});const text=String(req.body&&req.body.text||"").trim();if(!text)return res.status(400).json({ok:false,error:"Escribí un mensaje"});await ref.collection("messages").add({text,authorId:req.authUser.id,authorEmail:req.authUser.email||"",authorName:req.authUser.name||req.authUser.email||"",createdAt:new Date()});await ref.update({lastMessageAt:new Date(),updatedAt:new Date()});const fresh=await ref.get(),ms=await ref.collection("messages").orderBy("createdAt","asc").limit(300).get();const messages=ms.docs.map(d=>({id:d.id,...d.data(),createdDate:(d.data().createdAt&&d.data().createdAt.toDate?d.data().createdAt.toDate():new Date()).toLocaleString("es-AR")}));res.json({ok:true,item:{...productSearchPublicData(fresh),messages,commercials:calculateSourcingCommercials(fresh.data())}});}catch(e){console.error(e);res.status(500).json({ok:false,error:"Error enviando mensaje"});}});
app.post("/api/product-searches/:id/upload",authRequired,async(req,res)=>{try{const ref=db.collection(PRODUCT_SEARCH_COLLECTION).doc(req.params.id),snap=await ref.get();if(!snap.exists)return res.status(404).json({ok:false,error:"Búsqueda inexistente"});if(!(await canViewProductSearch(req.authUser,snap.data()||{})))return res.status(403).json({ok:false,error:"Sin permiso"});const b=req.body||{},raw=String(b.data||"");const buffer=Buffer.from(raw,"base64");if(!buffer.length||buffer.length>12*1024*1024)return res.status(400).json({ok:false,error:"Archivo inválido o mayor a 12 MB"});const fileId=makeId("bpsf"),name=sanitizeFilename(b.name||"archivo"),path=`product-searches/${req.params.id}/${fileId}_${name}`;const file=getBucket().file(path);await file.save(buffer,{metadata:{contentType:String(b.type||"application/octet-stream"),metadata:{originalName:name,category:String(b.category||"Otro")}},resumable:false});const entry={id:fileId,name,category:String(b.category||"Otro"),contentType:String(b.type||"application/octet-stream"),storagePath:path,size:buffer.length,uploadedBy:req.authUser.email||"",uploadedAt:new Date()};await ref.update({files:admin.firestore.FieldValue.arrayUnion(entry),updatedAt:new Date()});const fresh=await ref.get();res.json({ok:true,item:{...productSearchPublicData(fresh),commercials:calculateSourcingCommercials(fresh.data())}});}catch(e){console.error(e);res.status(500).json({ok:false,error:e.message||"Error subiendo archivo"});}});
app.get("/api/product-searches/:id/files/:fileId/view",authRequired,async(req,res)=>{try{const ref=db.collection(PRODUCT_SEARCH_COLLECTION).doc(req.params.id),snap=await ref.get();if(!snap.exists)return res.status(404).send("No encontrado");const x=snap.data()||{};if(!(await canViewProductSearch(req.authUser,x)))return res.status(403).send("Sin permiso");const f=(Array.isArray(x.files)?x.files:[]).find(z=>String(z.id)===String(req.params.fileId));if(!f)return res.status(404).send("Archivo inexistente");const file=getBucket().file(f.storagePath);res.setHeader("Content-Type",f.contentType||"application/octet-stream");res.setHeader("Content-Disposition",`inline; filename="${sanitizeFilename(f.name)}"`);file.createReadStream().on("error",()=>res.status(404).end()).pipe(res);}catch(e){console.error(e);res.status(500).send("Error abriendo archivo");}});




// =====================================================
// BLOQUE 6F2 - BASE DE CONOCIMIENTO SCB
// =====================================================
const KNOWLEDGE_COLLECTION = "knowledge_articles";
const KNOWLEDGE_PROGRESS_COLLECTION = "knowledge_progress";
const KNOWLEDGE_TYPES = ["TEMA", "QA", "CAPACITACION"];
const KNOWLEDGE_LEVELS = ["BASICO", "INTERMEDIO", "AVANZADO"];

function normalizeKnowledgeType(value) {
  const clean = String(value || "").trim().toUpperCase();
  return KNOWLEDGE_TYPES.includes(clean) ? clean : "TEMA";
}
function normalizeKnowledgeLevel(value) {
  const clean = String(value || "").trim().toUpperCase();
  return KNOWLEDGE_LEVELS.includes(clean) ? clean : "BASICO";
}
function knowledgeTypeLabel(value) {
  const type = normalizeKnowledgeType(value);
  if (type === "QA") return "Preguntas y Respuestas";
  if (type === "CAPACITACION") return "Capacitaciones";
  return "Temas";
}
function knowledgeLevelLabel(value) {
  const level = normalizeKnowledgeLevel(value);
  if (level === "INTERMEDIO") return "Intermedio";
  if (level === "AVANZADO") return "Avanzado";
  return "Básico";
}
function sanitizeKnowledgeTags(value) {
  const source = Array.isArray(value) ? value : String(value || "").split(",");
  return Array.from(new Set(source.map(x => String(x || "").trim()).filter(Boolean))).slice(0, 30);
}
function canManageKnowledge(user) { return isAdmin(user); }
function knowledgePublic(doc, includeDraft = false) {
  const data = doc && typeof doc.data === "function" ? (doc.data() || {}) : (doc || {});
  return {
    id: doc && doc.id ? doc.id : String(data.id || ""),
    type: normalizeKnowledgeType(data.type),
    typeLabel: knowledgeTypeLabel(data.type),
    title: String(data.title || ""),
    summary: String(data.summary || ""),
    question: String(data.question || ""),
    answer: String(data.answer || ""),
    content: String(data.content || ""),
    sellerAction: String(data.sellerAction || ""),
    category: String(data.category || "General"),
    level: normalizeKnowledgeLevel(data.level),
    levelLabel: knowledgeLevelLabel(data.level),
    tags: Array.isArray(data.tags) ? data.tags : [],
    published: data.published === true,
    featured: data.featured === true,
    mandatory: data.mandatory === true,
    durationMinutes: Math.max(0, Number(data.durationMinutes || 0)),
    instructor: String(data.instructor || ""),
    trainingDate: String(data.trainingDate || ""),
    videoUrl: String(data.videoUrl || ""),
    externalUrl: String(data.externalUrl || ""),
    relatedArticleId: String(data.relatedArticleId || ""),
    sortOrder: Number(data.sortOrder || 0),
    files: Array.isArray(data.files) ? data.files : [],
    views: Number(data.views || 0),
    createdBy: String(data.createdBy || ""),
    createdByName: String(data.createdByName || ""),
    createdDate: docDateToISO(data.createdAt),
    updatedDate: docDateToISO(data.updatedAt),
    ...(includeDraft ? { internalNotes: String(data.internalNotes || "") } : {})
  };
}

app.get("/conocimiento", (req, res) => {
  res.send(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Base de Conocimiento SCB</title><meta name="viewport" content="width=device-width,initial-scale=1.0"><style>
  body{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;color:#111827}.topbar{background:#1a73e8;color:#fff;padding:16px 24px;display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap}.container{max-width:1450px;margin:auto;padding:24px}.box,.article{background:#fff;border-radius:14px;box-shadow:0 4px 18px rgba(0,0,0,.07);padding:18px;margin-bottom:16px}.tabs,.actions,.filters{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.tab,button{border:0;border-radius:9px;padding:11px 15px;font-weight:700;cursor:pointer;background:#1a73e8;color:#fff}.tab{background:#fff;color:#1a73e8;border:1px solid #1a73e8}.tab.active{background:#1a73e8;color:#fff}.secondary{background:#fff;color:#1a73e8;border:1px solid #1a73e8}.danger{background:#d93025}.success{background:#188038}.search{font-size:18px;padding:15px;border:2px solid #cfd8e8;border-radius:12px;width:100%;box-sizing:border-box}select,input,textarea{padding:10px;border:1px solid #cfd7e2;border-radius:8px;box-sizing:border-box;font:inherit}textarea{width:100%;min-height:110px;resize:vertical}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.article{cursor:pointer;border:1px solid #e5e7eb}.article:hover{border-color:#1a73e8}.pill{display:inline-block;padding:5px 9px;border-radius:999px;background:#eef4ff;color:#174ea6;font-size:12px;font-weight:700;margin:2px}.muted,.small{color:#667085;font-size:13px}.modalBack{position:fixed;inset:0;background:rgba(15,23,42,.52);display:none;align-items:center;justify-content:center;padding:18px;z-index:1500}.modal{background:#fff;border-radius:16px;width:100%;max-width:1050px;max-height:92vh;overflow:auto}.modalHead{padding:16px 20px;border-bottom:1px solid #e5e7eb;display:flex;justify-content:space-between}.modalBody{padding:20px}.formGrid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}.formGrid .wide{grid-column:1/-1}label{font-size:12px;font-weight:700;color:#475467;display:block;margin-bottom:5px}.fileChip{display:inline-block;background:#f2f4f7;border-radius:8px;padding:8px 10px;margin:4px;text-decoration:none;color:#174ea6}.progress{background:#eef4ff;padding:12px;border-radius:10px;margin-top:10px}.hidden{display:none!important}@media(max-width:900px){.grid,.formGrid{grid-template-columns:1fr}.container{padding:12px}.topbar{padding:12px}.filters>*{width:100%}}
  </style></head><body><div class="topbar"><div><strong>CRMSCB</strong> / Base de Conocimiento SCB</div><div class="actions"><button class="secondary" onclick="location='/crm'">Volver</button><button id="newBtn" style="display:none" onclick="openEditor()">+ Nuevo contenido</button></div></div><div class="container">
  <div class="box"><h1 style="margin-top:0">Base de Conocimiento SCB</h1><div class="muted">Temas complejos, respuestas rápidas y capacitaciones internas.</div><div class="tabs" style="margin-top:16px"><button class="tab active" data-type="TEMA" onclick="setType('TEMA')">Temas</button><button class="tab" data-type="QA" onclick="setType('QA')">Preguntas y Respuestas</button><button class="tab" data-type="CAPACITACION" onclick="setType('CAPACITACION')">Capacitaciones</button></div><div style="margin-top:15px"><input id="q" class="search" placeholder="Buscar producto, caso, pregunta, procedimiento, NCM o capacitación..."></div><div class="filters" style="margin-top:12px"><select id="category"><option value="">Todas las categorías</option></select><select id="level"><option value="">Todos los niveles</option><option value="BASICO">Básico</option><option value="INTERMEDIO">Intermedio</option><option value="AVANZADO">Avanzado</option></select><select id="sort"><option value="recent">Más recientes</option><option value="featured">Destacados primero</option><option value="popular">Más consultados</option></select><button class="secondary" onclick="clearFilters()">Limpiar</button></div></div>
  <div id="msg" class="small"></div><div id="articles" class="grid"></div></div>
  <div id="viewModal" class="modalBack"><div class="modal"><div class="modalHead"><b id="viewTitle">Detalle</b><button class="secondary" onclick="closeView()">Cerrar</button></div><div id="viewBody" class="modalBody"></div></div></div>
  <div id="editModal" class="modalBack"><div class="modal"><div class="modalHead"><b id="editTitle">Nuevo contenido</b><button class="secondary" onclick="closeEditor()">Cerrar</button></div><div class="modalBody"><div class="formGrid"><div><label>Tipo</label><select id="eType"><option value="TEMA">Tema</option><option value="QA">Pregunta y Respuesta</option><option value="CAPACITACION">Capacitación</option></select></div><div><label>Categoría</label><input id="eCategory" placeholder="Ej: Aduana, Comercial, Producto"></div><div><label>Nivel</label><select id="eLevel"><option value="BASICO">Básico</option><option value="INTERMEDIO">Intermedio</option><option value="AVANZADO">Avanzado</option></select></div><div class="wide"><label>Título</label><input id="eTitle" style="width:100%"></div><div class="wide"><label>Resumen corto</label><textarea id="eSummary"></textarea></div><div class="wide" id="questionWrap"><label>Pregunta</label><textarea id="eQuestion"></textarea></div><div class="wide" id="answerWrap"><label>Respuesta</label><textarea id="eAnswer"></textarea></div><div class="wide"><label>Contenido completo / desarrollo</label><textarea id="eContent" style="min-height:220px"></textarea></div><div class="wide"><label>Qué debe hacer el vendedor</label><textarea id="eSellerAction"></textarea></div><div class="wide"><label>Etiquetas separadas por coma</label><input id="eTags" style="width:100%"></div><div><label>Video o enlace externo</label><input id="eVideoUrl"></div><div><label>Duración (minutos)</label><input id="eDuration" type="number" min="0"></div><div><label>Instructor / responsable</label><input id="eInstructor"></div><div><label>Fecha capacitación</label><input id="eTrainingDate" type="date"></div><div><label>Orden</label><input id="eSortOrder" type="number" value="0"></div><div><label><input id="ePublished" type="checkbox"> Publicado</label><label><input id="eFeatured" type="checkbox"> Destacado</label><label><input id="eMandatory" type="checkbox"> Obligatoria</label></div></div><div class="box" style="box-shadow:none;border:1px solid #e5e7eb;margin-top:14px"><h3>Archivos</h3><input id="eFiles" type="file" multiple><div id="selectedFiles" class="small"></div><div id="existingFiles"></div></div><div class="actions"><button class="success" onclick="saveArticle()">Guardar</button><button id="deleteBtn" class="danger" style="display:none" onclick="deleteArticle()">Eliminar</button></div></div></div></div>
  <script>
  const RAW=localStorage.getItem('crmscb_user');if(!RAW)location='/?redirect='+encodeURIComponent(location.pathname);const USER=JSON.parse(RAW||'{}');const OF=window.fetch.bind(window);window.fetch=function(u,o){o=o||{};o.headers=Object.assign({},o.headers||{}, {'x-user-id':USER.id||'','x-auth-token':USER.token||''});return OF(u,o)};const ADMIN=String(USER.role||'').toLowerCase()==='admin';if(ADMIN)document.getElementById('newBtn').style.display='inline-block';let TYPE='TEMA',ROWS=[],CURRENT=null,PENDING=[];function E(v){return String(v||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}function setType(t){TYPE=t;document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.type===t));render()}function clearFilters(){q.value='';category.value='';level.value='';sort.value='recent';render()}function text(x){return [x.title,x.summary,x.question,x.answer,x.content,x.sellerAction,x.category,(x.tags||[]).join(' ')].join(' ').toLowerCase()}function render(){let a=ROWS.filter(x=>x.type===TYPE);const term=q.value.trim().toLowerCase(),cat=category.value,lev=level.value;if(term)a=a.filter(x=>text(x).includes(term));if(cat)a=a.filter(x=>x.category===cat);if(lev)a=a.filter(x=>x.level===lev);if(sort.value==='featured')a.sort((x,y)=>Number(y.featured)-Number(x.featured)||String(y.updatedDate).localeCompare(String(x.updatedDate)));else if(sort.value==='popular')a.sort((x,y)=>Number(y.views)-Number(x.views));else a.sort((x,y)=>Number(y.sortOrder)-Number(x.sortOrder)||String(y.updatedDate).localeCompare(String(x.updatedDate)));articles.innerHTML=a.length?a.map(x=>'<div class="article" data-id="'+E(x.id)+'" onclick="openView(this.dataset.id)"><div><span class="pill">'+E(x.category)+'</span><span class="pill">'+E(x.levelLabel)+'</span>'+(x.featured?'<span class="pill">Destacado</span>':'')+'</div><h3>'+E(x.title)+'</h3><div class="muted">'+E(x.summary||x.question||'')+'</div><div class="small" style="margin-top:10px">'+Number(x.views||0)+' consulta(s) · '+E(x.updatedDate||x.createdDate||'')+'</div></div>').join(''):'<div class="box">No hay contenido para mostrar.</div>'}
  async function load(){const r=await fetch('/api/knowledge?ts='+Date.now()),d=await r.json();if(!r.ok||!d.ok)return msg.innerText=d.error||'Error';ROWS=d.rows||[];const cats=[...new Set(ROWS.map(x=>x.category).filter(Boolean))].sort();category.innerHTML='<option value="">Todas las categorías</option>'+cats.map(c=>'<option>'+E(c)+'</option>').join('');render()}async function openView(id){const r=await fetch('/api/knowledge/'+encodeURIComponent(id)+'?ts='+Date.now()),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'Error');const x=d.item;CURRENT=x;viewTitle.innerText=x.title;let body='<div><span class="pill">'+E(x.typeLabel)+'</span><span class="pill">'+E(x.category)+'</span><span class="pill">'+E(x.levelLabel)+'</span></div><h2>'+E(x.title)+'</h2>';if(x.summary)body+='<p><b>Resumen:</b> '+E(x.summary)+'</p>';if(x.question)body+='<h3>Pregunta</h3><div style="white-space:pre-wrap">'+E(x.question)+'</div>';if(x.answer)body+='<h3>Respuesta</h3><div style="white-space:pre-wrap">'+E(x.answer)+'</div>';if(x.content)body+='<h3>Desarrollo</h3><div style="white-space:pre-wrap;line-height:1.55">'+E(x.content)+'</div>';if(x.sellerAction)body+='<h3>Qué debe hacer el vendedor</h3><div class="progress" style="white-space:pre-wrap">'+E(x.sellerAction)+'</div>';if(x.videoUrl)body+='<p><a target="_blank" href="'+E(x.videoUrl)+'">Abrir video o enlace externo</a></p>';if(x.type==='CAPACITACION')body+='<div class="progress"><b>Duración:</b> '+Number(x.durationMinutes||0)+' min · <b>Instructor:</b> '+E(x.instructor||'-')+(x.mandatory?' · <b>Obligatoria</b>':'')+'<div style="margin-top:10px"><button data-id="'+E(x.id)+'" onclick="markCompleted(this.dataset.id)">Marcar capacitación completada</button></div></div>';body+='<div>'+(x.files||[]).map(f=>'<a class="fileChip" target="_blank" href="/api/knowledge/'+E(x.id)+'/files/'+E(f.id)+'/view?userId='+encodeURIComponent(USER.id)+'&token='+encodeURIComponent(USER.token)+'">📎 '+E(f.name)+'</a>').join('')+'</div>';if(ADMIN)body+='<div class="actions" style="margin-top:18px"><button data-id="'+E(x.id)+'" onclick="closeView();openEditor(this.dataset.id)">Editar</button></div>';viewBody.innerHTML=body;viewModal.style.display='flex';load()}function closeView(){viewModal.style.display='none'}
  function toggleEditorFields(){const t=eType.value;questionWrap.style.display=t==='QA'?'block':'none';answerWrap.style.display=t==='QA'?'block':'none'}eType.onchange=toggleEditorFields;eFiles.onchange=function(){PENDING=PENDING.concat(Array.from(this.files||[]));this.value='';selectedFiles.innerHTML=PENDING.map((f,i)=>E(f.name)+' <button class="secondary" data-index="'+i+'" onclick="removePendingFile(Number(this.dataset.index))">Quitar</button>').join('<br>')};function removePendingFile(i){if(!Number.isInteger(i)||i<0||i>=PENDING.length)return;PENDING.splice(i,1);selectedFiles.innerHTML=PENDING.map((f,j)=>E(f.name)+' <button class="secondary" data-index="'+j+'" onclick="removePendingFile(Number(this.dataset.index))">Quitar</button>').join('<br>')}function fill(x){eType.value=x.type||'TEMA';eCategory.value=x.category||'General';eLevel.value=x.level||'BASICO';eTitle.value=x.title||'';eSummary.value=x.summary||'';eQuestion.value=x.question||'';eAnswer.value=x.answer||'';eContent.value=x.content||'';eSellerAction.value=x.sellerAction||'';eTags.value=(x.tags||[]).join(', ');eVideoUrl.value=x.videoUrl||'';eDuration.value=x.durationMinutes||0;eInstructor.value=x.instructor||'';eTrainingDate.value=x.trainingDate||'';eSortOrder.value=x.sortOrder||0;ePublished.checked=!!x.published;eFeatured.checked=!!x.featured;eMandatory.checked=!!x.mandatory;existingFiles.innerHTML=(x.files||[]).map(f=>'<span class="fileChip">📎 '+E(f.name)+'</span>').join('');toggleEditorFields()}function openEditor(id){if(!ADMIN)return;PENDING=[];selectedFiles.innerHTML='';CURRENT=id?ROWS.find(x=>x.id===id):null;if(CURRENT){editTitle.innerText='Editar contenido';deleteBtn.style.display='inline-block';fill(CURRENT)}else{editTitle.innerText='Nuevo contenido';deleteBtn.style.display='none';fill({type:TYPE,category:'General',level:'BASICO',published:true})}editModal.style.display='flex'}function closeEditor(){editModal.style.display='none'}function payload(){return {type:eType.value,category:eCategory.value.trim(),level:eLevel.value,title:eTitle.value.trim(),summary:eSummary.value.trim(),question:eQuestion.value.trim(),answer:eAnswer.value.trim(),content:eContent.value.trim(),sellerAction:eSellerAction.value.trim(),tags:eTags.value.split(',').map(x=>x.trim()).filter(Boolean),videoUrl:eVideoUrl.value.trim(),durationMinutes:Number(eDuration.value||0),instructor:eInstructor.value.trim(),trainingDate:eTrainingDate.value,sortOrder:Number(eSortOrder.value||0),published:ePublished.checked,featured:eFeatured.checked,mandatory:eMandatory.checked}}async function file64(f){return await new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(String(r.result||'').split(',').pop());r.onerror=no;r.readAsDataURL(f)})}async function saveArticle(){const p=payload();if(!p.title)return alert('Ingresá un título');const id=CURRENT&&CURRENT.id;const r=await fetch(id?'/api/knowledge/'+id:'/api/knowledge',{method:id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)}),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'Error');const aid=d.item.id;for(let i=0;i<PENDING.length;i++){const f=PENDING[i];if(f.size>12*1024*1024){alert(f.name+' supera 12 MB');continue}const data=await file64(f);const rr=await fetch('/api/knowledge/'+aid+'/upload',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:f.name,type:f.type,data})}),dd=await rr.json();if(!rr.ok||!dd.ok)return alert(dd.error||'Error subiendo archivo')}closeEditor();await load()}async function deleteArticle(){if(!CURRENT||!confirm('¿Eliminar este contenido?'))return;const r=await fetch('/api/knowledge/'+CURRENT.id,{method:'DELETE'}),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'Error');closeEditor();load()}async function markCompleted(id){const r=await fetch('/api/knowledge/'+id+'/progress',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:'COMPLETADA'})}),d=await r.json();if(!r.ok||!d.ok)return alert(d.error||'Error');alert('Capacitación marcada como completada')}
  q.oninput=render;category.onchange=render;level.onchange=render;sort.onchange=render;load();
  </script></body></html>`);
});

app.get("/api/knowledge", authRequired, async (req, res) => {
  try {
    const snap = await db.collection(KNOWLEDGE_COLLECTION).orderBy("updatedAt", "desc").limit(500).get();
    const includeDraft = canManageKnowledge(req.authUser);
    const rows = snap.docs.map(doc => knowledgePublic(doc, includeDraft)).filter(x => includeDraft || x.published);
    res.json({ ok: true, rows });
  } catch (error) {
    console.error("ERROR /api/knowledge GET:", error);
    res.status(500).json({ ok: false, error: "Error cargando la base de conocimiento" });
  }
});
app.get("/api/knowledge/:id", authRequired, async (req, res) => {
  try {
    const ref = db.collection(KNOWLEDGE_COLLECTION).doc(req.params.id); const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ ok: false, error: "Contenido inexistente" });
    const data = snap.data() || {};
    if (!data.published && !canManageKnowledge(req.authUser)) return res.status(403).json({ ok: false, error: "Contenido no publicado" });
    ref.update({ views: admin.firestore.FieldValue.increment(1), lastViewedAt: new Date() }).catch(() => {});
    res.json({ ok: true, item: knowledgePublic(snap, canManageKnowledge(req.authUser)) });
  } catch (error) { console.error(error); res.status(500).json({ ok: false, error: "Error cargando contenido" }); }
});
app.post("/api/knowledge", authRequired, async (req, res) => {
  try {
    if (!canManageKnowledge(req.authUser)) return res.status(403).json({ ok: false, error: "Solo Admin puede crear contenido" });
    const b = req.body || {}; if (!String(b.title || "").trim()) return res.status(400).json({ ok: false, error: "Ingresá un título" });
    const ref = db.collection(KNOWLEDGE_COLLECTION).doc(); const now = new Date();
    const data = { type: normalizeKnowledgeType(b.type), category: String(b.category || "General").trim() || "General", level: normalizeKnowledgeLevel(b.level), title: String(b.title || "").trim(), summary: String(b.summary || "").trim(), question: String(b.question || "").trim(), answer: String(b.answer || "").trim(), content: String(b.content || "").trim(), sellerAction: String(b.sellerAction || "").trim(), tags: sanitizeKnowledgeTags(b.tags), videoUrl: String(b.videoUrl || "").trim(), durationMinutes: Math.max(0, Number(b.durationMinutes || 0)), instructor: String(b.instructor || "").trim(), trainingDate: String(b.trainingDate || ""), sortOrder: Number(b.sortOrder || 0), published: b.published === true, featured: b.featured === true, mandatory: b.mandatory === true, files: [], views: 0, createdBy: req.authUser.email || "", createdByName: req.authUser.name || "", createdAt: now, updatedAt: now };
    await ref.set(data); const fresh = await ref.get(); res.json({ ok: true, item: knowledgePublic(fresh, true) });
  } catch (error) { console.error(error); res.status(500).json({ ok: false, error: "Error creando contenido" }); }
});
app.put("/api/knowledge/:id", authRequired, async (req, res) => {
  try {
    if (!canManageKnowledge(req.authUser)) return res.status(403).json({ ok: false, error: "Solo Admin puede editar contenido" });
    const ref = db.collection(KNOWLEDGE_COLLECTION).doc(req.params.id), snap = await ref.get(); if (!snap.exists) return res.status(404).json({ ok: false, error: "Contenido inexistente" });
    const b = req.body || {}; const update = { type: normalizeKnowledgeType(b.type), category: String(b.category || "General").trim() || "General", level: normalizeKnowledgeLevel(b.level), title: String(b.title || "").trim(), summary: String(b.summary || "").trim(), question: String(b.question || "").trim(), answer: String(b.answer || "").trim(), content: String(b.content || "").trim(), sellerAction: String(b.sellerAction || "").trim(), tags: sanitizeKnowledgeTags(b.tags), videoUrl: String(b.videoUrl || "").trim(), durationMinutes: Math.max(0, Number(b.durationMinutes || 0)), instructor: String(b.instructor || "").trim(), trainingDate: String(b.trainingDate || ""), sortOrder: Number(b.sortOrder || 0), published: b.published === true, featured: b.featured === true, mandatory: b.mandatory === true, updatedBy: req.authUser.email || "", updatedAt: new Date() };
    if (!update.title) return res.status(400).json({ ok: false, error: "Ingresá un título" }); await ref.update(update); const fresh = await ref.get(); res.json({ ok: true, item: knowledgePublic(fresh, true) });
  } catch (error) { console.error(error); res.status(500).json({ ok: false, error: "Error actualizando contenido" }); }
});
app.delete("/api/knowledge/:id", authRequired, async (req, res) => {
  try { if (!canManageKnowledge(req.authUser)) return res.status(403).json({ ok: false, error: "Solo Admin puede eliminar contenido" }); await db.collection(KNOWLEDGE_COLLECTION).doc(req.params.id).delete(); res.json({ ok: true }); } catch (error) { console.error(error); res.status(500).json({ ok: false, error: "Error eliminando contenido" }); }
});
app.post("/api/knowledge/:id/upload", authRequired, async (req, res) => {
  try {
    if (!canManageKnowledge(req.authUser)) return res.status(403).json({ ok: false, error: "Solo Admin puede adjuntar archivos" });
    const ref = db.collection(KNOWLEDGE_COLLECTION).doc(req.params.id), snap = await ref.get(); if (!snap.exists) return res.status(404).json({ ok: false, error: "Contenido inexistente" });
    const b = req.body || {}, buffer = Buffer.from(String(b.data || ""), "base64"); if (!buffer.length || buffer.length > 12 * 1024 * 1024) return res.status(400).json({ ok: false, error: "Archivo inválido o mayor a 12 MB" });
    const fileId = makeId("kbfile"), name = sanitizeFilename(b.name || "archivo"), storagePath = `knowledge/${req.params.id}/${fileId}_${name}`; await getBucket().file(storagePath).save(buffer, { metadata: { contentType: String(b.type || "application/octet-stream"), metadata: { originalName: name } }, resumable: false });
    const entry = { id: fileId, name, contentType: String(b.type || "application/octet-stream"), storagePath, size: buffer.length, uploadedBy: req.authUser.email || "", uploadedAt: new Date() }; await ref.update({ files: admin.firestore.FieldValue.arrayUnion(entry), updatedAt: new Date() }); const fresh = await ref.get(); res.json({ ok: true, item: knowledgePublic(fresh, true) });
  } catch (error) { console.error(error); res.status(500).json({ ok: false, error: error.message || "Error subiendo archivo" }); }
});
app.get("/api/knowledge/:id/files/:fileId/view", authRequired, async (req, res) => {
  try { const ref = db.collection(KNOWLEDGE_COLLECTION).doc(req.params.id), snap = await ref.get(); if (!snap.exists) return res.status(404).send("No encontrado"); const data = snap.data() || {}; if (!data.published && !canManageKnowledge(req.authUser)) return res.status(403).send("Sin permiso"); const f = (Array.isArray(data.files) ? data.files : []).find(x => String(x.id) === String(req.params.fileId)); if (!f) return res.status(404).send("Archivo inexistente"); res.setHeader("Content-Type", f.contentType || "application/octet-stream"); res.setHeader("Content-Disposition", `inline; filename="${sanitizeFilename(f.name)}"`); getBucket().file(f.storagePath).createReadStream().on("error", () => res.status(404).end()).pipe(res); } catch (error) { console.error(error); res.status(500).send("Error abriendo archivo"); }
});
app.put("/api/knowledge/:id/progress", authRequired, async (req, res) => {
  try { const article = await db.collection(KNOWLEDGE_COLLECTION).doc(req.params.id).get(); if (!article.exists || !article.data().published) return res.status(404).json({ ok: false, error: "Capacitación inexistente" }); if (normalizeKnowledgeType(article.data().type) !== "CAPACITACION") return res.status(400).json({ ok: false, error: "Este contenido no es una capacitación" }); const status = String(req.body && req.body.status || "EN_PROGRESO").toUpperCase(); const docId = `${req.authUser.id}__${req.params.id}`; await db.collection(KNOWLEDGE_PROGRESS_COLLECTION).doc(docId).set({ userId: req.authUser.id, userEmail: req.authUser.email || "", articleId: req.params.id, status: ["NO_INICIADA", "EN_PROGRESO", "COMPLETADA"].includes(status) ? status : "EN_PROGRESO", completedAt: status === "COMPLETADA" ? new Date() : null, updatedAt: new Date() }, { merge: true }); res.json({ ok: true }); } catch (error) { console.error(error); res.status(500).json({ ok: false, error: "Error guardando progreso" }); }
});


// =====================================================
// BLOQUE 6G - ENTRYPOINT CLOUD RUN
// =====================================================

functions.http("helloHttp", app);